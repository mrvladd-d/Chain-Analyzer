

---

# Page 1

# Annual Report 2022

---

# Page 3

Dear shareholders, colleagues, customers, and partners:

We are living through a period of historic economic, societal, and geopolitical change. The world in 2022 looks nothing like the world in 2019. As I write this, inflation is at a 40-year high, supply chains are stretched, and the war in Ukraine is ongoing.  At  the  same  time,  we  are  entering  a  technological  era  with  the  potential  to  power  awesome  advancements across every sector of our economy and society. As the world's largest software company, this places us at a historic intersection of opportunity and responsibility to the world around us.

Our mission to empower every person and every organization on the planet to achieve more has never been more urgent  or  more  necessary.  For  all  the  uncertainty  in  the  world,  one  thing  is  clear:  People  and  organizations  in  every industry  are  increasingly  looking  to  digital  technology  to  overcome  today's  challenges  and  emerge  stronger.  And  no company is better positioned to help them than Microsoft.

Every day this past fiscal year I have had the privilege to witness our customers use our platforms and tools to connect what technology can do with what the world needs it to do.


## Here are just a few examples:


- · Ferrovial, which builds and manages some of the world's busiest airports and highways, is using our cloud infrastructure to build safer roads as it prepares for a future of autonomous transportation.
- · Peace Parks Foundation, a nonprofit helping protect natural ecosystems in Southern Africa, is using Microsoft Dynamics 365 and Power BI to secure essential funding, as well as our Azure AI and IoT solutions to help rangers scale their park maintenance and wildlife crime prevention work.
- · One of the world's largest robotics companies, Kawasaki Heavy Industries, is using the breadth of our toolsfrom Azure IoT and HoloLens-to create an industrial metaverse solution that brings its distributed workforce together with its network of connected equipment to improve productivity and keep employees safe.
- · Globo, the biggest media and TV company in Brazil, is using Power Platform to empower its employees to build their own solutions for everything from booking sets to setting schedules.
- · And  Ørsted,  which  produces  a  quarter  of  the  world's  wind  energy,  is  using  the  Microsoft  Intelligent  Data Platform to turn data from its offshore turbines into insights for predictive maintenance.


Amid this dynamic environment, we delivered record results in fiscal year 2022: We reported $198 billion in revenue and $83 billion in operating income. And the Microsoft Cloud surpassed $100 billion in annualized revenue for the first time.


## OUR RESPONSIBILITY

As a corporation, our purpose and actions must be aligned with addressing the world's problems, not creating new ones. At our very core, we need to deliver innovation that helps drive broad economic growth. We, as a company, will do well when the world around us does well.

That's what I believe will lead to widespread human progress and ultimately improve the lives of everyone. There is no more powerful input than digital technology to drive the world's economic output. This is the core thesis for our being as a company, but it's not enough. As we drive global economic growth, we must also commit to creating a more inclusive, equitable, sustainable, and trusted future.


## Support inclusive economic growth

We  must  ensure  the  growth  we  drive  reaches  every  person,  organization,  community,  and  country.  This  starts  with increasing access to digital skills. This year alone, more than 23 million people accessed digital skills training as part of our global skills initiative.

---

# Page 4

But  skills  alone  aren't  enough-we  need  to  help  people  better  prepare  for  and  connect  to  jobs.  That's  why  we've committed to equip 10 million people from underserved communities with skills for jobs in the digital economy by 2025.

One  area  of  digital  skills  has  become  especially  critical:  cybersecurity.  Cybersecurity  is  a  significant  threat  for governments,  businesses,  and  individuals  around  the  world,  yet  there  simply  aren't  enough  people  with  cybersecurity skills to fill open jobs.

To help address this, we've committed to skill and recruit 250,000 people into the US cybersecurity workforce by 2025especially those underrepresented in the field. And we're helping an additional 24 countries with substantial cybersecurity workforce shortages close their gaps too.

We also continue to deliver affordable, relevant cloud technology and industry-specific solutions to nonprofit organizations addressing the world's most pressing issues. This year, we provided $3.2 billion in donated and discounted technology to 302,000  nonprofits  serving  over  1.2 billion  people  globally.  And  earlier  this  month,  we  announced  that  Microsoft  will double the number of nonprofits we reach worldwide over the next five years.


## Protect fundamental rights

We unequivocally support the fundamental rights of people, from defending democracy, to protecting human rights, to addressing racial injustice and inequity. And, as people's access to education, healthcare, jobs, and other critical services becomes increasingly dependent on technology, it's clear that access to broadband and accessible technology is also fundamental to building a more equitable future.

Since 2017, we've helped more than 50 million people in unserved rural communities globally gain access to affordable broadband coverage. Building on our work in eight US cities, we're now partnering with five US states with significant broadband  adoption  gaps  to  increase  access,  adoption,  and  equity.  And-given  the  importance  of  current  data  to broadband planning-the  new  Microsoft  Digital  Equity  Dashboard  will  help  US  policymakers  and  communities  identify neighborhoods where funding and programmatic investment can achieve measurable impact.

This year, we continued our journey to address racial injustice and inequity by increasing representation within Microsoft, engaging our ecosystem, and strengthening our communities.

Across our ecosystem, we are more than 90% of the way toward our commitment to spend an incremental $500 million with Black- and African American-owned suppliers. We've coordinated over 80 justice reform partnerships to help 145 communities expand access to data-driven insights that advance a more equitable system of justice and public safety. And we've expanded our Technology Education and Learning Support (TEALS) program to 290 high schools in cities with large Black and African American communities-to promote more equitable access to computer science education.

Our  work  to  help  preserve,  protect,  and  advance  democracy  by  promoting  a  healthy  information  ecosystem  and safeguarding  electoral  processes  is  as  salient  as  ever  in  today's  geopolitical  climate.  Our  AccountGuard  nation-state threat  notification  service  protects  more  than  4 million  accounts  of  election  officials,  human  rights  organizations, journalists, and other organizations. Our efforts to preserve and protect journalism in the United States and Mexico have been  extended  globally  through  new  partnerships  with  the  Thomson  Reuters  Foundation,  Report  for  the  World,  and others.

This year, we responded to six humanitarian emergencies in five countries through donations, technology, services, and employee  giving.  As  of  July  2022,  we've  committed  $257 million  in  financial  and  technology  assistance  to  the  global response to the war in Ukraine, including support for government, businesses, nonprofits, and humanitarian assistance for refugees. And, through our AI for Humanitarian Action initiative, we're helping organizations harness the power of AI to improve their disaster preparedness, response, and recovery.

Finally, we continued working toward our five-year commitment to bridge the disability divide for the more than 1 billion people around the world with disabilities, seeking to expand accessibility in technology, the workforce, and

---

# Page 5

workplace. As just one example of this work, use of our Office Accessibility Checker-our -spell check‖ for accessibilityhas  grown  by  9x  over  the  past  year.  And,  along  with  partner  companies,  we  launched  the  Neurodiversity  Career Connector, a jobs marketplace for neurodivergent job seekers.


# Create a sustainable future

We must ensure that economic growth does not come at the expense of our planet. Addressing climate change requires swift,  collective  action  and  technical  innovation.  We're  continuing  our  pursuit  of  our  own  ambitious  commitments  and helping others achieve their climate goals, aided by technology.

In  March,  we  released  our  second  annual  sustainability  report,  sharing  our  progress,  challenges,  and  learnings  as  we pursue our commitments to become carbon negative, water positive, and zero waste. Although we continued to make progress on several of our goals with an overall reduction in Scope 1 and Scope 2 emissions, our Scope 3 emissions increased, due in large part to significant global datacenter expansions and the growth in Xbox sales and usage. Despite these increases, we remain dedicated to achieving a net-zero future. We recognize that progress won't always be linear, and the rate at which we can implement emissions reductions is dependent on many factors that can fluctuate over time.

On the path to becoming water positive, we invested in 21 water replenishment projects that are expected to generate over 1.3 million cubic meters of volumetric benefits in nine water basins around the world. Progress toward our zero waste commitment included diverting more than 15,200 metric tons of solid waste otherwise headed to landfills and incinerators, as well as launching new Circular Centers to increase reuse and reduce e-waste at our datacenters.

We contracted to protect over  17,000  acres  of  land  (50%  more  than  the  land  we  use  to  operate),  thus  achieving  our commitment to protect more land than we use by 2025.

And  with  Microsoft  Cloud  for  Sustainability,  we're  expanding  our  work  to  help  customers  meet  their  ambitious sustainability goals by enabling them to better collect, track, and analyze the metrics of their sustainability strategy.


## Earn trust

To drive positive impact and growth with technology, people need to be able to trust the technologies they use and the companies behind them. We are committed to earning trust-both trust in business model alignment with our customers and  partners,  and  trust  in  technology,  spanning  privacy,  security,  digital  safety,  the  responsible  use  of  AI,  and transparency.

We're dedicated to preserving our customers' privacy and their ability to control their own data. We advocate for strong privacy  laws  that  require  companies,  including  ours,  to  be  accountable  and  responsible  in  their  collection  and  use  of personal  data.  That's  why  we  supported  the  new  Trans-Atlantic  Data  Privacy  Framework  and  committed  to  meet  or exceed all the requirements it outlines. And through the Microsoft privacy dashboard, millions of people each year can make meaningful choices about how their data is used.

Security and digital safety are foundational to trust in today's complex threat landscape. We analyze 43 trillion security signals daily and use the insights to inform increased protections. This year, we blocked 34.7 billion identity threats and 37 billion  email  threats.  Over  the  past  four  years,  we've  sent  over  67,000  nation-state-related  threat  notifications  to customers to help them protect themselves from digital threats.

This comprehensive capability has been critical during recent world events, including the war in Ukraine. Our efforts have involved  both  defending  key  infrastructure  in  the  country-including  assisting  with  the  detection  and  disruption  of cyberattacks and  cyberinfluence operations and  evacuating  data  to the cloud-as  well  as  supporting  people, communities, and organizations on the ground as part of our humanitarian and disaster response.

---

# Page 6

Our commitment to responsibly develop and use technologies like AI is core to who we are. We put our commitment into practice, not only within Microsoft but by empowering our customers and partners to do the same and by advocating for policy change. We released our Responsible AI Standard, which outlines 17 goals aligned to our six AI principles and includes  tools  and  practices  to  support  them.  And  we  share  our  open-source  tools,  including  the  new  Responsible  AI Dashboard, to help developers building AI technologies identify and mitigate issues before deployment.

Finally,  we provide clear reporting and information on how we run our business and how we work with customers and partners, delivering the transparency that is central to trust. Our annual Impact Summary shares more about our progress and learnings across these four commitments, and our Reports Hub provides detailed reports on our environmental data, our political activities, our workforce demographics, our human rights work, and more.

We should all be proud of this work-and I am. But it's easy to talk about what we're doing well. As we look to the next year and beyond, we'll continue to reflect on where the world needs us to do better.


## OUR OPPORTUNITY

Now, let me turn to how we are positioned to capture the massive opportunities ahead. Over the past few years, I've written extensively about digital transformation, but now we need to go beyond that to deliver on what I call the -digital imperative.‖

Technology  is  a  deflationary  force  in  an  inflationary  economy.  Every  organization  in  every  industry  will  need  to  infuse technology  into  every  business  process  and  function  so  they  can  do  more  with  less.  It's  what  I  believe  will  make  the difference between organizations that thrive and those that get left behind.

In the coming years, technology as a percentage of GDP will double from 5% to 10% and beyond, as technology moves from  a  back-office  cost  center  to  a  defining  feature  of  every  product  and  service.  But  even  more  important  will  be technology's  influence  on  the  other  90%  of  the  world's  economy.  From  communications  and  commerce,  to  logistics, financial services, energy, healthcare, and entertainment, digital technology will power the entire global economy as every company becomes a software company in its own right.

Across our customer solution areas, we are delivering powerful platforms, tools, and services that expand our opportunity to help every organization in every industry deliver on the digital imperative-with a business model that is trusted and always aligned with their success.


## Apps and infrastructure

We are building Azure as the world's computer, with more than 60 datacenter regions-more than any other providerdelivering faster access to cloud services while addressing critical data residency requirements. With Azure Arc, we're bringing Azure anywhere, meeting customers where they are and enabling them to run apps across on-premises, edge, or multicloud  environments.  And  we're  extending  our  infrastructure  to  the  5G  network  edge  with  Azure  for  Operators, introducing new solutions to help telecom operators deliver ultra-low-latency services closer to end users.

As the digital and physical worlds come together, we're also leading in the industrial metaverse. From smart factories, to smart buildings, to smart cities, we're helping organizations use Azure IoT, Azure Digital Twins, and Microsoft Mesh to digitize people, places, and things, in order to visualize, simulate, and analyze any business process.


## Data and AI

From best-in-class databases and analytics to data  governance, we have the most comprehensive data stack to help every organization turn its data into predictive and analytical power. With our new Microsoft Intelligent Data

---

# Page 7

Platform, we are helping customers focus on creating value instead of integrating a fragmented data estate. Cosmos DB is  the  go-to  database  powering  the  world's  most  demanding,  mission-critical  workloads,  at  any  scale.  With  Azure Synapse, we're removing traditional barriers between enterprise data warehousing and big data analytics so anyone can collaborate,  build,  and  manage  analytics  solutions.  And  we're  creating  an  entirely  new  market  category  with  Microsoft Purview, as we help organizations govern, protect, and manage their data estate across platforms and clouds.

When it comes to AI, we're seeing a paradigm shift as the world's large AI models become platforms themselves. And we are helping organizations apply the world's most advanced coding and language models to a variety of use cases, such as writing assistance, code generation, and reasoning over data with our new Azure OpenAI Service.


# Digital and app innovation

We have the most popular developer tools for any cloud and any platform to help organizations modernize existing apps and build new ones. GitHub is the most complete developer platform to build, scale, and deliver secure software. This year, we introduced GitHub Copilot, a first-of-its-kind AI pair programmer, to help developers write better code faster. And organizations are increasingly turning to both Visual Studio and our Azure PaaS services to streamline development and create modern, more resilient cloud-native applications.

Low-code/no-code tools are rapidly becoming a priority for every organization's digital capability. With Power Platform, we are  helping  domain  experts  rapidly  drive  productivity  gains  when  it's  never  been  more  important.  We  have  nearly 25 million  monthly  active  users.  And  we're  innovating  to  make  it  even  easier  for  teams  of  professional  and  citizen developers to automate workflows, create apps, build virtual agents, and analyze data.


## Business applications

With  our  expanding  portfolio  of  business  applications,  we  are  helping  every  business  become  a  hyperconnected business-unifying  data,  process,  and  teams  across  the  organization.  New  Dynamics  365  Connected  Spaces  helps organizations across diverse industries-from real estate and retail, to factories and construction-manage their physical operations.  And  with  new  integrations  between  Dynamics  365  and  Teams,  we  are  creating  a  new  category  of collaborative applications that helps businesses surface data and insights right in the flow of work.

Our industry clouds bring together capabilities across the Microsoft Cloud  with industry-specific customizations to help organizations  improve  time  to  value,  increase  agility,  and  lower  costs.  We  completed  our  acquisition  of  Nuance Communications this year, adding new cloud and enterprise AI capabilities for healthcare, as well as other industries. And as sustainability becomes an existential priority not just for our society but for every organization, our new Microsoft Cloud for  Sustainability,  which  I  mentioned  earlier,  is  helping  our  customers  record,  report,  and  ultimately  reduce  their environmental impact.


## Modern work

Hybrid  work is  now just  work.  Every  organization  is  looking  to  reconnect  and  reengage  the  workforce  at  home,  in  the office, and everywhere in between. Microsoft Teams is the most used and most advanced platform for work, surpassing 270 million  monthly  active  users  this  year.  It's  the  only  solution  with  meetings,  calls,  chat,  collaboration,  and  business process automation in one place.

Teams Rooms is bringing Teams to a growing ecosystem of devices to help organizations rethink their approach to space and help employees participate fully  in meetings from anywhere. And  with Microsoft Viva,  we're building  an employee experience platform that brings together communications, knowledge, learning, resources, and insights in the flow of work to empower employees and strengthen their connection to their company's mission and culture.

---

# Page 8

# Modern life

The PC has never been more relevant to work, life, and play. This year, we launched Windows 11, the biggest update to our  operating  system  in  a  decade.  It  reimagines  everything  from  the  user  experience  to  the  store  to  help  people  and organizations  be  more  productive,  connected,  and  secure,  and  to  build  a  more  open  ecosystem  for  developers  and creators. There are now more than 1.4 billion monthly active devices running Windows 10 or Windows 11. We launched new Surface devices to support every  person and  work style.  And  we  have  nearly  60 million  Microsoft  365 consumer subscriptions as we help people create, connect, and share wherever they go.


## Security

Cybersecurity is the number one threat facing every business today. To keep our customers secure, we build security by design  into  every  product  we  sell,  and  we  deliver  end-to-end  solutions  spanning  security,  compliance,  identity,  device management, and privacy across clouds and platforms. We are the only cloud provider with multicloud protection for the industry's top three cloud platforms. Our new Entra product family includes tools for permissions management, identity governance, and identity verification. And we now offer managed threat detection and response with Microsoft Security Experts.


## LinkedIn

LinkedIn  has  become  mission  critical  to  connect  creators  with  their  communities,  job  seekers  with  jobs,  learners  with skills, and marketers with buyers. LinkedIn now has more than 850 million members, and our Sales, Talent, Marketing, and Premium Subscriptions lines of business have all surpassed $1 billion in annual revenue over the past 12 months.


## Search, advertising, and news

When  it  comes  to  advertising,  we  are  creating  a  new  monetization  engine  for  the  web-an  alternative  that  offers marketers  and  publishers  more  long-term  viable  ad  solutions-while  upholding  consumer  privacy  and  strong  data governance. We're focused on increasing our share and engagement across our browser Microsoft Edge, our search engine Microsoft Bing, and our personalized content feed Microsoft Start.

And with our acquisition of Xandr, we now power one of the largest marketplaces for premium advertising. Netflix chose us this summer as its exclusive technology and sales partner for its first ad-supported subscription offering, a validation of the differentiated value we provide to publishers looking for a flexible partner to build and innovate with them. I couldn't be more excited about our expansive opportunity ahead in this space.


## Gaming

The big bets we have made across content, community, and cloud over the past few years continue to pay off. We've sold more  Xbox  Series  S  and  Series  X  consoles  life-to-date  than  any  previous  generation  of  Xbox,  and  with  Xbox  Cloud Gaming, we're bringing games to entirely new endpoints. In the past year, we've made many of our most popular titles accessible on phones, tablets, TVs, and low-spec PCs for the first time. Our Xbox Game Pass subscription service now includes access to hundreds of games. And with our planned acquisition of Activision Blizzard, we aim to give players more choice to play great games wherever, whenever, and however they want. Choice is equally important to developers, who we want to support with a diversity of distribution and business models for their games. We believe the acquisition will unlock opportunities for innovation and enable the industry to grow.


## OUR CULTURE

Our culture is the foundation on which our mission and strategy stand, and cultivating it is our greatest priority. We're always working to close the gap between our espoused culture and the lived experience of the more than

---

# Page 9

220,000 people who work at Microsoft. Essential to this is our commitment to continually exercise our growth mindset and confront our fixed mindset with  humility, curiosity,  compassion, and the recognition  that,  while none  of  us  will  ever  be perfect, we can always be better than we are today.

This growth mindset served us well through the historic changes of the past few years. It sustains our everyday practice of customer  obsession.  It  helps  us  care  for  our  colleagues  and  collaborate  more  effectively  across  the  company.  And  it deeply informs our longstanding commitment to diversity and inclusion .

If we want to serve the world, we need to represent the world. Each year we strive to increase representation, and 2022 was no exception. We saw the strongest progress in years across several demographic groups, as you can see in our latest Diversity & Inclusion Report. We are one of the most transparent companies of our size when it comes to the data we share, and we continually challenge ourselves to increase visibility into where we're succeeding and where we need to address gaps. We've added new data, such as military status, gender representation by geography, employee exits, and additional pay data, to reflect our workforce more broadly. As we make meaningful progress, we continue our commitment to meet the increasing expectations for driving innovation, welcoming diverse perspectives, and leading global change.

Giving is also core to our culture at Microsoft. In 2022, our employees gave $255 million (with company match) to over 32,000 nonprofits. And more than 29,000 employees volunteered over 720,000 hours to causes they care about.

I'm constantly in awe of how our employees bring their passion to work each day-for each other, for our customers, and for their communities.

***

I want to close by thanking you for your continued investment in Microsoft. Our growth and impact this past year would not have been possible without your commitment to the company and belief in its mission.

The opportunity  to  apply  technology  to  make  a  real  difference  for  every  customer,  community,  and  country  has  never been greater. And I truly believe if we continue to live our mission, embrace our responsibility, and grasp that opportunity, there is no limit to what we can achieve for the world in the year ahead and beyond.

Satya Nadella Chairman and Chief Executive Officer October 24, 2022

---

# Page 10

# FINANCIAL REVIEW


## ISSUER PURCHASES OF EQUITY SECURITIES, DIVIDENDS, AND STOCK PERFORMANCE


## MARKET AND STOCKHOLDERS

Our common stock is traded on the NASDAQ Stock Market under the symbol MSFT. On July 25, 2022, there were 86,465 registered holders of record of our common stock.


## SHARE REPURCHASES AND DIVIDENDS


## Share Repurchases

On September 20, 2016, our Board of Directors approved a share repurchase program authorizing up to $40.0 billion in share repurchases. This share repurchase program commenced in December 2016 and was completed in February 2020.

On September 18, 2019, our Board of Directors approved a share repurchase program authorizing up to $40.0 billion in share repurchases. This share repurchase program commenced in February 2020 and was completed in November 2021.

On September 14, 2021, our Board of Directors approved a share repurchase program authorizing up to $60.0 billion in share repurchases. This share repurchase program commenced in November 2021, following completion of the program approved  on  September 18,  2019,  has  no  expiration  date,  and  may  be  terminated  at  any  time.  As  of  June 30,  2022, $40.7 billion remained of this $60.0 billion share repurchase program.


We repurchased the following shares of common stock under the share repurchase programs:
| (In millions)       | Shares   | Amount     | Shares   | Amount    | Shares   | Amount      |
|---------------------|----------|------------|----------|-----------|----------|-------------|
| Year Ended June 30, |          | 2022       |          | 2021      |          | 2020        |
| First Quarter       | 21       | $ 6,200    | 25       | $  5,270  | 29       | $  4,000    |
| Second Quarter      | 20       | 6,233      | 27       | 5,750     | 32       | 4,600       |
| Third Quarter       | 26       | 7,800      | 25       | 5,750     | 37       | 6,000       |
| Fourth Quarter      | 28       | 7,800      | 24       | 6,200     | 28       | 5,088       |
| Total               | 95       | $   28,033 | 101      | $  22,970 | 126      | $    19,688 |


All repurchases were made using cash resources. Shares repurchased during the fourth and third quarters of fiscal year 2022  were  under  the  share  repurchase  program  approved  on  September 14,  2021.  Shares  repurchased  during  the second quarter of fiscal year 2022 were under the share repurchase programs approved on both September 14, 2021 and September 18, 2019.  Shares repurchased  during the first  quarter  of  fiscal  year  2022,  fiscal  year  2021,  and  the  fourth quarter  of  fiscal  year  2020  were  under  the  share  repurchase  program  approved  on  September 18,  2019.  Shares repurchased during the third quarter of fiscal year 2020 were under the share repurchase programs approved on both September 20, 2016 and September 18, 2019. All other shares repurchased were under the share repurchase program approved  on  September 20,  2016.  The  above  table  excludes  shares  repurchased  to  settle  employee  tax  withholding related to the vesting of stock awards of $4.7 billion, $4.4 billion, and $3.3 billion for fiscal years 2022, 2021, and 2020, respectively.

---

# Page 11

# Dividends


Our Board of Directors declared the following dividends:
| Declaration Date   | Record Date       | Payment Date      | Dividend Per Share   | Amount        |
|--------------------|-------------------|-------------------|----------------------|---------------|
| Fiscal Year 2022   |                   |                   |                      | (In millions) |
| September 14, 2021 | November 18, 2021 | December 9, 2021  | $   0.62             | $ 4,652       |
| December 7, 2021   | February 17, 2022 | March 10, 2022    | 0.62                 | 4,645         |
| March 14, 2022     | May 19, 2022      | June 9, 2022      | 0.62                 | 4,632         |
| June 14, 2022      | August 18, 2022   | September 8, 2022 | 0.62                 | 4,627         |
| Total              |                   |                   | $   2.48             | $   18,556    |
| Fiscal Year 2021   |                   |                   |                      |               |
| September 15, 2020 | November 19, 2020 | December 10, 2020 | $  0.56              | $  4,230      |
| December 2, 2020   | February 18, 2021 | March 11, 2021    | 0.56                 | 4,221         |
| March 16, 2021     | May 20, 2021      | June 10, 2021     | 0.56                 | 4,214         |
| June 16, 2021      | August 19, 2021   | September 9, 2021 | 0.56                 | 4,206         |
| Total              |                   |                   | $  2.24              | $  16,871     |


The dividend declared on June 14, 2022 was included in other current liabilities as of June 30, 2022.

---

# Page 12

# STOCK PERFORMANCE


## COMPARISON OF 5 YEAR CUMULATIVE TOTAL RETURN*

Among Microsoft Corporation, the S&P 500 Index and the NASDAQ Computer Index


|                       |   6/17 |   6/18 |   6/19 |   6/20 |   6/21 |   6/22 |
|-----------------------|--------|--------|--------|--------|--------|--------|
| Microsoft Corporation |    100 | 145.84 | 201.36 | 309.69 | 416.25 | 397.9  |
| S&P 500               |    100 | 114.37 | 126.29 | 135.77 | 191.15 | 170.86 |
| NASDAQ Computer       |    100 | 131.27 | 139.29 | 196.4  | 288.13 | 228.71 |



- * $100 invested on 6/30/17 in stock or index, including reinvestment of dividends. Fiscal year ending June 30.

---

# Page 13

# Note About Forward-Looking Statements

This report includes estimates, projections, statements relating to our business plans, objectives, and expected operating results that are -forward-looking statements‖ within the meaning of the Private Securities Litigation Reform Act of 1995, Section 27A  of  the  Securities  Act  of  1933,  and  Section 21E  of  the  Securities  Exchange  Act  of  1934.  Forward-looking statements may appear throughout this report, including the following sections: -Business‖ in our fiscal year 2022 Form 10-K and -Management's Discussion and Analysis of Financial Condition and Results of Operations‖ in our fiscal year 2022 Form 10-K. These forward-looking statements generally are identified by  the  words  -believe,‖  -project,‖  -expect,‖ -anticipate,‖  -estimate,‖  -intend,‖  -strategy,‖  -future,‖  -opportunity,‖  -plan,‖  -may,‖  -should,‖  -will,‖  -would,‖  -will  be,‖  -will continue,‖ -will likely result,‖ and similar expressions. Forward-looking statements are based on current expectations and assumptions that are subject to risks and uncertainties that may cause actual results to differ materially. We describe risks and  uncertainties  that  could  cause  actual  results  and  events  to  differ  materially  in  -Risk  Factors,‖  -Management's Discussion and Analysis of Financial Condition and Results of Operations,‖ and -Quantitative and Qualitative Disclosures about Market Risk" in our fiscal year 2022 Form 10-K. Readers are cautioned not to place undue reliance on forwardlooking  statements,  which  speak  only  as  of  the  date  they  are  made.  We  undertake  no  obligation  to  update  or  revise publicly any forward-looking statements, whether because of new information, future events, or otherwise.


## BUSINESS


## GENERAL


## Embracing Our Future

Microsoft is a technology company whose mission is to empower every person and every organization on the planet to achieve more. We strive to create local opportunity, growth, and impact in every country around the world. Our platforms and  tools  help  drive  small  business  productivity,  large  business  competitiveness,  and  public-sector  efficiency.  We  are creating the tools and platforms that deliver better, faster, and more effective solutions to support new startups, improve educational and health outcomes, and empower human ingenuity.

Microsoft is innovating and expanding our entire portfolio to help people and organizations overcome today's challenges and emerge stronger. We bring technology and products together into experiences and solutions that unlock value for our customers.

In a dynamic environment, digital technology is the key input that powers the world's economic output. Our ecosystem of customers and partners have learned that while hybrid work is complex, embracing flexibility, different work styles, and a culture of trust can help navigate the challenges the world faces today. Organizations of all sizes have digitized businesscritical functions, redefining what they can expect from their business applications. Customers are looking to unlock value while simplifying security and management. From infrastructure and data, to business applications and collaboration, we provide unique, differentiated value to customers.

We are building a distributed computing fabric - across cloud and the edge - to help every organization build, run, and manage mission-critical workloads anywhere. In the next phase of innovation, artificial intelligence (-AI‖) capabilities are rapidly advancing, fueled by data and knowledge of the world. We are enabling metaverse experiences at all layers of our stack,  so  customers  can  more  effectively  model,  automate,  simulate,  and  predict  changes  within  their  industrial environments, feel a greater sense of presence in the new world of hybrid work, and create custom immersive worlds to enable new opportunities for connection and experimentation.


## What We Offer

Founded in 1975, we develop and support software, services, devices, and solutions that deliver new value for customers and help people and businesses realize their full potential.

---

# Page 14

We offer an array of services, including cloud-based solutions that provide customers with software, services, platforms, and content, and we provide solution support and consulting services. We also deliver relevant online advertising to a global audience.

Our  products  include  operating  systems,  cross-device  productivity  and  collaboration  applications,  server  applications, business solution applications, desktop and server management tools, software development tools, and video games. We also design and sell devices, including PCs, tablets, gaming and entertainment consoles, other intelligent devices, and related accessories.


# The Ambitions That Drive Us


To achieve our vision, our research and development efforts focus on three interconnected ambitions:
- · Reinvent productivity and business processes.
- · Build the intelligent cloud and intelligent edge platform.
- · Create more personal computing.



## Reinvent Productivity and Business Processes

At Microsoft, we provide technology and resources to help our customers create a secure hybrid work environment. Our family of products plays a key role in the ways the world works, learns, and connects.

Our  growth  depends  on  securely  delivering  continuous  innovation  and  advancing  our  leading  productivity  and collaboration tools and services, including Office 365, Dynamics 365, and LinkedIn. Microsoft 365 brings together Office 365, Windows, and Enterprise Mobility + Security to help organizations empower  their employees with AI-backed tools that  unlock creativity,  increase collaboration,  and fuel innovation,  all the  while enabling compliance coverage and data protection. Microsoft Teams is a comprehensive platform for work, with meetings, calls, chat, collaboration, and business process automation. Microsoft Viva is an employee experience platform that brings together communications, knowledge, learning, resources, and insights powered by Microsoft 365. Together with the Microsoft Cloud, Dynamics 365, Microsoft Teams,  and  Azure  Synapse  bring  a  new  era  of  collaborative  applications  that  transform  every  business  function  and process. Microsoft Power Platform is helping domain experts drive productivity gains with low-code/no-code tools, robotic process  automation,  virtual agents,  and  business  intelligence. In a dynamic  labor  market,  LinkedIn  is  helping professionals use the platform to connect, learn, grow, and get hired.


## Build the Intelligent Cloud and Intelligent Edge Platform

As digital transformation accelerates, organizations in every sector across the globe can address challenges that will have a fundamental impact on their success. For enterprises, digital technology empowers employees, optimizes operations, engages customers, and in some cases, changes the very core of products and services. Microsoft has a proven track record of delivering high value to our customers across many diverse and durable growth markets.

We continue to invest in high performance and sustainable computing to meet the growing  demand for fast access to Microsoft services provided by our network of cloud computing infrastructure and datacenters. Azure is a trusted cloud with comprehensive compliance coverage and AI-based security built in.

Our  cloud  business  benefits  from  three  economies  of  scale:  datacenters  that  deploy  computational  resources  at significantly  lower  cost  per  unit  than  smaller  ones;  datacenters  that  coordinate  and  aggregate  diverse  customer, geographic, and application demand patterns, improving the utilization of computing, storage, and network resources; and multi-tenancy locations that lower application maintenance labor costs.

---

# Page 15

The Microsoft Cloud is the most comprehensive and trusted cloud, providing the best integration across the technology stack while offering openness, improving time to value, reducing costs, and increasing agility. Being a global-scale cloud, Azure uniquely offers hybrid consistency, developer productivity, AI capabilities, and trusted security and compliance. We see more emerging use cases and needs for compute and security at the edge and are accelerating our innovation across the spectrum of intelligent edge devices, from Internet of Things (-IoT‖) sensors to gateway devices and edge hardware to build, manage, and secure edge workloads. With Azure Stack, organizations can extend Azure into their own datacenters to create a consistent stack across the public cloud and the intelligent edge.

Our hybrid infrastructure consistency spans security, compliance, identity, and management, helping to support the realworld needs and evolving regulatory requirements of commercial customers and enterprises. Our industry clouds bring together  capabilities  across  the  entire  Microsoft  Cloud,  along  with  industry-specific  customizations,  to  improve  time  to value,  increase  agility,  and  lower  costs.  Azure  Arc  simplifies  governance  and  management  by  delivering  a  consistent multi-cloud and on-premises management platform. Security, compliance, identity, and management underlie our entire tech stack. We offer integrated, end-to-end capabilities to protect people and organizations.

In  March  2022,  we  completed  our  acquisition  of  Nuance  Communications,  Inc.  (-Nuance‖).  Together,  Microsoft  and Nuance will enable organizations across industries to accelerate their business goals with security-focused, cloud-based solutions infused with powerful, vertically optimized AI.

We are accelerating our development of mixed reality solutions with new  Azure services and devices. Microsoft Mesh enables presence and shared experiences from anywhere through mixed reality applications. The opportunity to merge the  physical  and  digital  worlds,  when  combined  with  the  power  of  Azure  cloud  services,  unlocks  new  workloads  and experiences to create common understanding and drive more informed decisions.

The ability to convert data into AI drives our competitive advantage. Azure SQL Database makes it possible for customers to take SQL Server from their on-premises datacenter to a fully managed instance in the cloud to utilize built-in AI. Azure Synapse  brings  together  data  integration,  enterprise  data  warehousing,  and  big  data  analytics  in  a  comprehensive solution. We are accelerating adoption of AI innovations from research to products. Our innovation helps every developer be  an  AI  developer,  with  approachable  new  tools  from  Azure  Machine  Learning  Studio  for  creating  simple  machine learning  models,  to  the  powerful  Azure  Machine  Learning  Workbench  for  the  most  advanced  AI  modeling  and  data science.  From  GitHub  to  Visual  Studio,  we  provide  a  developer  tool  chain  for  everyone,  no  matter  the  technical experience, across all platforms, whether Azure, Windows, or any other cloud or client platform.

Additionally, we are extending our infrastructure beyond the planet, bringing cloud computing to space. Azure Orbital is a fully managed ground station as a service for fast downlinking of data.


## Create More Personal Computing

We strive to make computing more personal by putting people at the core of the experience, enabling them to interact with technology in more intuitive, engaging, and dynamic ways. Microsoft 365 is empowering people and organizations to be productive and secure as they adapt to more fluid ways of working, learning, and playing. Windows also plays a critical role in fueling our cloud business with Windows 365, a desktop operating system that's also a cloud service. From another internet-connected device, including Android or macOS devices, you can run Windows 365, just like a virtual machine.

With Windows 11, we have simplified the design and experience to empower productivity and inspire creativity. Windows 11 offers innovations focused on enhancing productivity and is designed to support hybrid work. It adds new experiences that include powerful task switching tools like new snap layouts, snap groups, and desktops; new ways to stay connected through Microsoft Teams chat; the information you want at your fingertips; and more. Windows 11 security and privacy features include operating system security, application security, and user and identity security.

---

# Page 16

Tools  like  search,  news,  and  maps  have  given  us  immediate  access  to  the  world's  information.  Today,  through  our Search,  News,  Mapping,  and  Browse  services,  Microsoft  delivers  unique  trust,  privacy,  and  safety  features.  Microsoft Edge is our fast and secure browser that helps protect your data, with built-in shopping tools designed to save you time and money. Organizational tools such as Collections, Vertical Tabs, and Immersive Reader help make the most of your time while browsing, streaming, searching, and sharing.

We are committed to designing and marketing first-party devices to help drive innovation, create new device categories, and stimulate demand in the Windows ecosystem. The Surface family includes Surface Laptop Studio, Surface Laptop 4, Surface Laptop Go 2, Surface Laptop Pro 8, Surface Pro X, Surface Go 3, Surface Studio 2, and Surface Duo 2.

With  three  billion  people  actively  playing  games  today,  and  a  new  generation  steeped  in  interactive  entertainment, Microsoft continues to invest in content, community, and cloud services. We have broadened our approach to how we think about gaming end-to-end, from the way games are created and distributed to how they are played, including cloud gaming so players can stream across PC, console, and mobile. We have a strong position with our large and growing highly engaged community of gamers, including the acquisition of ZeniMax Media Inc., the parent company of Bethesda Softworks LLC. In January 2022, we announced plans to acquire Activision Blizzard, Inc., a leader in game development and an interactive entertainment content publisher. Xbox Game Pass is a community with access to a curated library of over 100 first- and third-party console and PC titles. Xbox Cloud Gaming is Microsoft's game streaming technology that is complementary to our console hardware and gives fans the ultimate choice to play the games they want, with the people they want, on the devices they want.


## Our Future Opportunity


The case for digital transformation has never been more urgent. Customers are looking to us to help improve productivity and  the  affordability  of  their  products  and  services.  We  continue  to  develop  complete,  intelligent  solutions  for  our customers  that  empower  people  to  stay  productive  and  collaborate,  while  safeguarding  businesses  and  simplifying  IT management. Our goal is to lead the industry in several distinct areas of technology over the long term, which we expect will translate to sustained growth. We are investing significant resources in:
- · Transforming the workplace to deliver new modern, modular business applications, drive deeper insights, and improve how people communicate, collaborate, learn, work, play, and interact with one another.
- · Building  and  running  cloud-based  services  in  ways  that  unleash  new  experiences  and  opportunities  for businesses and individuals.
- · Applying AI to drive insights and act on our customer's behalf by understanding and interpreting their needs using natural methods of communication.
- · Tackling  security  from  all  angles  with  our  integrated,  end-to-end  solutions  spanning  security,  compliance, identity, and management, across all clouds and platforms.
- · Inventing  new  gaming  experiences  that  bring  people  together  around  their  shared  love  for  games  on  any devices and pushing the boundaries of innovation with console and PC gaming by creating the next wave of entertainment.
- · Using  Windows  to  fuel  our  cloud  business,  grow  our  share  of  the  PC  market,  and  drive  increased engagement  with  our  services  like  Microsoft  365  Consumer,  Teams,  Edge,  Bing,  Xbox  Game  Pass,  and more.


Our future growth depends on our ability to transcend current product category definitions, business models, and sales motions. We have the opportunity to redefine what customers and partners can expect and are working to deliver new solutions that reflect the best of Microsoft.

---

# Page 17

# Corporate Social Responsibility


## Commitment to Sustainability

We work to ensure that technology is inclusive, trusted, and increases sustainability. We are accelerating progress toward a  more  sustainable  future  by  reducing  our  environmental  footprint,  advancing  research,  helping  our  customers  build sustainable solutions, and advocating for policies that benefit the environment. In January 2020, we announced a bold commitment and detailed plan to be carbon negative by 2030, and to remove from the environment by 2050 all the carbon we  have  emitted  since  our  founding  in  1975.  This  included  a  commitment  to  invest  $1 billion  over  four  years  in  new technologies and innovative climate solutions. We built on this pledge by adding commitments to be water positive by 2030, zero waste by 2030, and to protect ecosystems by developing a Planetary Computer. We also help our suppliers and customers around the world use Microsoft technology to reduce their own carbon footprint.

Fiscal year 2021 was a year of both successes and challenges. While we continued to make progress on several of our goals, with an overall reduction in our combined Scope 1 and Scope 2 emissions, our Scope 3 emissions increased, due in  substantial  part  to  significant  global  datacenter  expansions  and  growth  in  Xbox  sales  and  usage  as  a  result  of  the COVID-19 pandemic. Despite these Scope 3 increases,  we  will  continue  to  build  the  foundations  and  do  the  work  to deliver on our commitments, and help our customers and partners achieve theirs. We have learned the impact of our work will not all be felt immediately, and our experience highlights how progress won't always be linear.


While fiscal year 2021 presented us with some new learnings, we also made some great progress. A few examples that illuminate the diversity of our work include:
- · We purchased the removal of 1.4 million metrics tons of carbon.
- · Four of our datacenters received new or renewed Zero Waste certifications.
- · We granted $100 million to Breakthrough Energy Catalyst to accelerate the development of climate solutions the world needs to reach net-zero across four key areas: direct air capture, green hydrogen, long duration energy storage, and sustainable aviation fuel.
- · We joined the First Movers Coalition as an early  leader and  expert partner  in the carbon dioxide removal sector, with a commitment of $200 million toward carbon removal by 2030.


Sustainability is an existential priority for our society and businesses today. This led us to create our Microsoft Cloud for Sustainability, an entirely new business process category to help organizations monitor their carbon footprint across their operations. We also joined with leading organizations to launch the Carbon Call - an initiative to mobilize collective action to solve carbon emissions and removal accounting challenges for a net zero future.

The investments we make in sustainability carry through to our products, services, and devices. We design our devices, from  Surface  to  Xbox,  to  minimize  their  impact  on  the  environment.  Our  cloud  and  AI  services  and  datacenters  help businesses cut energy consumption, reduce physical footprints, and design sustainable products.


## Addressing Racial Injustice and Inequity

We  are  committed  to  addressing  racial  injustice  and  inequity  in  the  United  States  for  Black  and  African  American communities and helping improve lived experiences at Microsoft, in employees' communities, and beyond. Our Racial Equity Initiative focuses on three multi-year pillars, each containing actions and progress we expect to make or exceed by 2025.


- · Strengthening our communities: using data, technology, and partnerships to help improve the lives of Black and African American people in the United States, including our employees and their communities.
- · Evolving  our  ecosystem:  using  our  balance  sheet  and  relationships  with  suppliers  and  partners  to  foster societal change and create new opportunities.

---

# Page 18

- · Increasing  representation  and  strengthening  inclusion:  build  on  our  momentum,  adding  a  $150 million investment to strengthen inclusion and double the number of Black, African American, Hispanic, and Latinx leaders in the United States by 2025.


Over the last year, we collaborated with partners and worked within neighborhoods and communities to launch and scale a number of projects and programs, including: working with 70 organizations in 145 communities on the Justice Reform Initiative, expanding access to affordable broadband and devices for Black and African American communities and key institutions  that  support  them  in  major  urban  centers,  expanding  access  to  skills  and  education  to  support  Black  and African American students and adults to succeed in the digital economy, and increasing technology support for nonprofits that provide critical services to Black and African American communities.

We have made meaningful progress on representation and inclusion at Microsoft. We are 90 percent of the way to our 2025 commitment to double the number of Black and African American people managers, senior individual contributors, and senior  leaders in the  U.S.,  and  50 percent  of  the  way  for  Hispanic  and  Latinx  people  managers,  senior  individual contributors, and senior leaders in the U.S.

We exceeded our goal on increasing the percentage of transaction  volumes with Black- and African American-owned financial institutions and increased our deposits with Black- and African American-owned minority depository institutions, enabling  increased  funds  into  local  communities.  Additionally,  we  enriched  our  supplier  pipeline,  reaching  more  than 90 percent of our goal to spend $500 million with double the number of Black and African American-owned suppliers. We also increased the number of identified partners in the Black Partner Growth Initiative and continue to invest in the partner community through the Black Channel Partner Alliance by supporting events focused on business growth, accelerators, and mentorship.

Progress does not undo the egregious injustices of the past or diminish those who continue to live with inequity. We are committed  to  leveraging  our  resources  to  help  accelerate  diversity  and  inclusion  across  our  ecosystem  and  to  hold ourselves accountable to accelerate change - for Microsoft, and beyond.


## Investing in Digital Skills

The COVID-19 pandemic led to record unemployment, disrupting livelihoods of people around the world. After helping over  30 million  people  in  249  countries  and  territories  with  our  global  skills  initiative,  we  introduced  a  new  initiative  to support a more skills-based labor market, with greater flexibility and accessible learning paths to develop the right skills needed for the most in-demand jobs. Our skills initiative brings together learning resources, certification opportunities, and job-seeker tools from LinkedIn, GitHub, and Microsoft Learn, and is built on data insights drawn from LinkedIn's Economic Graph. We previously invested $20 million in key non-profit partnerships through Microsoft Philanthropies to help people from underserved communities that are often excluded by the digital economy.

We  also  launched  a  national  campaign  with  U.S.  community  colleges  to  help  skill  and  recruit  into  the  cybersecurity workforce 250,000 people by 2025, representing half of the country's workforce shortage. To that end, we are making curriculum available free of charge to all of the nation's public community colleges, providing training for new and existing faculty at 150 community colleges, and providing scholarships and supplemental resources to 25,000 students.


## HUMAN CAPITAL RESOURCES


## Overview

Microsoft aims to recruit, develop, and retain world-changing talent from a diversity of backgrounds. To foster their and our success, we seek to create an environment where people can thrive, where they can do their best work, where they can proudly be their authentic selves, guided by our values, and where they know their needs can be met. We strive to maximize  the  potential  of  our  human  capital  resources  by  creating  a  respectful,  rewarding,  and  inclusive  work environment that enables our global employees to create products and services that further our mission to empower every person and every organization on the planet to achieve more.

---

# Page 19

As of June 30, 2022, we employed approximately 221,000 people on a full-time basis, 122,000 in the U.S. and 99,000 internationally.  Of  the  total  employed  people,  85,000  were  in  operations,  including  manufacturing,  distribution,  product support, and consulting services; 73,000 were in product research and development; 47,000 were in sales and marketing; and 16,000 were in general and administration. Certain employees are subject to collective bargaining agreements.


# Our Culture


Microsoft's culture is grounded in the growth mindset. This means everyone is on a continuous journey to learn and grow. We believe potential can be nurtured and is not pre-determined, and we should always be learning and curious - trying new things without fear of failure. We identified four attributes that allow growth mindset to flourish:
- · Obsessing over what matters to our customers.
- · Becoming more diverse and inclusive in everything we do.
- · Operating as one company, One Microsoft, instead of multiple siloed businesses.
- · Making a difference in the lives of each other, our customers, and the world around us.


Our employee listening systems enable us to gather feedback directly from our workforce to inform our programs and employee needs globally. Seventy percent of employees globally participated in our fiscal year 2022 Employee Signals survey,  which  covers  a  variety  of  topics  such  as  thriving,  inclusion,  team  culture,  wellbeing,  and  learning  and development. Throughout the fiscal year, we collect over 75,000 Daily Pulse employee survey responses. During fiscal year  2022,  our  Daily  Pulse  surveys  gave  us  invaluable  insights  into  ways  we  could  support  employees  through  the COVID-19 pandemic, addressing racial injustice, the war in Ukraine, and their general wellbeing. In addition to Employee Signals  and  Daily  Pulse  surveys,  we  gain  insights  through  onboarding,  internal  mobility,  leadership,  performance  and development, exit surveys, internal Yammer channels, employee Q&A sessions, and AskHR Service support.


## Diversity and Inclusion

At Microsoft we have an inherently inclusive mission: to empower every person and every organization on the planet to achieve  more.  We  think  of  diversity  and  inclusion  as  core  to  our  business  model,  informing  our  actions  to  impact economies and people around the world. There are billions of people who want to achieve more, but have a different set of  circumstances,  abilities,  and  backgrounds  that  often  limit  access  to  opportunity  and  achievement.  The  better  we represent that diversity inside Microsoft, the more effectively we can innovate for those we seek to empower.


We strive to include others by holding ourselves accountable for diversity, driving global systemic change in our workplace and workforce, and creating an inclusive work environment. Through this commitment we can allow everyone the chance to  be  their  authentic  selves  and  do  their  best  work  every  day.  We  support  multiple  highly  active  Employee  Resource Groups for women, families, racial and ethnic minorities, military, people with disabilities, and employees who identify as LGBTQIA+, where employees can go for support, networking, and community-building. As described in our 2021 Proxy Statement, annual performance and compensation reviews of our senior leadership team include an evaluation of their contributions to employee culture and diversity. To ensure accountability over time, we publicly disclose our progress on a multitude of workforce metrics including:
- · Detailed breakdowns of gender, racial, and ethnic minority representation in our employee population, with data by job types, levels, and segments of our business.
- · Our EEO-1 report (equal employment opportunity).
- · Disability representation.
- · Pay equity (see details below).

---

# Page 20

# Total Rewards

We develop dynamic, sustainable, market-driven, and strategic programs with the goal of providing a highly differentiated portfolio to attract, reward, and retain top talent and enable our employees to thrive. These programs reinforce our culture and  values  such  as  collaboration  and  growth  mindset.  Managers  evaluate  and  recommend  rewards  based  on,  for example, how well we leverage the work of others and contribute to the success of our colleagues. We monitor pay equity and career progress across multiple dimensions.

As part of our effort to promote a One Microsoft and inclusive culture, in fiscal year 2021 we expanded stock eligibility to all Microsoft employees as part of our annual rewards process. This includes all non-exempt and exempt employees and equivalents across the globe including business support professionals and datacenter and retail employees. In response to the Great Reshuffle, in fiscal year 2022 we announced a sizable investment in annual merit and annual stock award opportunity  for  all  employees  below  senior  executive  levels.  We  also  invested  in  base  salary  adjustments  for  our datacenter  and  retail  hourly  employees  and  hourly  equivalents  outside  the  U.S.  These  investments  have  supported retention and help to ensure that Microsoft remains an employer of choice.


## Pay Equity

In our 2021 Diversity and Inclusion Report, we reported that all racial and ethnic minority employees in the U.S. combined earn $1.006 for every $1.000 earned by their white counterparts, that women in the U.S. earn $1.002 for every  $1.000 earned by their counterparts in the U.S. who are men, and women in the U.S. plus our twelve other largest employee geographies  representing  86.6%  of  our  global  population  (Australia,  Canada,  China,  France,  Germany,  India,  Ireland, Israel, Japan, Romania, Singapore, and the United Kingdom) combined earn $1.001 for every $1.000 by men in these countries. Our intended result is a global performance and development approach that fosters our culture, and competitive compensation that ensures equitable pay by role while supporting pay for performance.


## Wellness and Safety

Microsoft is committed to supporting our employees' well-being and safety while they are at work and in their personal lives.

We took a wide  variety  of measures  to  protect  the  health  and  well-being  of  our  employees,  suppliers,  and  customers during  the  COVID-19  pandemic  and  are  now  supporting  employees  in  shifting  to  return  to  office  and/or  hybrid arrangements. We developed hybrid guidelines for managers and employees to support the transition and continue to identify ways we can support hybrid work scenarios through our employee listening systems.

We  have  invested  significantly  in  holistic  wellbeing,  and  offer  a  differentiated  benefits  package  which  includes  many physical,  emotional,  and  financial  wellness  programs  including  counseling  through  the  Microsoft  CARES  Employee Assistance  Program,  mental  wellbeing  support,  flexible  fitness  benefits,  savings  and  investment  tools,  adoption assistance, and back-up care for children and elders. Finally, our Occupational Health and Safety program helps ensure employees can stay safe while they are working.

We continue to strive to support our Ukrainian employees and their dependents during the Ukraine crisis with emergency relocation assistance, emergency leave, and other benefits.


## Learning and Development


Our  growth  mindset  culture  begins  with  valuing  learning  over  knowing  -  seeking  out  new  ideas,  driving  innovation, embracing challenges, learning from failure, and improving over time. To support this culture, we offer a wide range of learning  and  development  opportunities.  We  believe  learning  can  be  more  than  formal  instruction,  and  our  learning philosophy focuses on providing the right learning, at the right time, in the right way. Opportunities include:
- · Personalized, integrated, and relevant views of all learning opportunities on both our internal learning portal Learning (Viva Learning + LinkedIn Learning) and our external learning portal MS Learn are available to all employees worldwide.

---

# Page 21

- · In-the-classroom  learning,  learning  cohorts,  our  early-in-career  Aspire  program,  and  manager  excellence communities.
- · Required  learning  for  all  employees  and  managers  on  topics  such  as  compliance,  regulation,  company culture, leadership, and management. This includes the annual Standards of Business Conduct training.
- · On-the-job -stretch‖ and advancement opportunities.
- · Managers  holding  conversations  about  employees'  career  and  development  plans,  coaching  on  career opportunities, and programs like mentoring and sponsorship.
- · Customized  manager  learning  to  build  people  manager  capabilities  and  similar  learning  solutions  to  build leadership skills for all employees including differentiated leadership development programs.
- · New  employee  orientation  covering  a  range  of  topics  including  company  values,  and  culture,  as  well  as ongoing onboarding programs.
- · New tools to assist managers and employees in learning how to operate, be productive, and connect in the new  flexible  hybrid  world  of  work.  These  include  quick  guides  for  teams  to  use,  such  as  Creating  Team Agreements, Reconnecting as a Team, and Running Effective Hybrid Meetings.


Our employees embrace the growth mindset and take advantage of the formal learning opportunities as well as thousands of  informal  and  on-the-job  learning  opportunities.  In  terms  of  formal  on-line  learning  solutions,  in  fiscal  year  2022  our employees completed over 4.7 million courses, averaging over 14 hours per employee. Given our focus on understanding core  company  beliefs  and  compliance  topics,  all  employees  complete  required  learning  programs  like  Standards  of Business Conduct, Privacy, Unconscious Bias, and preventing harassment courses. Our corporate learning portal has over 100,000 average monthly active users. We have over 27,000 people managers, all of whom must complete between 20-33 hours of required manager capability and excellence training and are assigned ongoing required training each year. In addition, all employees complete skills training based on the profession they are in each year.


## New Ways of Working

The COVID-19 pandemic accelerated our capabilities and culture with respect to flexible work. We introduced a Hybrid Workplace Flexibility Guide to better support managers and employees as they adapt to new ways of working that shift paradigms, embrace flexibility, promote inclusion, and drive innovation. Our ongoing survey data shows employees value the flexibility related to work location, work site, and work hours, and while many have begun returning to worksites as conditions have permitted, they also continue to adjust hours and/or spend some of workweeks working at home, another site, or remotely. We are focused on building capabilities to support a variety of workstyles where individuals, teams, and our business can deliver success.


## OPERATING SEGMENTS

We  operate  our  business  and  report  our  financial  performance  using  three  segments:  Productivity  and  Business Processes, Intelligent Cloud, and More Personal Computing. Our segments provide management with a comprehensive financial  view  of  our  key  businesses.  The  segments  enable  the  alignment  of  strategies  and  objectives  across  the development,  sales,  marketing,  and  services  organizations,  and  they  provide  a  framework  for  timely  and  rational allocation of resources within businesses.

Additional  information  on  our  operating  segments  and  geographic  and  product  information  is  contained  in  Note  19  Segment Information and Geographic Data of the Notes to Financial Statements in our fiscal year 2022 Form 10-K.

Our reportable segments are described below.

---

# Page 22

# Productivity and Business Processes


Our  Productivity  and  Business  Processes  segment  consists  of  products  and  services  in  our  portfolio  of  productivity, communication, and information services, spanning a variety of devices and platforms. This segment primarily comprises:
- · Office Commercial  (Office 365 subscriptions, the Office 365 portion of Microsoft 365 Commercial subscriptions, and Office licensed on-premises), comprising Office, Exchange, SharePoint, Microsoft Teams, Office 365 Security and Compliance, and Microsoft Viva.
- · Office  Consumer, including Microsoft 365 Consumer subscriptions, Office licensed on-premises, and other Office services.
- · LinkedIn, including Talent Solutions, Marketing Solutions, Premium Subscriptions, and Sales Solutions.
- · Dynamics  business  solutions, including Dynamics  365,  comprising  a  set  of intelligent, cloud-based applications across ERP, CRM, Customer Insights, Power Apps, and Power Automate; and on-premises ERP and CRM applications.



## Office Commercial

Office Commercial is designed to increase personal, team, and organizational productivity through a range of products and services. Growth depends on our ability to reach new users in new markets such as frontline workers, small and medium  businesses,  and  growth  markets,  as  well  as  add  value  to  our  core  product  and  service  offerings  to  span productivity  categories  such  as  communication,  collaboration,  analytics,  security,  and  compliance.  Office  Commercial revenue is mainly affected by a combination of continued installed base growth and average revenue per user expansion, as well as the continued shift from Office licensed on-premises to Office 365.


## Office Consumer

Office Consumer is designed to increase personal productivity through a range of products and services. Growth depends on our ability  to reach  new  users, add  value to  our  core product set, and continue to expand our product and service offerings into new markets. Office Consumer revenue is mainly affected by the percentage of customers that buy Office with their new devices and the continued shift from Office licensed on-premises to Microsoft 365 Consumer subscriptions. Office  Consumer  Services  revenue  is  mainly  affected  by  the  demand  for  communication  and  storage  through  Skype, Outlook.com, and OneDrive, which is largely driven by subscriptions, advertising, and the sale of minutes.


## LinkedIn

LinkedIn  connects  the  world's  professionals  to  make  them  more  productive  and  successful  and  transforms  the  way companies hire,  market,  sell,  and  learn.  Our  vision  is  to  create  economic  opportunity  for  every  member  of  the  global workforce through the  ongoing development of the world's first Economic Graph, a digital representation  of the global economy.  In  addition  to  LinkedIn's  free  services,  LinkedIn  offers  monetized  solutions:  Talent  Solutions,  Marketing Solutions, Premium Subscriptions, and Sales Solutions. Talent Solutions provide insights for workforce planning and tools to hire, nurture, and develop talent. Talent Solutions also includes Learning Solutions, which help businesses close critical skills  gaps  in  times  where  companies  are  having  to  do  more  with  existing  talent.  Marketing  Solutions  help  companies reach,  engage,  and  convert  their  audiences  at  scale.  Premium  Subscriptions  enables  professionals  to  manage  their professional identity, grow their network, and connect with talent through additional services like premium search. Sales Solutions help companies strengthen customer relationships, empower teams with digital selling tools, and acquire new opportunities. LinkedIn has over 850 million members and has offices around the globe. Growth will depend on our ability to  increase  the  number  of  LinkedIn  members  and  our  ability  to  continue  offering  services  that  provide  value  for  our members  and  increase  their  engagement.  LinkedIn  revenue  is  mainly  affected  by  demand  from  enterprises  and professional organizations for subscriptions to Talent Solutions, Sales Solutions, and Premium Subscriptions offerings, as well as member engagement and the quality of the sponsored content delivered to those members to drive Marketing Solutions.

---

# Page 23

# Dynamics

Dynamics  provides  cloud-based  and  on-premises  business  solutions  for  financial  management,  enterprise  resource planning  (-ERP‖),  customer  relationship  management  (-CRM‖),  supply  chain  management,  and  other  application development  platforms  for  small  and  medium  businesses,  large  organizations,  and  divisions  of  global  enterprises. Dynamics revenue is driven by the number of users licensed and applications consumed, expansion of average revenue per user, and the continued shift to Dynamics 365, a unified set of cloud-based intelligent business applications, including Power Apps and Power Automate.


## Competition

Competitors to Office include software and global application vendors, such as Apple, Cisco Systems, Meta, Google, IBM, Okta, Proofpoint, Slack, Symantec, Zoom, and numerous web-based and mobile application competitors as well as local application  developers.  Apple  distributes  versions  of  its  pre-installed  application  software,  such  as  email  and  calendar products,  through  its  PCs,  tablets,  and  phones.  Cisco  Systems  is  using  its  position  in  enterprise  communications equipment  to  grow  its  unified  communications  business.  Google  provides  a  hosted  messaging  and  productivity  suite. Slack provides teamwork and collaboration software. Zoom offers videoconferencing and cloud phone solutions. Okta, Proofpoint, and  Symantec  provide  security  solutions  across  email  security,  information  protection, identity, and governance. Web-based offerings competing with individual applications have also positioned themselves as alternatives to our products and services. We compete by providing powerful, flexible, secure, integrated industry-specific, and easyto-use  productivity  and  collaboration  tools  and  services  that  create  comprehensive  solutions  and  work  well  with technologies our customers already have both on-premises or in the cloud.

LinkedIn faces competition from online professional networks, recruiting companies, talent management companies, and larger companies that are focusing on talent management and human resource services; job boards; traditional recruiting firms; and companies that provide learning and development products and services. Marketing Solutions competes with online and offline outlets that generate revenue from advertisers and marketers, and Sales Solutions competes with online and offline outlets for companies with lead generation and customer intelligence and insights.

Dynamics competes with cloud-based and on-premises business solution providers such as Oracle, Salesforce, and SAP.


## Intelligent Cloud


Our  Intelligent  Cloud  segment  consists  of  our  public,  private,  and  hybrid  server  products  and  cloud  services  that  can power modern business and developers. This segment primarily comprises:
- · Server products and cloud services, including Azure and other cloud services; SQL Server, Windows Server, Visual Studio, System Center, and related Client Access Licenses (-CALs‖); and Nuance and GitHub.
- · Enterprise  Services,  including  Enterprise  Support  Services,  Microsoft  Consulting  Services,  and  Nuance professional services.



## Server Products and Cloud Services

Azure is a comprehensive set of cloud services that offer developers, IT professionals, and enterprises freedom to build, deploy,  and  manage  applications  on  any  platform  or  device.  Customers  can  use  Azure  through  our  global  network  of datacenters  for  computing,  networking,  storage,  mobile  and  web  application  services,  AI,  IoT,  cognitive  services,  and machine learning. Azure enables customers to devote more resources to development and use of applications that benefit their  organizations,  rather  than  managing  on-premises  hardware  and  software.  Azure  revenue  is  mainly  affected  by infrastructure-as-a-service and platform-as-a-service consumption-based services, and per user-based services such as Enterprise Mobility + Security.

---

# Page 24

Our server products are designed to make IT professionals, developers, and their systems more productive and efficient. Server software is integrated server infrastructure and middleware designed to support software applications built on the Windows  Server  operating  system.  This  includes  the  server  platform,  database,  business  intelligence,  storage, management and operations, virtualization, service-oriented architecture platform, security, and identity software. We also license  standalone  and  software  development  lifecycle  tools  for  software  architects,  developers,  testers,  and  project managers. GitHub provides a collaboration platform and code hosting service for developers. Server products revenue is mainly  affected  by  purchases  through  volume  licensing  programs,  licenses  sold  to  original  equipment  manufacturers (-OEM‖), and retail packaged products. CALs provide access rights to certain server products, including SQL Server and Windows Server, and revenue is reported along with the associated server product.

Nuance  and  GitHub  include  both  cloud  and  on-premises  offerings.  Nuance  provides  healthcare  and  enterprise  AI solutions. GitHub provides a collaboration platform and code hosting service for developers.


# Enterprise Services

Enterprise  Services,  including  Enterprise  Support  Services,  Microsoft  Consulting  Services,  and  Nuance  Professional Services,  assist  customers  in  developing,  deploying,  and  managing  Microsoft  server  solutions,  Microsoft  desktop solutions, and Nuance conversational AI and ambient intelligent solutions, along with providing training and certification to developers and IT professionals on various Microsoft products.


## Competition

Azure  faces  diverse  competition  from  companies  such  as  Amazon,  Google,  IBM,  Oracle,  VMware,  and  open  source offerings. Our Enterprise Mobility + Security offerings also compete with products from a range of competitors including identity  vendors,  security  solution  vendors,  and  numerous  other  security  point  solution  vendors.  Azure's  competitive advantage  includes  enabling  a  hybrid  cloud,  allowing  deployment  of  existing  datacenters  with  our  public  cloud  into  a single,  cohesive  infrastructure,  and  the  ability  to  run  at  a  scale  that  meets  the  needs  of  businesses  of  all  sizes  and complexities. We believe our cloud's global scale, coupled with our broad portfolio of identity and security solutions, allows us to effectively solve complex cybersecurity challenges for our customers and differentiates us from the competition.

Our  server  products  face  competition  from  a  wide  variety  of  server  operating  systems  and  applications  offered  by companies with a range of market approaches. Vertically integrated computer manufacturers such as Hewlett-Packard, IBM,  and  Oracle  offer  their  own  versions  of  the  Unix  operating  system  preinstalled  on  server  hardware.  Nearly  all computer manufacturers offer server hardware for the Linux operating system and many contribute to Linux operating system  development.  The  competitive  position  of  Linux  has  also  benefited  from  the  large  number  of  compatible applications now produced by many commercial and non-commercial software developers. A number of companies, such as Red Hat, supply versions of Linux.

We  compete  to  provide  enterprise-wide  computing  solutions  and  point  solutions  with  numerous  commercial  software vendors that offer solutions and middleware technology platforms, software applications for connectivity (both Internet and intranet), security, hosting, database, and e-business servers. IBM and Oracle lead a group of companies focused on the Java Platform Enterprise Edition that competes with our enterprise-wide computing solutions. Commercial competitors for our server applications for PC-based distributed client-server environments include CA Technologies, IBM, and Oracle. Our web application platform software competes with open source software such as Apache, Linux, MySQL, and PHP. In middleware, we compete against Java vendors.

Our database, business intelligence, and data warehousing solutions offerings compete with products from IBM, Oracle, SAP, Snowflake, and other companies. Our system management solutions compete with server management and server virtualization platform providers, such as BMC, CA Technologies, Hewlett-Packard, IBM, and VMware. Our products for software developers compete against offerings from Adobe, IBM, Oracle, and other companies, and also against opensource projects, including Eclipse (sponsored by CA Technologies, IBM, Oracle, and SAP), PHP, and Ruby on Rails.

---

# Page 25

We  believe  our  server  products  provide  customers  with  advantages  in  performance,  total  costs  of  ownership,  and productivity  by  delivering  superior  applications,  development  tools,  compatibility  with  a  broad  base  of  hardware  and software applications, security, and manageability.

Our Enterprise Services business competes with a wide range of companies that provide strategy and business planning, application development, and infrastructure services, including multinational consulting firms and small niche businesses focused on specific technologies.


# More Personal Computing


Our  More  Personal  Computing  segment  consists  of  products  and  services  that  put  customers  at  the  center  of  the experience with our technology. This segment primarily comprises:
- · Windows,  including  Windows  OEM  licensing  (-Windows  OEM‖)  and  other  non-volume  licensing  of  the Windows operating system; Windows Commercial, comprising volume licensing of the Windows operating system, Windows cloud services, and other Windows commercial offerings; patent licensing; and Windows Internet of Things.
- · Devices, including Surface and PC accessories.
- · Gaming, including Xbox hardware and Xbox content and services, comprising first- and third-party content (including  games  and  in-game  content),  Xbox  Game  Pass  and  other  subscriptions,  Xbox  Cloud  Gaming, third-party disc royalties, advertising, and other cloud services.
- · Search and news advertising.



## Windows


The  Windows  operating  system  is  designed  to  deliver  a  more  personal  computing  experience  for  users  by  enabling consistency  of  experience,  applications,  and  information  across  their  devices.  Windows  OEM  revenue  is  impacted significantly  by  the  number  of  Windows  operating  system  licenses  purchased  by  OEMs,  which  they  pre-install  on  the devices they sell. In addition to computing device market volume, Windows OEM revenue is impacted by:
- · The mix of computing devices based on form factor and screen size.
- · Differences in device market demand between developed markets and growth markets.
- · Attachment of Windows to devices shipped.
- · Customer mix between consumer, small and medium businesses, and large enterprises.
- · Changes in inventory levels in the OEM channel.
- · Pricing changes and promotions, pricing variation that occurs when the mix of devices manufactured shifts from  local  and  regional  system  builders  to  large  multinational  OEMs,  and  different  pricing  of  Windows versions licensed.
- · Constraints in the supply chain of device components.
- · Piracy.


Windows Commercial revenue, which includes volume licensing of the Windows operating system and Windows cloud services  such  as  Microsoft  Defender  for  Endpoint,  is  affected  mainly  by  the  demand  from  commercial  customers  for volume licensing and Software Assurance (-SA‖), as well as advanced security offerings. Windows Commercial revenue often reflects the number of information workers in a licensed enterprise and is relatively independent of the number of PCs sold in a given year.

Patent  licensing  includes  our  programs  to  license  patents  we  own  for  use  across  a  broad  array  of  technology  areas, including mobile devices and cloud offerings.

Windows IoT  extends  the  power  of  Windows  and  the  cloud  to  intelligent  systems  by  delivering  specialized  operating systems, tools, and services for use in embedded devices.

---

# Page 26

# Devices

We design  and  sell  devices,  including  Surface  and  PC  accessories.  Our  devices  are  designed  to  enable  people  and organizations to connect to the people and content that matter most using Windows and integrated Microsoft products and services. Surface is designed to help organizations, students, and consumers be more productive. Growth in Devices is dependent on total PC shipments, the ability to attract new customers, our product roadmap, and expanding into new categories.


## Gaming

Our  gaming  platform  is  designed  to  provide  a  variety  of  entertainment  through  a  unique  combination  of  content, community,  and  cloud.  Our  exclusive  game  content  is  created  through  Xbox  Game  Studios,  a  collection  of  first-party studios creating iconic and differentiated gaming experiences. We continue to invest in new gaming studios and content to expand our IP roadmap and leverage new content creators. These unique gaming experiences are the cornerstone of Xbox Game Pass, a subscription service and gaming community with access to a curated library of over 100 first- and third-party console and PC titles.

The gamer remains at the heart of the Xbox ecosystem. We continue to open new opportunities for gamers to engage both  on-  and  off-console  with  both  the  launch  of  Xbox  Cloud  Gaming,  our  game  streaming  service,  and  continued investment in gaming hardware. Xbox Cloud Gaming utilizes Microsoft's Azure cloud technology to allow direct and ondemand streaming of games to PCs, consoles, and mobile devices, enabling gamers to take their favorite games with them and play on the device most convenient to them.

Xbox enables people to connect and share online gaming experiences that are accessible on Xbox consoles, Windowsenabled  devices,  and  other  devices. Xbox  is  designed  to  benefit  users  by  providing  access  to  a  network  of  certified applications and services and to benefit our developer and partner ecosystems by providing access to a large customer base. Xbox revenue is mainly affected by subscriptions and sales of first- and third-party content, as well as advertising. Growth of our Gaming business is determined by the overall active user base through Xbox enabled content, availability of games, providing exclusive game content that gamers seek, the computational power and reliability of the devices used to access our content and services, and the ability to create new experiences through first-party content creators.


## Search and News Advertising

Our Search and news advertising business is designed to deliver relevant search, native, and display advertising to a global audience. We have several partnerships with other companies, including Yahoo, through which we provide and monetize search queries. Growth depends on our ability to attract new users, understand intent, and match intent with relevant content and advertiser offerings.

On  June 6,  2022,  we  acquired  Xandr,  Inc.,  a  technology  platform  with  tools  to  accelerate  the  delivery  of  our  digital advertising solutions.


## Competition

Windows faces competition from various software products and from alternative platforms and devices, mainly from Apple and Google. We believe Windows competes effectively by giving customers choice, value, flexibility, security, an easy-touse interface, and compatibility with a broad range of hardware and software applications, including those that enable productivity.

Devices face competition from various computer, tablet, and hardware manufacturers who offer a unique combination of high-quality  industrial  design  and  innovative  technologies  across  various  price  points.  These  manufacturers,  many  of which are also current or potential partners and customers, include Apple and our Windows OEMs.

---

# Page 27

Xbox  and  our  cloud  gaming  services  face  competition  from  various  online  gaming  ecosystems  and  game  streaming services, including those operated by Amazon, Apple, Meta, Google, and Tencent. We also compete with other providers of entertainment services such as video streaming platforms. Our gaming platform competes with console platforms from Nintendo  and  Sony,  both  of  which  have  a  large,  established  base  of  customers. We  believe  our  gaming  platform  is effectively  positioned  against,  and  uniquely  differentiated  from,  competitive  products  and  services  based  on  significant innovation  in  hardware  architecture,  user  interface,  developer  tools,  online  gaming  and  entertainment  services,  and continued strong exclusive content from our own first-party game franchises as well as other digital content offerings.

Our Search and news advertising business competes with Google and a  wide array of websites, social  platforms like Meta, and portals that provide content and online offerings to end users.


# OPERATIONS

We have operations centers that support operations in their regions, including customer contract and order processing, credit  and  collections,  information  processing,  and  vendor  management  and  logistics.  The  regional  center  in  Ireland supports the European, Middle Eastern, and African region; the center in Singapore supports the Japan, India, Greater China, and Asia-Pacific region; and the centers in Fargo, North Dakota, Fort Lauderdale, Florida, Puerto Rico, Redmond, Washington, and Reno, Nevada support Latin America and North America. In addition to the operations centers, we also operate datacenters throughout the Americas, Europe, Australia, and Asia, as well as in the Middle East and Africa.

To serve the needs of customers around the world and to improve the quality and usability of products in international markets, we localize many of our products to reflect local languages and conventions. Localizing a product may require modifying the user interface, altering dialog boxes, and translating text.

Our devices are primarily manufactured by third-party contract manufacturers. For the majority of our products, we have the  ability  to  use  other  manufacturers  if  a  current  vendor  becomes  unavailable  or  unable  to  meet  our  requirements. However, some of our products contain certain components for which there are very few qualified suppliers. For these components, we have limited near-term flexibility to use other manufacturers if a current vendor becomes unavailable or is unable to meet our requirements. Extended disruptions at these suppliers and/or manufacturers could lead to a similar disruption in our ability to manufacture devices on time to meet consumer demand.


## RESEARCH AND DEVELOPMENT


## Product and Service Development, and Intellectual Property

We develop most of our products and services internally through the following engineering groups.


- · Cloud  and  AI ,  focuses  on  making  IT  professionals,  developers,  and  their  systems  more  productive  and efficient  through  development  of  cloud  infrastructure,  server,  database,  CRM,  ERP,  software  development tools  and  services  (including  GitHub),  AI  cognitive  services,  and  other  business  process  applications  and services for enterprises.
- · Experiences and Devices , focuses on instilling a unifying product ethos across our end-user experiences and devices,  including  Office,  Windows,  Teams,  consumer  web  experiences  (including  search  and  news advertising), and the Surface line of devices.
- · Security, Compliance, Identity, and Management , focuses on cloud platform and application security, identity and network access, enterprise mobility, information protection, and managed services.
- · Technology  and  Research , focuses  on  our  AI innovations and  other forward-looking research  and development efforts spanning infrastructure, services, and applications.
- · LinkedIn , focuses on our services that transform the way customers hire, market, sell, and learn.

---

# Page 28

- · Gaming, focuses on developing hardware, content, and services across a large range of platforms to help grow our user base through game experiences and social interaction.


Internal  development  allows  us  to  maintain  competitive  advantages  that  come  from  product  differentiation  and  closer technical  control  over  our  products  and  services.  It  also  gives  us  the  freedom  to  decide  which  modifications  and enhancements are most important and when they should be implemented. We strive to obtain information as early as possible about changing usage patterns and hardware advances that may affect software and hardware design. Before releasing new software platforms, and as we make significant modifications to existing platforms, we provide application vendors with a range of resources and guidelines for development, training, and testing. Generally, we also create product documentation internally.

We protect our intellectual property investments in a variety of ways. We work actively in the U.S. and internationally to ensure  the  enforcement  of  copyright,  trademark,  trade  secret,  and  other  protections  that  apply  to  our  software  and hardware products, services, business plans, and branding. We are a leader among technology companies in pursuing patents  and  currently  have  a  portfolio  of  over  69,000  U.S.  and  international  patents  issued  and  over  19,000  pending worldwide.  While  we  employ  much  of  our  internally-developed  intellectual  property  exclusively  in  our  products  and services,  we  also  engage  in  outbound  licensing  of  specific  patented  technologies  that  are  incorporated  into  licensees' products. From time to time, we enter into broader cross-license agreements with other technology companies covering entire groups of patents. We may also purchase or license technology that we incorporate into our products and services. At times, we make select intellectual property broadly available at no or low cost to achieve a strategic objective, such as promoting  industry  standards,  advancing  interoperability,  supporting  societal  and/or  environmental  efforts,  or  attracting and enabling our external development community. Our increasing engagement with open source software will also cause us to license our intellectual property rights broadly in certain situations.

While it may be necessary in the future to seek or renew licenses relating to various aspects of our products, services, and business methods, we believe, based upon past experience and industry practice, such licenses generally can be obtained  on  commercially  reasonable  terms.  We  believe  our  continuing  research  and  product  development  are  not materially  dependent  on  any  single  license  or  other  agreement  with  a  third  party  relating  to  the  development  of  our products.


## Investing in the Future

Our success is based on our ability to create new and compelling products, services, and experiences for our users, to initiate  and  embrace  disruptive  technology  trends,  to  enter  new  geographic  and  product  markets,  and  to  drive  broad adoption of our products and services. We invest in a range of emerging technology trends and breakthroughs that we believe  offer  significant  opportunities  to  deliver  value  to  our  customers  and  growth  for  the  Company.  Based  on  our assessment of key technology trends, we maintain our long-term commitment to research and development across a wide spectrum of technologies, tools, and platforms spanning digital work and life experiences, cloud computing, AI, devices, and operating systems.

While  our  main  product  research  and  development  facilities  are  located  in  Redmond,  Washington,  we  also  operate research and development facilities in other parts of the U.S. and around the world. This global approach helps us remain competitive in local markets and enables us to continue to attract top talent from across the world.

We plan to continue to make significant investments in a broad range of product research and development activities, and as  appropriate  we  will  coordinate  our  research  and  development  across  operating  segments  and  leverage  the  results across the Company.

In addition to our main research and development operations, we also operate Microsoft Research. Microsoft Research is one of the world's largest corporate research organizations and works in close collaboration with top universities around the world to advance the state-of-the-art in computer science and a broad range of other disciplines, providing us a unique perspective on future trends and contributing to our innovation.

---

# Page 29

# DISTRIBUTION, SALES, AND MARKETING

We market and distribute our products and services through the following channels: OEMs, direct, and distributors and resellers.  Our  sales  force  performs  a  variety  of  functions,  including  working  directly  with  commercial  enterprises  and public-sector  organizations  worldwide  to  identify  and  meet  their  technology  and  digital  transformation  requirements; managing OEM relationships; and supporting system integrators, independent software vendors, and other partners who engage directly with our customers to perform sales, consulting, and fulfillment functions for our products and services.


## OEMs

We distribute our products and services through OEMs that pre-install our software on new devices and servers they sell. The largest component of the OEM business is the Windows operating system pre-installed on devices. OEMs also sell devices pre-installed with other Microsoft products and services, including applications such as Office and the capability to subscribe to Office 365.

There are two broad categories of OEMs. The largest category of OEMs are direct OEMs as our relationship with them is managed through a direct agreement between Microsoft and the OEM. We have distribution agreements covering one or more of our products with virtually all the multinational OEMs, including Dell, Hewlett-Packard, Lenovo, and with many regional  and  local  OEMs. The  second  broad  category  of  OEMs  are  system  builders  consisting  of  lower-volume  PC manufacturers, which source Microsoft software for pre-installation and local redistribution primarily through the Microsoft distributor channel rather than through a direct agreement or relationship with Microsoft.


## Direct

Many organizations that license our products and services transact directly with us through Enterprise Agreements and Enterprise Services contracts, with sales support from system integrators, independent software vendors, web agencies, and partners that advise organizations on licensing our products and services (-Enterprise Agreement Software Advisors‖ or -ESA‖). Microsoft offers direct sales programs targeted to reach small, medium, and corporate customers, in addition to those offered through the reseller channel. A large network of partner advisors support many of these sales.

We also sell commercial and consumer products and services directly to customers, such as cloud services, search, and gaming, through our digital marketplaces and online stores. In fiscal year 2021, we closed our Microsoft Store physical locations and opened our Microsoft Experience Centers. Microsoft Experience Centers are designed to facilitate deeper engagement with our partners and customers across industries.


## Distributors and Resellers

Organizations  also  license  our  products  and  services  indirectly,  primarily  through  licensing  solution  partners  (-LSP‖), distributors, value-added resellers (-VAR‖), and retailers. Although each type of reselling partner may reach organizations of all sizes, LSPs are primarily engaged with large organizations, distributors resell primarily to VARs, and VARs typically reach small and medium organizations. ESAs are also typically authorized as LSPs and operate as resellers for our other volume licensing programs. Microsoft Cloud Solution Provider is our main partner program for reselling cloud services.

We  distribute our retail packaged  products  primarily  through  independent  non-exclusive distributors, authorized replicators,  resellers,  and  retail  outlets.  Individual  consumers  obtain  these  products  primarily  through  retail  outlets. We distribute  our  devices  through  third-party  retailers.  We  have  a  network  of  field  sales  representatives  and  field  support personnel that solicit orders from distributors and resellers and provide product training and sales support.

Our Dynamics business solutions are also licensed to enterprises through a global network of channel partners providing vertical solutions and specialized services.

---

# Page 30

# LICENSING OPTIONS

We offer options for organizations that want to purchase our cloud services, on-premises software, and SA. We license software  to  organizations  under  volume  licensing  agreements  to  allow  the  customer  to  acquire  multiple  licenses  of products and services instead of having to acquire separate licenses through retail channels. We use different programs designed to provide flexibility for organizations of various sizes. While these programs may differ in various parts of the world, generally they include those discussed below.

SA conveys rights to new software and upgrades for perpetual licenses released over the contract period. It also provides support, tools, training, and other licensing benefits to help customers deploy and use software efficiently. SA is included with certain volume licensing agreements and is an optional purchase with others.


## Volume Licensing Programs


## Enterprise Agreement

Enterprise Agreements offer large organizations a manageable volume licensing program that gives them the flexibility to buy cloud services and software licenses under one agreement. Enterprise Agreements are designed for medium or large organizations that want to license cloud services and on-premises software organization-wide over a three-year period. Organizations can elect to purchase perpetual licenses or subscribe to licenses. SA is included.


## Microsoft Customer Agreement

A Microsoft Customer Agreement is a simplified purchase agreement presented, accepted, and stored through a digital experience. A Microsoft Customer Agreement is a non-expiring agreement that is designed to support all customers over time, whether purchasing through a partner or directly from Microsoft.


## Microsoft Online Subscription Agreement

A Microsoft Online Subscription Agreement is designed for small and medium organizations that want to subscribe to, activate, provision, and maintain cloud services seamlessly and directly via the web. The agreement allows customers to acquire monthly or annual subscriptions for cloud-based services.


## Microsoft Products and Services Agreement

Microsoft Products and Services Agreements are designed for medium and large organizations that want to license cloud services  and  on-premises  software  as  needed,  with  no  organization-wide  commitment,  under  a  single,  non-expiring agreement.  Organizations  purchase  perpetual  licenses  or  subscribe  to  licenses.  SA  is  optional  for  customers  that purchase perpetual licenses.


## Open Value

Open Value agreements are a simple, cost-effective way to acquire the latest Microsoft technology. These agreements are designed for small and medium organizations that want to license cloud services and on-premises software over a three-year period. Under Open Value agreements, organizations can elect to purchase perpetual licenses or subscribe to licenses and SA is included.


## Select Plus

A Select Plus agreement is designed for government and academic organizations to acquire on-premises licenses at any affiliate or department level, while realizing advantages as one organization. Organizations purchase perpetual licenses and SA is optional.

---

# Page 31

# Partner Programs

The Microsoft Cloud Solution Provider program offers customers an easy way to license the cloud services they need in combination  with  the  value-added  services  offered  by  their  systems  integrator,  managed  services  provider,  or  cloud reseller  partner.  Partners  in  this  program  can  easily  package  their  own  products  and  services  to  directly  provision, manage, and support their customer subscriptions.

The Microsoft Services Provider License Agreement allows hosting service providers and independent software vendors who want to license eligible Microsoft software products to provide software services and hosted applications to their end customers. Partners license software over a three-year period and are billed monthly based on consumption.

The  Independent  Software  Vendor  Royalty  program  enables  partners  to  integrate  Microsoft  products  into  other applications and then license the unified business solution to their end users.


## CUSTOMERS

Our  customers  include  individual  consumers,  small  and  medium  organizations,  large  global  enterprises,  public-sector institutions, Internet service providers, application developers, and OEMs. Our practice is to ship our products promptly upon receipt of purchase orders from customers; consequently, backlog is not significant.


## AVAILABLE INFORMATION


Our  Internet  address  is  www.microsoft.com.  At  our  Investor  Relations  website,  www.microsoft.com/investor,  we  make available free of charge a variety of information for investors. Our goal is to maintain the Investor Relations website as a portal through which investors can easily find or navigate to pertinent information about us, including:
- · Our  annual  report  on  Form  10-K,  quarterly  reports  on  Form  10-Q,  current  reports  on  Form  8-K,  and  any amendments to those reports, as soon as reasonably practicable after we electronically file that material with or furnish it to the Securities and Exchange Commission (-SEC‖) at www.sec.gov.
- · Information on our business strategies, financial results, and metrics for investors.
- · Announcements  of  investor  conferences,  speeches,  and  events  at  which  our  executives  talk  about  our product, service, and competitive strategies. Archives of these events are also available.
- · Press  releases  on  quarterly  earnings,  product  and  service  announcements,  legal  developments,  and international news.
- · Corporate  governance  information  including  our  articles  of  incorporation,  bylaws,  governance  guidelines, committee charters, codes of conduct and ethics, global corporate social responsibility initiatives, and other governance-related policies.
- · Other  news  and  announcements  that  we  may  post  from  time  to  time  that  investors  might  find  useful  or interesting.
- · Opportunities to sign up for email alerts to have information pushed in real time.


We publish a variety of reports and resources related to our Corporate Social Responsibility programs and progress on our  Reports  Hub  website,  www.microsoft.com/corporate-responsibility/reports-hub,  including  reports  on  sustainability, responsible sourcing, accessibility, digital trust, and public policy engagement.

The information found on these websites is not part of, or incorporated by reference into, this or any other report we file with, or furnish to, the SEC. In addition to these channels, we use social media to communicate to the public. It is possible that the information we post on social media could be deemed to be material to investors. We encourage investors, the media, and others interested in Microsoft to review the information we post on the social media channels listed on our Investor Relations website.

---

# Page 32

# MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

The  following  Management's  Discussion  and  Analysis  of  Financial  Condition  and  Results  of  Operations  (-MD&A‖)  is intended to help the reader understand the results of operations and financial condition of Microsoft Corporation. MD&A is provided  as  a  supplement  to,  and  should  be  read  in  conjunction  with,  our  consolidated  financial  statements  and  the accompanying Notes to Financial Statements in our fiscal year 2022 Form 10-K. This section generally discusses the results of our operations for the year ended June 30, 2022 compared to the year ended June 30, 2021. For a discussion of the year ended June 30, 2021 compared to the year ended June 30, 2020, please refer to in our fiscal year 2022 Form 10-K, -Management's Discussion and Analysis of Financial Condition and Results of Operations‖ in our Annual Report on Form 10-K for the year ended June 30, 2021.


## OVERVIEW

Microsoft is a technology company whose mission is to empower every person and every organization on the planet to achieve more. We strive to create local opportunity, growth, and impact in every country around the world. Our platforms and tools help drive small business productivity, large business competitiveness, and public-sector efficiency. They also support new startups, improve educational and health outcomes, and empower human ingenuity.

We generate revenue by offering a wide range of cloud-based and other services to people and businesses; licensing and supporting an array of software products; designing, manufacturing, and selling devices; and delivering relevant online advertising  to  a  global  audience.  Our  most  significant  expenses  are  related  to  compensating  employees;  designing, manufacturing, marketing, and selling our products and services; datacenter costs in support of our cloud-based services; and income taxes.


Highlights from fiscal year 2022 compared with fiscal year 2021 included:
- · Microsoft Cloud (formerly commercial cloud) revenue increased 32% to $91.2 billion.
- · Office  Commercial  products  and  cloud  services  revenue  increased  13%  driven  by  Office  365  Commercial growth of 18%.
- · Office  Consumer  products  and  cloud  services  revenue  increased  11%  and  Microsoft  365  Consumer subscribers grew to 59.7 million.
- · LinkedIn revenue increased 34%.
- · Dynamics products and cloud services revenue increased 25% driven by Dynamics 365 growth of 39%.
- · Server products and cloud services revenue increased 28% driven by Azure and other cloud services growth of 45%.
- · Windows original equipment manufacturer licensing (-Windows OEM‖) revenue increased 11%.
- · Windows Commercial products and cloud services revenue increased 11%.
- · Xbox content and services revenue increased 3%.
- · Search and news advertising revenue excluding traffic acquisition costs increased 27%.
- · Surface revenue increased 3%.


On March 4, 2022, we completed our acquisition of Nuance Communications, Inc. (-Nuance‖) for a total purchase price of $18.8 billion,  consisting  primarily  of  cash.  Nuance  is  a  cloud  and  artificial  intelligence  (-AI‖)  software  provider  with healthcare  and  enterprise  AI  experience,  and  the  acquisition  will  build  on  our  industry-specific  cloud  offerings.  The financial results of Nuance have been included in our consolidated financial statements since the date of the acquisition. Nuance is reported as part of our Intelligent Cloud segment. Refer to Note 8 - Business Combinations of the Notes to Financial Statements in our fiscal year 2022 Form 10-K for further discussion.

---

# Page 33

# Industry Trends

Our industry is dynamic and highly competitive, with frequent changes in both technologies and business models.  Each industry shift is an opportunity to conceive new products, new technologies, or new ideas that can further transform the industry and our business. At Microsoft, we push the boundaries of what is possible through a broad range of research and development activities  that  seek  to  identify  and  address  the  changing  demands  of  customers  and  users,  industry trends, and competitive forces.


## Economic Conditions, Challenges, and Risks

The markets for software, devices, and cloud-based services are dynamic and highly competitive. Our competitors are developing  new  software  and  devices,  while  also  deploying  competing  cloud-based  services  for  consumers  and businesses. The devices and form factors customers prefer evolve rapidly, and influence how users access services in the cloud, and in some cases, the user's choice of which suite of cloud-based services to use. We must continue to evolve and adapt over an extended time in pace with this changing environment. The investments we are making in infrastructure and devices will continue to increase our operating costs and may decrease our operating margins.

Our success is highly dependent on our ability to attract and retain qualified employees. We hire a mix of university and industry talent worldwide. We compete for talented individuals globally by offering an exceptional working environment, broad customer reach, scale in resources, the ability to grow one's career across many different products and businesses, and competitive compensation and benefits. Aggregate demand for our software, services, and devices is correlated to global macroeconomic and geopolitical factors, which remain dynamic.

Our devices are primarily manufactured by third-party contract manufacturers, some of which contain certain components for which there are very few qualified suppliers. For these components, we have limited near-term flexibility to use other manufacturers if a current vendor becomes unavailable or is unable to meet our requirements. Extended disruptions at these suppliers and/or manufacturers could lead to a similar disruption in our ability to manufacture devices on time to meet consumer demand.

Our international operations provide a significant portion of our total revenue and expenses. Many of these revenue and expenses are denominated in currencies other than the U.S. dollar. As a result, changes in foreign exchange rates may significantly affect revenue and expenses. Fluctuations in the U.S. dollar relative to certain foreign currencies did not have a material impact on reported revenue or expenses from our international operations in fiscal year 2022.

Refer to Risk Factors in our fiscal year 2022 Form 10-K for a discussion of these factors and other risks.


## Seasonality

Our revenue fluctuates  quarterly  and  is  generally  higher  in  the  second  and  fourth  quarters  of  our  fiscal  year.  Second quarter revenue is driven by corporate year-end spending trends in our major markets and holiday season spending by consumers, and fourth quarter revenue is driven by the volume of multi-year on-premises contracts executed during the period.


## Reportable Segments

We report our financial performance based on the following segments: Productivity and Business Processes, Intelligent Cloud, and More Personal Computing. The segment amounts included in MD&A are presented on a basis consistent with our internal management reporting. Additional information on our reportable segments is contained in Note 19 - Segment Information and Geographic Data of the Notes to Financial Statements in our fiscal year 2022 Form 10-K.


## Metrics

We use metrics in assessing the performance of our business and to make informed decisions regarding the allocation of resources. We disclose metrics to enable investors to evaluate progress against our ambitions, provide transparency into performance trends, and reflect the continued evolution of our products and services. Our commercial and other business metrics are fundamentally connected based on how customers use our products and

---

# Page 34

services. The metrics are disclosed in the MD&A or the Notes to Financial Statements in our fiscal year 2022 Form 10-K. Financial metrics are calculated based on financial results prepared in accordance with accounting principles generally accepted in the United States of America (-GAAP‖), and growth comparisons relate to the corresponding period of last fiscal year.

In the first quarter of fiscal year 2022, we made updates to the presentation and method of calculation for certain metrics, most notably changes to incorporate all current and anticipated revenue streams within our Office Consumer and Server products and cloud services metrics and changes to align with how we manage our Windows OEM and Search and news advertising businesses. None of these changes had a material impact on previously reported amounts in our MD&A.

In  the  third  quarter  of  fiscal  year  2022,  we  completed  our  acquisition  of  Nuance.  Nuance is included  in all commercial metrics  and  our  Server  products  and  cloud  services  revenue  growth  metric.  Azure  and  other  cloud  services  revenue includes Nuance cloud services, and Server products revenue includes Nuance on-premises offerings.


## Commercial

Our  commercial  business  primarily  consists  of  Server  products  and  cloud  services,  Office  Commercial,  Windows Commercial,  the  commercial  portion  of  LinkedIn,  Enterprise  Services,  and  Dynamics.  Our  commercial  metrics  allow management and investors to assess the overall  health of  our  commercial  business  and  include  leading  indicators  of future performance.

Commercial remaining performance obligation

Commercial  portion  of  revenue  allocated  to  remaining performance obligations, which includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods

Microsoft Cloud revenue

Revenue from Azure and other cloud services, Office 365 Commercial, the commercial portion of LinkedIn, Dynamics 365, and other commercial cloud properties

Microsoft Cloud gross margin percentage

Gross margin percentage for our Microsoft Cloud business


## Productivity and Business Processes and Intelligent Cloud

Metrics related to our Productivity and Business Processes and Intelligent Cloud segments assess the health of our core businesses within these segments. The metrics reflect our cloud and on-premises product strategies and trends.

Office Commercial products and cloud services revenue growth

Office Consumer products and cloud services revenue growth

Office 365 Commercial seat growth

Microsoft 365 Consumer subscribers

Revenue  from  Office  Commercial  products  and  cloud services (Office 365 subscriptions, the Office 365 portion of  Microsoft  365  Commercial  subscriptions,  and  Office licensed on-premises), comprising Office, Exchange, SharePoint,  Microsoft  Teams,  Office  365  Security  and Compliance, and Microsoft Viva

Revenue  from Office Consumer  products and cloud services, including Microsoft 365 Consumer subscriptions, Office licensed on-premises, and other Office services

The  number  of  Office  365  Commercial  seats  at  end  of period  where  seats  are  paid  users  covered  by  an  Office 365 Commercial subscription

The  number  of  Microsoft  365  Consumer  subscribers  at end of period

---

# Page 35

Dynamics products and cloud services revenue growth

LinkedIn revenue growth

Server products and cloud services revenue growth

Revenue  from  Dynamics  products  and  cloud  services, including  Dynamics  365,  comprising  a  set  of  intelligent, cloud-based  applications  across  ERP,  CRM,  Customer Insights,  Power  Apps,  and  Power  Automate;  and  onpremises ERP and CRM applications

Revenue from LinkedIn, including Talent Solutions, Marketing  Solutions,  Premium  Subscriptions,  and  Sales Solutions

Revenue from Server products and cloud services, including  Azure  and  other  cloud  services;  SQL  Server, Windows  Server,  Visual Studio, System  Center, and related Client Access Licenses (-CALs‖); and Nuance and GitHub


## More Personal Computing

Metrics related to our More Personal Computing segment assess the performance of key lines of business within this segment.  These  metrics  provide  strategic  product  insights  which  allow  us  to  assess  the  performance  across  our commercial and consumer businesses. As we have diversity of target audiences and sales motions within the Windows business, we monitor metrics that are reflective of those varying motions.

Windows OEM revenue growth

Revenue  from  sales  of  Windows  Pro  and  non-Pro  licenses  sold through the OEM channel

Windows Commercial products and cloud services revenue growth

Revenue  from  Windows  Commercial  products  and  cloud  services, comprising volume  licensing of the Windows  operating  system, Windows cloud services, and other Windows commercial offerings

Surface revenue growth

Revenue from Surface devices and accessories

Xbox content and services revenue growth

Revenue from Xbox content and services, comprising first- and third- party  content  (including  games  and  in-game  content),  Xbox  Game Pass  and  other  subscriptions,  Xbox  Cloud  Gaming,  third-party  disc royalties, advertising, and other cloud services

Search and news advertising revenue, excluding TAC, growth

Revenue from search and news advertising excluding traffic acquisition  costs  (-TAC‖)  paid  to  Bing  Ads  network  publishers  and news partners


## SUMMARY RESULTS OF OPERATIONS


| (In millions, except percentages and per share amounts)   | 2022      | 2021       | Percentage  Change   |
|-----------------------------------------------------------|-----------|------------|----------------------|
| Revenue                                                   | $ 198,270 | 168,088  $ | 18%                  |
| Gross margin                                              | 135,620   | 115,856    | 17%                  |
| Operating income                                          | 83,383    | 69,916     | 19%                  |
| Net income                                                | 72,738    | 61,271     | 19%                  |
| Diluted earnings per share                                | 9.65      | 8.05       | 20%                  |
| Adjusted net income (non-GAAP)                            | 69,447    | 60,651     | 15%                  |
| Adjusted diluted earnings per share (non-GAAP)            | 9.21      | 7.97       | 16%                  |


Adjusted net income and adjusted diluted earnings per share (-EPS‖) are non-GAAP financial measures which exclude the net income tax benefit related to transfer of intangible properties in the first quarter of fiscal year 2022 and the

---

# Page 36

net income tax benefit related to an India Supreme Court decision on withholding taxes in the third quarter of fiscal year 2021. Refer to the Non-GAAP Financial Measures section below for a reconciliation of our financial results reported in accordance with GAAP to non-GAAP financial results. See Note 12 - Income Taxes of the Notes to Financial Statements in our fiscal year 2022 Form 10-K for further discussion.


# Fiscal Year 2022 Compared with Fiscal Year 2021

Revenue  increased  $30.2 billion  or  18%  driven  by  growth  across  each  of  our  segments.  Intelligent  Cloud  revenue increased driven by Azure and other cloud services. Productivity and Business Processes revenue increased driven by Office  365  Commercial  and  LinkedIn.  More  Personal  Computing  revenue  increased  driven  by  Search  and  news advertising and Windows.

Cost of revenue increased $10.4 billion or 20% driven by growth in Microsoft Cloud.

Gross margin increased $19.8 billion or 17% driven by growth across each of our segments.


- · Gross  margin  percentage  decreased  slightly.  Excluding  the  impact  of  the  fiscal  year  2021  change  in accounting  estimate  for  the  useful  lives  of  our  server  and  network  equipment,  gross  margin  percentage increased 1 point driven by improvement in Productivity and Business Processes.
- · Microsoft Cloud gross margin percentage decreased slightly to 70%. Excluding the impact of the change in accounting  estimate,  Microsoft  Cloud  gross  margin  percentage  increased  3  points  driven  by  improvement across our cloud services, offset in part by sales mix shift to Azure and other cloud services.


Operating  expenses increased $6.3 billion  or  14%  driven  by  investments  in  cloud  engineering,  LinkedIn,  Gaming,  and commercial sales.


Key changes in operating expenses were:
- · Research  and  development  expenses  increased  $3.8 billion  or  18%  driven  by  investments  in  cloud engineering, Gaming, and LinkedIn.
- · Sales and marketing expenses increased $1.7 billion or 8% driven by investments in commercial sales and LinkedIn. Sales and marketing included a favorable foreign currency impact of 2%.
- · General  and  administrative  expenses  increased  $793 million  or  16%  driven  by  investments  in  corporate functions.


Operating income increased $13.5 billion or 19% driven by growth across each of our segments.

Current  year  net  income  and  diluted  EPS  were  positively  impacted  by  the  net  tax  benefit  related  to  the  transfer  of intangible properties, which resulted in an increase to net income and diluted EPS of $3.3 billion and $0.44, respectively. Prior year net income and diluted EPS were positively impacted by the net tax benefit related to the India Supreme Court decision on withholding taxes, which resulted in an increase to net income and diluted EPS of $620 million and $0.08, respectively.

Gross margin and operating income both included an unfavorable foreign currency impact of 2%.


## SEGMENT RESULTS OF OPERATIONS


| (In millions, except percentages)   | 2022        | 2021       | Percentage  Change   |
|-------------------------------------|-------------|------------|----------------------|
| Revenue                             |             |            |                      |
| Productivity and Business Processes | $ 63,364    | $  53,915  | 18%                  |
| Intelligent Cloud                   | 75,251      | 60,080     | 25%                  |
| More Personal Computing             | 59,655      | 54,093     | 10%                  |
| Total                               | $   198,270 | $  168,088 | 18%                  |
| Operating Income                    |             |            |                      |
| Productivity and Business Processes | $ 29,687    | $  24,351  | 22%                  |
| Intelligent Cloud                   | 32,721      | 26,126     | 25%                  |
| More Personal Computing             | 20,975      | 19,439     | 8%                   |
| Total                               | $ 83,383    | $  69,916  | 19%                  |

---

# Page 37

# Reportable Segments


## Fiscal Year 2022 Compared with Fiscal Year 2021


## Productivity and Business Processes

Revenue increased $9.4 billion or 18%.


- · Office Commercial  products  and  cloud  services  revenue  increased  $4.4 billion or 13%.  Office  365 Commercial  revenue  grew  18%  driven  by  seat  growth  of  14%,  with  continued  momentum  in  small  and medium business and frontline worker offerings, as well as growth in revenue per user. Office Commercial products revenue declined 22% driven by continued customer shift to cloud offerings.
- · Office Consumer products and cloud services revenue increased $641 million or 11% driven by Microsoft 365 Consumer subscription revenue. Microsoft 365 Consumer subscribers grew 15% to 59.7 million.
- · LinkedIn revenue increased $3.5 billion or 34% driven by a strong job market in our Talent Solutions business and advertising demand in our Marketing Solutions business.
- · Dynamics products and cloud services revenue increased 25% driven by Dynamics 365 growth of 39%.



## Operating income increased $5.3 billion or 22%.


- · Gross margin increased $7.3 billion or 17% driven by growth in Office 365 Commercial and LinkedIn. Gross margin percentage  was relatively  unchanged.  Excluding  the  impact  of  the  change  in  accounting  estimate, gross margin percentage increased 2 points driven by improvement across all cloud services.
- · Operating expenses increased $2.0 billion or 11% driven by investments in LinkedIn and cloud engineering.


Gross margin and operating income both included an unfavorable foreign currency impact of 2%.


## Intelligent Cloud


## Revenue increased $15.2 billion or 25%.


- · Server products and cloud services revenue increased $14.7 billion or 28% driven by Azure and other cloud services.  Azure  and  other  cloud  services  revenue  grew  45%  driven  by  growth  in  our  consumption-based services. Server products revenue increased 5% driven by hybrid solutions, including Windows Server and SQL Server running in multi-cloud environments.
- · Enterprise Services revenue increased $464 million or 7% driven by growth in Enterprise Support Services.



## Operating income increased $6.6 billion or 25%.


- · Gross margin increased $9.4 billion or 22% driven by growth in Azure and other cloud services. Gross margin percentage decreased. Excluding the impact of the change in accounting estimate, gross margin percentage was relatively unchanged driven by improvement in Azure and other cloud services, offset in part by sales mix shift to Azure and other cloud services.
- · Operating expenses increased $2.8 billion or 16% driven by investments in Azure and other cloud services.


Revenue and operating income included an unfavorable foreign currency impact of 2% and 3%, respectively.


## More Personal Computing


## Revenue increased $5.6 billion or 10%.


- · Windows  revenue  increased  $2.3 billion  or  10%  driven  by  growth  in  Windows  OEM  and  Windows Commercial.  Windows  OEM  revenue  increased  11%  driven  by  continued  strength  in  the  commercial  PC market, which has higher revenue per license. Windows Commercial products and cloud services revenue increased 11% driven by demand for Microsoft 365.

---

# Page 38

- · Search and news advertising revenue increased $2.3 billion or 25%. Search and news advertising revenue excluding traffic acquisition costs increased 27% driven by higher revenue per search and search volume.
- · Gaming revenue increased $860 million or 6% on a strong prior year comparable that benefited from Xbox Series X|S launches and stay-at-home scenarios, driven by growth in Xbox hardware and Xbox content and services.  Xbox  hardware  revenue  increased  16%  due  to  continued  demand  for  Xbox  Series  X|S.  Xbox content and services revenue increased 3% driven by growth in Xbox Game Pass subscriptions and firstparty content, offset in part by a decline in third-party content.
- · Surface revenue increased $226 million or 3%.



## Operating income increased $1.5 billion or 8%.


- · Gross margin increased $3.1 billion or 10% driven by growth in Windows and Search and news advertising. Gross margin percentage was relatively unchanged.
- · Operating  expenses  increased  $1.5 billion  or  14%  driven  by  investments  in  Gaming,  Search  and  news advertising, and Windows marketing.



## OPERATING EXPENSES


## Research and Development


| (In millions, except percentages)   | 2022      | 2021       | Percentage  Change   |
|-------------------------------------|-----------|------------|----------------------|
| Research and development            | $  24,512 | 20,716   $ | 18%                  |
| As a percent of revenue             | 12%       | 12%        | 0ppt                 |


Research and development expenses include payroll, employee benefits, stock-based compensation expense, and other headcount-related  expenses  associated  with  product  development.  Research  and  development  expenses  also  include third-party development and programming costs, localization costs incurred to translate software for international markets, and the amortization of purchased software code and services content.

Research and development expenses increased $3.8 billion or 18% driven by investments in cloud engineering, Gaming, and LinkedIn.


## Sales and Marketing


| (In millions, except percentages)   | 2022      | 2021       | Percentage  Change   |
|-------------------------------------|-----------|------------|----------------------|
| Sales and marketing                 | $  21,825 | 20,117   $ | 8%                   |
| As a percent of revenue             | 11%       | 12%        | (1)ppt               |


Sales  and  marketing  expenses  include  payroll,  employee  benefits,  stock-based  compensation  expense,  and  other headcount-related expenses associated with sales and marketing personnel, and the costs of advertising, promotions, trade shows, seminars, and other programs.

Sales  and  marketing  expenses  increased  $1.7 billion  or  8%  driven  by  investments  in  commercial  sales  and  LinkedIn. Sales and marketing included a favorable foreign currency impact of 2%.


## General and Administrative


| (In millions, except percentages)   | 2022     | 2021      | Percentage  Change   |
|-------------------------------------|----------|-----------|----------------------|
| General and administrative          | $  5,900 | 5,107   $ | 16%                  |
| As a percent of revenue             | 3%       | 3%        | 0ppt                 |

---

# Page 39

General and administrative expenses include payroll, employee benefits, stock-based compensation expense, and other headcount-related expenses associated with finance, legal, facilities, certain human resources and other administrative personnel, certain taxes, and legal and other administrative fees.

General and administrative expenses increased $793 million or 16% driven by investments in corporate functions.


# OTHER INCOME (EXPENSE), NET


The components of other income (expense), net were as follows:
| (In millions)                                                                            |                |                  |
|------------------------------------------------------------------------------------------|----------------|------------------|
| Year Ended June 30, Interest and dividends income                                        | 2022 $   2,094 | 2021 $     2,131 |
|                                                                                          | (2,063)        |                  |
| Interest expense                                                                         |                | (2,346)          |
| Net recognized gains on investments                                                      | 461            | 1,232            |
| Net gains (losses) on derivatives  Net gains (losses) on foreign currency remeasurements | (52) (75)      | 17   54          |
| Other, net                                                                               |                |                  |
|                                                                                          | (32)           | 98               |
| Total                                                                                    | $ 333          | $  1,186         |


We use derivative  instruments  to  manage  risks  related  to  foreign  currencies,  equity  prices,  interest  rates,  and  credit; enhance  investment  returns;  and  facilitate  portfolio  diversification.  Gains  and  losses  from  changes  in  fair  values  of derivatives that are not designated as hedging instruments are primarily recognized in other income (expense), net.

Interest and dividends income decreased due to lower portfolio balances. Interest expense decreased due to a decrease in  outstanding  long-term debt due to debt maturities. Net recognized gains on investments decreased primarily due to lower gains on equity securities.


## INCOME TAXES


## Effective Tax Rate

Our effective tax rate for fiscal years 2022 and 2021 was 13% and 14%, respectively. The decrease in our effective tax rate was primarily due to a $3.3 billion net income tax benefit in the first quarter of fiscal year 2022 related to the transfer of intangible properties, offset in part by changes in the mix of our income before income taxes between the U.S. and foreign countries, as well as tax benefits in the prior year from the India Supreme Court decision on withholding taxes in the case of Engineering Analysis Centre of Excellent Private Limited vs The Commissioner of Income Tax, an agreement between  the  U.S.  and  India  tax  authorities  related  to  transfer  pricing,  and  final  Tax  Cuts  and  Jobs  Act  (-TCJA‖) regulations.

In the first quarter of fiscal year 2022, we transferred certain intangible properties from our Puerto Rico subsidiary to the U.S. The transfer of intangible properties resulted in a $3.3 billion net income tax benefit in the first quarter of fiscal year 2022, as the value of future U.S. tax deductions exceeds the current tax liability from the U.S. global intangible low-taxed income tax.

We  have  historically  paid  India  withholding  taxes  on  software  sales  through  distributor  withholding  and  tax  audit assessments in India. In March 2021, the India Supreme Court ruled favorably for companies in 86 separate appeals, some dating back to 2012, holding that software sales are not subject to India withholding taxes. Although we were not a party to the appeals, our software sales in India were determined to be not subject to withholding taxes. Therefore, we recorded a net income tax benefit of $620 million in the third quarter of fiscal year 2021 to reflect the results of the India Supreme Court decision impacting fiscal year 1996 through fiscal year 2016.

Our effective tax rate was lower than the U.S. federal statutory rate, primarily due to the net income tax benefit related to the  transfer  of  intangible  properties,  earnings  taxed  at  lower  rates  in  foreign  jurisdictions  resulting  from  producing  and distributing our products and services through our foreign regional operations center in Ireland, and tax benefits relating to stock-based compensation.

---

# Page 40

The mix of income before income taxes between the U.S. and foreign countries impacted our effective tax rate as a result of  the  geographic  distribution  of,  and  customer  demand  for,  our  products  and  services.  In  fiscal  year  2022,  our  U.S. income before income taxes was $47.8 billion and our foreign income before income taxes was $35.9 billion. In fiscal year 2021,  our  U.S.  income  before  income  taxes  was  $35.0 billion  and  our  foreign  income  before  income  taxes  was $36.1 billion.


# Uncertain Tax Positions

We settled  a  portion  of  the  Internal  Revenue  Service  (-IRS‖)  audit  for  tax  years  2004  to  2006  in  fiscal  year  2011.  In February 2012, the IRS withdrew its 2011 Revenue Agents Report related to unresolved issues for tax years 2004 to 2006 and reopened the audit phase of the examination. We also settled a portion of the IRS audit for tax years 2007 to 2009 in fiscal year 2016, and a portion of the IRS audit for tax years 2010 to 2013 in fiscal year 2018. In the second quarter of fiscal year 2021, we settled an additional portion of the IRS audits for tax years 2004 to 2013 and made a payment of $1.7 billion, including tax and interest. We remain under audit for tax years 2004 to 2017.

As  of  June 30,  2022,  the  primary  unresolved  issues  for  the  IRS  audits  relate  to  transfer  pricing,  which  could  have  a material impact in our consolidated financial statements when the matters are resolved. We believe our allowances for income tax contingencies are adequate. We have not received a proposed assessment for the unresolved key transfer pricing  issues  and  do  not  expect  a  final  resolution  of  these  issues  in  the  next  12  months. Based  on  the  information currently available, we do not anticipate a significant increase or decrease to our tax contingencies for these issues within the next 12 months.

We are subject to income tax in many jurisdictions outside the U.S. Our operations in certain jurisdictions remain subject to examination for tax years 1996 to 2021, some of which are currently under audit by local tax authorities. The resolution of each of these audits is not expected to be material to our consolidated financial statements.


## NON-GAAP FINANCIAL MEASURES

Adjusted  net  income  and  adjusted  diluted  EPS  are  non-GAAP  financial  measures  which  exclude  the  net tax  benefit related to the transfer of intangible properties in the first quarter of fiscal year 2022 and the net income tax benefit related to an India Supreme Court decision on withholding taxes in the third quarter of fiscal year 2021. We believe these nonGAAP measures aid investors  by  providing  additional  insight  into  our  operational  performance  and  help  clarify  trends affecting our business. For comparability of reporting, management considers non-GAAP measures in conjunction with GAAP financial results in evaluating business performance. These non-GAAP financial measures presented should not be considered a substitute for, or superior to, the measures of financial performance prepared in accordance with GAAP.


The following table reconciles our financial results reported in accordance with GAAP to non-GAAP financial results:
| (In millions, except percentages and per share amounts)                             | 2022      | 2021      | Percentage  Change   |
|-------------------------------------------------------------------------------------|-----------|-----------|----------------------|
| Net income                                                                          | $  72,738 | $  61,271 | 19%                  |
| Net income tax benefit related to transfer of intangible properties                 | (3,291)   | 0         | *                    |
| Net income tax benefit related to India Supreme Court decision on withholding taxes | 0         | (620)     | *                    |
| Adjusted net income (non-GAAP)                                                      | $ 69,447  | $  60,651 | 15%                  |
| Diluted earnings per share                                                          | $ 9.65    | $  8.05   | 20%                  |
| Net income tax benefit related to transfer of intangible properties                 | (0.44)    | 0         | *                    |
| Net income tax benefit related to India Supreme Court decision on withholding taxes | 0         | (0.08)    | *                    |
| Adjusted diluted earnings per share (non-GAAP)                                      | $ 9.21    | $  7.97   | 16%                  |
* Not meaningful.

---

# Page 41

# LIQUIDITY AND CAPITAL RESOURCES

We expect existing cash, cash equivalents, short-term investments, cash flows from operations,  and  access to capital markets to continue to be  sufficient to fund  our  operating activities  and  cash  commitments for  investing  and  financing activities,  such  as  dividends,  share  repurchases,  debt  maturities,  material  capital  expenditures,  and  the  transition  tax related to the TCJA, for at least the next 12 months and thereafter for the foreseeable future.


## Cash, Cash Equivalents, and Investments

Cash,  cash  equivalents,  and  short-term  investments  totaled  $104.8 billion  and  $130.3 billion  as  of  June 30,  2022  and 2021, respectively. Equity investments were $6.9 billion and $6.0 billion as of June 30, 2022 and 2021, respectively. Our short-term investments are primarily intended to facilitate liquidity and capital preservation. They consist predominantly of highly liquid investment-grade fixed-income securities, diversified among  industries and  individual issuers. The investments  are  predominantly  U.S.  dollar-denominated  securities,  but  also  include  foreign  currency-denominated securities to diversify risk. Our fixed-income investments are exposed to interest rate risk and credit risk. The credit risk and  average  maturity  of  our  fixed-income  portfolio  are  managed  to  achieve  economic  returns  that  correlate  to  certain fixed-income  indices.  The  settlement  risk  related  to  these  investments  is  insignificant  given  that  the  short-term investments held are primarily highly liquid investment-grade fixed-income securities.


## Valuation

In general, and where applicable, we use quoted prices in active markets for identical assets or liabilities to determine the fair  value  of  our  financial  instruments.  This  pricing  methodology  applies  to  our  Level 1  investments,  such  as  U.S. government securities, common and preferred stock, and mutual funds. If quoted prices in active markets for identical assets or liabilities are not available to determine fair value, then we use quoted prices for similar assets and liabilities or inputs other than the quoted prices that are observable either directly or indirectly. This pricing methodology applies to our Level 2 investments, such as commercial paper, certificates of deposit, U.S. agency securities, foreign government bonds, mortgage- and asset-backed securities, corporate notes and bonds, and municipal securities. Level 3 investments  are valued  using  internally-developed  models  with  unobservable  inputs.  Assets  and  liabilities  measured  at  fair  value  on  a recurring basis using unobservable inputs are an immaterial portion of our portfolio.

A majority of our investments are priced by pricing vendors and are generally Level 1 or Level 2 investments as these vendors  either  provide  a  quoted  market  price  in  an  active  market  or  use  observable  inputs  for  their  pricing  without applying significant adjustments. Broker pricing is used mainly when a quoted price is not available, the investment is not priced by our pricing vendors, or when a broker price is more reflective of fair values in the market in which the investment trades. Our broker-priced investments are generally classified as Level 2 investments because the broker prices these investments  based  on  similar  assets  without  applying  significant  adjustments.  In  addition,  all our broker-priced investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments. Our fair value processes include controls that are designed to ensure appropriate fair values are recorded. These  controls  include  model  validation,  review  of  key  model  inputs,  analysis  of  period-over-period  fluctuations,  and independent recalculation of prices where appropriate.


## Cash Flows

Cash  from  operations  increased  $12.3 billion  to  $89.0 billion  for  fiscal  year  2022,  mainly  due  to  an  increase  in  cash received from customers, offset in part by an increase in cash paid to suppliers and employees. Cash used in financing increased  $10.4 billion  to  $58.9 billion  for  fiscal  year  2022,  mainly  due  to  a  $5.3 billion  increase  in  common  stock repurchases  and  a  $5.3 billion  increase  in  repayments  of  debt.  Cash  used  in  investing  increased  $2.7 billion  to $30.3 billion for fiscal year 2022, mainly due to a $13.1 billion increase in cash used for acquisitions of companies, net of cash  acquired,  and  purchases  of  intangible  and  other  assets,  and  a  $3.3 billion  increase  in  additions  to  property  and equipment, offset in part by a $15.6 billion increase in cash from net investment purchases, sales, and maturities.

---

# Page 42

# Debt Proceeds

We issue debt to take advantage of favorable pricing and liquidity in the debt markets, reflecting our credit rating and the low  interest  rate  environment.  The  proceeds  of  these  issuances  were  or  will  be  used  for  general  corporate  purposes, which may include, among other things, funding for working capital, capital expenditures, repurchases of capital stock, acquisitions, and repayment of existing debt. In March 2021 and June 2020, we exchanged a portion of our existing debt at  a  premium for  cash  and  new  debt  with  longer  maturities  to  take  advantage  of  favorable  financing  rates  in  the  debt markets,  reflecting  our  credit  rating  and  the  low  interest  rate  environment.  Refer  to  Note  11  -  Debt  of  the  Notes  to Financial Statements in our fiscal year 2022 Form 10-K for further discussion.


## Unearned Revenue

Unearned  revenue  comprises  mainly  unearned  revenue  related  to  volume  licensing  programs,  which  may  include Software Assurance (-SA‖) and cloud services. Unearned revenue is generally invoiced annually at the beginning of each contract  period  for  multi-year  agreements  and  recognized  ratably  over  the  coverage  period.  Unearned  revenue  also includes payments for other offerings for which we have been paid in advance and earn the revenue when we transfer control of the product or service. Refer to Note 1 - Accounting Policies of the Notes to Financial Statements in our fiscal year 2022 Form 10-K for further discussion.


The following table outlines the expected future recognition of unearned revenue as of June 30, 2022:
| (In millions)       |           |
|---------------------|-----------|
| Three Months Ending |           |
| September 30, 2022  | $  17,691 |
| December 31, 2022   | 13,923    |
| March 31, 2023      | 9,491     |
| June 30, 2023       | 4,433     |
| Thereafter          | 2,870     |
| Total               | $ 48,408  |


If  our customers choose to license cloud-based versions of our products and services rather than licensing transactionbased products and services, the associated revenue will shift from being recognized at the time of the transaction to being recognized over the subscription period or upon consumption, as applicable.


## Material Cash Requirements and Other Obligations


## Contractual Obligations


The following table summarizes the payments due by fiscal year for our outstanding contractual obligations as of June 30, 2022:
| (In millions)                                                 | 2023       | Thereafter   | Total      |
|---------------------------------------------------------------|------------|--------------|------------|
| Long-term debt:  (a)                                          |            |              |            |
| Principal payments                                            | $ 2,750    | $ 52,761     | $ 55,511   |
| Interest payments                                             | 1,468      | 21,139       | 22,607     |
| Construction commitments  (b)                                 | 7,942      | 576          | 8,518      |
| Operating and finance leases, including imputed interest  (c) | 4,609      | 44,045       | 48,654     |
| Purchase commitments  (d)                                     | 42,669     | 2,985        | 45,654     |
| Total                                                         | $   59,438 | $  121,506   | $  180,944 |

---

# Page 43

- (a) Refer to Note 11 - Debt of the Notes to Financial Statements in our fiscal year 2022 Form 10-K.
- (b) Refer to Note 7 - Property and Equipment of the Notes to Financial Statements in our fiscal year 2022 Form 10-K.
- (c) Refer to Note 14 - Leases of the Notes to Financial Statements in our fiscal year 2022 Form 10-K.
- (d) Purchase commitments primarily relate to datacenters and include open purchase orders and take-or-pay contracts that are not presented as construction commitments above.



## Income Taxes

As a result of the TCJA, we are required to pay a one-time transition tax on deferred foreign income not previously subject to U.S. income tax. Under the TCJA, the transition tax is payable in interest-free installments over eight years, with 8% due in each of the first five years, 15% in year six, 20% in year seven, and 25% in year eight. We have paid transition tax of $6.2 billion, which included $1.5 billion for fiscal year 2022. The remaining transition tax of $12.0 billion is payable over the next four years, with $1.3 billion payable within 12 months.

Provisions enacted in the TCJA related to the capitalization for tax purposes of research and experimental expenditures became effective on July 1, 2022. These provisions require us to capitalize research and experimental expenditures and amortize  them  on  the  U.S.  tax  return  over  five  or  fifteen  years,  depending  on  where  research  is  conducted.  The  final foreign  tax  credit  regulations,  also  effective  on  July 1,  2022,  introduced  significant  changes  to  foreign  tax  credit calculations in the U.S. tax return. While these provisions are not expected to have a material impact on our fiscal year 2023 effective tax rate on a net basis, our cash paid for taxes would increase unless these provisions are postponed or modified through legislative processes.


## Share Repurchases

During fiscal  years 2022 and 2021, we repurchased 95 million shares and 101 million shares of our common stock for $28.0 billion and $23.0 billion, respectively, through our share repurchase programs. All repurchases were made using cash resources. As of June 30, 2022, $40.7 billion remained of our $60 billion share repurchase program. Refer to Note 16 - Stockholders' Equity of the Notes to Financial Statements in our fiscal year 2022 Form 10-K for further discussion.


## Dividends

During fiscal year 2022, our Board of Directors declared quarterly dividends of $0.62 per share. We intend to continue returning capital to shareholders in the form of dividends, subject to declaration by our Board of Directors. Refer to Note 16 - Stockholders' Equity of the Notes to Financial Statements in our fiscal year 2022 Form 10-K for further discussion.


## Other Planned Uses of Capital

On January 18, 2022, we entered into a definitive agreement to acquire Activision Blizzard, Inc. (-Activision Blizzard‖) for $95.00  per  share  in  an  all-cash  transaction  valued  at  $68.7 billion,  inclusive  of  Activision  Blizzard's  net  cash.  The acquisition has been approved by Activision Blizzard's shareholders, and we expect it to close in fiscal year 2023, subject to the satisfaction of certain regulatory approvals and other customary closing conditions.

We  will  continue  to  invest  in  sales,  marketing,  product  support  infrastructure,  and  existing  and  advanced  areas  of technology,  as  well  as  continue  making  acquisitions  that  align  with  our  business  strategy.  Additions  to  property  and equipment will continue, including new facilities, datacenters, and computer systems for research and development, sales and marketing, support, and administrative staff. We expect capital expenditures to increase in coming years to support growth  in  our  cloud  offerings.  We  have  operating  and  finance  leases  for  datacenters,  corporate  offices,  research  and development facilities, Microsoft Experience Centers, and certain equipment. We have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of capital resources.

---

# Page 44

# RECENT ACCOUNTING GUIDANCE

Refer to Note 1 - Accounting Policies of the Notes to Financial Statements in our fiscal year 2022 Form 10-K for further discussion.


## CRITICAL ACCOUNTING ESTIMATES

Our  consolidated  financial  statements  and  accompanying  notes  are  prepared  in  accordance  with  GAAP.  Preparing consolidated  financial  statements  requires  management  to  make  estimates  and  assumptions  that  affect  the  reported amounts of assets, liabilities,  revenue,  and  expenses.  Critical  accounting  estimates  are  those  estimates  that  involve  a significant  level  of  estimation  uncertainty  and  could  have  a  material  impact  on  our  financial  condition  or  results  of operations.  We  have  critical  accounting  estimates  in  the  areas  of  revenue  recognition,  impairment  of  investment securities, goodwill, research and development costs, legal and other contingencies, income taxes, and inventories.


## Revenue Recognition

Our  contracts  with  customers  often  include  promises  to  transfer  multiple  products  and  services  to  a  customer. Determining whether products and services are considered distinct performance obligations that should be accounted for separately  versus  together  may  require  significant  judgment.  When  a  cloud-based  service  includes  both  on-premises software  licenses  and  cloud  services,  judgment  is  required  to  determine  whether  the  software  license  is  considered distinct and accounted for separately, or not distinct and accounted for together with the cloud service and recognized over time. Certain cloud services, primarily Office 365, depend on a significant level of integration, interdependency, and interrelation  between the desktop applications and cloud services, and are accounted for together as one performance obligation. Revenue from Office 365 is recognized ratably over the period in which the cloud services are provided.

Judgment is required to determine the stand-alone selling price (-SSP‖) for each distinct performance obligation. We use a single amount to estimate SSP for items that are not sold separately, including on-premises licenses sold with SA or software updates provided at no additional charge. We use a range of amounts to estimate SSP when we sell each of the products and services separately and need to determine whether there is a discount to be allocated based on the relative SSP of the various products and services.

In instances where SSP is not directly observable, such as when we do not sell the product or service separately, we determine the SSP using information that may include market conditions and other observable inputs. We typically have more  than  one  SSP  for  individual  products  and  services  due  to  the  stratification  of  those  products  and  services  by customers  and  circumstances.  In  these  instances,  we  may  use  information  such  as  the  size  of  the  customer  and geographic region in determining the SSP.

Due to the various benefits from and the nature of our SA program, judgment is required to assess the pattern of delivery, including the exercise pattern of certain benefits across our portfolio of customers.

Our products are generally sold with a right of return, we may provide other credits or incentives, and in certain instances we  estimate  customer  usage  of  our  products  and  services,  which  are  accounted  for  as  variable  consideration  when determining the amount of revenue to recognize. Returns and credits are estimated at contract inception and updated at the  end  of  each  reporting  period  if  additional  information  becomes  available.  Changes  to  our  estimated  variable consideration were not material for the periods presented.


## Impairment of Investment Securities

We review debt investments quarterly for credit losses and impairment. If the cost of an investment exceeds its fair value, we evaluate, among other factors, general market conditions, credit quality of debt instrument issuers, and the extent to which the fair value is less than cost. This determination requires significant judgment. In making this

---

# Page 45

judgment,  we  employ  a  systematic  methodology  that  considers  available  quantitative  and  qualitative  evidence  in evaluating  potential  impairment  of  our  investments.  In  addition,  we  consider  specific  adverse  conditions  related  to  the financial health of, and business outlook for, the investee. If we have plans to sell the security or it is more likely than not that  we  will  be  required  to  sell  the  security  before  recovery,  then  a  decline  in  fair  value  below  cost  is  recorded  as  an impairment  charge  in  other  income  (expense),  net  and  a  new  cost  basis  in  the  investment  is  established.  If  market, industry, and/or investee conditions deteriorate, we may incur future impairments.

Equity  investments  without  readily  determinable  fair  values  are  written  down  to  fair  value  if  a  qualitative  assessment indicates that the investment is impaired and the fair value of the investment is less than carrying value. We perform a qualitative assessment on a periodic basis. We are required to estimate the fair value of the investment to determine the amount of the impairment loss. Once an investment is determined to be impaired, an impairment charge is recorded in other income (expense), net.


# Goodwill

We allocate goodwill to reporting units based on the reporting unit expected to benefit from the business combination. We evaluate our reporting units on an annual basis and, if necessary, reassign goodwill using a relative fair value allocation approach. Goodwill is tested for impairment at the reporting unit level (operating segment or one level below an operating segment) on an annual basis (May 1 for us) and between annual tests if an event occurs or circumstances change that would  more  likely  than  not  reduce  the  fair  value  of  a  reporting  unit  below  its  carrying  value.  These  events  or circumstances could include a significant change in the business climate, legal factors, operating performance indicators, competition, or sale or disposition of a significant portion of a reporting unit.

Application of the goodwill impairment test requires judgment, including the identification of reporting units, assignment of assets and liabilities to reporting units, assignment of goodwill to reporting units, and determination of the fair value of each reporting unit. The fair value of each reporting unit is estimated primarily through the use of a discounted cash flow methodology. This analysis requires significant judgments, including estimation of future cash flows, which is dependent on internal forecasts, estimation of the long-term rate of growth for our business, estimation of the useful life over which cash flows will occur, and determination of our weighted average cost of capital.

The estimates used to calculate the fair value of a reporting unit change from year to year based on operating results, market  conditions,  and  other  factors.  Changes  in  these  estimates  and  assumptions  could  materially  affect  the determination of fair value and goodwill impairment for each reporting unit.


## Research and Development Costs

Costs  incurred  internally  in  researching  and  developing  a  computer  software  product  are  charged  to  expense  until technological feasibility has been established for the product. Once technological feasibility is established, software costs are capitalized until the product is available for general release to customers. Judgment is required in determining when technological  feasibility  of  a  product  is  established.  We  have  determined  that  technological  feasibility  for  our  software products is reached after all high-risk development issues have been resolved through coding and testing. Generally, this occurs  shortly  before  the  products  are  released  to  production.  The  amortization  of  these  costs  is  included  in  cost  of revenue over the estimated life of the products.


## Legal and Other Contingencies

The outcomes of legal proceedings and claims brought against us are subject to significant uncertainty. An estimated loss from a loss contingency such as a legal proceeding or claim is accrued by  a charge to income if it is probable that an asset  has  been  impaired  or  a  liability  has  been  incurred  and  the  amount  of  the  loss  can  be  reasonably  estimated.  In determining  whether  a  loss  should  be  accrued  we  evaluate,  among  other  factors,  the  degree  of  probability  of  an unfavorable outcome and the ability to make a reasonable estimate of the amount of loss. Changes in these factors could materially impact our consolidated financial statements.

---

# Page 46

# Income Taxes

The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year, and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity's financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely  than  not  that  the  tax  position  will  be  sustained  on  examination  by  the  taxing  authorities,  based  on  the  technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required  in  assessing  the  future  tax  consequences  of  events  that  have  been  recognized  in  our  consolidated  financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our consolidated financial statements.


## Inventories

Inventories are stated at average cost, subject to the lower of cost or net realizable value. Cost includes materials, labor, and manufacturing overhead related to the purchase and production of inventories. Net realizable value is the estimated selling price less estimated costs of completion, disposal, and transportation. We regularly review inventory quantities on hand, future purchase commitments with our suppliers, and the estimated utility of our inventory. These reviews include analysis of demand forecasts, product life cycle status, product development plans, current sales levels, pricing strategy, and component cost trends. If our review indicates a reduction in utility below carrying value, we reduce our inventory to a new cost basis through a charge to cost of revenue.


## CHANGE IN ACCOUNTING ESTIMATE

In July 2022, we completed an assessment of the useful lives of our server and network equipment. Due to investments in software  that  increased  efficiencies  in  how  we  operate  our  server  and  network  equipment,  as  well  as  advances  in technology, we determined we should increase the estimated useful lives of both server and network equipment from four years to six years. This change in accounting estimate will be effective beginning fiscal year 2023. Based on the carrying amount of server and network equipment included in property and equipment, net as of June 30, 2022, it is estimated this change will increase our fiscal year 2023 operating income by $3.7 billion. We had previously increased the estimated useful lives of both server and network equipment in July 2020.

---

# Page 47

# STATEMENT OF MANAGEMENT'S RESPONSIBILITY FOR FINANCIAL STATEMENTS

Management is responsible for the preparation of the consolidated financial statements and related information that are presented in this report. The consolidated financial statements, which include amounts based on management's estimates and judgments, have been prepared in conformity with accounting principles generally accepted in the United States of America.

The  Company  designs  and  maintains  accounting  and  internal  control  systems  to  provide  reasonable  assurance  at reasonable cost that  assets  are  safeguarded  against  loss  from  unauthorized  use  or  disposition,  and  that  the  financial records  are  reliable  for  preparing  consolidated  financial  statements  and  maintaining  accountability  for  assets.  These systems  are  augmented  by  written  policies,  an  organizational  structure  providing  division  of  responsibilities,  careful selection and training of qualified personnel, and a program of internal audits.

The Company engaged Deloitte & Touche LLP, an independent registered public accounting firm, to audit and render an opinion  on  the  consolidated  financial  statements  and  internal  control  over  financial  reporting  in  accordance  with  the standards of the Public Company Accounting Oversight Board (United States).

The Board of Directors, through its Audit Committee, consisting solely of independent directors of the Company, meets periodically  with  management,  internal  auditors,  and  our  independent  registered  public  accounting  firm  to  ensure  that each is meeting its responsibilities and to discuss matters concerning internal controls and financial reporting. Deloitte & Touche LLP and the internal auditors each have full and free access to the Audit Committee.

Satya Nadella Chief Executive Officer

Amy E. Hood

Executive Vice President and Chief Financial Officer

Alice L. Jolla

Corporate Vice President and Chief Accounting Officer

---

# Page 48

# QUANTITATIVE AND QUALITATIVE DISCLOSURES ABOUT MARKET RISK


## RISKS

We are  exposed  to  economic  risk  from  foreign  exchange  rates,  interest  rates,  credit  risk,  and  equity  prices.  We  use derivatives instruments to manage these risks, however, they may still impact our consolidated financial statements.


## Foreign Currencies

Certain  forecasted  transactions,  assets,  and  liabilities  are  exposed  to  foreign  currency  risk.  We  monitor  our  foreign currency  exposures  daily  to  maximize  the  economic  effectiveness  of  our  foreign  currency  positions,  including  hedges. Principal currency exposures include the Euro, Japanese yen, British pound, Canadian dollar, and Australian dollar.


## Interest Rate

Securities  held  in  our  fixed-income  portfolio  are  subject  to  different  interest  rate  risks  based  on  their  maturities.  We manage the average maturity of the fixed-income portfolio to achieve economic returns that correlate to certain global fixed-income indices.


## Credit

Our  fixed-income  portfolio  is  diversified  and  consists  primarily  of  investment-grade  securities.  We  manage  credit exposures relative to broad-based indices and to facilitate portfolio diversification.


## Equity

Securities held in our equity investments portfolio are subject to price risk.


## SENSITIVITY ANALYSIS

The following table sets forth the potential loss in future earnings or fair values, including associated derivatives, resulting from hypothetical changes in relevant market rates or prices:

(In millions)


| Risk Categories                | Hypothetical Change                                       | June 30, 2022   | Impact     |
|--------------------------------|-----------------------------------------------------------|-----------------|------------|
| Foreign currency - Revenue     | 10% decrease in foreign exchange rates                    | $  (6,822)      | Earnings   |
| Foreign currency - Investments | 10% decrease in foreign exchange rates                    | (94)            | Fair Value |
| Interest rate                  | 100 basis point increase in U.S. treasury  interest rates | (2,536)         | Fair Value |
| Credit                         | 100 basis point increase in credit spreads                | (350)           | Fair Value |
| Equity                         | 10% decrease in equity market prices                      | (637)           | Earnings   |

---

# Page 49

# FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA


## INCOME STATEMENTS


| (In millions, except per share amounts)   |             |           |           |
|-------------------------------------------|-------------|-----------|-----------|
| Year Ended June 30,                       | 2022        | 2021      | 2020      |
| Revenue:                                  |             |           |           |
| Product                                   | $    72,732 | 71,074  $ | 68,041  $ |
| Service and other                         | 125,538     | 97,014    | 74,974    |
| Total revenue                             | 198,270     | 168,088   | 143,015   |
| Cost of revenue:                          |             |           |           |
| Product                                   | 19,064      | 18,219    | 16,017    |
| Service and other                         | 43,586      | 34,013    | 30,061    |
| Total cost of revenue                     | 62,650      | 52,232    | 46,078    |
| Gross margin                              | 135,620     | 115,856   | 96,937    |
| Research and development                  | 24,512      | 20,716    | 19,269    |
| Sales and marketing                       | 21,825      | 20,117    | 19,598    |
| General and administrative                | 5,900       | 5,107     | 5,111     |
| Operating income                          | 83,383      | 69,916    | 52,959    |
| Other income, net                         | 333         | 1,186     | 77        |
| Income before income taxes                | 83,716      | 71,102    | 53,036    |
| Provision for income taxes                | 10,978      | 9,831     | 8,755     |
| Net income                                | $ 72,738    | $ 61,271  | $ 44,281  |
| Earnings per share:                       |             |           |           |
| Basic                                     | $ 9.70      | $ 8.12    | $ 5.82    |
| Diluted                                   | $ 9.65      | $ 8.05    | $ 5.76    |
| Weighted average shares outstanding:      |             |           |           |
| Basic                                     | 7,496       | 7,547     | 7,610     |
| Diluted                                   | 7,540       | 7,608     | 7,683     |


Refer to accompanying notes.

---

# Page 50

# COMPREHENSIVE INCOME STATEMENTS


|                                                | (In millions)   | (In millions)   | (In millions)   |
|------------------------------------------------|-----------------|-----------------|-----------------|
| Year Ended June 30,                            | 2022            | 2021            | 2020            |
| Net income                                     | $  72,738       | $  61,271       | $   44,281      |
| Other comprehensive income (loss), net of tax: |                 |                 |                 |
| Net change related to derivatives              | 6               | 19              | (38)            |
| Net change related to investments              | (5,360)         | (2,266)         | 3,990           |
| Translation adjustments and other              | (1,146)         | 873             | (426)           |
| Other comprehensive income (loss)              | (6,500)         | (1,374)         | 3,526           |
| Comprehensive income                           | $ 66,238        | $  59,897       | $  47,807       |


Refer to accompanying notes.

---

# Page 51

# BALANCE SHEETS

(In millions)


| June 30,                                                                                   | 2022         | 2021      |
|--------------------------------------------------------------------------------------------|--------------|-----------|
| Assets                                                                                     |              |           |
| Current assets:                                                                            |              |           |
| Cash and cash equivalents                                                                  | $ 13,931     | $  14,224 |
| Short-term investments                                                                     | 90,826       | 116,110   |
| Total cash, cash equivalents, and short-term investments                                   | 104,757      | 130,334   |
| Accounts receivable, net of allowance for doubtful accounts of  $633  and $751             | 44,261       | 38,043    |
| Inventories                                                                                | 3,742        | 2,636     |
| Other current assets                                                                       | 16,924       | 13,393    |
| Total current assets                                                                       | 169,684      | 184,406   |
| Property and equipment, net of accumulated depreciation of  $59,660  and $51,351           | 74,398       | 59,715    |
| Operating lease right-of-use assets                                                        | 13,148       | 11,088    |
| Equity investments                                                                         | 6,891        | 5,984     |
| Goodwill                                                                                   | 67,524       | 49,711    |
| Intangible assets, net                                                                     | 11,298       | 7,800     |
| Other long-term assets                                                                     | 21,897       | 15,075    |
| Total assets                                                                               | $    364,840 | $ 333,779 |
| Liabilities and stockholders' equity                                                       |              |           |
| Current liabilities:                                                                       |              |           |
| Accounts payable                                                                           | $ 19,000     | $  15,163 |
| Current portion of long-term debt                                                          | 2,749        | 8,072     |
| Accrued compensation                                                                       | 10,661       | 10,057    |
| Short-term income taxes                                                                    | 4,067        | 2,174     |
| Short-term unearned revenue                                                                | 45,538       | 41,525    |
| Other current liabilities                                                                  | 13,067       | 11,666    |
| Total current liabilities                                                                  | 95,082       | 88,657    |
| Long-term debt                                                                             | 47,032       | 50,074    |
| Long-term income taxes                                                                     | 26,069       | 27,190    |
| Long-term unearned revenue                                                                 | 2,870        | 2,616     |
| Deferred income taxes                                                                      | 230          | 198       |
| Operating lease liabilities                                                                | 11,489       | 9,629     |
| Other long-term liabilities                                                                | 15,526       | 13,427    |
| Total liabilities                                                                          | 198,298      | 191,791   |
| Commitments and contingencies                                                              |              |           |
| Stockholders' equity:                                                                      |              |           |
| Common stock and paid-in capital - shares authorized 24,000; outstanding  7,464  and 7,519 | 86,939       | 83,111    |
| Retained earnings                                                                          | 84,281       | 57,055    |
| Accumulated other comprehensive income (loss)                                              | (4,678)      | 1,822     |
| Total stockholders' equity                                                                 | 166,542      | 141,988   |
| Total liabilities and stockholders' equity                                                 | $ 364,840    | $ 333,779 |


Refer to accompanying notes.

---

# Page 52

# CASH FLOWS STATEMENTS

(In millions)


| Year Ended June 30,                                                                            | 2022       | 2021       | 2020       |
|------------------------------------------------------------------------------------------------|------------|------------|------------|
| Operations                                                                                     |            |            |            |
| Net income                                                                                     | $   72,738 | $   61,271 | $   44,281 |
| Adjustments to reconcile net income to net cash from operations:                               |            |            |            |
| Depreciation, amortization, and other                                                          | 14,460     | 11,686     | 12,796     |
| Stock-based compensation expense                                                               | 7,502      | 6,118      | 5,289      |
| Net recognized gains on investments and derivatives                                            | (409)      | (1,249)    | (219  )    |
| Deferred income taxes                                                                          | (5,702)    | (150)      | 11         |
| Changes in operating assets and liabilities:                                                   |            |            |            |
| Accounts receivable                                                                            | (6,834)    | (6,481)    | (2,577  )  |
| Inventories                                                                                    | (1,123)    | (737)      | 168        |
| Other current assets                                                                           | (709)      | (932)      | (2,330  )  |
| Other long-term assets                                                                         | (2,805)    | (3,459)    | (1,037  )  |
| Accounts payable                                                                               | 2,943      | 2,798      | 3,018      |
| Unearned revenue                                                                               | 5,109      | 4,633      | 2,212      |
| Income taxes                                                                                   | 696        | (2,309)    | (3,631  )  |
| Other current liabilities                                                                      | 2,344      | 4,149      | 1,346      |
| Other long-term liabilities                                                                    | 825        | 1,402      | 1,348      |
| Net cash from operations                                                                       | 89,035     | 76,740     | 60,675     |
| Financing                                                                                      |            |            |            |
| Cash premium on debt exchange                                                                  | 0          | (1,754)    | (3,417  )  |
| Repayments of debt                                                                             | (9,023)    | (3,750)    | (5,518  )  |
| Common stock issued                                                                            | 1,841      | 1,693      | 1,343      |
| Common stock repurchased                                                                       | (32,696)   | (27,385)   | (22,968  ) |
| Common stock cash dividends paid                                                               | (18,135)   | (16,521)   | (15,137  ) |
| Other, net                                                                                     | (863)      | (769)      | (334  )    |
| Net cash used in financing                                                                     | (58,876)   | (48,486)   | (46,031  ) |
| Investing                                                                                      |            |            |            |
| Additions to property and equipment                                                            | (23,886)   | (20,622)   | (15,441  ) |
| Acquisition of companies, net of cash acquired, and purchases of   intangible and other assets | (22,038)   | (8,909)    | (2,521  )  |
| Purchases of investments                                                                       | (26,456)   | (62,924)   | (77,190  ) |
| Maturities of investments                                                                      | 16,451     | 51,792     | 66,449     |
| Sales of investments                                                                           | 28,443     | 14,008     | 17,721     |
| Other, net                                                                                     | (2,825)    | (922)      | (1,241  )  |
| Net cash used in investing                                                                     | (30,311)   | (27,577)   | (12,223  ) |
| Effect of foreign exchange rates on cash and cash equivalents                                  | (141)      | (29)       | (201  )    |
| Net change in cash and cash equivalents                                                        | (293)      | 648        | 2,220      |
| Cash and cash equivalents, beginning of period                                                 | 14,224     | 13,576     | 11,356     |
| Cash and cash equivalents, end of period                                                       | $ 13,931   | $  14,224  | $  13,576  |


Refer to accompanying notes.

---

# Page 53

# STOCKHOLDERS' EQUITY STATEMENTS

(In millions, except per share amounts)


| Year Ended June 30,                           | 2022       | 2021         | 2020        |
|-----------------------------------------------|------------|--------------|-------------|
| Common stock and paid-in capital              |            |              |             |
| Balance, beginning of period                  | $ 83,111   | $  80,552    | $    78,520 |
| Common stock issued                           | 1,841      | 1,963        | 1,343       |
| Common stock repurchased                      | (5,688)    | (5,539)      | (4,599)     |
| Stock-based compensation expense              | 7,502      | 6,118        | 5,289       |
| Other, net                                    | 173        | 17           |             |
| Balance, end of period                        | 86,939     | 83,111       | 80,552      |
| Retained earnings                             |            |              |             |
| Balance, beginning of period                  | 57,055     | 34,566       | 24,150      |
| Net income                                    | 72,738     | 61,271       | 44,281      |
| Common stock cash dividends                   | (18,552)   | (16,871)     | (15,483)    |
| Common stock repurchased                      | (26,960)   | (21,879)     | (18,382)    |
| Cumulative effect of accounting changes       | 0          | (32)         |             |
| Balance, end of period                        | 84,281     | 57,055       | 34,566      |
| Accumulated other comprehensive income (loss) |            |              |             |
| Balance, beginning of period                  | 1,822      | 3,186        | (340)       |
| Other comprehensive income (loss)             | (6,500)    | (1,374)      | 3,526       |
| Cumulative effect of accounting changes       | 0          | 10           |             |
| Balance, end of period                        | (4,678)    | 1,822        | 3,186       |
| Total stockholders' equity                    | $  166,542 | $    141,988 | $  118,304  |
| Cash dividends declared per common share      | $ 2.48     | $  2.24      | $  2.04     |


Refer to accompanying notes.

(1)

0

0

---

# Page 54

# NOTES TO FINANCIAL STATEMENTS


## NOTE 1 - ACCOUNTING POLICIES


## Accounting Principles

Our consolidated financial statements and accompanying notes are prepared in accordance with accounting principles generally accepted in the United States of America (-GAAP‖).

We have recast certain  prior  period  amounts  to  conform  to  the  current  period  presentation.  The  recast  of  these  prior period  amounts  had  no  impact  on  our  consolidated  balance  sheets,  consolidated  income  statements,  or  consolidated cash flows statements.


## Principles of Consolidation

The consolidated financial statements include the accounts of Microsoft Corporation and its subsidiaries. Intercompany transactions and balances have been eliminated.


## Estimates and Assumptions

Preparing  financial  statements  requires  management  to  make  estimates  and  assumptions  that  affect  the  reported amounts  of  assets,  liabilities,  revenue,  and  expenses.  Examples  of  estimates  and  assumptions  include:  for  revenue recognition, determining the nature and timing of satisfaction of performance obligations, and determining the standalone selling price (-SSP‖) of performance obligations, variable consideration, and other obligations such as product returns and refunds; loss contingencies; product warranties; the fair value of and/or potential impairment of goodwill and intangible assets for our reporting units; product life cycles; useful lives of our tangible and intangible assets; allowances for doubtful accounts;  the  market  value  of,  and  demand  for,  our  inventory;  stock-based  compensation  forfeiture  rates;  when technological  feasibility  is  achieved  for  our  products;  the  potential  outcome  of  uncertain  tax  positions  that  have  been recognized in our consolidated financial statements or tax returns; and determining the timing and amount of impairments for investments. Actual results and outcomes may differ from management's estimates and assumptions due to risks and uncertainties.

In July 2022, we completed an assessment of the useful lives of our server and network equipment. Due to investments in software  that  increased  efficiencies  in  how  we  operate  our  server  and  network  equipment,  as  well  as  advances  in technology, we determined we should increase the estimated useful lives of both server and network equipment from four years to six  years. This change in accounting estimate will be effective beginning fiscal year 2023. We had previously increased the estimated useful lives of both server and network equipment in July 2020.


## Foreign Currencies

Assets  and  liabilities  recorded  in  foreign  currencies  are  translated  at  the  exchange  rate  on  the  balance  sheet  date. Revenue and expenses are translated at average rates of exchange prevailing during the year. Translation adjustments resulting from this process are recorded to other comprehensive income.


## Revenue


## Product Revenue and Service and Other Revenue

Product  revenue  includes  sales  from  operating  systems,  cross-device  productivity  applications,  server  applications, business solution  applications,  desktop  and  server  management  tools,  software  development  tools,  video  games,  and hardware such as PCs, tablets, gaming and entertainment consoles, other intelligent devices, and related accessories.

---

# Page 55

Service  and  other  revenue  includes  sales  from  cloud-based  solutions  that  provide  customers  with  software,  services, platforms, and content such as Office 365, Azure, Dynamics 365, and Xbox; solution support; and consulting services. Service and other revenue also includes sales from online advertising and LinkedIn.


# Revenue Recognition

Revenue is recognized upon transfer of control of promised products or services to customers in an amount that reflects the  consideration  we  expect  to  receive  in  exchange  for  those  products  or  services.  We  enter  into  contracts  that  can include various combinations of products and services, which are generally capable of being distinct and accounted for as separate  performance  obligations.  Revenue  is  recognized  net  of  allowances  for  returns  and  any  taxes  collected  from customers, which are subsequently remitted to governmental authorities.


## Nature of Products and Services

Licenses for on-premises software provide the customer with a right to use the software as it exists when made available to the customer. Customers may purchase perpetual licenses or subscribe to licenses, which provide customers with the same functionality and differ mainly in the duration over which the customer benefits from the software. Revenue from distinct  on-premises  licenses  is  recognized  upfront  at  the  point  in  time  when  the  software  is  made  available  to  the customer. In cases where we allocate revenue to software updates, primarily because the updates are provided at no additional charge, revenue is recognized as the updates are provided, which is generally ratably over the estimated life of the related device or license.

Certain  volume  licensing  programs,  including  Enterprise  Agreements,  include  on-premises  licenses  combined  with Software  Assurance  (-SA‖).  SA  conveys  rights  to  new  software  and  upgrades  released  over  the  contract  period  and provides support, tools, and training to help customers deploy and use products more efficiently. On-premises licenses are  considered  distinct  performance  obligations  when  sold  with  SA.  Revenue  allocated  to  SA  is  generally  recognized ratably  over  the  contract  period  as  customers  simultaneously  consume  and  receive  benefits,  given  that  SA  comprises distinct performance obligations that are satisfied over time.

Cloud services, which allow customers to use hosted software over the contract period without taking possession of the software, are provided on either a subscription or consumption basis. Revenue related to cloud services provided on a subscription  basis  is  recognized  ratably  over  the  contract  period.  Revenue  related  to  cloud  services  provided  on  a consumption basis, such as the amount of storage used in a period, is recognized based on the customer utilization of such resources. When cloud services require a significant level of integration and interdependency with software and the individual components are not considered distinct, all revenue is recognized over the period in which the cloud services are provided.

Revenue from search advertising is recognized when the advertisement appears in the search results or when the action necessary to  earn  the  revenue  has  been  completed.  Revenue  from  consulting  services  is  recognized  as  services  are provided.

Our  hardware  is  generally  highly  dependent  on,  and  interrelated  with,  the  underlying  operating  system  and  cannot function without the operating system. In these cases, the hardware and software license are accounted for as a single performance  obligation  and  revenue  is  recognized  at  the  point  in  time  when  ownership  is  transferred  to  resellers  or directly to end customers through retail stores and online marketplaces.

Refer to Note 19 - Segment Information and Geographic Data for further information, including revenue by significant product and service offering.


## Significant Judgments

Our  contracts  with  customers  often  include  promises  to  transfer  multiple  products  and  services  to  a  customer. Determining whether products and services are considered distinct performance obligations that should be

---

# Page 56

accounted for separately versus together may require significant judgment. When a cloud-based service includes both onpremises  software  licenses  and  cloud  services,  judgment  is  required  to  determine  whether  the  software  license  is considered distinct and accounted for separately, or not distinct and accounted for together with the cloud service and recognized  over  time.  Certain  cloud  services,  primarily  Office  365,  depend  on  a  significant  level  of  integration, interdependency, and interrelation between the desktop applications and cloud services, and are accounted for together as one performance obligation. Revenue from Office 365 is recognized ratably over the period in which the cloud services are provided.

Judgment is required to determine the SSP for each distinct performance obligation. We use a single amount to estimate SSP for items that are not sold separately, including on-premises licenses sold with SA or software updates provided at no  additional  charge.  We  use  a  range  of  amounts  to  estimate  SSP  when  we  sell  each  of  the  products  and  services separately and need to determine whether there is a discount to be allocated based on the relative SSP of the various products and services.

In instances where SSP is not directly observable, such as when we do not sell the product or service separately, we determine the SSP using information that may include market conditions and other observable inputs. We typically have more  than  one  SSP  for  individual  products  and  services  due  to  the  stratification  of  those  products  and  services  by customers  and  circumstances.  In  these  instances,  we  may  use  information  such  as  the  size  of  the  customer  and geographic region in determining the SSP.

Due to the various benefits from and the nature of our SA program, judgment is required to assess the pattern of delivery, including the exercise pattern of certain benefits across our portfolio of customers.

Our products are generally sold with a right of return, we may provide other credits or incentives, and in certain instances we  estimate  customer  usage  of  our  products  and  services,  which  are  accounted  for  as  variable  consideration  when determining the amount of revenue to recognize. Returns and credits are estimated at contract inception and updated at the  end  of  each  reporting  period  if  additional  information  becomes  available.  Changes  to  our  estimated  variable consideration were not material for the periods presented.


## Contract Balances and Other Receivables

Timing of revenue recognition may differ from the timing of invoicing to customers. We record a receivable when revenue is recognized prior to invoicing, or unearned revenue when revenue is recognized subsequent to invoicing. For multi-year agreements,  we  generally  invoice  customers  annually  at  the  beginning  of  each  annual  coverage  period.  We  record  a receivable related to revenue recognized for multi-year on-premises licenses as we have an unconditional right to invoice and receive payment in the future related to those licenses.

Unearned revenue comprises mainly unearned revenue related to volume licensing programs, which may include SA and cloud services. Unearned revenue is generally invoiced annually at the beginning of each contract period for multi-year agreements and recognized ratably over the coverage period. Unearned revenue also includes payments for consulting services  to  be  performed  in  the  future,  LinkedIn  subscriptions,  Office  365  subscriptions,  Xbox  subscriptions, Windows post-delivery support, Dynamics business solutions, and other offerings for which we have been paid in advance and earn the revenue when we transfer control of the product or service.

Refer to Note 13 - Unearned Revenue for further information, including unearned revenue by segment and changes in unearned revenue during the period.

Payment terms and conditions vary by contract type, although terms generally include a requirement of payment within 30 to 60 days. In instances where the timing of revenue recognition differs from the timing of invoicing, we have determined our contracts generally do not include a significant financing component. The primary purpose of our invoicing terms is to provide customers with simplified and predictable ways of purchasing our products and services, not to receive financing from our customers or to provide customers with financing. Examples include invoicing at the beginning of a subscription term  with  revenue  recognized  ratably  over  the  contract  period,  and  multi-year  on-premises  licenses  that  are  invoiced annually with revenue recognized upfront.

---

# Page 57

As of June 30, 2022 and 2021, other receivables due from suppliers were $1.0 billion and $965 million, respectively, and are included in accounts receivable, net in our consolidated balance sheets.

As of June 30, 2022 and 2021, long-term accounts receivable, net of allowance for doubtful accounts, was $3.8 billion and $3.4 billion, respectively, and is included in other long-term assets in our consolidated balance sheets.

The allowance for  doubtful  accounts  reflects  our  best  estimate  of  probable  losses  inherent  in  the  accounts  receivable balance.  We  determine  the  allowance  based  on  known  troubled  accounts,  historical  experience,  and  other  currently available evidence.


Activity in the allowance for doubtful accounts was as follows:
| (In millions)                |          |          |         |
|------------------------------|----------|----------|---------|
| Year Ended June 30,          | 2022     | 2021     | 2020    |
| Balance, beginning of period | $    798 | $    816 | $   434 |
| Charged to costs and other   | 157      | 234      | 560     |
| Write-offs                   | (245)    | (252)    | (178  ) |
| Balance, end of period       | $ 710    | $  798   | $  816  |



Allowance for doubtful accounts included in our consolidated balance sheets:
|                                                             | (In millions)   | (In millions)   | (In millions)   |
|-------------------------------------------------------------|-----------------|-----------------|-----------------|
| June 30,                                                    | 2022            | 2021            | 2020            |
| Accounts receivable, net of allowance for doubtful accounts | $    633        | 751  $          | 788  $          |
| Other long-term assets                                      | 77              | 47              | 28              |
| Total                                                       | $ 710           | $ 798           | $  816          |


We record financing receivables when we offer certain of our customers the option to acquire our software products and services  offerings  through  a  financing  program  in  a  limited  number  of  countries.  As  of  June 30,  2022  and  2021,  our financing  receivables, net were  $4.1 billion and  $4.4 billion, respectively, for short-term  and  long-term  financing receivables, which are included in other current assets and other long-term assets in our consolidated balance sheets. We record  an  allowance  to  cover  expected  losses  based  on  troubled  accounts,  historical  experience,  and  other  currently available evidence.


## Assets Recognized from Costs to Obtain a Contract with a Customer

We recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales incentive programs meet the requirements to be capitalized. Total capitalized costs to obtain a contract were immaterial during the periods presented and are included in other current and long-term assets in our consolidated balance sheets.

We apply a practical  expedient to expense costs as incurred for costs to obtain a contract  with a customer when  the amortization  period  would  have  been  one  year  or  less.  These  costs  include  our  internal  sales  force  compensation program and certain partner sales incentive  programs as we have determined annual compensation is commensurate with annual sales activities.


## Cost of Revenue

Cost of revenue includes: manufacturing and distribution costs for products sold and programs licensed; operating costs related to product support service centers and product distribution centers; costs incurred to include software on PCs sold by original equipment manufacturers (-OEM‖), to drive traffic to our websites, and to acquire online

---

# Page 58

advertising space; costs incurred to support and maintain online products and services, including datacenter costs and royalties; warranty costs; inventory valuation adjustments; costs associated with the delivery of consulting services; and the amortization of capitalized software development costs. Capitalized software development costs are amortized over the estimated lives of the products.


# Product Warranty

We provide for the estimated costs of fulfilling our obligations under hardware and software warranties at the time the related revenue is recognized. For hardware warranties, we estimate the costs based on historical and projected product failure  rates,  historical  and  projected  repair  costs,  and  knowledge  of  specific  product  failures  (if  any).  The  specific hardware warranty terms and conditions vary depending upon the product sold and the country in which we do business, but generally include parts and labor over a period generally ranging from 90 days to three years. For software warranties, we estimate the costs to provide bug fixes, such as security patches, over the estimated life of the software. We regularly reevaluate  our  estimates  to  assess  the  adequacy  of  the  recorded  warranty  liabilities  and  adjust  the  amounts  as necessary.


## Research and Development

Research and development expenses include payroll, employee benefits, stock-based compensation expense, and other headcount-related  expenses  associated  with  product  development.  Research  and  development  expenses  also  include third-party development and programming costs, localization costs incurred to translate software for international markets, and the amortization of purchased software code and services content. Such costs related to software development are included  in  research  and  development  expense  until  the  point  that  technological  feasibility  is  reached,  which  for  our software products, is generally shortly before the products are released to production. Once technological feasibility is reached, such costs are capitalized and amortized to cost of revenue over the estimated lives of the products.


## Sales and Marketing

Sales  and  marketing  expenses  include  payroll,  employee  benefits,  stock-based  compensation  expense,  and  other headcount-related expenses associated with sales and marketing personnel, and the costs of advertising, promotions, trade  shows,  seminars,  and  other  programs.  Advertising  costs  are  expensed  as  incurred.  Advertising  expense  was $1.5 billion, $1.5 billion, and $1.6 billion in fiscal years 2022, 2021, and 2020, respectively.


## Stock-Based Compensation

Compensation cost for stock awards, which include restricted stock units (-RSUs‖) and performance stock units (-PSUs‖), is measured at the fair value on the grant date and recognized as expense, net of estimated forfeitures, over the related service or performance period. The fair value of stock awards is based on the quoted price of our common stock on the grant date less the present value of expected dividends not received during the vesting period. We measure the fair value of PSUs using a Monte Carlo valuation model. Compensation cost for RSUs is recognized using the straight-line method and for PSUs is recognized using the accelerated method.

Compensation expense for the employee stock purchase plan (-ESPP‖) is measured as the discount the employee is entitled to upon purchase and is recognized in the period of purchase.


## Income Taxes

Income tax expense includes U.S. and international income taxes, and interest and penalties on uncertain tax positions. Certain income and expenses are not reported in tax returns and financial statements in the same year. The tax effect of such temporary differences is  reported  as  deferred  income  taxes.  Deferred  tax  assets  are  reported  net  of  a  valuation allowance when it is more likely than not that a tax benefit will not be realized. All deferred income taxes are classified as long-term in our consolidated balance sheets.

---

# Page 59

# Financial Instruments


## Investments

We consider all highly liquid interest-earning investments with a maturity of three months or less at the date of purchase to be cash equivalents. The fair values of these investments approximate their carrying values. In general, investments with original maturities of greater than three months and remaining maturities of less than one year are classified as short-term investments. Investments with maturities beyond one year may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations.

Debt  investments  are  classified  as  available-for-sale  and  realized  gains  and  losses  are  recorded  using  the  specific identification method.  Changes  in  fair value, excluding credit losses and  impairments, are recorded in other comprehensive  income.  Fair  value  is  calculated  based  on  publicly  available  market  information  or  other  estimates determined by management. If the cost of an investment exceeds its fair value, we evaluate, among other factors, general market conditions, credit quality of debt instrument issuers, and the extent to which the fair value is less than cost. To determine  credit  losses,  we  employ  a  systematic  methodology  that  considers  available  quantitative  and  qualitative evidence. In addition, we consider specific adverse conditions related to the financial health of, and business outlook for, the investee. If we have plans to sell the security or it is more likely than not that we will be required to sell the security before recovery, then a decline in fair value below cost is recorded as an impairment charge in other income (expense), net and a new cost basis in the investment is established. If market, industry, and/or investee conditions deteriorate, we may incur future impairments.

Equity investments with readily determinable fair values are measured at fair value. Equity investments without readily determinable  fair  values  are  measured  using  the  equity  method  or  measured  at  cost  with  adjustments  for  observable changes in price or impairments (referred to as the measurement alternative). We perform a qualitative assessment on a periodic basis and recognize an impairment if there are sufficient indicators that the fair value of the investment is less than carrying value. Changes in value are recorded in other income (expense), net.


## Derivatives

Derivative  instruments  are  recognized  as  either  assets  or  liabilities  and  measured  at  fair  value.  The  accounting  for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation.

For derivative instruments designated as fair value hedges, gains and losses are recognized in other income (expense), net  with  offsetting  gains  and  losses  on  the  hedged  items. Gains and losses representing hedge components excluded from the assessment of effectiveness are recognized in other income (expense), net.

For derivative  instruments  designated as cash flow hedges,  gains and  losses are initially reported  as a component of other comprehensive income and subsequently recognized in other income (expense), net with the corresponding hedged item. Gains and losses representing hedge components excluded from the assessment of effectiveness are recognized in other income (expense), net.

For derivative instruments that are not designated as hedges, gains and losses from changes in fair values are primarily recognized in other income (expense), net.


## Fair Value Measurements


We account for certain assets and liabilities at fair value. The hierarchy below lists three levels of fair value based on the extent to which inputs used in measuring fair value are observable in the market. We categorize each of our fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:
- · Level 1 - inputs are based upon unadjusted quoted prices for identical instruments in active markets. Our Level 1 investments include U.S. government securities, common and preferred stock, and mutual funds. Our Level 1 derivative assets and liabilities include those actively traded on exchanges.

---

# Page 60

- · Level 2 -  inputs  are  based  upon quoted  prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-based valuation techniques (e.g. the Black-Scholes model) for which all significant inputs are observable in the market or can be corroborated by observable  market  data  for  substantially  the  full  term  of  the  assets  or  liabilities.  Where  applicable,  these models project  future  cash  flows  and  discount  the  future  amounts  to  a  present  value  using  market-based observable inputs including interest rate curves, credit spreads, foreign exchange rates, and forward and spot prices for currencies. Our Level 2 investments include commercial paper, certificates of deposit, U.S. agency securities,  foreign  government  bonds,  mortgage-  and asset-backed securities,  corporate  notes  and  bonds, and municipal securities. Our Level 2 derivative assets and liabilities include certain over-the-counter forward, option, and swap contracts.
- · Level 3 - inputs are generally unobservable and typically reflect management's estimates of assumptions that market participants would use in pricing the asset or liability. The fair values are therefore determined using model-based  techniques,  including  option  pricing  models  and  discounted  cash  flow  models.  Our  Level 3 assets and liabilities  include  investments  in  corporate  notes  and  bonds,  municipal  securities,  and  goodwill and  intangible  assets,  when  they  are  recorded  at  fair  value  due  to  an  impairment  charge. Unobservable inputs used in the models are significant to the fair values of the assets and liabilities.


We measure equity investments without readily determinable fair values on a nonrecurring basis. The fair values of these investments are determined based on valuation techniques using the best information available, and may include quoted market prices, market comparables, and discounted cash flow projections.


## Inventories

Inventories are stated at average cost, subject to the lower of cost or net realizable value. Cost includes materials, labor, and manufacturing overhead related to the purchase and production of inventories. Net realizable value is the estimated selling price less estimated costs of completion, disposal, and transportation. We regularly review inventory quantities on hand, future purchase commitments with our suppliers, and the estimated utility of our inventory. If our review indicates a reduction in utility below carrying value, we reduce our inventory to a new cost basis through a charge to cost of revenue.


## Property and Equipment

Property and equipment is stated at cost less accumulated depreciation, and depreciated using the straight-line method over the shorter of the estimated useful life of the asset or the lease term. The estimated useful lives of our property and equipment  are  generally  as  follows:  computer  software  developed  or  acquired  for  internal  use,  three  to  seven  years; computer equipment, two to four years; buildings and improvements, five to 15 years; leasehold improvements, three to 20 years; and furniture and equipment, one to 10 years. Land is not depreciated.


## Leases

We determine if an arrangement is a lease at inception. Operating leases are  included in operating  lease right-of-use (-ROU‖) assets, other current liabilities, and operating lease liabilities in our consolidated balance sheets. Finance leases are included in property and equipment, other current liabilities, and other long-term liabilities in our consolidated balance sheets.

ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to  make  lease  payments  arising  from  the  lease.  Operating  lease  ROU  assets  and  liabilities  are  recognized  at commencement date based on the present value of lease payments over the lease term. As most of our leases do not provide  an  implicit  rate,  we  generally  use  our  incremental  borrowing  rate  based  on  the  estimated  rate  of  interest  for collateralized  borrowing  over  a  similar  term  of  the  lease  payments  at  commencement  date.  The  operating  lease  ROU asset also includes any lease payments made and excludes lease incentives. Our lease terms may include options to extend or terminate the lease when it is reasonably  certain that we will exercise that option. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

---

# Page 61

We have lease agreements with lease and non-lease components,  which are  generally  accounted for separately. For certain  equipment  leases,  such  as  vehicles,  we  account  for  the  lease  and  non-lease  components  as  a  single  lease component.  Additionally,  for  certain  equipment  leases,  we  apply  a  portfolio  approach  to  effectively  account  for  the operating lease ROU assets and liabilities.


# Goodwill

Goodwill is tested for impairment at the reporting unit level (operating segment or one level below an operating segment) on an annual basis (May 1 for us) and between annual tests if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value.


## Intangible Assets

Our intangible assets are subject to amortization and are amortized using the straight-line method over their estimated period of benefit, ranging from one to 20 years. We evaluate the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired.


## Recent Accounting Guidance


## Accounting for Income Taxes

In  December  2019,  the  Financial  Accounting  Standards  Board  issued  a  new  standard  to  simplify  the  accounting  for income  taxes.  The  guidance  eliminates  certain  exceptions  related  to  the  approach  for  intraperiod  tax  allocation,  the methodology for calculating income taxes in an interim period, and the recognition of deferred tax liabilities for outside basis differences related to changes in ownership of equity method investments and foreign subsidiaries. The guidance also  simplifies  aspects  of  accounting  for  franchise  taxes  and  enacted  changes  in  tax  laws  or  rates  and  clarifies  the accounting for transactions that result in a step-up in the tax basis of goodwill. We adopted the standard effective July 1, 2021. Adoption of the standard did not have a material impact on our consolidated financial statements.


## NOTE 2 - EARNINGS PER SHARE

Basic  earnings  per  share  (-EPS‖)  is  computed  based  on  the  weighted  average  number  of  shares  of  common  stock outstanding during the period. Diluted EPS is computed based on the weighted average number of shares of common stock plus the effect of dilutive potential common shares outstanding during the period using the treasury stock method. Dilutive potential common shares include outstanding stock options and stock awards.


The components of basic and diluted EPS were as follows:
| (In millions, except earnings per share)                |          |           |           |
|---------------------------------------------------------|----------|-----------|-----------|
| Year Ended June 30,                                     | 2022     | 2021      | 2020      |
| Net income available for common shareholders (A)        | $ 72,738 | 61,271  $ | 44,281  $ |
| Weighted average outstanding shares of common stock (B) | 7,496    | 7,547     | 7,610     |
| Dilutive effect of stock-based awards                   | 44       | 61        | 73        |
| Common stock and common stock equivalents (C)           | 7,540    | 7,608     | 7,683     |
| Earnings Per Share                                      |          |           |           |
| Basic (A/B)                                             | $ 9.70   | $ 8.12    | $ 5.82    |
| Diluted (A/C)                                           | $ 9.65   | $ 8.05    | $ 5.76    |


Anti-dilutive  stock-based  awards  excluded  from  the  calculations  of  diluted  EPS  were  immaterial  during  the  periods presented.

---

# Page 62

# NOTE 3 - OTHER INCOME (EXPENSE), NET


The components of other income (expense), net were as follows:
|                                                       | (In millions)   | (In millions)   | (In millions)   |
|-------------------------------------------------------|-----------------|-----------------|-----------------|
| Year Ended June 30,                                   | 2022            | 2021            | 2020            |
| Interest and dividends income                         | $   2,094       | $     2,131     | $     2,680     |
| Interest expense                                      | (2,063)         | (2,346  )       | (2,591)         |
| Net recognized gains on investments                   | 461             | 1,232           | 32              |
| Net gains (losses) on derivatives                     | (52)            | 17              | 187             |
| Net gains (losses) on foreign currency remeasurements | (75)            | 54              | (191)           |
| Other, net                                            | (32)            | 98              | (40)            |
| Total                                                 | $ 333           | $  1,186        | $  77           |



## Net Recognized Gains (Losses) on Investments

Net recognized gains (losses) on debt investments were as follows:

(4  )


|                                                             | (In millions)   | (In millions)   | (In millions)   |
|-------------------------------------------------------------|-----------------|-----------------|-----------------|
| Year Ended June 30,                                         | 2022            | 2021            | 2020            |
| Realized gains from sales of available-for-sale securities  | $    162        | $       105     | $      50       |
| Realized losses from sales of available-for-sale securities | (138)           | (40)            | (37  )          |
| Impairments and allowance for credit losses                 | (81)            | (2)             | (17  )          |
| Total                                                       | $ (57)          | $  63           | $               |



Net recognized gains (losses) on equity investments were as follows:
| (In millions)                                  |           |           |            |
|------------------------------------------------|-----------|-----------|------------|
| Year Ended June 30,                            | 2022      | 2021      | 2020       |
| Net realized gains on investments sold         | $      29 | $     123 | $       83 |
| Net unrealized gains on investments still held | 509       | 1,057     | 69         |
| Impairments of investments                     | (20)      | (11)      | (116)      |
| Total                                          | $ 518     | $ 1,169   | $   36     |

---

# Page 63

(In millions)

June 30, 2021

Changes in Fair Value Recorded

in Other Comprehensive

Income

Commercial paper

Level 2

$

4,316

$

0

$

0

$  4,316

$  1,331

$

2,985

$  0

Certificates of deposit

Level 2

3,615

0

0

3,615

2,920

695

0

U.S. government securities

Level 1

90,664

3,832

(111)

94,385

1,500

92,885

0

U.S. agency securities

Level 2

807

2

0

809

0

809

0

Foreign government bonds

Level 2

6,213

9

(2)

6,220

225

5,995

0


## NOTE 4 - INVESTMENTS


## Investment Components


The components of investments were as follows:
| (In millions)                                                  | Fair Value  Level   | Cost Basis   | Gains   | Adjusted  Unrealized  Unrealized Losses   | Recorded  Basis   | Cash and Cash Equivalents   | Short-term Investments   | Equity Investments   |
|----------------------------------------------------------------|---------------------|--------------|---------|-------------------------------------------|-------------------|-----------------------------|--------------------------|----------------------|
| June 30, 2022                                                  |                     |              |         |                                           |                   |                             |                          |                      |
| Changes in Fair Value Recorded  in Other Comprehensive  Income |                     |              |         |                                           |                   |                             |                          |                      |
| Commercial paper                                               | Level 2             | $ 2,500      | $ 0     | $ 0                                       | $ 2,500           | $ 2,498                     | $ 2                      | $ 0                  |
| Certificates of deposit                                        | Level 2             | 2,071        | 0       | 0                                         | 2,071             | 2,032                       | 39                       | 0                    |
| U.S. government securities                                     | Level 1             | 79,696       | 29      | (2,178)                                   | 77,547            | 9                           | 77,538                   | 0                    |
| U.S. agency securities                                         | Level 2             | 419          | 0       | (9)                                       | 410               | 0                           | 410                      | 0                    |
| Foreign government bonds                                       | Level 2             | 506          | 0       | (24)                                      | 482               | 0                           | 482                      | 0                    |
| Mortgage- and asset-backed  securities                         | Level 2             | 727          | 1       | (30)                                      | 698               | 0                           | 698                      | 0                    |
| Corporate notes and bonds                                      | Level 2             | 11,661       | 4       | (554)                                     | 11,111            | 0                           | 11,111                   | 0                    |
| Corporate notes and bonds                                      | Level 3             | 67           | 0       | 0                                         | 67                | 0                           | 67                       | 0                    |
| Municipal securities                                           | Level 2             | 368          | 19      | (13)                                      | 374               | 0                           | 374                      | 0                    |
| Municipal securities                                           | Level 3             | 103          | 0       | (6)                                       | 97                | 0                           | 97                       | 0                    |
| Total debt investments                                         |                     | $  98,118    | $   53  | $  (2,814)                                | $  95,357         | $   4,539                   | $  90,818                | $          0         |
| Changes in Fair Value Recorded  in Net Income                  |                     |              |         |                                           |                   |                             |                          |                      |
| Equity investments                                             | Level 1             |              |         |                                           | $ 1,590           | $ 1,134                     | $  0                     | $ 456                |
| Equity investments                                             | Other               |              |         |                                           | 6,435             | 0                           | 0                        | 6,435                |
| Total equity investments                                       |                     |              |         |                                           | $ 8,025           | $ 1,134                     | $ 0                      | $ 6,891              |
| Cash                                                           |                     |              |         |                                           | $ 8,258           | $ 8,258                     | $ 0                      | $ 0                  |
| Derivatives, net  (a)                                          |                     |              |         |                                           | 8                 | 0                           | 8                        | 0                    |
| Total                                                          |                     |              |         |                                           | $111,648          | $  13,931                   | $  90,826                | $   6,891            |


Cash

Fair Value

Level

Adjusted

Cost Basis

Unrealized

Gains

Unrealized

Losses

Recorded

Basis

and Cash

Equivalents

Short-term

Investments

Equity

Investments

---

# Page 64

| (In millions)                                 | Fair Value  Level   | Adjusted  Cost Basis    | Unrealized  Gains   | Unrealized Losses   | Recorded  Basis          | Cash and Cash Equivalents   | Short-term Investments   | Equity Investments   |
|-----------------------------------------------|---------------------|-------------------------|---------------------|---------------------|--------------------------|-----------------------------|--------------------------|----------------------|
| June 30, 2021                                 |                     |                         |                     |                     |                          |                             |                          |                      |
| Mortgage- and asset- backed securities        | Level 2             | 3,442                   | 22                  | (6)                 | 3,458                    | 0                           | 3,458                    | 0                    |
| Corporate notes and bonds                     | Level 2             | 8,443                   | 249                 | (9)                 | 8,683                    | 0                           | 8,683                    | 0                    |
| Corporate notes and bonds                     | Level 3             | 63                      | 0                   | 0                   | 63                       | 0                           | 63                       | 0                    |
| Municipal securities                          | Level 2             | 308                     | 63                  | 0                   | 371                      | 0                           | 371                      | 0                    |
| Municipal securities                          | Level 3             | 95                      | 0                   | (7)                 | 88                       | 0                           | 88                       | 0                    |
| Total debt investments                        |                     | $  117,966    $   4,177 |                     | $    (135)          | $  122,008    $    5,976 |                             | $  116,032               | $         0          |
| Changes in Fair Value Recorded  in Net Income |                     |                         |                     |                     |                          |                             |                          |                      |
| Equity investments                            | Level 1             |                         |                     |                     | $  1,582                 | $  976                      | $   0                    | $  606               |
| Equity investments                            | Other               |                         |                     |                     | 5,378                    | 0                           | 0                        | 5,378                |
| Total equity investments                      |                     |                         |                     |                     | $  6,960                 | $  976                      | $  0                     | $  5,984             |
| Cash                                          |                     |                         |                     |                     | $  7,272                 | $  7,272                    | $  0                     | $  0                 |
| Derivatives, net  (a)                         |                     |                         |                     |                     | 78                       | 0                           | 78                       | 0                    |
| Total                                         |                     |                         |                     |                     | $ 136,318                | $  14,224                   | $  116,110               | $  5,984             |
(a) Refer to Note 5 - Derivatives for further information on the fair value of our derivative instruments.


Equity investments presented as -Other‖ in the tables above include investments without readily determinable fair values measured using the equity method or measured at cost with adjustments for observable changes in price or impairments, and investments measured at fair value using net asset value as a practical expedient which are not categorized in the fair value hierarchy. As of June 30, 2022 and 2021, equity investments without readily determinable fair values measured at cost with adjustments for observable changes in price or impairments were $3.8 billion and $3.3 billion, respectively.


## Unrealized Losses on Debt Investments


Debt investments with continuous unrealized losses for less than 12 months and 12 months or greater and their related fair values were as follows:
|                                        | Less than 12 Months   | Less than 12 Months   | 12 Months or Greater   | 12 Months or Greater   |                   | Total              |
|----------------------------------------|-----------------------|-----------------------|------------------------|------------------------|-------------------|--------------------|
| (In millions)                          | Fair Value            | Unrealized  Losses    | Fair Value             | Unrealized  Losses     | Total  Fair Value | Unrealized  Losses |
| June 30, 2022                          |                       |                       |                        |                        |                   |                    |
| U.S. government and agency  securities | $ 59,092              | $ (1,835)             | $ 2,210                | $ (352)                | $ 61,302          | $(2,187)           |
| Foreign government bonds               | 418                   | (18)                  | 27                     | (6)                    | 445               | (24)               |
| Mortgage- and asset-backed  securities | 510                   | (26)                  | 41                     | (4)                    | 551               | (30)               |
| Corporate notes and bonds              | 9,443                 | (477)                 | 786                    | (77)                   | 10,229            | (554)              |
| Municipal securities                   | 178                   | (12)                  | 74                     | (7)                    | 252               | (19)               |
| Total                                  | $  69,641             | $      (2,368)        | $            3,138     | $         (446)        | $   72,779        | $       (2,814)    |

---

# Page 65

|                                       | Less than 12 Months   | Less than 12 Months   | 12 Months or Greater   | 12 Months or Greater   |                   | Total              |
|---------------------------------------|-----------------------|-----------------------|------------------------|------------------------|-------------------|--------------------|
| (In millions)                         | Fair Value            | Unrealized  Losses    | Fair Value             | Unrealized  Losses     | Total  Fair Value | Unrealized  Losses |
| June 30, 2021                         |                       |                       |                        |                        |                   |                    |
| U.S. government and agency securities | $    5,294            | $  (111)              | $  0                   | $  0                   | $  5,294          | $         (111)    |
| Foreign government bonds              | 3,148                 | (1)                   | 5                      | (1  )                  | 3,153             | (2  )              |
| Mortgage- and asset-backed securities | 1,211                 | (5)                   | 87                     | (1  )                  | 1,298             | (6  )              |
| Corporate notes and bonds             | 1,678                 | (8)                   | 34                     | (1  )                  | 1,712             | (9  )              |
| Municipal securities                  | 58                    | (7)                   | 1                      | 0                      | 59                | (7  )              |
| Total                                 | $  11,389             | $    (132)            | $    127               | (3  )  $               | $      11,516     | $         (135)    |


Unrealized losses from fixed-income securities are primarily attributable to changes in interest rates. Management does not believe any remaining unrealized losses represent impairments based on our evaluation of available evidence.


# Debt Investment Maturities


| (In millions)                         | Adjusted  Cost Basis   | Estimated Fair Value   |
|---------------------------------------|------------------------|------------------------|
| June 30, 2022                         |                        |                        |
| Due in one year or less               | $ 26,480               | $ 26,470               |
| Due after one year through five years | 52,006                 | 50,748                 |
| Due after five years through 10 years | 18,274                 | 16,880                 |
| Due after 10 years                    | 1,358                  | 1,259                  |
| Total                                 | $  98,118              | $  95,357              |



## NOTE 5 - DERIVATIVES

We use derivative instruments to manage risks related to foreign currencies, interest rates, equity prices, and credit; to enhance  investment  returns;  and  to  facilitate  portfolio  diversification.  Our  objectives  for  holding  derivatives  include reducing, eliminating, and efficiently managing the economic impact of these exposures as effectively as possible. Our derivative programs include strategies that both qualify and do not qualify for hedge accounting treatment.


## Foreign Currencies

Certain  forecasted  transactions,  assets,  and  liabilities  are  exposed  to  foreign  currency  risk.  We  monitor  our  foreign currency exposures daily to maximize the economic effectiveness of our foreign currency hedge positions.

Foreign currency risks related to certain non-U.S. dollar-denominated investments are hedged using foreign exchange forward contracts that are designated as fair value hedging instruments. Foreign currency risks related to certain Eurodenominated  debt  are  hedged  using  foreign  exchange  forward  contracts  that  are  designated  as  cash  flow  hedging instruments.

Certain options and forwards not designated as hedging instruments are also used to manage the variability in foreign exchange rates on certain balance sheet amounts and to manage other foreign currency exposures.


## Interest Rate

Interest rate risks related to certain fixed-rate debt are hedged using interest rate swaps that are designated as fair value hedging instruments to effectively convert the fixed interest rates to floating interest rates.

---

# Page 66

Securities  held  in  our  fixed-income  portfolio  are  subject  to  different  interest  rate  risks  based  on  their  maturities.  We manage the average maturity of our fixed-income portfolio to achieve economic returns that correlate to certain broadbased fixed-income indices using exchange-traded option and futures contracts and over-the-counter swap and option contracts. These contracts are not designated as hedging instruments and are included in -Other contracts‖ in the tables below.


# Equity

Securities held in our equity investments portfolio are subject to market price risk. At times, we may hold options, futures, and swap contracts. These contracts are not designated as hedging instruments and are included in -Other contracts‖ in the tables below.


## Credit

Our fixed-income portfolio is diversified and consists primarily of investment-grade securities. We use credit default swap contracts  to  manage  credit  exposures  relative  to  broad-based  indices  and  to  facilitate  portfolio  diversification.  These contracts are not designated as hedging instruments and are included in -Other contracts‖ in the tables below.


## Credit-Risk-Related Contingent Features

Certain  of  our  counterparty  agreements  for  derivative  instruments  contain  provisions  that  require  our  issued  and outstanding long-term unsecured debt to maintain an investment grade credit rating and require us to maintain minimum liquidity of $1.0 billion. To the extent we fail to meet these requirements, we will be required to post collateral, similar to the standard convention related to over-the-counter derivatives. As of June 30, 2022, our long-term unsecured debt rating was AAA, and cash investments were in excess of $1.0 billion. As a result, no collateral was required to be posted.


The  following  table  presents  the  notional  amounts  of  our  outstanding  derivative  instruments  measured  in  U.S.  dollar equivalents:
| (In millions)                         | June 30, 2022   | June 30, 2021   |
|---------------------------------------|-----------------|-----------------|
| Designated as Hedging Instruments     |                 |                 |
| Foreign exchange contracts purchased  | $ 635           | $ 635           |
| Foreign exchange contracts sold       | 0               | 6,081           |
| Interest rate contracts purchased     | 1,139           | 1,247           |
| Not Designated as Hedging Instruments |                 |                 |
| Foreign exchange contracts purchased  | 10,322          | 14,223          |
| Foreign exchange contracts sold       | 21,606          | 23,391          |
| Other contracts purchased             | 2,773           | 2,456           |
| Other contracts sold                  | 544             | 763             |



## Fair Values of Derivative Instruments


The following table presents our derivative instruments:
| (In millions)                     | Derivative  Assets   | Derivative  Liabilities   | Derivative  Assets   | Derivative  Liabilities   |
|-----------------------------------|----------------------|---------------------------|----------------------|---------------------------|
| Designated as Hedging Instruments |                      |                           |                      |                           |
| Foreign exchange contracts        | $ 0                  | $(77)                     | $  76                | $   (8)                   |

---

# Page 67

| (In millions)                                            | Derivative  Assets   | Derivative  Liabilities   | Derivative  Assets   | Derivative  Liabilities   |
|----------------------------------------------------------|----------------------|---------------------------|----------------------|---------------------------|
| Interest rate contracts                                  | 3                    | 0                         | 40                   | 0                         |
| Not Designated as Hedging Instruments                    |                      |                           |                      |                           |
| Foreign exchange contracts                               | 333                  | (362)                     | 227                  | (291)                     |
| Other contracts                                          | 20                   | (112)                     | 56                   | (36)                      |
| Gross amounts of derivatives                             | 356                  | (551)                     | 399                  | (335)                     |
| Gross amounts of derivatives offset in the balance sheet | (130)                | 133                       | (141)                | 142                       |
| Cash collateral received                                 | 0                    | (75)                      | 0                    | (42)                      |
| Net amounts of derivatives                               | $ 226                | $ (493)                   | $  258               | $  (235)                  |
| Reported as                                              |                      |                           |                      |                           |
| Short-term investments                                   | $ 8                  | $ 0                       | $  78                | $  0                      |
| Other current assets                                     | 218                  | 0                         | 137                  | 0                         |
| Other long-term assets                                   | 0                    | 0                         | 43                   | 0                         |
| Other current liabilities                                | 0                    | (298)                     | 0                    | (182)                     |
| Other long-term liabilities                              | 0                    | (195)                     | 0                    | (53)                      |
| Total                                                    | $  226               | $   (493)                 | $   258              | $  (235)                  |


Gross derivative assets and liabilities subject to legally enforceable master netting agreements for which we have elected to  offset  were  $343 million  and  $550 million,  respectively,  as  of  June 30,  2022,  and  $395 million  and  $335 million, respectively, as of June 30, 2021.


The following table presents the fair value of our derivatives instruments on a gross basis:
| (In millions)          | Level 1   | Level 2   | Level 3   | Total   |
|------------------------|-----------|-----------|-----------|---------|
| June 30, 2022          |           |           |           |         |
| Derivative assets      | $       1 | $ 349     | $      6  | $   356 |
| Derivative liabilities | 0         | (551)     | 0         | (551)   |
| June 30, 2021          |           |           |           |         |
| Derivative assets      | 0         | 396       | 3         | 399     |
| Derivative liabilities | 0         | (335)     | 0         | (335  ) |


Gains (losses) on derivative instruments recognized in other income (expense), net were as follows:

0


| (In millions)                                                   |      | 2021    |       |
|-----------------------------------------------------------------|------|---------|-------|
| Year Ended June 30,                                             | 2022 |         | 2020  |
| Designated as Fair Value Hedging Instruments                    |      |         |       |
| Foreign exchange contracts                                      |      |         |       |
| Derivatives                                                     | $ 49 | 193  $  | $ 1   |
| Hedged items                                                    | (50) | (188  ) | 3     |
| Excluded from effectiveness assessment                          | 4    | 30      | 139   |
| Interest rate contracts                                         |      |         |       |
| Derivatives                                                     | (92) | (37  )  | 93    |
| Hedged items                                                    | 108  | 53      | (93)  |
| Designated as Cash Flow Hedging Instruments                     |      |         |       |
| Foreign exchange contracts                                      |      |         |       |
| Amount reclassified from accumulated other comprehensive income | (79) | 17      |       |
| Not Designated as Hedging Instruments                           |      |         |       |
| Foreign exchange contracts                                      | 383  | 27      | (123) |
| Other contracts                                                 | (72) | 9       | 50    |

---

# Page 68

Gains (losses), net of tax, on derivative instruments recognized in our consolidated comprehensive income statements were as follows:
|                                                                  | (In millions)   | (In millions)   | (In millions)   |
|------------------------------------------------------------------|-----------------|-----------------|-----------------|
| Year Ended June 30,                                              | 2022            | 2021            | 2020            |
| Designated as Cash Flow Hedging Instruments                      |                 |                 |                 |
| Foreign exchange contracts  Included in effectiveness assessment | $  (57)         | $  34           | $   (38)        |



# NOTE 6 - INVENTORIES


The components of inventories were as follows:
| (In millions)   |                     |
|-----------------|---------------------|
| June 30,        | 2022 2021           |
| Raw materials   | $ 1,144   1,190  $  |
| Work in process | 82 79               |
| Finished goods  | 2,516   1,367       |
| Total           | $  3,742   2,636  $ |



## NOTE 7 - PROPERTY AND EQUIPMENT


The components of property and equipment were as follows:
| (In millions) June 30,          | 2022     | 2021      |
|---------------------------------|----------|-----------|
| Land                            | $ 4,734  | $  3,660  |
| Buildings and improvements      | 55,014   | 43,928    |
| Leasehold improvements          | 7,819    | 6,884     |
| Computer equipment and software | 60,631   | 51,250    |
| Furniture and equipment         | 5,860    | 5,344     |
| Total, at cost                  | 134,058  | 111,066   |
| Accumulated depreciation        | (59,660) | (51,351)  |
| Total, net                      | $ 74,398 | $  59,715 |


During  fiscal  years  2022,  2021,  and  2020,  depreciation  expense  was  $12.6 billion,  $9.3 billion,  and  $10.7 billion, respectively.  We  have  committed  $8.5 billion,  primarily  related  to  datacenters,  for  the  construction  of  new  buildings, building improvements, and leasehold improvements as of June 30, 2022.


## NOTE 8 - BUSINESS COMBINATIONS


## Nuance Communications, Inc.

On March 4, 2022, we completed our acquisition of Nuance Communications, Inc. (-Nuance‖) for a total purchase price of $18.8 billion,  consisting  primarily  of  cash.  Nuance  is  a  cloud  and  artificial  intelligence  (-AI‖)  software  provider  with healthcare  and  enterprise  AI  experience,  and  the  acquisition  will  build  on  our  industry-specific  cloud  offerings.  The financial results of Nuance have been included in our consolidated financial statements since the date of the acquisition. Nuance is reported as part of our Intelligent Cloud segment.

The purchase price allocation as of the date of acquisition was based on a preliminary valuation and is subject to revision as more detailed analyses are completed and additional information about the fair value of assets acquired and liabilities assumed becomes available.

---

# Page 69

The major classes of assets and liabilities to which we have preliminarily allocated the purchase price were as follows:
| (In millions)          |            |
|------------------------|------------|
| Goodwill  (a)          | $  16,308  |
| Intangible assets      | 4,365      |
| Other assets           | 59         |
| Other liabilities  (b) | (1,971)    |
| Total                  | $   18,761 |
(a) Goodwill was assigned to our Intelligent Cloud segment and was primarily attributed to increased synergies that are expected  to  be  achieved  from  the  integration  of  Nuance.  None  of  the  goodwill  is  expected  to  be  deductible  for income tax purposes.
(b) Includes $986 million of convertible senior notes issued by Nuance in 2015 and 2017, of which $985 million was redeemed  prior  to  June 30,  2022.  The  remaining  $1 million  of  notes  are  redeemable  through  their  respective maturity dates and are included in other current liabilities on our consolidated balance sheets as of June 30, 2022.


Following are the details of the purchase price allocated to the intangible assets acquired:

9 years

5 years

4 years

7 years


| (In millions, except average life)   | Amount   | Weighted Average Life   |
|--------------------------------------|----------|-------------------------|
| Customer-related                     | $2,610   |                         |
| Technology-based                     | 1,540    |                         |
| Marketing-related                    | 215      |                         |
| Total                                | $4,365   |                         |



## ZeniMax Media Inc.

On March 9, 2021, we completed our acquisition of ZeniMax Media Inc. (-ZeniMax‖), the parent company of Bethesda Softworks LLC (-Bethesda‖), for a total purchase price of $8.1 billion, consisting primarily of cash. The purchase price included  $766 million  of  cash  and  cash  equivalents  acquired.  Bethesda  is  one  of  the  largest,  privately  held  game developers  and  publishers  in  the  world,  and  brings  a  broad  portfolio  of  games,  technology,  and  talent  to  Xbox.  The financial results of ZeniMax have been included in our consolidated financial statements since the date of the acquisition. ZeniMax is reported as part of our More Personal Computing segment.


The allocation of the purchase price to goodwill was completed as of December 31, 2021. The major classes of assets and liabilities to which we have allocated the purchase price were as follows:
| (In millions)             |           |
|---------------------------|-----------|
| Cash and cash equivalents | $  766    |
| Goodwill                  | 5,510     |
| Intangible assets         | 1,968     |
| Other assets              | 121       |
| Other liabilities         | (244  )   |
| Total                     | $   8,121 |


Goodwill  was  assigned  to  our  More  Personal  Computing  segment.  The  goodwill  was  primarily  attributed  to  increased synergies  that  are  expected  to  be  achieved  from  the  integration  of  ZeniMax.  None  of  the  goodwill  is  expected  to  be deductible for income tax purposes.


Following are details of the purchase price allocated to the intangible assets acquired:
| (In millions, except average life)   | Amount   | Weighted Average Life   |
|--------------------------------------|----------|-------------------------|
| Technology-based                     | $  1,341 | 4 years                 |
| Marketing-related                    | 627      | 11 years                |
| Total                                | $  1,968 | 6 years                 |

---

# Page 70

# Activision Blizzard, Inc.

On January 18, 2022, we entered into a definitive agreement to acquire Activision Blizzard, Inc. (-Activision Blizzard‖) for $95.00 per share in an all-cash transaction valued at $68.7 billion, inclusive of Activision Blizzard's net cash. Activision Blizzard  is  a  leader  in  game  development  and  an  interactive  entertainment  content  publisher.  The  acquisition  will accelerate the growth in our gaming business across mobile, PC, console, and cloud and will provide building blocks for the  metaverse.  The  acquisition  has  been  approved  by  Activision  Blizzard's  shareholders,  and  we  expect  it  to  close  in fiscal year 2023, subject to the satisfaction of certain regulatory approvals and other customary closing conditions.


## NOTE 9 - GOODWILL


Changes in the carrying amount of goodwill were as follows:
| (In millions)                        | June 30,   | 2020 Acquisitions   | Other     | June 30,  2021   | Acquisitions   | Other     | June 30,  2022   |
|--------------------------------------|------------|---------------------|-----------|------------------|----------------|-----------|------------------|
| Productivity and Business  Processes | $  24,190  | $  0                | $  127    | $ 24,317         | $ 599          | $ (105)   | $ 24,811         |
| Intelligent Cloud                    | 12,697     | 505                 | 54        | 13,256           | 16,879   (b)   | 47   (b)  | 30,182           |
| More Personal Computing              | 6,464      | 5,556   (a)         | 118   (a) | 12,138           | 648            | (255)     | 12,531           |
| Total                                | $   43,351 | $    6,061          | $   299   | $  49,711        | $  18,126      | $   (313) | $  67,524        |
(a) Includes goodwill of $5.5 billion related to ZeniMax. See Note 8 - Business Combinations for further information.
(b) Includes goodwill of $16.3 billion related to Nuance. See Note 8 - Business Combinations for further information.


The measurement periods for the valuation of assets acquired and liabilities assumed end as soon as information on the facts  and  circumstances  that  existed  as  of  the  acquisition  dates  becomes  available,  but  do  not  exceed  12  months. Adjustments in purchase price allocations may require a change in the amounts allocated to goodwill during the periods in which the adjustments are determined.

Any change in the goodwill amounts resulting from foreign currency translations and purchase accounting adjustments are presented as -Other‖ in the table above. Also included in -Other‖ are business dispositions and transfers between segments due to reorganizations, as applicable.


## Goodwill Impairment

We test  goodwill  for  impairment  annually  on  May 1  at  the  reporting  unit  level,  primarily  using  a  discounted  cash  flow methodology with a peer-based, risk-adjusted weighted average cost of capital. We believe use of a discounted cash flow approach is the most reliable indicator of the fair values of the businesses.

No instances of impairment were identified in our May 1, 2022, May 1, 2021, or May 1, 2020 tests. As of June 30, 2022 and 2021, accumulated goodwill impairment was $11.3 billion.


## NOTE 10 - INTANGIBLE ASSETS


The components of intangible assets, all of which are finite-lived, were as follows:
| (In millions)     | Gross   Carrying   Amount   | Amortization   | Accumulated  Net Carrying  Amount   | Gross   Carrying   Amount   | Accumulated  Amortization   | Net Carrying  Amount   |
|-------------------|-----------------------------|----------------|-------------------------------------|-----------------------------|-----------------------------|------------------------|
| June 30,          |                             |                | 2022                                |                             |                             | 2021                   |
| Technology-based  | $ 11,277                    | $              | (6,958) $ 4,319                     | $  9,779                    | $  (7,007)                  | $  2,772               |
| Customer-related  | 7,342                       |                | (3,171) 4,171                       | 4,958                       | (2,859)                     | 2,099                  |
| Marketing-related | 4,942                       |                | (2,143) 2,799                       | 4,792                       | (1,878)                     | 2,914                  |
| Contract-based    | 16                          |                | (7) 9                               | 446                         | (431)                       | 15                     |
| Total             | $   23,577  (a)             | $   (12,279)   | $  11,298                           | 19,975  $   (b)             | $  (12,175)                 | $    7,800             |

---

# Page 71

- (a) Includes  intangible  assets  of  $4.4 billion  related  to  Nuance.  See  Note  8  -  Business  Combinations  for  further information.
- (b) Includes  intangible  assets  of  $2.0 billion  related  to  ZeniMax.  See  Note  8  -  Business  Combinations  for  further information.


No material impairments of intangible assets were identified during fiscal years 2022, 2021, or 2020. We estimate that we have no significant residual value related to our intangible assets.


The components of intangible assets acquired during the periods presented were as follows:
| (In millions)       | Amount   | Weighted Average Life   | Amount     | Weighted Average Life   |
|---------------------|----------|-------------------------|------------|-------------------------|
| Year Ended June 30, | 2022     |                         | 2021       |                         |
| Technology-based    | $ 2,611  | 4 years                 | 1,628    $ | 4 years                 |
| Customer-related    | 2,837    | 9 years                 | 96         | 4 years                 |
| Marketing-related   | 233      | 4 years                 | 625        | 6 years                 |
| Contract-based      | 0        | 0 years                 | 10         | 3 years                 |
| Total               | $ 5,681  | 7 years                 | 2,359    $ | 5 years                 |


Intangible  assets  amortization  expense  was  $2.0 billion,  $1.6 billion,  and  $1.6 billion  for  fiscal  years  2022,  2021,  and 2020, respectively.


The following table outlines the estimated future amortization expense related to intangible assets held as of June 30, 2022:
| (In millions)        |         |
|----------------------|---------|
| Year Ending June 30, |         |
| 2023                 | $ 2,654 |
| 2024                 | 2,385   |
| 2025                 | 1,631   |
| 2026                 | 1,227   |
| 2027                 | 809     |
| Thereafter           | 2,592   |
| Total                | $11,298 |



## NOTE 11 - DEBT

The components of debt were as follows:

520

486

718


| (In millions, issuance by calendar year)   | Maturities (calendar year)   | Stated Interest Rate   | Effective Interest Rate   | June 30, 2022   | June 30, 2021   |
|--------------------------------------------|------------------------------|------------------------|---------------------------|-----------------|-----------------|
| 2009 issuance of $3.8 billion  (a)         | 2039                         | 5.20%                  | 5.24%                     | $ 520           | $               |
| 2010 issuance of $4.8 billion  (a)         | 2040                         | 4.50%                  | 4.57%                     | 486             |                 |
| 2011 issuance of $2.3 billion  (a)         | 2041                         | 5.30%                  | 5.36%                     | 718             |                 |
| 2012 issuance of $2.3 billion  (a)         | 2022-2042                    | 2.13%-3.50%            | 2.24%-3.57%               | 1,204           | 1,204           |
| 2013 issuance of $5.2 billion  (a)         | 2023-2043                    | 2.38%-4.88%            | 2.47%-4.92%               | 2,814           | 2,814           |
| 2013 issuance of  € 4.1 billion            | 2028-2033                    | 2.63%-3.13%            | 2.69%-3.22%               | 2,404           | 4,803           |
| 2015 issuance of $23.8 billion  (a)        | 2022-2055                    | 2.65%-4.75%            | 2.72%-4.78%               | 10,805          | 12,305          |
| 2016 issuance of $19.8 billion  (a)        | 2023-2056                    | 2.00%-3.95%            | 2.10%-4.03%               | 9,430           | 12,180          |
| 2017 issuance of $17.0 billion  (a)        | 2024-2057                    | 2.88%-4.50%            | 3.04%-4.53%               | 8,945           | 10,695          |
| 2020 issuance of $10.0 billion  (a)        | 2050-2060                    | 2.53%-2.68%            | 2.53%-2.68%               | 10,000          | 10,000          |
| 2021 issuance of $8.2 billion  (a)         | 2052-2062                    | 2.92%-3.04%            | 2.92%-3.04%               | 8,185           | 8,185           |
| Total face value                           |                              |                        |                           | 55,511          | 63,910          |

---

# Page 72

| (In millions, issuance by calendar year)   | Maturities (calendar year)   | Stated Interest Rate   | Effective Interest Rate   | June 30, 2022   | June 30, 2021   |
|--------------------------------------------|------------------------------|------------------------|---------------------------|-----------------|-----------------|
| Unamortized discount and issuance costs    |                              |                        |                           | (471)           | (511)           |
| Hedge fair value adjustments  (b)          |                              |                        |                           | (68)            | 40              |
| Premium on debt exchange  (a)              |                              |                        |                           | (5,191)         | (5,293)         |
| Total debt                                 |                              |                        |                           | 49,781          | 58,146          |
| Current portion of long-term debt          |                              |                        |                           | (2,749)         | (8,072)         |
| Long-term debt                             |                              |                        |                           | $  47,032       | $  50,074       |
(a) In March 2021 and June 2020, we exchanged a portion of our existing debt at a premium for cash and new debt with longer maturities. The premiums are amortized over the terms of the new debt.
(b) Refer to Note 5 - Derivatives for further information on the interest rate swaps related to fixed-rate debt.


As of June 30, 2022 and 2021, the estimated fair value of long-term debt, including the current portion, was $50.9 billion and $70.0 billion, respectively. The estimated fair values are based on Level 2 inputs.

Debt  in  the  table  above  is  comprised  of  senior  unsecured  obligations  and  ranks  equally  with  our  other  outstanding obligations. Interest is paid semi-annually, except for the Euro-denominated debt, which is paid annually. Cash paid for interest on our debt for fiscal years 2022, 2021, and 2020 was $1.9 billion, $2.0 billion, and $2.4 billion, respectively.


The following table outlines maturities of our long-term debt, including the current portion, as of June 30, 2022:
| (In millions)        |           |
|----------------------|-----------|
| Year Ending June 30, |           |
| 2023                 | $ 2,750   |
| 2024                 | 5,250     |
| 2025                 | 2,250     |
| 2026                 | 3,000     |
| 2027                 | 8,000     |
| Thereafter           | 34,261    |
| Total                | $  55,511 |



## NOTE 12 - INCOME TAXES


## Provision for Income Taxes

The components of the provision for income taxes were as follows:

58

(6)

11


| (In millions)              |            | 2021      | 2020       |
|----------------------------|------------|-----------|------------|
| Year Ended June 30,        | 2022       |           |            |
| Current Taxes              |            |           |            |
| U.S. federal               | $ 8,329    | $  3,285  | $  3,537   |
| U.S. state and local       | 1,679      | 1,229     | 763        |
| Foreign                    | 6,672      | 5,467     | 4,444      |
| Current taxes              | $   16,680 | $   9,981 | $    8,744 |
| Deferred Taxes             |            |           |            |
| U.S. federal               | $ (4,815)  | $  25     | $          |
| U.S. state and local       | (1,062)    | (204)     |            |
| Foreign                    | 175        | 29        | (41)       |
| Deferred taxes             | $ (5,702)  | $  (150)  | $          |
| Provision for income taxes | $ 10,978   | $  9,831  | $  8,755   |

---

# Page 73

U.S. and foreign components of income before income taxes were as follows:
|                            | (In millions)   | (In millions)   | (In millions)   |
|----------------------------|-----------------|-----------------|-----------------|
| Year Ended June 30,        | 2022            | 2021            | 2020            |
| U.S.                       | $ 47,837        | $ 34,972        | $ 24,116        |
| Foreign                    | 35,879          | 36,130          | 28,920          |
| Income before income taxes | $  83,716       | 71,102  $       | 53,036  $       |



# Effective Tax Rate


The  items  accounting  for  the  difference  between  income  taxes  computed  at  the  U.S.  federal  statutory  rate  and  our effective rate were as follows:
| Year Ended June 30,                                      | 2022   | 2021       | 2020       |
|----------------------------------------------------------|--------|------------|------------|
| Federal statutory rate                                   | 21.0%  | 1.0%    2  | 21.0%      |
| Effect of:                                               |        |            |            |
| Foreign earnings taxed at lower rates                    | (1.3)% | .7)%    (2 | 3.7)%    ( |
| Impact of intangible property transfers                  | (3.9)% | 0%         | 0%         |
| Foreign-derived intangible income deduction              | (1.1)% | .3)%    (1 | 1.1)%    ( |
| State income taxes, net of federal benefit               | 1.4%   | 1.4%       | 1.3%       |
| Research and development credit                          | (0.9)% | .9)%    (0 | 1.1)%    ( |
| Excess tax benefits relating to stock-based compensation | (1.9)% | .4)%    (2 | 2.2)%    ( |
| Interest, net                                            | 0.5%   | 0.5%       | 1.0%       |
| Other reconciling items, net                             | (0.7)% | .8)%    (1 | 1.3%       |
| Effective rate                                           | 13.1%  | 3.8%    1  | 16.5%      |


In the first quarter of fiscal year 2022, we transferred certain intangible properties from our Puerto Rico subsidiary to the U.S. The transfer of intangible properties resulted in a $3.3 billion net income tax benefit in the first quarter of fiscal year 2022, as the value of future U.S. tax deductions exceeds the current tax liability from the U.S. global intangible low-taxed income (-GILTI‖) tax.

We  have  historically  paid  India  withholding  taxes  on  software  sales  through  distributor  withholding  and  tax  audit assessments in India. In March 2021, the India Supreme Court ruled favorably in the case of Engineering Analysis Centre of Excellence Private Limited vs The Commissioner of Income Tax for companies in 86 separate appeals, some dating back to 2012, holding that software sales are not subject to India withholding taxes. Although we were not a party to the appeals, our software sales in India were determined to be not subject to withholding taxes. Therefore, we recorded a net income tax benefit of $620 million in the third quarter of fiscal year 2021 to reflect the results of the India Supreme Court decision impacting fiscal year 1996 through fiscal year 2016.

The decrease from the federal statutory rate in fiscal year 2022 is primarily due to the net income tax benefit related to the transfer  of  intangible  properties,  earnings  taxed  at  lower  rates  in  foreign  jurisdictions  resulting  from  producing  and distributing our products and services through our foreign regional operations center in Ireland, and tax benefits relating to stock-based compensation. The decrease from the federal statutory rate in fiscal year 2021 is primarily due to earnings taxed at lower rates in foreign jurisdictions resulting from producing and distributing our products and services through our foreign regional operations centers in Ireland and Puerto Rico, tax benefits relating to stock-based compensation, and tax benefits from the India Supreme Court decision on withholding taxes. The decrease from the federal statutory rate in fiscal year 2020 is primarily due to earnings taxed at lower rates in foreign jurisdictions resulting from producing and distributing our products and services through our foreign regional operations centers in Ireland and Puerto Rico, and tax benefits relating  to  stock-based  compensation.  In  fiscal  years  2022,  2021,  and  2020,  our  foreign  regional  operating  centers  in Ireland and Puerto Rico, which are taxed at rates lower than the U.S. rate, generated 71%, 82%, and 86% of our foreign income before tax. Other reconciling items, net

---

# Page 74

consists primarily of tax credits and GILTI tax, and in fiscal year 2021, includes tax benefits from the India Supreme Court decision on withholding taxes. In fiscal years 2022, 2021, and 2020, there were no individually significant other reconciling items.

The decrease in our effective tax rate for fiscal year 2022 compared to fiscal year 2021 was primarily due to a $3.3 billion net income tax benefit in the first quarter of fiscal year 2022 related to the transfer of intangible properties, offset in part by changes in the mix of our income before income taxes between the U.S. and foreign countries, as well as tax benefits in the prior year from the India Supreme Court decision on withholding taxes, an agreement between the U.S. and India tax authorities related to transfer pricing, and final Tax Cuts and Jobs Act (-TCJA‖) regulations. The decrease in our effective tax rate for fiscal year 2021 compared to fiscal year 2020 was primarily due to tax benefits from the India Supreme Court decision on withholding taxes, an agreement between the U.S. and India tax authorities related to transfer pricing, final TCJA regulations, and an increase in tax benefits relating to stock-based compensation.

The components of the deferred income tax assets and liabilities were as follows:

(In millions)


| June 30,                                               | 2022        | 2021         |
|--------------------------------------------------------|-------------|--------------|
| Deferred Income Tax Assets                             |             |              |
| Stock-based compensation expense                       | $ 601       | $  502       |
| Accruals, reserves, and other expenses                 | 2,874       | 2,960        |
| Loss and credit carryforwards                          | 1,546       | 1,090        |
| Amortization                                           | 10,656      | 6,346        |
| Leasing liabilities                                    | 4,557       | 4,060        |
| Unearned revenue                                       | 2,876       | 2,659        |
| Other                                                  | 461         | 319          |
| Deferred income tax assets                             | 23,571      | 17,936       |
| Less valuation allowance                               | (1,012)     | (769)        |
| Deferred income tax assets, net of valuation allowance | $    22,559 | $     17,167 |
| Deferred Income Tax Liabilities                        |             |              |
| Book/tax basis differences in investments and debt     | $ (174)     | $  (2,381)   |
| Leasing assets                                         | (4,291)     | (3,834)      |
| Depreciation                                           | (1,602)     | (1,010)      |
| Deferred tax on foreign earnings                       | (3,104)     | (2,815)      |
| Other                                                  | (103)       | (144)        |
| Deferred income tax liabilities                        | $ (9,274)   | $  (10,184)  |
| Net deferred income tax assets                         | $ 13,285    | $  6,983     |
| Reported As                                            |             |              |
| Other long-term assets                                 | $ 13,515    | $  7,181     |
| Long-term deferred income tax liabilities              | (230)       | (198)        |
| Net deferred income tax assets                         | $ 13,285    | $  6,983     |


Deferred income tax balances reflect the effects of temporary differences between the carrying amounts of assets and liabilities  and  their  tax  bases  and  are  stated  at  enacted  tax  rates  expected  to  be  in  effect  when  the  taxes  are  paid  or recovered.

As of June 30, 2022, we had federal, state, and foreign net operating loss carryforwards of $318 million, $1.3 billion, and $2.1 billion,  respectively.  The  federal  and state  net  operating  loss carryforwards will expire in various  years from fiscal 2023  through  2042,  if  not  utilized.  The  majority  of  our  foreign  net  operating  loss  carryforwards  do  not  expire.  Certain acquired net operating loss carryforwards are subject to an annual limitation but are expected to be realized

---

# Page 75

with the exception of those which have a valuation allowance. As of June 30, 2022, we had $1.3 billion federal capital loss carryforwards for U.S. tax purposes from our acquisition of Nuance. The federal capital loss carryforwards are subject to an annual limitation and will expire in various years from fiscal 2023 through 2025.

The  valuation  allowance  disclosed  in  the  table  above  relates  to  the  foreign  net  operating  loss  carryforwards,  federal capital loss carryforwards, and other net deferred tax assets that may not be realized.

Income taxes paid, net of refunds, were $16.0 billion, $13.4 billion, and $12.5 billion in fiscal years 2022, 2021, and 2020, respectively.


## Uncertain Tax Positions

Gross  unrecognized  tax  benefits  related  to  uncertain  tax  positions  as  of  June 30,  2022,  2021,  and  2020,  were $15.6 billion, $14.6 billion, and $13.8 billion, respectively, which were primarily included in long-term income taxes in our consolidated balance sheets. If recognized, the resulting tax benefit would affect our effective tax rates for fiscal years 2022, 2021, and 2020 by $13.3 billion, $12.5 billion, and $12.1 billion, respectively.

As of June 30, 2022, 2021, and 2020, we had accrued interest expense related to uncertain tax positions of $4.3 billion, $4.3 billion, and $4.0 billion, respectively, net of income tax benefits. The provision for income taxes for fiscal years 2022, 2021, and 2020 included interest expense related to uncertain tax positions of $36 million, $274 million, and $579 million, respectively, net of income tax benefits.


The aggregate changes in the gross unrecognized tax benefits related to uncertain tax positions were as follows:
|                                                         | (In millions)   | (In millions)   | (In millions)   |
|---------------------------------------------------------|-----------------|-----------------|-----------------|
| Year Ended June 30,                                     | 2022            | 2021            | 2020            |
| Beginning unrecognized tax benefits                     | $ 14,550        | $  13,792       | $  13,146       |
| Decreases related to settlements                        | (317)           | (195)           | (31)            |
| Increases for tax positions related to the current year | 1,145           | 790             | 647             |
| Increases for tax positions related to prior years      | 461             | 461             | 366             |
| Decreases for tax positions related to prior years      | (246)           | (297)           | (331)           |
| Decreases due to lapsed statutes of limitations         | 0               | (1)             | (5)             |
| Ending unrecognized tax benefits                        | $  15,593       | $    14,550     | $  13,792       |


We settled  a  portion  of  the  Internal  Revenue  Service  (-IRS‖)  audit  for  tax  years  2004  to  2006  in  fiscal  year  2011.  In February 2012, the IRS withdrew its 2011 Revenue Agents Report related to unresolved issues for tax years 2004 to 2006 and reopened the audit phase of the examination. We also settled a portion of the IRS audit for tax years 2007 to 2009 in fiscal year 2016, and a portion of the IRS audit for tax years 2010 to 2013 in fiscal year 2018. In the second quarter of fiscal year 2021, we settled an additional portion of the IRS audits for tax years 2004 to 2013 and made a payment of $1.7 billion, including tax and interest. We remain under audit for tax years 2004 to 2017.

As  of  June 30,  2022,  the  primary  unresolved  issues  for  the  IRS  audits  relate  to  transfer  pricing,  which  could  have  a material impact in our consolidated financial statements when the matters are resolved. We believe our allowances for income tax contingencies are adequate. We have not received a proposed assessment for the unresolved key transfer pricing  issues  and  do  not  expect  a  final  resolution  of  these  issues  in  the  next  12  months. Based  on  the  information currently available, we do not anticipate a significant increase or decrease to our tax contingencies for these issues within the next 12 months.

We are subject to income tax in many jurisdictions outside the U.S. Our operations in certain jurisdictions remain subject to examination for tax years 1996 to 2021, some of which are currently under audit by local tax authorities. The resolution of each of these audits is not expected to be material to our consolidated financial statements.

---

# Page 76

# NOTE 13 - UNEARNED REVENUE


Unearned revenue by segment was as follows:
|                                     | (In millions)   | (In millions)   |
|-------------------------------------|-----------------|-----------------|
| June 30,                            | 2022            | 2021            |
| Productivity and Business Processes | $ 24,558        | $ 22,120        |
| Intelligent Cloud                   | 19,371          | 17,710          |
| More Personal Computing             | 4,479           | 4,311           |
| Total                               | $  48,408       | 44,141  $       |



Changes in unearned revenue were as follows:
| (In millions)                   |            |
|---------------------------------|------------|
| Year Ended June 30, 2022        |            |
| Balance, beginning of period    | $ 44,141   |
| Deferral of revenue             | 110,455    |
| Recognition of unearned revenue | (106,188)  |
| Balance, end of period          | $   48,408 |


Revenue  allocated  to  remaining  performance  obligations,  which  includes  unearned  revenue  and  amounts  that  will  be invoiced  and  recognized  as  revenue  in  future  periods,  was  $193 billion  as  of  June 30,  2022,  of  which  $189 billion  is related to the commercial portion of revenue. We expect to recognize approximately 45% of this revenue over the next 12 months and the remainder thereafter.


## NOTE 14 - LEASES

We have operating and finance leases for datacenters, corporate offices, research and development facilities, Microsoft Experience Centers, and certain equipment. Our leases have remaining lease terms of 1 year to 19 years, some of which include options to extend the leases for up to 5 years, and some of which include options to terminate the leases within 1 year.


The components of lease expense were as follows:
|                                     | (In millions)   | (In millions)   | (In millions)   |
|-------------------------------------|-----------------|-----------------|-----------------|
| Year Ended June 30,                 | 2022            | 2021            | 2020            |
| Operating lease cost                | $  2,461        | 2,127  $        | 2,043  $        |
| Finance lease cost:                 |                 |                 |                 |
| Amortization of right-of-use assets | $ 980           | $ 921           | $ 611           |
| Interest on lease liabilities       | 429             | 386             | 336             |
| Total finance lease cost            | $ 1,409         | $ 1,307         | $ 947           |

---

# Page 77

Supplemental cash flow information related to leases was as follows:
|                                                                         | (In millions)   | (In millions)   | (In millions)   |
|-------------------------------------------------------------------------|-----------------|-----------------|-----------------|
| Year Ended June 30,                                                     | 2022            | 2021            | 2020            |
| Cash paid for amounts included in the measurement of lease liabilities: |                 |                 |                 |
| Operating cash flows from operating leases                              | $  2,368        | 2,052  $        | 1,829  $        |
| Operating cash flows from finance leases                                | 429             | 386             | 336             |
| Financing cash flows from finance leases                                | 896             | 648             | 409             |
| Right-of-use assets obtained in exchange for lease obligations:         |                 |                 |                 |
| Operating leases                                                        | 5,268           | 4,380           | 3,677           |
| Finance leases                                                          | 4,234           | 3,290           | 3,467           |



Supplemental balance sheet information related to leases was as follows:
| (In millions, except lease term and discount rate)   |             |             |
|------------------------------------------------------|-------------|-------------|
| June 30,                                             | 2022        | 2021        |
| Operating Leases                                     |             |             |
| Operating lease right-of-use assets                  | $    13,148 | $    11,088 |
| Other current liabilities                            | $ 2,228     | $  1,962    |
| Operating lease liabilities                          | 11,489      | 9,629       |
| Total operating lease liabilities                    | $ 13,717    | $  11,591   |
| Finance Leases                                       |             |             |
| Property and equipment, at cost                      | $ 17,388    | $  14,107   |
| Accumulated depreciation                             | (3,285)     | (2,306)     |
| Property and equipment, net                          | $ 14,103    | $  11,801   |
| Other current liabilities                            | $ 1,060     | $  791      |
| Other long-term liabilities                          | 13,842      | 11,750      |
| Total finance lease liabilities                      | $ 14,902    | $  12,541   |
| Weighted Average Remaining Lease Term                |             |             |
| Operating leases                                     | 8 years     | 8 years     |
| Finance leases                                       | 12 years    | 12 years    |
| Weighted Average Discount Rate                       |             |             |
| Operating leases                                     | 2.1%        | 2.2%        |
| Finance leases                                       | 3.1%        | 3.4%        |



The following table outlines maturities of our lease liabilities as of June 30, 2022:
| (In millions) Year Ending June 30,   | Operating  Leases   | Finance  Leases   |
|--------------------------------------|---------------------|-------------------|
| 2023                                 | $ 2,456             | $ 1,477           |
| 2024                                 | 2,278               | 1,487             |
| 2025                                 | 1,985               | 1,801             |
| 2026                                 | 1,625               | 1,483             |
| 2027                                 | 1,328               | 1,489             |
| Thereafter                           | 5,332               | 9,931             |
| Total lease payments                 | 15,004              | 17,668            |
| Less imputed interest                | (1,287)             | (2,766)           |
| Total                                | $    13,717         | $   14,902        |

---

# Page 78

As  of  June 30,  2022,  we  have  additional  operating  and  finance  leases,  primarily  for  datacenters,  that  have  not  yet commenced of  $7.2 billion  and  $8.8 billion,  respectively.  These  operating  and  finance  leases  will  commence  between fiscal year 2023 and fiscal year 2028 with lease terms of 1 year to 18 years.


# NOTE 15 - CONTINGENCIES


## Antitrust Litigation and Claims


## China State Administration for Market Regulation Investigation

In 2014, Microsoft was informed that China's State Agency for Market Regulation (-SAMR‖) (formerly State Administration for  Industry  and  Commerce)  had  begun  a  formal  investigation  relating  to  China's  Anti-Monopoly  Law,  and  the  SAMR conducted onsite inspections of Microsoft offices in Beijing,  Shanghai, Guangzhou,  and Chengdu. In  2019,  the  SAMR presented preliminary views as to certain possible violations of China's Anti-Monopoly Law.


## Product-Related Litigation


## U.S. Cell Phone Litigation

Microsoft  Mobile  Oy,  a  subsidiary  of  Microsoft,  along  with  other  handset  manufacturers  and  network  operators,  is  a defendant in 46 lawsuits, including 45 lawsuits filed in the Superior Court for the District of Columbia by individual plaintiffs who allege that radio emissions from cellular handsets caused their brain tumors and other adverse health effects. We assumed responsibility for these claims in our agreement to acquire Nokia's Devices and Services business and have been substituted for the Nokia defendants. Nine of these cases were filed in 2002 and are consolidated for certain pre-trial proceedings;  the  remaining  cases  are  stayed.  In  a  separate  2009  decision,  the  Court  of  Appeals  for  the  District  of Columbia held that adverse health effect  claims  arising  from  the  use  of  cellular  handsets  that  operate  within  the  U.S. Federal Communications Commission radio frequency emission guidelines (-FCC Guidelines‖) are pre-empted by federal law. The plaintiffs allege that their handsets either operated outside the FCC Guidelines or were manufactured before the FCC Guidelines  went  into  effect.  The  lawsuits  also  allege  an  industry-wide  conspiracy  to  manipulate  the  science  and testing around emission guidelines.

In 2013, the defendants in the consolidated cases moved to exclude the plaintiffs' expert evidence of general causation on the basis of flawed scientific methodologies. In 2014, the trial court granted in part and denied in part the defendants' motion to exclude the plaintiffs' general causation experts. The defendants filed an interlocutory appeal to the District of Columbia Court of Appeals challenging the standard for evaluating expert scientific evidence. In October 2016, the Court of Appeals issued its decision adopting the standard advocated by the defendants and remanding the cases to the trial court for further proceedings under that standard. The plaintiffs have filed supplemental expert evidence, portions of which the  defendants  have  moved  to  strike.  In  August  2018,  the  trial  court  issued  an  order  striking  portions  of  the  plaintiffs' expert reports. A hearing on general causation is scheduled for September of 2022.


## Other Contingencies

We also  are  subject  to  a  variety  of  other  claims  and  suits  that  arise  from  time  to  time  in  the  ordinary  course  of  our business. Although management currently believes that resolving claims against us, individually or in aggregate, will not have  a  material  adverse  impact  in  our  consolidated  financial  statements,  these  matters  are  subject  to  inherent uncertainties and management's view of these matters may change in the future.

As  of  June 30,  2022,  we  accrued  aggregate  legal  liabilities  of  $364 million.  While  we  intend  to  defend  these  matters vigorously,  adverse  outcomes  that  we  estimate  could  reach  approximately  $600 million  in  aggregate  beyond  recorded amounts are  reasonably  possible. Were  unfavorable  final  outcomes  to  occur,  there  exists  the  possibility  of  a  material adverse impact in our consolidated financial statements for the period in which the effects become reasonably estimable.

---

# Page 79

# NOTE 16 - STOCKHOLDERS' EQUITY


## Shares Outstanding


Shares of common stock outstanding were as follows:
| (In millions)              |       |       |       |
|----------------------------|-------|-------|-------|
| Year Ended June 30,        | 2022  | 2021  | 2020  |
| Balance, beginning of year | 7,519 | 7,571 | 7,643 |
| Issued                     | 40    | 49    | 54    |
| Repurchased                | (95)  | (101) | (126) |
| Balance, end of year       | 7,464 | 7,519 | 7,571 |



## Share Repurchases

On September 20, 2016, our Board of Directors approved a share repurchase program authorizing up to $40.0 billion in share repurchases. This share repurchase program commenced in December 2016 and was completed in February 2020.

On September 18, 2019, our Board of Directors approved a share repurchase program authorizing up to $40.0 billion in share repurchases. This share repurchase program commenced in February 2020 and was completed in November 2021.

On September 14, 2021, our Board of Directors approved a share repurchase program authorizing up to $60.0 billion in share repurchases. This share repurchase program commenced in November 2021, following completion of the program approved  on  September 18,  2019,  has  no  expiration  date,  and  may  be  terminated  at  any  time.  As  of  June 30,  2022, $40.7 billion remained of this $60.0 billion share repurchase program.


We repurchased the following shares of common stock under the share repurchase programs:
| (In millions)       | Shares   | Amount   | Shares   | Amount    | Shares   | Amount   |
|---------------------|----------|----------|----------|-----------|----------|----------|
| Year Ended June 30, |          | 2022     |          | 2021      |          | 2020     |
| First Quarter       | 21       | $ 6,200  | 25       | $  5,270  | 29       | $  4,000 |
| Second Quarter      | 20       | 6,233    | 27       | 5,750     | 32       | 4,600    |
| Third Quarter       | 26       | 7,800    | 25       | 5,750     | 37       | 6,000    |
| Fourth Quarter      | 28       | 7,800    | 24       | 6,200     | 28       | 5,088    |
| Total               | 95       | $28,033  | 101      | $  22,970 | 126      | $19,688  |


All repurchases were made using cash resources. Shares repurchased during the fourth and third quarters of fiscal year 2022  were  under  the  share  repurchase  program  approved  on  September 14,  2021.  Shares  repurchased  during  the second quarter of fiscal year 2022 were under the share repurchase programs approved on both September 14, 2021 and September 18, 2019.  Shares repurchased  during the first  quarter  of  fiscal  year  2022,  fiscal  year  2021,  and  the  fourth quarter  of  fiscal  year  2020  were  under  the  share  repurchase  program  approved  on  September 18,  2019.  Shares repurchased during the third quarter of fiscal year 2020 were under the share repurchase programs approved on both September 20, 2016 and September 18, 2019. All other shares repurchased were under the share repurchase program approved  on  September 20,  2016.  The  above  table  excludes  shares  repurchased  to  settle  employee  tax  withholding related to the vesting of stock awards of $4.7 billion, $4.4 billion, and $3.3 billion for fiscal years 2022, 2021, and 2020, respectively.

---

# Page 80

# Dividends


Our Board of Directors declared the following dividends:
| Declaration Date   | Record Date                            | Payment Date                          | Dividend Per Share   | Amount        |
|--------------------|----------------------------------------|---------------------------------------|----------------------|---------------|
| Fiscal Year 2022   |                                        |                                       |                      | (In millions) |
| September 14, 2021 | November 18, 2021                      | December 9, 2021                      | $ 0.62               | $ 4,652       |
| December 7, 2021   | February 17, 2022                      | March 10, 2022                        | 0.62                 | 4,645         |
| March 14, 2022     | May 19, 2022                           | June 9, 2022                          | 0.62                 | 4,632         |
| June 14, 2022      | August 18, 2022                        | September 8, 2022                     | 0.62                 | 4,627         |
| Total              |                                        |                                       | $  2.48              | $  18,556     |
| Fiscal Year 2021   |                                        |                                       |                      |               |
| September 15, 2020 | November 19, 2020    December 10, 2020 |                                       | $  0.56              | $ 4,230       |
| December 2, 2020   | February 18, 2021                      | March 11, 2021                        | 0.56                 | 4,221         |
| March 16, 2021     | May 20, 2021                           | June 10, 2021                         | 0.56                 | 4,214         |
| June 16, 2021      |                                        | August 19, 2021     September 9, 2021 | 0.56                 | 4,206         |
| Total              |                                        |                                       | $  2.24              | $ 16,871      |


The dividend declared on June 14, 2022 was included in other current liabilities as of June 30, 2022.


## NOTE 17 - ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)


The following table summarizes the changes in accumulated other comprehensive income (loss) by component:
| (In millions)                                                                           | 2022      | 2021    |         |
|-----------------------------------------------------------------------------------------|-----------|---------|---------|
| Year Ended June 30,                                                                     |           |         | 2020    |
| Derivatives                                                                             |           |         |         |
| Balance, beginning of period                                                            | $ (19)    | $  (38) | $  0    |
| Unrealized gains (losses), net of tax of  $(15) , $9, and $(10)                         | (57)      | 34      | (38)    |
| Reclassification adjustments for (gains) losses included in other income (expense), net | 79        | (17)    | 0       |
| Tax expense (benefit) included in provision for income taxes                            | (16)      | 2       | 0       |
| Amounts reclassified from accumulated other comprehensive income (loss)                 | 63        | (15)    | 0       |
| Net change related to derivatives, net of tax of  $1 , $7, and $(10)                    | 6         | 19      | (38)    |
| Balance, end of period                                                                  | $ (13)    | $  (19) | $  (38) |
| Investments                                                                             |           |         |         |
| Balance, beginning of period                                                            | $ 3,222   | $ 5,478 | $ 1,488 |
| Unrealized gains (losses), net of tax of  $(1,440) , $(589), and $1,057                 | (5,405)   | (2,216) | 3,987   |
| Reclassification adjustments for (gains) losses included in other income (expense), net | 57        | (63)    | 4       |
| Tax expense (benefit) included in provision for income taxes                            | (12)      | 13      | (1)     |
| Amounts reclassified from accumulated other comprehensive income (loss)                 | 45        | (50)    | 3       |
| Net change related to investments, net of tax of  $(1,428) , $(602), and $1,058         | (5,360)   | (2,266) | 3,990   |
| Cumulative effect of accounting changes                                                 | 0         | 10      | 0       |
| Balance, end of period                                                                  | $ (2,138) | $ 3,222 | $ 5,478 |

---

# Page 81

|                                                                     | (In millions)   | (In millions)   | (In millions)   |
|---------------------------------------------------------------------|-----------------|-----------------|-----------------|
| Year Ended June 30,                                                 | 2022            | 2021            | 2020            |
| Translation Adjustments and Other                                   |                 |                 |                 |
| Balance, beginning of period                                        | $ (1,381)       | $(2,254)        | $(1,828)        |
| Translation adjustments and other, net of tax of  $0 , $(9), and $1 | (1,146)         | 873             | (426)           |
| Balance, end of period                                              | $ (2,527)       | $(1,381)        | $(2,254)        |
| Accumulated other comprehensive income (loss), end of period        | $ (4,678)       | $ 1,822         | $ 3,186         |



# NOTE 18 - EMPLOYEE STOCK AND SAVINGS PLANS

We grant stock-based compensation to employees and directors. Awards that expire or are canceled without delivery of shares generally  become available for issuance  under the plans. We issue new shares of Microsoft common stock to satisfy vesting of awards granted under our stock plans. We also have an ESPP for all eligible employees.


Stock-based compensation expense and related income tax benefits were as follows:
|                                                         | (In millions)   | (In millions)   | (In millions)   |
|---------------------------------------------------------|-----------------|-----------------|-----------------|
| Year Ended June 30,                                     | 2022            | 2021            | 2020            |
| Stock-based compensation expense                        | $7,502          | 6,118  $        | $  5,289        |
| Income tax benefits related to stock-based compensation | 1,293           | 1,065           | 938             |



## Stock Plans

Stock awards entitle the holder to receive shares of Microsoft common stock as the award vests. Stock awards generally vest over a service period of four years or five years.


## Executive Incentive Plan

Under  the  Executive  Incentive  Plan,  the  Compensation  Committee  approves  stock  awards  to  executive  officers  and certain senior executives. RSUs generally vest ratably over a service period of four years. PSUs generally vest over a performance period of three years. The number of shares the PSU holder receives is based on the extent to which the corresponding performance goals have been achieved.


## Activity for All Stock Plans


The fair value of stock awards was estimated on the date of grant using the following assumptions:
| Year ended June 30,                     | 2022             | 2021             | 2020           |
|-----------------------------------------|------------------|------------------|----------------|
| Dividends per share (quarterly amounts) | $   0.56 -  0.62 | 0.51 - 0.56  $   | 0.46 - 0.51  $ |
| Interest rates                          | 0.03% - 3.6%     | .01% - 1.5%    0 | 0.1% - 2.2%    |

---

# Page 82

During fiscal year 2022, the following activity occurred under our stock plans:
|                                      | Shares (In millions)   | Weighted Average  Grant-Date Fair Value   |
|--------------------------------------|------------------------|-------------------------------------------|
| Stock Awards                         |                        |                                           |
| Nonvested balance, beginning of year | 100                    | $152.51                                   |
| Granted  (a)                         | 50                     | 291.22                                    |
| Vested                               | (47)                   | 143.10                                    |
| Forfeited                            | (10)                   | 189.88                                    |
| Nonvested balance, end of year       | 93                     | $227.59                                   |
(a) Includes  1 million,  2 million,  and  2 million  of  PSUs  granted  at  target  and  performance  adjustments  above  target levels for fiscal years 2022, 2021, and 2020, respectively.


As of  June 30,  2022,  there  was  approximately  $16.7 billion  of  total  unrecognized  compensation  costs  related  to  stock awards.  These  costs  are  expected  to  be  recognized  over  a  weighted  average  period  of  three  years.  The  weighted average grant-date fair value of stock awards granted was $291.22, $221.13, and $140.49 for fiscal years 2022, 2021, and 2020, respectively. The fair value of stock awards vested was $14.1 billion, $13.4 billion, and $10.1 billion, for fiscal years 2022, 2021, and 2020, respectively. As of June 30, 2022, an aggregate of 211 million shares were authorized for future grant under our stock plans.


## Employee Stock Purchase Plan

We have an ESPP for all eligible employees. Shares of our common stock may be purchased by employees at threemonth  intervals  at  90%  of  the  fair  market  value  on  the  last  trading  day  of  each  three-month  period.  Employees  may purchase shares having a value not exceeding 15% of their gross compensation during an offering period. Under the terms of the ESPP that were approved in 2012, the plan was set to terminate on December 31, 2022. At our 2021 Annual Shareholders Meeting, our shareholders approved a successor ESPP with a January 1, 2022 effective date and ten-year expiration of December 31, 2031. No additional shares were requested at this meeting.


Employees purchased the following shares during the periods presented:
| (Shares in millions)    |           |           |           |
|-------------------------|-----------|-----------|-----------|
| Year Ended June 30,     | 2022      | 2021      | 2020      |
| Shares purchased        | 7         | 8         | 9         |
| Average price per share | $  259.55 | 207.88  $ | 142.22  $ |


As of June 30, 2022, 81 million shares of our common stock were reserved for future issuance through the ESPP.


## Savings Plans

We have savings plans in the U.S. that qualify  under  Section 401(k)  of  the  Internal  Revenue  Code,  and  a  number  of savings plans in international locations. Eligible U.S. employees may contribute a portion of their salary into the savings plans, subject to certain limitations. We match a portion of each dollar a participant contributes into the plans. Employerfunded retirement benefits for all plans were $1.4 billion, $1.2 billion, and $1.0 billion in fiscal years 2022, 2021, and 2020, respectively, and were expensed as contributed.

---

# Page 83

# NOTE 19 - SEGMENT INFORMATION AND GEOGRAPHIC DATA

In  its  operation  of  the  business,  management,  including  our  chief  operating  decision  maker,  who  is  also  our  Chief Executive Officer, reviews certain financial information, including segmented internal profit and loss statements prepared on a basis not consistent with GAAP. During the periods presented, we reported our financial performance based on the following segments: Productivity and Business Processes, Intelligent Cloud, and More Personal Computing.

Our reportable segments are described below.


## Productivity and Business Processes


Our  Productivity  and  Business  Processes  segment  consists  of  products  and  services  in  our  portfolio  of  productivity, communication, and information services, spanning a variety of devices and platforms. This segment primarily comprises:
- · Office Commercial  (Office 365 subscriptions, the Office 365 portion of Microsoft 365 Commercial subscriptions, and Office licensed on-premises), comprising Office, Exchange, SharePoint, Microsoft Teams, Office 365 Security and Compliance, and Microsoft Viva.
- · Office  Consumer, including Microsoft 365 Consumer subscriptions, Office licensed on-premises, and other Office services.
- · LinkedIn, including Talent Solutions, Marketing Solutions, Premium Subscriptions, and Sales Solutions.
- · Dynamics  business  solutions, including Dynamics  365,  comprising  a  set  of intelligent, cloud-based applications across ERP, CRM, Customer Insights, Power Apps, and Power Automate; and on-premises ERP and CRM applications.



## Intelligent Cloud


Our  Intelligent  Cloud  segment  consists  of  our  public,  private,  and  hybrid  server  products  and  cloud  services  that  can power modern business and developers. This segment primarily comprises:
- · Server products and cloud services, including Azure and other cloud services; SQL Server, Windows Server, Visual Studio, System Center, and related Client Access Licenses (-CALs‖); and Nuance and GitHub.
- · Enterprise  Services,  including  Enterprise  Support  Services,  Microsoft  Consulting  Services,  and  Nuance professional services.



## More Personal Computing


Our  More  Personal  Computing  segment  consists  of  products  and  services  that  put  customers  at  the  center  of  the experience with our technology. This segment primarily comprises:
- · Windows,  including  Windows  OEM  licensing  and  other  non-volume  licensing  of  the  Windows  operating system;  Windows  Commercial,  comprising  volume  licensing  of  the  Windows  operating  system,  Windows cloud services, and other Windows commercial offerings; patent licensing; and Windows Internet of Things.
- · Devices, including Surface and PC accessories.
- · Gaming, including Xbox hardware and Xbox content and services, comprising first- and third-party content (including  games  and  in-game  content),  Xbox  Game  Pass  and  other  subscriptions,  Xbox  Cloud  Gaming, third-party disc royalties, advertising, and other cloud services.
- · Search and news advertising.


Revenue and costs are  generally  directly  attributed  to  our  segments.  However,  due  to  the  integrated  structure  of  our business, certain revenue  recognized and costs incurred by  one segment may benefit other segments. Revenue from certain contracts is allocated among the segments based on the relative value of the underlying products and services, which can include allocation based on actual prices charged, prices when sold separately, or estimated costs plus a profit margin. Cost of revenue is allocated in certain cases based on a relative revenue methodology. Operating expenses that are allocated primarily include those relating to marketing of products and services from which multiple segments benefit and are generally allocated based on relative gross margin.

---

# Page 84

In addition, certain costs incurred at a corporate level that are identifiable and that benefit our segments are allocated to them.  These  allocated  costs  include  legal,  including  settlements  and  fines,  information  technology,  human  resources, finance,  excise  taxes,  field  selling,  shared  facilities  services,  and  customer  service  and  support.  Each  allocation  is measured differently based on the specific facts and circumstances of the costs being allocated.


Segment revenue and operating income were as follows during the periods presented:
| (In millions) Year Ended June 30,   | 2022       | 2021       | 2020       |
|-------------------------------------|------------|------------|------------|
| Revenue                             |            |            |            |
| Productivity and Business Processes | $ 63,364   | $ 53,915   | $ 46,398   |
| Intelligent Cloud                   | 75,251     | 60,080     | 48,366     |
| More Personal Computing             | 59,655     | 54,093     | 48,251     |
| Total                               | $  198,270 | 168,088  $ | 143,015  $ |
| Operating Income                    |            |            |            |
| Productivity and Business Processes | $ 29,687   | $ 24,351   | $ 18,724   |
| Intelligent Cloud                   | 32,721     | 26,126     | 18,324     |
| More Personal Computing             | 20,975     | 19,439     | 15,911     |
| Total                               | $ 83,383   | $ 69,916   | $ 52,959   |



No sales to an individual customer or country other than the United States accounted for more than 10% of revenue for fiscal years 2022, 2021, or 2020. Revenue, classified by the major geographic areas in which our customers were located, was as follows:
| (In millions)       |          |            |            |
|---------------------|----------|------------|------------|
| Year Ended June 30, | 2022     | 2021       | 2020       |
| United States  (a)  | $100,218 | $ 83,953   | $ 73,160   |
| Other countries     | 98,052   | 84,135     | 69,855     |
| Total               | $198,270 | 168,088  $ | 143,015  $ |
(a) Includes billings to OEMs and certain multinational organizations because of the nature of these businesses and the impracticability of determining the geographic source of the revenue.



Revenue, classified by significant product and service offerings, was as follows:
| (In millions)                      |                 | 2021           |               |
|------------------------------------|-----------------|----------------|---------------|
| Year Ended June 30,                | 2022            |                | 2020 $ 41,379 |
| Server products and cloud services | $ 67,321 44,862 | $ 52,589       | 35,316        |
| Office products and cloud services | 24,761          | 39,872  22,488 | 21,510        |
| Windows                            |                 |                | 11,575        |
| Gaming                             | 16,230          | 15,370         |               |
| LinkedIn                           | 13,816          | 10,289         | 8,077         |
| Search and news advertising        | 11,591          | 9,267          | 8,524         |
| Enterprise Services                | 7,407           | 6,943          | 6,409         |
| Devices                            | 6,991           | 6,791          | 6,457         |
| Other                              | 5,291           | 4,479          | 3,768         |
| Total                              | $   198,270     | 168,088  $     | 143,015  $    |


We have recast certain previously reported amounts in the table above to conform to the way we internally manage and monitor our business.

---

# Page 85

Our  Microsoft  Cloud  (formerly  commercial  cloud)  revenue,  which  includes  Azure  and  other  cloud  services,  Office  365 Commercial, the commercial portion of LinkedIn, Dynamics 365, and other commercial cloud properties, was $91.2 billion, $69.1 billion and $51.7 billion in fiscal years 2022, 2021, and 2020, respectively. These amounts are primarily included in Server products and cloud services, Office products and cloud services, and LinkedIn in the table above.

Assets are not allocated to segments for internal reporting presentations. A portion of amortization and depreciation is included  with  various  other  costs  in  an  overhead  allocation  to  each  segment.  It  is  impracticable  for  us  to  separately identify the amount of amortization and depreciation by segment that is included in the measure of segment profit or loss.


Long-lived assets,  excluding financial  instruments  and  tax  assets,  classified  by  the  location  of  the  controlling  statutory company and with countries over 10% of the total shown separately, were as follows:
| (In millions)   |            |            |            |
|-----------------|------------|------------|------------|
| June 30,        | 2022       | 2021       | 2020       |
| United States   | $ 106,430  | $ 76,153   | $ 60,789   |
| Ireland         | 15,505     | 13,303     | 12,734     |
| Other countries | 44,433     | 38,858     | 29,770     |
| Total           | $  166,368 | 128,314  $ | 103,293  $ |

---

# Page 86

# REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

To the Stockholders and the Board of Directors of Microsoft Corporation


## Opinion on the Financial Statements

We  have  audited  the  accompanying  consolidated  balance  sheets  of  Microsoft  Corporation  and  subsidiaries  (the -Company‖) as of June 30, 2022 and 2021, the related consolidated statements of income, comprehensive income, cash flows,  and  stockholders'  equity,  for  each  of  the  three  years  in  the  period  ended  June  30,  2022,  and  the  related  notes (collectively referred to as the -financial statements‖). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of June 30, 2022 and 2021, and the results of its operations and its cash  flows  for  each  of  the  three  years  in  the  period  ended  June  30,  2022,  in  conformity  with  accounting  principles generally accepted in the United States of America.

We have also  audited,  in  accordance  with  the  standards  of  the  Public  Company  Accounting  Oversight  Board  (United States)  (PCAOB),  the  Company's  internal  control  over  financial  reporting  as  of  June  30,  2022,  based  on  criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the  Treadway  Commission  and  our  report  dated  July  28,  2022,  expressed  an  unqualified  opinion  on  the  Company's internal control over financial reporting.


## Basis for Opinion

These  financial  statements  are  the  responsibility  of  the  Company's  management.  Our  responsibility  is  to  express  an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

We conducted our audits in accordance with the standards of the  PCAOB. Those standards require that we plan and perform  the  audit  to  obtain  reasonable  assurance  about  whether  the  financial  statements  are  free  of  material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks.  Such  procedures  included  examining,  on  a  test  basis,  evidence  regarding  the  amounts  and  disclosures  in  the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial  statements. We believe that our audits provide a reasonable basis for our opinion.


## Critical Audit Matters

The critical audit matters communicated below are matters arising from the current-period audit of the financial statements that  were  communicated  or  required  to  be  communicated  to  the  audit  committee  and  that  (1)  relate  to  accounts  or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

---

# Page 87

# Revenue Recognition - Refer to Note 1 to the financial statements


## Critical Audit Matter Description

The Company recognizes revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products or services. The Company offers customers the ability to acquire multiple licenses of software products and services, including cloud-based services, in its customer agreements through its volume licensing programs.


Significant judgment is exercised by the Company in determining revenue recognition for these customer agreements, and includes the following:
- · Determination  of  whether  products  and  services  are  considered  distinct  performance  obligations  that  should  be accounted for separately versus together, such as software licenses and related services that are sold with cloudbased services.
- · The pattern of delivery (i.e., timing of when revenue is recognized) for each distinct performance obligation.
- · Identification  and treatment of contract terms that may impact the timing and amount of revenue recognized (e.g., variable consideration, optional purchases, and free services).
- · Determination of stand-alone selling prices for each distinct performance obligation and for products and services that are not sold separately.


Given these factors and due to the volume of transactions, the related audit effort in evaluating management's judgments in determining revenue recognition for these customer agreements was extensive and required a high degree of auditor judgment.


## How the Critical Audit Matter Was Addressed in the Audit


Our principal audit procedures related to the Company's revenue recognition for these customer agreements included the following:
- · We  tested  the  effectiveness  of  controls  related  to  the  identification  of  distinct  performance  obligations,  the determination of the timing of revenue recognition, and the estimation of variable consideration.
- · We evaluated management's significant accounting policies related to these customer agreements for reasonableness.
- · We selected a sample of customer agreements and performed the following procedures:
- -Obtained and read contract source documents for each selection, including master agreements, and other documents that were part of the agreement.
- -Tested management's identification and treatment of contract terms.
- -Assessed the terms in the customer agreement and evaluated the appropriateness of management's application of their accounting policies, along with their use of estimates, in the determination of revenue recognition conclusions.
- · We evaluated the reasonableness of management's estimate of stand-alone selling prices for products and services that are not sold separately.
- · We tested the mathematical accuracy of management's calculations of revenue and the associated timing of revenue recognized in the financial statements.

---

# Page 88

# Income Taxes - Uncertain Tax Positions - Refer to Note 12 to the financial statements


## Critical Audit Matter Description

The  Company's  long-term  income  taxes  liability  includes  uncertain  tax  positions  related  to  transfer  pricing  issues  that remain unresolved with the Internal Revenue Service (-IRS‖). The Company remains under IRS audit, or subject to IRS audit,  for  tax  years  subsequent  to  2003. While  the  Company  has  settled  a  portion  of  the  IRS  audits,  resolution  of  the remaining matters could have a material impact on the Company's financial statements.

Conclusions  on  recognizing  and  measuring  uncertain  tax  positions  involve  significant  estimates  and  management judgment and include complex considerations of the Internal Revenue Code, related regulations, tax case laws, and prioryear  audit  settlements.  Given  the  complexity  and  the  subjective  nature  of  the  transfer  pricing  issues  that  remain unresolved  with  the  IRS,  evaluating  management's  estimates  relating  to  their  determination  of  uncertain  tax  positions required extensive audit effort and a high degree of auditor judgment, including involvement of our tax specialists.


## How the Critical Audit Matter Was Addressed in the Audit


Our  principal  audit  procedures  to  evaluate  management's  estimates  of  uncertain  tax  positions  related  to  unresolved transfer pricing issues included the following:
- · We  evaluated  the  appropriateness  and  consistency  of  management's  methods  and  assumptions  used  in  the identification,  recognition,  measurement,  and  disclosure  of  uncertain  tax  positions,  which  included  testing  the effectiveness of the related internal controls.
- · We  read  and  evaluated  management's  documentation,  including  relevant  accounting  policies  and  information obtained by management from outside tax specialists, that detailed the basis of the uncertain tax positions.
- · We  tested  the  reasonableness  of  management's  judgments  regarding  the  future  resolution  of  the  uncertain  tax positions, including an evaluation of the technical merits of the uncertain tax positions.
- · For  those  uncertain  tax  positions  that  had  not  been  effectively  settled,  we  evaluated  whether  management  had appropriately considered new information that could significantly change the recognition, measurement or disclosure of the uncertain tax positions.
- · We  evaluated  the  reasonableness  of  management's  estimates  by  considering  how  tax  law,  including  statutes, regulations and case law, impacted management's judgments.


/S/    DELOITTE & TOUCHE LLP

Seattle, Washington July 28, 2022

We have served as the Company's auditor since 1983.

---

# Page 89

# CHANGES IN AND DISAGREEMENTS WITH ACCOUNTANTS ON ACCOUNTING AND FINANCIAL DISCLOSURE

Not applicable.


## CONTROLS AND PROCEDURES

Under  the  supervision  and  with  the  participation  of  our  management,  including  the  Chief  Executive  Officer  and  Chief Financial Officer, we have evaluated the effectiveness of our disclosure controls and procedures as required by Exchange Act  Rule  13a-15(b)  as  of  the  end  of  the  period  covered  by  this  report.  Based  on  that  evaluation,  the  Chief  Executive Officer and Chief Financial Officer have concluded that these disclosure controls and procedures are effective.


## REPORT OF MANAGEMENT ON INTERNAL CONTROL OVER FINANCIAL REPORTING

Our management is responsible for establishing and maintaining adequate internal control over financial reporting for the Company. Internal control over financial reporting is a process to provide reasonable assurance regarding the reliability of our financial reporting for  external purposes in accordance with accounting principles generally accepted in the United States  of  America.  Internal  control  over  financial  reporting  includes  maintaining  records  that  in  reasonable  detail accurately and fairly reflect our transactions; providing reasonable assurance that transactions are recorded as necessary for preparation of our consolidated financial statements; providing reasonable assurance that receipts and expenditures of company  assets  are  made  in  accordance  with  management  authorization;  and  providing  reasonable  assurance  that unauthorized  acquisition,  use,  or  disposition  of  company  assets  that  could  have  a  material  effect  on  our  consolidated financial statements would be prevented or detected on a timely basis. Because of its inherent limitations, internal control over financial reporting is not intended to provide absolute assurance that a misstatement of our consolidated financial statements would be prevented or detected.

Management conducted an evaluation of the effectiveness of our internal control over financial reporting based on the framework in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway  Commission.  Based  on  this  evaluation,  management  concluded  that  the  Company's  internal  control  over financial  reporting  was  effective  as  of  June 30,  2022.  There  were  no  changes  in  our  internal  control  over  financial reporting  during  the  quarter  ended  June 30,  2022  that  have  materially  affected,  or  are  reasonably  likely  to  materially affect, our internal control over financial reporting. Deloitte & Touche LLP has audited our internal control over financial reporting as of June 30, 2022; their report follows.

---

# Page 90

# REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

To the Stockholders and the Board of Directors of Microsoft Corporation


## Opinion on Internal Control over Financial Reporting

We have audited the internal control over financial reporting of Microsoft Corporation and subsidiaries (the -Company‖) as of  June  30,  2022,  based  on  criteria  established  in Internal  Control-Integrated  Framework  (2013) issued  by  the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of June 30, 2022, based on criteria established in Internal Control-Integrated Framework (2013) issued by COSO.

We have also  audited,  in  accordance  with  the  standards  of  the  Public  Company  Accounting  Oversight  Board  (United States) (PCAOB), the consolidated financial statements as of and for the year ended June 30, 2022, of the Company and our report dated July 28, 2022, expressed an unqualified opinion on those financial statements.


## Basis for Opinion

The Company's management is responsible for maintaining effective internal control over financial reporting and for its assessment  of  the  effectiveness  of  internal  control  over  financial  reporting,  included  in  the  accompanying  Report  of Management on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company's internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

We conducted our audit  in  accordance  with  the  standards  of  the  PCAOB.  Those  standards  require  that  we  plan  and perform  the  audit  to  obtain  reasonable  assurance  about  whether  effective  internal  control  over  financial  reporting  was maintained  in  all  material  respects.  Our  audit  included  obtaining  an  understanding  of  internal  control  over  financial reporting,  assessing  the  risk  that  a  material  weakness  exists,  testing  and  evaluating  the  design  and  operating effectiveness of internal  control  based  on  the  assessed  risk,  and  performing  such  other  procedures  as  we  considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.


## Definition and Limitations of Internal Control over Financial Reporting

A company's internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability  of  financial  reporting  and  the  preparation  of  financial  statements  for  external  purposes  in  accordance  with generally accepted accounting principles. A company's internal control over financial reporting includes those policies and procedures  that  (1)  pertain  to  the  maintenance  of  records  that,  in  reasonable  detail,  accurately  and  fairly  reflect  the transactions  and  dispositions  of  the  assets  of  the  company;  (2)  provide  reasonable  assurance  that  transactions  are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management  and  directors  of  the  company;  and  (3)  provide  reasonable  assurance  regarding  prevention  or  timely detection of unauthorized acquisition, use, or disposition of the company's assets that could have a material effect on the financial statements.

Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections  of  any  evaluation  of  effectiveness  to  future  periods  are  subject  to  the  risk  that  controls  may  become inadequate  because  of  changes  in  conditions,  or  that  the  degree  of  compliance  with  the  policies  or  procedures  may deteriorate.

/S/ DELOITTE & TOUCHE LLP

Seattle, Washington July 28, 2022

---

# Page 91

# DIRECTORS AND EXECUTIVE OFFICERS OF MICROSOFT CORPORATION


## DIRECTORS


## Satya Nadella

Chairman and Chief Executive Officer, Microsoft Corporation


## Sandra E. Peterson  2,3

Operating Partner,

Clayton, Dubilier & Rice, LLC


## John W. Stanton  1,4

Founder and Chairman, Trilogy Partnerships


## Reid G. Hoffman  4

General Partner, Greylock Partners


## Penny S. Pritzker  4

Founder and Chairman, PSP Partners, LLC


## John W. Thompson  3,4

Lead Independent Director, Microsoft Corporation


## Hugh F. Johnston  1

Vice Chairman and Executive Vice President and Chief Financial Officer, PepsiCo, Inc.

Carlos A. Rodriguez  1

Chief Executive Officer, ADP, Inc.

Emma N. Walmsley  2,4

Chief Executive Officer, GSK, plc


## Teri L. List 1,3

Former Executive Vice President and Chief Financial Officer, Gap, Inc.


## Charles W. Scharf  2,3

Chief Executive Officer and President, Wells Fargo & Company


## Padmasree Warrior  2

Founder, President and Chief Executive Officer, Fable Group Inc.


## Board Committees


- 1. Audit Committee
- 2. Compensation Committee
- 3. Governance and Nominating Committee
- 4. Environmental, Social, and Public Policy Committee



## EXECUTIVE OFFICERS


## Satya Nadella

Chairman and Chief Executive Officer


## Judson Althoff

Executive Vice President and Chief Commercial Officer


## Christopher C. Capossela

Executive Vice President, Marketing and Consumer Business, and Chief Marketing Officer


## Kathleen T. Hogan

Executive Vice President and Chief Human Resources Officer


## Amy E. Hood

Executive Vice President and Chief Financial Officer


## Bradford L. Smith

Vice Chair and President


## Christopher D. Young

Executive Vice President, Business Development, Strategy, and Ventures

---

# Page 92

# INVESTOR RELATIONS


## Investor Relations


## Registered Shareholder Services

You can contact Microsoft Investor Relations at any time to order financial documents such as annual reports and Form 10-Ks free of charge.

Call  us  toll-free  at  (800)  285-7772  or  outside  the  United States,  call  (425)  706-4400.  We  can  be  contacted  between the  hours  of  9:00  a.m.  to  5:00  p.m.  Pacific  Time  to  answer investment oriented questions about Microsoft.

For access to additional financial information, visit the Investor Relations website online at:

www.microsoft.com/investor

Our e-mail is msft@microsoft.com

Our mailing address is: Investor Relations Microsoft Corporation One Microsoft Way Redmond, Washington 98052-6399


## Attending the Annual Meeting

The 2022 Annual Shareholders Meeting will be held as a virtual-only  meeting .  Any  shareholder  can  join  the  Annual Meeting,  while  shareholders  of  record  as  of  October 12, 2022,  will  be  able  to  vote  and  submit  questions  during  the meeting.

Date: Tuesday, December 13, 2022

Time: 8:30 a.m. Pacific Time

Virtual Shareholder Meeting:

www.virtualshareholdermeeting.com/MSFT22


## Submit Your Question

We invite  you  to  submit  any  questions  via  the  proxy  voting site at www.proxyvote.com. We will include as many of your questions as possible during the Q&A session of the meeting and  will provide  answers  to  questions  on  the  Microsoft Investor Relations website under the Annual Meeting page.


Computershare,  our  transfer  agent,  can  help  you  with  a variety of shareholder related services including:
- · Change of address
- · Lost stock certificates
- · Transfer of stock to another person
- · Additional administrative services


Computershare also administers a direct stock purchase plan and a dividend reinvestment program for the company.

Contact Computershare directly to find out more about these services  and  programs  at  800-285-7772,  option  1,  or  visit online at: https://www.computershare.com/Microsoft

You can e-mail the transfer agent at: web.queries@computershare.com

You can also send mail to the transfer agent at: Computershare P.O. Box 43006 Providence RI 02940-3078

Shareholders can sign up for electronic alerts to access the annual report  and  proxy  statement  online.  The  service  gets you the information you need faster and also gives you the power and convenience of online proxy voting. To sign up for this free service, visit the Annual Report site on the Investor Relations website at:

http://www.microsoft.com/investor/AnnualReports/default.asp

x


## Environmental, Social, and  Governance  (ESG)/Corporate Social Responsibility

Many  of  our  shareholders  are  increasingly  focused  on  the importance of the effective engagement  and  action on environmental,  social,  and  governance  topics.  To  meet  the expectations  of  our  stakeholders  and  to  and  maintain  their trust,  we  are committed to conducting our business in ways that  are  principled,  transparent,  and  accountable  and  we have  made  a  broad  range  of  environmental  and  social commitments. From our CEO and Senior Leadership Team and  throughout  our  organization,  people  at  Microsoft  are working to conduct our business in principled ways that make a significant positive impact  on  important  global  issues. Microsoft's Board of Directors provides insight, feedback, and oversight across a broad range of environmental and social matters. In particular, among  the  responsibilities of the Board's Environmental, Social, and Public Policy Committee is to review and provide guidance to the Board and management  about  the  Company's  policies  and  programs that relate to corporate social responsibility.

For more about Microsoft's CSR commitments and performance, please visit: www.microsoft.com/transparency.

---

# Page 93

