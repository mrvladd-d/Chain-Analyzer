

---

# Page 1

# For personal use only


## RECTIFIER TECHNOLOGIES LTD

ABN: 82 058 010 692


## ANNUAL REPORT 2022

---

# Page 2

# Rectifier Technologies Ltd Contents


## 30 June 2022


| Corporate directory                                                       |   2 |
|---------------------------------------------------------------------------|-----|
| Chairman's report                                                         |   3 |
| Directors' report                                                         |   5 |
| Auditor's independence declaration                                        |  14 |
| Statement of profit or loss and other comprehensive income                |  15 |
| Statement of financial position                                           |  16 |
| Statement of changes in equity                                            |  17 |
| Statement of cash flows                                                   |  18 |
| Notes to the financial statements                                         |  19 |
| Directors' declaration                                                    |  48 |
| Independent auditor's report to the members of Rectifier Technologies Ltd |  49 |
| Shareholder information                                                   |  54 |



## For personal use only

---

# Page 3

# Rectifier Technologies Ltd Corporate directory 30 June 2022

Directors

Company secretary

Ms Nova Taylor

Registered office

Share register

Stock exchange listing

Corporate Governance Statement

97 Highbury Road

BURWOOD, VIC 3125

Telephone: + 61 3 9896 7550

Facsimile:  + 61 3 9896 7566

Computershare Investor Services Pty Ltd 452 Johnston Street ABBOTSFORD, VIC 3067 Telephone:  1300 137 328

Grant Thornton Audit Pty Ltd Collins Square, Tower 5 727 Collins Street MELBOURNE, VIC 3008

ANZ Banking Group Limited 10 Main Street BOX HILL, VIC 3128

Westpac Banking Corporation 39-41Hamilton Place, MOUNT WAVERLEY, VIC 3149

Rectifier Technologies Ltd shares are listed on the Australian Securities Exchange (ASX code: RFT)

https://www.rectifiertechnologies.com/

The directors and management are committed to conducting the business of Rectifier Technologies Ltd in an ethical manner and in accordance with the highest standards of corporate governance. Rectifier Technologies Ltd has adopted and has substantially complied with the ASX Corporate Governance Principles and Recommendations (Fourth Edition) ('Recommendations') to the extent appropriate to the size and nature of its operations.

The consolidated entity's Corporate Governance Statement, which sets out the corporate governance practices that were in operation during the financial year and identifies and explains any Recommendations that have not been followed and ASX Appendix 4G are released to the ASX on the same day the Annual Report is released. The Corporate Governance Statement and Corporate Governance Compliance Manual can be found on the Company's website at https://www.rectifiertechnologies.com/investors-relations/.

Bankers Website For personal use only

Mr. Ying Ming Wang Mr. Yanbin Wang Mr. Valentino Vescovi Mr. Nigel Machin

---

# Page 4

Rectifier Technologies Ltd Chairman's report 30 June 2022


# Financial Results

The Company reported an increase in revenue by approximately 22.8% to $16.30 million from $13.27 million in the previous reporting period.


- The increase in revenue from 30 June 2021 resulted from the demand increase for the electric vehicle chargers market with the global economy's recovery from the COVID-19 pandemic.


Profit before tax increased to $1.23 million in the current reporting period compared to $1.03 million in the last reporting period. We have successfully managed the business growth despite the COVID interruption and global supply chain issues in FY 2022.

The following table below shows the results for the 12 months to June 2022 compared with those of the previous corresponding period.


|                                                        | ($'000')   | ($'000')   |
|--------------------------------------------------------|------------|------------|
|                                                        | 2022       | 2021       |
| Revenue from continuing operations (refer to note 5&6) | 16,303     | 13,266     |
| Gross Profit                                           | 7,409      | 6,042      |
| Gross Margin %                                         | 50%        | 51%        |
| Profit from continuing operations before tax           | 1,232      | 1,033      |
| Income Tax Expense                                     | (740)      | (493)      |
| Profit from continuing operations after tax            | 492        | 540        |
| Net Profit                                             | 492        | 540        |



## Funding


- On 6 February 2017, Rectifier Technologies Malaysia obtained a loan amounting to MYR 5,460,000 (AUD 1,629,851) from Public Bank Berhad to acquire a new manufacturing facility. The carrying amount of the loan was MYR 4,648,453 (AUD 1,531,464) as of 30 June 2022.


On 7 October 2019, Rectifier Technologies Malaysia obtained a loan amounting to MYR 2,730,000 (AUD 929,393)  from the same bank to acquire a new manufacturing facility. The carrying amount of the loan was MYR 2,552,538 (AUD 840,951) as of 30 June 2022.


- On 2 October 2020, Rectifier Technologies Malaysia obtained a loan amounting to MYR 498,800 (AUD 159,780)  from the same bank to acquire rooftop solar PV net energy metering. The carrying amount of the loan was MYR 428,740 (AUD141,252) as of 30 June 2022.


On 30 March 2022, Rectifier Technologies Australia obtained a loan of AUD 3,000,000 from ANZ for working capital. The carrying amount of the loan was AUD 2,760,321 as of 30 June 2022 after monthly payments for principal and interest. The loan was discharged and fully paid on 2 September 2022.

For personal use only

On 2 September 2022, Rectifier Technologies Australia obtained a loan amounting to AUD 5,000,000 from WBC for working capital. The loan term is five years, and the indicative loan interest is 4.13% p.a. (variable rate). The repayment arrangement is principal plus interest up to 28 July 2027.


## Dividends Payments

No dividend was declared for the 2022 Financial year.

---

# Page 5

Rectifier Technologies Ltd Chairman's report 30 June 2022


# Review of Operations

The Company has successfully managed the COVID interruption to our business and global supply chain shortage and reported a profit in the current reporting period.

As the ASX announcement dated 9 February 2022, we received purchase orders totalling approximately USD 20 million from one of  our  major  customers  in  the  first  half-year  of  2022.  Our  international  procurement  team  has  secured  the  required manufacturing materials and is committed to delivering products to all customers with our best efforts.

The Company has continued work on the ERP system implementation as part of the Digital Enterprise Transformation. The first  phase  of  ERP  implementation has been completed, with Australia and Singapore subsidiaries consolidated into one platform. Phase 2 will bring the entire Company onto a unified platform that will significantly enhance efficiencies and business intelligence. The Company expects phase 2 of the ERP system implementation to begin in the first half-year of 2023 and take 12 months to implement.

To increase the competitiveness of RT22, the Company decided to significantly raise the technical benchmark for the product, which pushed back the original deadlines but resulted in a superior product. The engineering of the 'RT22 50KW EV Charger Module' has continued throughout the period. It has included the safety certification by TUV SUD, which is to be completed by Q4 2022, to enable our customers to supply the product in Europe and the USA. In addition, engineering has continued to work on the volume release of the product by validating a range of alternative components to ensure the supply chain meets market demand for the product. We are expecting RT22 to contribute significantly to company revenue in 2023.

On 26 July 2022, the Company announced that the 'Highbury DC Bi-Directional Charger' project was put on hold, and the available engineering resources have been deployed to other developments, such as the 'RT22 50KW EV Charger Module' and 'high-voltage input rectifier', which are now scheduled H1 2023.

We will continue to strive to grow our business in 2023, particularly in the electric vehicle chargers market.

30 September 2022 Melbourne Ying Ming Wang Chairman

Outlook For personal use only

---

# Page 6

Rectifier Technologies Ltd Directors' report 30 June 2022

The directors present their report, together with the financial statements, on the consolidated entity (referred to hereafter as the 'consolidated entity') consisting of Rectifier Technologies Ltd (referred to hereafter as the 'Company' or 'parent entity') and the entities it controlled at the end of, or during, the year ended 30 June 2022.


# Directors

The following persons were directors of Rectifier Technologies Ltd during the whole of the financial year and up to the date of this report, unless otherwise stated:

Mr. Ying Ming Wang

Mr. Yanbin Wang

Mr. Valentino Vescovi

Mr. Nigel Machin


## Principal activities

The principal activities of the consolidated entity during the financial year were designing and manufacturing high-efficiency power rectifiers and producing electronic and specialised magnetic components.


## Dividends

Dividends paid during the financial year were as follows:

Consolidated 2022 2021 $ $

Final dividend paid during 30 June 2022 of nil cents (for the year ended 30 June 2021: 0.1

cents) per ordinary share

-

1,375,701

The dividends paid on 8 December 2020, totalling to $1,375,701, refers to the 30 June 2020 financial year. There are no dividends declared in relation to the 30 June 2022 and 30 June 2021 financial years.


## Review of operations

The profit for the consolidated entity after providing for income tax amounted to $491,955 (30 June 2021: $540,379).

Specific information on the review of operations, financial position and business strategies is stated in the Chairman's report.


## Significant changes in the state of affairs

There were no significant changes in the state of affairs of the consolidated entity during the financial year.


## Matters subsequent to the end of the financial year

On 2 September 2022, the loan from ANZ with the carrying amount of the loan AUD 2,760,321 as of 30 June 2022 was discharged and fully paid.

On 2 September 2022, a loan from WBC of $5,000,000 was drawn. The term of the loan is 5 years and the indicative loan interest is 4.13% p.a. (variable rate). The repayment arrangement is principal and interest up to 28 July 2027.


## Likely developments and expected results of operations

Information on likely developments in the operations of the consolidated entity and the expected results of those operations in future financial years is stated in the Chairman's report.


## Environmental regulation

The consolidated entity is not subject to any significant environmental regulation under Australian Commonwealth or State law.

For personal use only

---

# Page 7

Rectifier Technologies Ltd Directors' report 30 June 2022


# Information on directors

Name:

Mr. Ying Ming Wang

Title:

Chairman - Non-Executive

Qualifications:

Master of Science

Experience and expertise:

As Managing Director of the Pudu Group, Ying Ming has built up a range of technology and property businesses, including Epern Telecom Co. Ltd., Beijing's largest privately owned ISP. He is also involved in the China Digital Kingdom, an internet datacentre development business in China. Board Member since June 2006 Pudu Group

Other current directorships:

Former directorships (last 3 years):

None

Special responsibilities:

Member of the audit committee 224,643,616 Ordinary Shares

Interests in shares:

Interests in options:

None

Name: Title: Name: Title: Name: Title: For personal use only

Mr. Yanbin Wang

Director - Executive and Chief Executive Officer

Qualifications:

Master of Law, Bachelor of Philosophy

Experience and expertise:

Before joining Rectifier Technologies as CEO in 2010, Yanbin was Chief Operations Officer at Tianjin IC Card Public Network Company of Tianjin, China and Vice-President of Transtech Sino America, based in Florida, USA. He was instrumental in restructuring the Rectifier Technologies group in 2012, leading it back to growth and profitability.

Board Member since August 2010

Other current directorships:

None

Former directorships (last 3 years): Special responsibilities:

None

Member of the audit committee

Interests in shares:

70,000,000 Ordinary Shares

Interests in options:

None

Mr. Valentino Vescovi

Director - Non-Executive

Qualifications:

Master of Science, Bachelor of Science

Experience and expertise:

As a founding director of Rectifier Technologies Pacific, Valentino was instrumental in its  product development programs that led the world in telecom power using switch mode technology. He brings the board a significant amount of technical and business expertise.

Board member 2003-2010 and from 30 October 2012

Other current directorships:

None

Former directorships (last 3 years):

None

Special responsibilities:

Member of the audit committee

Interests in shares:

37,040,000 Ordinary Shares

Interests in options:

None

Mr. Nigel Machin

Director - Executive and Head of Power Engineering

Qualifications:

Bachelor of Engineering

Experience and expertise:

Nigel was a founding director of Rectifier Technologies Pacific and has been involved in all its product development since. Before Rectifier Technologies, Nigel was involved in induction melting equipment at Inductotherm Melting, in sound reinforcement power amplifiers  for  professional  audio  at  Clockwork  Audio,  and  then  in  telecom  power supplies  at  Ausmode/Exicom.  He  has  published  8  papers  and  holds  two  current patents.

Board member since 3 April 2017

Other current directorships: Special responsibilities: Interests in shares: Interests in options:

None

Former directorships (last 3 years):

None

Member of the audit committee 22,010,000 Ordinary Shares 1,800,000 unlisted options

---

# Page 8

# Rectifier Technologies Ltd Directors' report 30 June 2022

'Other current directorships' quoted above are current directorships for listed entities only and exclude directorships of all other types of entities unless otherwise stated.

'Former directorships (last 3 years)' quoted above are directorships held in the last 3 years for listed entities only and exclude directorships of all other types of entities unless otherwise stated.


## Company secretary

Ms.  Nova  Taylor  was  appointed  as  Company  Secretary  on  3  February  2022.  Ms  Taylor  has  approximately  5  years' experience working with listed companies in Company Secretary and Assistant Company Secretary roles. She previously worked for Computershare Investor Services Pty Limited in various roles for over 10 years. Nova has completed a Bachelor of Laws at Deakin University.

Mr. Justyn Stedwell was appointed as Company Secretary on 31 July 2014 and resigned on 3 February 2022. He is a professional Company Secretary with over 10 years' experience as a Company Secretary of ASX listed companies. Mr Stedwell  holds  a  Bachelor  of  Commerce  from  Monash  University  and  a  Graduate  Diploma  in  Accounting  from  Deakin University.


## Meetings of directors


The number of meetings of the Company's Board of Directors ('the Board') held during the year ended 30 June 2022, and the number of meetings attended by each director was:
|                       | Full Board   | Full Board   | Audit and Risk Committee   | Audit and Risk Committee   |
|-----------------------|--------------|--------------|----------------------------|----------------------------|
|                       | Attended     | Held         | Attended                   | Held                       |
| Mr. Ying Ming Wang    | 4            | 4            | 1                          | 1                          |
| Mr. Yanbin Wang       | 4            | 4            | 1                          | 1                          |
| Mr. Valentino Vescovi | 4            | 4            | 1                          | 1                          |
| Mr. Nigel Machin      | 4            | 4            | 1                          | 1                          |


Held: represents the number of meetings held during the time the director held office.


## Remuneration report (audited)

The remuneration report details the key management personnel remuneration arrangements for the consolidated entity, in accordance with the requirements of the Corporations Act 2001 and its Regulations.


- Key management personnel are those persons having authority and responsibility for planning, directing and controlling the activities of the entity, directly or indirectly, including all directors.



The remuneration report is set out under the following main headings:
- ● Principles used to determine the nature and amount of remuneration
- ● Details of remuneration
- ● Service agreements
- ● Share-based compensation
- ● Additional information
- ● Additional disclosures relating to key management personnel



## Principles used to determine the nature and amount of remuneration

The objective of the consolidated entity's executive reward framework is to ensure reward for performance is competitive and appropriate for the results delivered. The framework aligns executive reward with the achievement of strategic objectives and the creation of value for shareholders, and it is considered to conform to the market best practice for the delivery of reward. The Board of Directors ('the Board') ensures that executive reward satisfies the following key criteria for good reward governance practices:

For personal use only


- ● competitiveness and reasonableness;
- ● acceptability to shareholders;
- ● performance linkage/alignment of executive compensation; and
- ● transparency.


The Board is responsible for determining and reviewing remuneration arrangements for its directors and executives. The performance of the consolidated entity depends on the quality of its directors and executives. The remuneration philosophy is to attract, motivate and retain high-performance and high-quality personnel.

---

# Page 9

Rectifier Technologies Ltd Directors' report 30 June 2022


The reward framework is designed to align executive reward to shareholders' interests. The Board has considered that it should seek to enhance shareholders' interests by:
- ● having economic profit as a core component of plan design;
- ● focusing on sustained growth in shareholder wealth, consisting of dividends and growth in share price, and delivering constant or increasing return on assets as well as focusing the executive on key non-financial drivers of value; and
- ● attracting and retaining high calibre executives.



Additionally, the reward framework should seek to enhance executives' interests by:
- ● rewarding capability and experience
- ● reflecting competitive reward for contribution to growth in shareholder wealth
- ● providing a clear structure for earning rewards


In accordance with best practice corporate governance, the remuneration structure of non-executive director and executive director is separate.


## Non-executive directors' remuneration

The Board's policy is to remunerate non-executive directors at market rates for comparable companies for time, commitment and responsibilities. The Board determines payments to the non-executive directors and reviews their remuneration annually, based on market practice, duties and accountability. Independent external advice is sought when required. The maximum aggregate amount of fees that can be paid to non-executive directors is subject to approval by shareholders at the Annual General Meeting. Fees for non-executive directors are not linked to the performance of the consolidated entity.

ASX listing rules require the aggregate non-executive directors' remuneration to be determined periodically by a general meeting.  The  most  recent  determination  was  at  the  Annual  General  Meeting  held  on  25  January  2022,  where  the shareholders approved a maximum annual aggregate remuneration of $32,760.


## Executive remuneration

The  consolidated  entity  aims  to  reward  executives  based  on  their  position  and  responsibility,  with  a  level  and  mix  of remuneration which has both fixed and variable components.


The executive remuneration and reward framework has four components:
- ● base pay and non-monetary benefits;
- ● short-term performance incentives;
- ● share-based payments; and
- ● other remuneration such as superannuation and long service leave.


The combination of these comprises the executive's total remuneration.

Fixed remuneration, consisting of base salary, superannuation and non-monetary benefits, is reviewed annually by the Board based on individual and business unit performance, the overall performance of the consolidated entity and comparable market remunerations.

Executives may receive their fixed remuneration in the form of cash or other fringe benefits (for example motor vehicle benefits), which does not create any additional costs to the consolidated entity and provides additional value to the executive.

The short-term incentives ('STI') program is designed to align the targets of the business units with the performance hurdles of executives. STI payments are granted to executives based on specific annual targets and key performance indicators ('KPI's')  being  achieved.  KPI's  include  profit  contribution,  customer  satisfaction,  leadership  contribution  and  product management.

The long-term incentives ('LTI') include long service leave and share-based payments. Shares are awarded to executives in accordance with performance guidelines established by the Board. These include increase in shareholders' value relative to the entire market and the increase compared to the consolidated entity's direct competitors. The Board reviewed the longterm equity-linked performance incentives specifically for executives during the year ended 30 June 2022.

For personal use only

---

# Page 10

# Rectifier Technologies Ltd Directors' report 30 June 2022


## Consolidated entity performance and link to remuneration

As part of each executive director and executive's remuneration package there may be a performance-based component, consisting of  key  performance indicators (KPI's). The intention of this program is to facilitate goal congruence between directors/executives with that of the business and shareholders. Where applicable, the KPI's are set annually, with a certain level of consultation with directors/executives to ensure buy-in. The measures are specifically tailored to the areas each director/executive is involved in and has a level of control over. The KPI's target areas the Board believes hold greater potential for the consolidated entity expansion and profit, covering financial and non-financial as well as short-term and longterm goals. The level set for each KPI is based on budgeted figures for the consolidated entity and respective industry standards.

Performance in relation to the KPI's is assessed annually, with bonuses being awarded depending on the number and deemed difficulty of the KPI's achieved. Following the assessment, the KPI's are reviewed by the Board in light of the desired and actual outcomes, and their efficiency is assessed in relation to the consolidated entity's goals and shareholder wealth before the KPI's are set for the following year.

In determining whether or not a KPI has been achieved, Rectifier Technologies Ltd bases the assessment on audited figures; however, where the KPI involves comparison of individual performance within the consolidated entity, management reports which form the foundation for the consolidated entity audited results are used.


- Refer to the section 'Additional information' below for details of the earnings and total shareholders return for the last five years.



## Use of remuneration consultants

During the financial year ended 30 June 2022, the consolidated entity, did not engage any remuneration consultants.


## Voting and comments made at the Company's 30 June 2021 Annual General Meeting ('AGM')

At the 25 January 2022 AGM, 99.77% of the votes received supported the adoption of the remuneration report for the year ended 30 June 2021. The Company did not receive any specific feedback at the AGM regarding its remuneration practices.


## Details of remuneration


## Amounts of remuneration

Details of the remuneration of key management personnel of the consolidated entity are set out in the following tables.


The key management personnel of the consolidated entity consisted of the following directors of Rectifier Technologies Ltd:
- ● Mr. Ying Ming Wang - Chairman - Non-Executive
- ● Mr. Yanbin Wang - Director - Executive and Chief Executive Officer
- ● Mr. Valentino Vescovi - Director - Non-Executive
- ● Mr. Nigel Machin - Director - Executive and Head of Power Engineering



## And the following persons:


- ● Mr. Paul Davis - Operations Manager - Rectifier Technologies Pacific Pty Ltd
- ● Mr. Seong Bow Lee - General Manager - Rectifier Technologies (M) Sdn Bhd
- ● Mr. Nicholas Yeoh - Director of Sales & Marketing - Rectifier Technologies Singapore Pte Ltd


For personal use only

---

# Page 11

# Rectifier Technologies Ltd Directors' report 30 June 2022


|                          | Short-term benefits    | Short-term benefits   | Short-term benefits   | Post- employment  benefits Super-   | Long-term  benefits   |           |
|--------------------------|------------------------|-----------------------|-----------------------|-------------------------------------|-----------------------|-----------|
| 2022                     | Cash salary and fees $ | Cash bonus* $         | Non- monetary $       | annuation $                         | Long service leave $  | Total $   |
| Non-Executive Directors: |                        |                       |                       |                                     |                       |           |
| Mr. Ying Ming Wang       | 16,500                 | -                     | -                     | -                                   | -                     | 16,500    |
| Mr. Valentino Vescovi    | 11,000                 | -                     | -                     | -                                   | -                     | 11,000    |
| Executive Directors:     |                        |                       |                       |                                     |                       |           |
| Mr. Yanbin Wang          | 320,500                | 20,950                | 20,233                | 45,648                              | -                     | 407,331   |
| Mr. Nigel Machin         | 205,449                | 8,352                 | -                     | 30,980                              | 6,374                 | 251,155   |
| Other Key Management     |                        |                       |                       |                                     |                       |           |
| Personnel:               |                        |                       |                       |                                     |                       |           |
| Mr. Paul Davis           | 179,920                | 7,322                 | -                     | 26,374                              | 5,577                 | 219,193   |
| Mr. Seong Bow Lee        | 96,390                 | 8,093                 | 1,246                 | 12,827                              | -                     | 118,556   |
| Mr. Nicholas Yeoh        | 312,281                | 25,663                | 2,096                 | -                                   | -                     | 340,040   |
|                          | 1,142,040              | 70,380                | 23,575                | 115,829                             | 11,951                | 1,363,775 |
* The cash bonus were approved upon payment on 25 February 2022.


**

The cash bonus is payable at the discretion of the board, equal to an amount of 5-10% of the total salary, subject to achievement of target profit.


|                                  | Short-term benefits    | Short-term benefits   | Short-term benefits   | Post- employment  benefits   | Long-term  benefits   |           |
|----------------------------------|------------------------|-----------------------|-----------------------|------------------------------|-----------------------|-----------|
| 2021                             | Cash salary and fees $ | Cash bonus* $         | Non- monetary $       | Super- annuation $           | Long service leave $  | Total $   |
| Non-Executive Directors:         |                        |                       |                       |                              |                       |           |
| Mr. Ying Ming Wang               | 16,500                 | -                     | -                     | -                            | -                     | 16,500    |
| Mr. Valentino Vescovi            | 11,000                 | -                     | -                     | -                            | -                     | 11,000    |
| Executive Directors:             |                        |                       |                       |                              |                       |           |
| Mr. Yanbin Wang                  | 296,182                | 26,801                | 20,230                | 43,541                       | -                     | 386,754   |
| Mr. Nigel Machin                 | 187,432                | 12,937                | -                     | 29,547                       | 4,910                 | 234,826   |
| Other Key Management  Personnel: |                        |                       |                       |                              |                       |           |
| Mr. Paul Davis                   | 158,849                | 18,789                | -                     | 23,856                       | 4,253                 | 205,747   |
| Mr. Seong Bow Lee                | 90,110                 | 9,676                 | 1,250                 | 12,252                       | -                     | 113,288   |
| Mr. Nicholas Yeoh                | 288,083                | 23,248                | 1,841                 | -                            | -                     | 313,172   |
|                                  | 1,048,156              | 91,451                | 23,321                | 109,196                      | 9,163                 | 1,281,287 |
For personal use only
* The cash bonus were approved upon payment on 29 January 2021.

---

# Page 12

## Rectifier Technologies Ltd Directors' report


# 30 June 2022


The proportion of remuneration linked to performance and the fixed proportion are as follows:
|                                  | Fixed remuneration   | Fixed remuneration   | Performance-based  remuneration - STI   | Performance-based  remuneration - STI   | Performance-based  remuneration - LTI   | Performance-based  remuneration - LTI   |
|----------------------------------|----------------------|----------------------|-----------------------------------------|-----------------------------------------|-----------------------------------------|-----------------------------------------|
|                                  | 2022                 | 2021                 | 2022                                    | 2021                                    | 2022                                    | 2021                                    |
| Non-Executive Directors:         |                      |                      |                                         |                                         |                                         |                                         |
| Mr. Ying Ming Wang               | 100.00%              | 100.00%              | -                                       | -                                       | -                                       | -                                       |
| Mr. Valentino Vescovi            | 100.00%              | 100.00%              | -                                       | -                                       | -                                       | -                                       |
| Executive Directors:             |                      |                      |                                         |                                         |                                         |                                         |
| Mr. Yanbin Wang                  | 94.86%               | 93.07%               | 5.14%                                   | 6.93%                                   | -                                       | -                                       |
| Mr. Nigel Machin                 | 96.67%               | 94.49%               | 3.33%                                   | 5.51%                                   | -                                       | -                                       |
| Other Key Management  Personnel: |                      |                      |                                         |                                         |                                         |                                         |
| Mr. Paul Davis                   | 96.66%               | 90.87%               | 3.34%                                   | 9.13%                                   | -                                       | -                                       |
| Mr. Seong Bow Lee                | 93.17%               | 91.46%               | 6.83%                                   | 8.54%                                   | -                                       | -                                       |
| Mr. Nicholas Yeoh                | 92.45%               | 92.58%               | 7.55%                                   | 7.42%                                   | -                                       | -                                       |



## Service agreements

The employment conditions of the CEO and specified executives are formalised in contracts of employment and all contracts require 4 weeks' notice, with no termination payments specified other than employee entitlements.


## Share-based compensation


## Issue of shares

There were no shares issued to directors and other key management personnel as part of compensation during the year ended 30 June 2022.

There  were  no  options  over  ordinary  shares  issued  to  directors  and  other  key  management  personnel  as  part  of compensation that were outstanding as at 30 June 2022.

There were no options over ordinary shares granted to or vested by directors and other key management personnel as part of compensation during the year ended 30 June 2022.


## Additional information

The earnings of the consolidated entity for the five years to 30 June 2022 are summarised below:

Name Options For personal use only


|                                                                                                   | 2022 $                                                                                            | 2021 $                                                                                            | 2020 $                                                                                            | 2019 $                                                                                            | 2018 $                                                                                            |
|---------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|
| Revenue (Including discontinued operation)                                                        | 16,303,329                                                                                        | 13,266,295                                                                                        | 16,734,759                                                                                        | 18,874,493                                                                                        | 7,834,710                                                                                         |
| Net Profit/(Loss)                                                                                 | 491,955                                                                                           | 540,379                                                                                           | 1,821,638                                                                                         | 2,127,038                                                                                         | 62,442                                                                                            |
| The factors that are considered to affect total shareholders return ('TSR') are summarised below: | The factors that are considered to affect total shareholders return ('TSR') are summarised below: | The factors that are considered to affect total shareholders return ('TSR') are summarised below: | The factors that are considered to affect total shareholders return ('TSR') are summarised below: | The factors that are considered to affect total shareholders return ('TSR') are summarised below: | The factors that are considered to affect total shareholders return ('TSR') are summarised below: |
|                                                                                                   | 2022                                                                                              | 2021                                                                                              | 2020                                                                                              | 2019                                                                                              | 2018                                                                                              |
| Share price at financial year end (cents per  share)                                              | 4.00                                                                                              | 2.80                                                                                              | 3.80                                                                                              | 4.60                                                                                              | 2.60                                                                                              |
| Changes Share price at financial year end  (cents per share)                                      | 1.20                                                                                              | (1.00)                                                                                            | (0.80)                                                                                            | 2.00                                                                                              | 0.90                                                                                              |
| Total dividends paid (cents per share)                                                            | -                                                                                                 | 0.10                                                                                              | -                                                                                                 | -                                                                                                 | -                                                                                                 |

---

# Page 13

## Rectifier Technologies Ltd


# Directors' report 30 June 2022


## Additional disclosures relating to key management personnel


## Shareholding


The number of shares in the Company held during the financial year by each director and other members of key management personnel of the consolidated entity, including their personally related parties, is set out below:
|                       | Balance at  the start of  the year   | Received  as part of  remuneration   | Additions   | Disposals/  other   | Balance at  the end of  the year   |
|-----------------------|--------------------------------------|--------------------------------------|-------------|---------------------|------------------------------------|
| Ordinary shares       |                                      |                                      |             |                     |                                    |
| Mr. Ying Ming Wang    | 224,643,616                          | -                                    | -           | -                   | 224,643,616                        |
| Mr. Yanbin Wang       | 70,000,000                           | -                                    | -           | -                   | 70,000,000                         |
| Mr. Valentino Vescovi | 37,640,000                           | -                                    | -           | (600,000)           | 37,040,000                         |
| Mr. Nigel Machin      | 22,010,000                           | -                                    | -           | -                   | 22,010,000                         |
| Mr. Paul Davis        | 5,000,000                            | -                                    | -           | -                   | 5,000,000                          |
| Mr. Seong Bow Lee     | 2,767,550                            | -                                    | -           | -                   | 2,767,550                          |
| Mr. Nicholas Yeoh     | 20,500,000                           | -                                    | -           | -                   | 20,500,000                         |
|                       | 382,561,166                          | -                                    | -           | (600,000)           | 381,961,166                        |



## Option holding


The number of options over ordinary shares in the Company held during the financial year by each director and other members of key management personnel of the consolidated entity, including their personally related parties, is set out below:
|                              | Balance at  the start of  the year   | Granted   | Exercised   | Expired/  forfeited/  other   | Balance at  the end of  the year   |
|------------------------------|--------------------------------------|-----------|-------------|-------------------------------|------------------------------------|
| Options over ordinary shares |                                      |           |             |                               |                                    |
| Mr. Ying Ming Wang           | -                                    | -         | -           | -                             | -                                  |
| Mr. Yanbin Wang              | -                                    | -         | -           | -                             | -                                  |
| Mr. Valentino Vescovi        | -                                    | -         | -           | -                             | -                                  |
| Mr. Nigel Machin             | 1,800,000                            | -         | -           | -                             | 1,800,000                          |
| Mr. Paul Davis               | 3,000,000                            | -         | -           | -                             | 3,000,000                          |
| Mr. Seong Bow Lee            | 3,000,000                            | -         | -           | -                             | 3,000,000                          |
| Mr. Nicholas Yeoh            | 3,000,000                            | -         | -           | -                             | 3,000,000                          |
|                              | 10,800,000                           | -         | -           | -                             | 10,800,000                         |



## This concludes the remuneration report, which has been audited.


## Shares under option


Unissued ordinary shares of Rectifier Technologies Ltd under option at the date of this report are as follows:
| Grant date    | Expiry date       | Exercise  price   | Number  under option   |
|---------------|-------------------|-------------------|------------------------|
| June 2003     | No expiry date    | $0.020            | 4,480,000              |
| November 2003 | No expiry date    | $0.020            | 8,360,000              |
| July 2019     | 13 September 2022 | $0.070            | 34,000,000             |
|               |                   |                   | 46,840,000             |


No person entitled to exercise the options had or has any right by virtue of the option to participate in any share issue of the Company or of any other body corporate.

For personal use only


## Shares issued on the exercise of options

There were no ordinary shares of Rectifier Technologies Ltd issued on the exercise of options during the year ended 30 June 2022 and up to the date of this report.

---

# Page 14

Rectifier Technologies Ltd Directors' report 30 June 2022


# Indemnity and insurance of officers or auditor

The Company has indemnified the directors and executives of the Company for costs incurred, in their capacity as a director or executive, for which they may be held personally liable, except where there is a lack of good faith.

During the financial year, the Company has paid premiums to insure each of the directors and officers against liabilities for costs and expenses incurred by them in defending any legal proceedings arising out of their conduct while acting in the capacity of director or officer of the Company and of any related body corporate, other than conduct involving a wilful breach of duty in relation to the Company. The amount of the premium was $35,960 for all directors and officers

The Company has not otherwise, during or  since  the  end  of  the  financial  year,  except  to  the  extent  permitted  by  law, indemnified or agreed to indemnify an officer or auditor of the Company or of any related body corporate against a liability incurred as such an officer or an auditor.


## Proceedings on behalf of the Company

No person has applied to the Court under section 237 of the Corporations Act 2001 for leave to bring proceedings on behalf of the Company, or to intervene in any proceedings to which the Company is a party for the purpose of taking responsibility on behalf of the Company for all or part of those proceedings.


## Non-audit services

There were no non-audit services provided during the financial year by the auditor.


## Officers of the Company who are former partners of Grant Thornton

There are no officers of the Company who are former partners of Grant Thornton.


## Auditor's independence declaration

A copy of the auditor's independence declaration as required under section 307C of the Corporations Act 2001 is set out immediately after this directors' report.

This report is made in accordance with a resolution of directors, pursuant to section 298(2)(a) of the Corporations Act 2001.


## On behalf of the directors

30 September 2022 Melbourne

Director For personal use only

---

# Page 15

# Auditor's Independence Declaration


## To the Directors of Rectifier Technologies Ltd


In accordance with the requirements of section 307C of the Corporations Act 2001 , as lead auditor for the audit of Rectifier Technologies Ltd for the year ended 30 June 2022, I declare that, to the best of my knowledge and belief, there have been:
- a no contraventions of the auditor independence requirements of the Corporations Act 2001 in relation to the audit; and
- b no contraventions of any applicable code of professional conduct in relation to the audit.


Grant Thornton Audit Pty Ltd Chartered Accountants

S C Trivett Partner - Audit & Assurance Melbourne, 30 September 2022

www.grantthornton.com.au ACN-130 913 594

Grant Thornton Audit Pty Ltd ACN 130 913 594 a subsidiary or related entity of Grant Thornton Australia Limited ABN 41 127 556 389 ACN 127 556 389. 'Grant Thornton' refers to the brand under which the Grant Thornton member firms provide assurance, tax and advisory services to their clients and/or refers to one or more member firms, as the context requires. Grant Thornton Australia Limited is a member firm of Grant Thornton International Ltd (GTIL). GTIL and the member firms are not a worldwide partnership. GTIL and each member firm is a separate legal entity. Services are delivered by the member firms. GTIL does not provide services to clients. GTIL and its member firms are not agents of, and do not obligate one another and are not liable for one another's acts or omissions. In the Australian context only, the use of the term 'Grant Thornton' may refer to Grant Thornton Australia Limited ABN 41 127 556 389 ACN 127 556 389 and its Australian subsidiaries and related entities. Liability limited by a scheme approved under Professional Standards Legislation.

w

Grant Thornton Audit Pty Ltd Level 22 Tower 5 Collins Square 727 Collins Street Melbourne VIC 3008 GPO Box 4736 Melbourne VIC 3001

T +61 3 8320 2222

---

# Page 16

# Statement of profit or loss and other comprehensive income


## Rectifier Technologies Ltd For the year ended 30 June 2022


|                                                                                                        |      | Consolidated   | Consolidated   |
|--------------------------------------------------------------------------------------------------------|------|----------------|----------------|
|                                                                                                        | Note | 2022 $         | 2021 $         |
| Revenue                                                                                                | 5    | 14,761,523     | 11,841,712     |
| Other income                                                                                           | 6    | 1,535,954      | 1,415,332      |
| Interest revenue                                                                                       |      | 5,852          | 9,251          |
| Expenses                                                                                               |      |                |                |
| Changes in inventories of finished goods and work in progress                                          |      | 2,097,687      | (424,565)      |
| Raw materials and consumables used                                                                     |      | (7,656,716)    | (4,022,084)    |
| Employee benefits expense                                                                              |      | (6,310,321)    | (5,071,148)    |
| Depreciation expense                                                                                   | 7    | (607,239)      | (554,839)      |
| Other expenses                                                                                         |      | (2,441,741)    | (2,010,880)    |
| Finance costs                                                                                          | 7    | (153,125)      | (149,094)      |
| Profit before income tax expense                                                                       |      | 1,231,874      | 1,033,685      |
| Income tax expense                                                                                     | 8    | (739,919)      | (493,306)      |
|                                                                                                        |      | 491,955        |                |
| Profit after income tax expense for the year attributable to the owners of  Rectifier Technologies Ltd |      |                | 540,379        |
| Other comprehensive income                                                                             |      |                |                |
| Items that may be reclassified subsequently to profit or loss Foreign currency translation             |      | 166,439        | (205,003)      |
| Other comprehensive income for the year, net of tax                                                    |      | 166,439        | (205,003)      |
| Total comprehensive income for the year attributable to the owners of  Rectifier Technologies Ltd      |      | 658,394        | 335,376        |
|                                                                                                        |      | Cents          | Cents          |
| Basic earnings per share                                                                               | 29   | 0.04           | 0.04           |


For personal use only

---

# Page 17

# Rectifier Technologies Ltd Statement of financial position As at 30 June 2022


|                                          | Note   | 2022 $       | 2021 $       |
|------------------------------------------|--------|--------------|--------------|
| Assets                                   |        |              |              |
| Current assets                           |        |              |              |
| Cash and cash equivalents                | 9      | 7,295,534    | 6,241,106    |
| Trade and other receivables              | 10     | 2,910,217    | 1,728,532    |
| Inventories                              | 11     | 5,877,879    | 1,906,090    |
| Current tax assets                       | 8      | 734,150      | 1,066,189    |
| Total current assets                     |        | 16,817,780   | 10,941,917   |
| Non-current assets For personal use only |        |              |              |
| Property, plant and equipment            | 12     | 4,605,248    | 4,170,591    |
| Right-of-use assets                      | 13     | 886,673      | 1,154,814    |
| Intangibles                              | 14     | 94,859       | 106,048      |
| Deferred tax assets                      | 8      | 524,993      | 464,209      |
| Total non-current assets                 |        | 6,111,773    | 5,895,662    |
| Total assets                             |        | 22,929,553   | 16,837,579   |
| Liabilities                              |        |              |              |
| Current liabilities                      |        |              |              |
| Trade and other payables                 | 15     | 5,549,921    | 2,649,978    |
| Borrowings                               | 16     | 1,122,142    | 154,710      |
| Lease liabilities                        | 17     | 212,781      | 295,410      |
| Current tax liabilities                  | 8      | 795,256      | 934,751      |
| Employee benefits                        | 18     | 933,573      | 747,547      |
| Total current liabilities                |        | 8,613,673    | 4,782,396    |
| Non-current liabilities                  |        |              |              |
| Borrowings                               | 16     | 4,151,846    | 2,439,390    |
| Lease liabilities                        | 17     | 457,534      | 588,464      |
| Deferred tax liabilities                 | 8      | 295,404      | 271,675      |
| Employee benefits                        | 18     | 56,389       | 59,341       |
| Total non-current liabilities            |        | 4,961,173    | 3,358,870    |
| Total liabilities                        |        | 13,574,846   | 8,141,266    |
| Net assets                               |        | 9,354,707    | 8,696,313    |
| Equity                                   |        |              |              |
| Issued capital                           | 19     | 39,992,575   | 39,992,575   |
| Reserves                                 | 20     | 513,264      | 466,825      |
| Accumulated losses                       |        | (31,151,132) | (31,763,087) |
| Total equity                             |        | 9,354,707    | 8,696,313    |

---

# Page 18

# Rectifier Technologies Ltd Statement of changes in equity For the year ended 30 June 2022


## Consolidated

Balance at 1 July 2020

Profit after income tax expense for the year Other comprehensive income for the year, net of tax

Total comprehensive income for the year

Transactions with owners in their capacity as owners: Contributions of equity, net of transaction costs (note 19) Dividends paid (note 21)

Balance at 30 June 2021


## Consolidated

Balance at 1 July 2021

Profit after income tax expense for the year Other comprehensive income for the year, net of tax

Total comprehensive income for the year

Transactions with owners in their capacity as owners: Lapsed options transferred to accumulated losses

Balance at 30 June 2022


| Issued  capital $   | Reserves $   | Accumulated  losses $   | Total equity $   |
|---------------------|--------------|-------------------------|------------------|
| 39,851,775          | 671,828      | (30,927,765)            | 9,595,838        |
| -                   | -            | 540,379                 | 540,379          |
| -                   | (205,003)    | -                       | (205,003)        |
| -                   | (205,003)    | 540,379                 | 335,376          |
| 140,800             | -            | -                       | 140,800          |
| -                   | -            | (1,375,701)             | (1,375,701)      |
| 39,992,575          | 466,825      | (31,763,087)            | 8,696,313        |



| Issued  capital $   | Reserves $   | Accumulated  losses $   | Total equity $   |
|---------------------|--------------|-------------------------|------------------|
| 39,992,575          | 466,825      | (31,763,087)            | 8,696,313        |
| -                   | -            | 491,955                 | 491,955          |
| -                   | 166,439      | -                       | 166,439          |
| -                   | 166,439      | 491,955                 | 658,394          |
| -                   | (120,000)    | 120,000                 | -                |
| 39,992,575          | 513,264      | (31,151,132)            | 9,354,707        |


For personal use only

---

# Page 19

# Rectifier Technologies Ltd Statement of cash flows For the year ended 30 June 2022


|                                                                  |      | Consolidated   | Consolidated   |
|------------------------------------------------------------------|------|----------------|----------------|
|                                                                  | Note | 2022 $         | 2021 $         |
| Cash flows from operating activities                             |      |                |                |
| Receipts from customers                                          |      | 16,257,817     | 13,640,920     |
| Payments to suppliers and employees                              |      | (17,230,486)   | (11,515,086)   |
| Government grants (COVID-19)                                     |      | -              | 435,900        |
| Interest received                                                |      | 6,091          | 16,984         |
| Finance costs                                                    |      | (147,406)      | (149,094)      |
| Income taxes refunded/(paid)                                     |      | 387,984        | (832,165)      |
| Net cash from/(used in) operating activities                     | 30   | (726,000)      | 1,597,459      |
| Cash flows from investing activities                             |      |                |                |
| Payments for property, plant and equipment                       |      | (629,211)      | (570,904)      |
| Proceeds from disposal of property, plant and equipment          |      | -              | 126            |
| Net cash used in investing activities                            |      | (629,211)      | (570,778)      |
| Cash flows from financing activities                             |      |                |                |
| Proceeds from issue of shares                                    | 19   | -              | 140,800        |
| Proceeds from borrowings                                         |      | 3,000,000      | 177,617        |
| Dividends paid                                                   | 21   | -              | (1,375,701)    |
| Repayment of borrowings                                          |      | (389,096)      | (126,018)      |
| Repayment of lease liabilities                                   |      | (317,318)      | (324,456)      |
| Net cash from/(used in) financing activities                     |      | 2,293,586      | (1,507,758)    |
| Net increase/(decrease) in cash and cash equivalents             |      | 938,375        | (481,077)      |
| Cash and cash equivalents at the beginning of the financial year |      | 6,241,106      | 6,873,680      |
| Effects of exchange rate changes on cash and cash equivalents    |      | 116,053        | (151,497)      |
| Cash and cash equivalents at the end of the financial year       | 9    | 7,295,534      | 6,241,106      |


For personal use only

---

# Page 20

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 1. General information

The financial statements cover Rectifier Technologies Ltd as a consolidated entity consisting of Rectifier Technologies Ltd and the entities it controlled at the end of, or during, the year. The financial statements are presented in Australian dollars, which is Rectifier Technologies Ltd's functional and presentation currency.

Rectifier Technologies Ltd is a listed public company limited by shares, incorporated and domiciled in Australia. Its registered office and principal place of business is:


## 97 Highbury Road


## Burwood, VIC 3125

A description of the nature of the consolidated entity's operations and its principal activities are included in the directors' report, which is not part of the financial statements.

The financial statements were authorised for issue, in accordance with a resolution of directors, on 30 September 2022. The directors have the power to amend and reissue the financial statements.


## Note 2. Significant accounting policies

The principal accounting policies adopted in the preparation of the financial statements are set out below. These policies have been consistently applied to all the years presented, unless otherwise stated.


## New or amended Accounting Standards and Interpretations adopted

The consolidated entity has adopted all of the new or amended Accounting Standards and Interpretations issued by the Australian Accounting Standards Board ('AASB') that are mandatory for the current reporting period.

Any new or amended Accounting Standards or Interpretations that are not yet mandatory have not been early adopted.


## Going concern

The financial report has been prepared on the basis of the Group continuing as a going concern, which assumes continuity of normal business activities and realisation of assets and the settlement of liabilities in the ordinary course of business.


## Basis of preparation

These general purpose financial statements have been prepared in accordance with Australian Accounting Standards and Interpretations issued by the Australian Accounting Standards Board ('AASB') and the Corporations Act 2001, as appropriate for for-profit oriented entities. These financial statements also comply with International Financial Reporting Standards as issued by the International Accounting Standards Board ('IASB').


## Historical cost convention

The financial statements have been prepared under the historical cost convention.


## Critical accounting estimates

The  preparation  of  the  financial  statements  requires  the  use  of  certain  critical  accounting  estimates.  It  also  requires management to exercise its judgement in the process of applying the consolidated entity's accounting policies. The areas involving a higher degree of judgement or complexity, or areas where assumptions and estimates are significant to the financial statements, are disclosed in note 3.


## Parent entity information

In accordance with the Corporations Act 2001, these financial statements present the results of the consolidated entity only. Supplementary information about the parent entity is disclosed in note 33.


## Principles of consolidation

The consolidated financial statements incorporate the assets and liabilities of all subsidiaries of Rectifier Technologies Ltd ('Company' or 'parent entity') as at 30 June 2022 and the results of all subsidiaries for the year ended. Rectifier Technologies Ltd and its subsidiaries together are referred to in these financial statements as the 'consolidated entity'.

For personal use only

---

# Page 21

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 2. Significant accounting policies (continued)

Subsidiaries are all those entities over which the consolidated entity has control. The consolidated entity controls an entity when the consolidated entity is exposed to, or has rights to, variable returns from its involvement with the entity and has the ability to affect those returns through its power to direct the activities of the entity. Subsidiaries are fully consolidated from the date on which control is transferred to the consolidated entity. They are de-consolidated from the date that control ceases.

Intercompany transactions, balances and unrealised gains on transactions between entities in the consolidated entity are eliminated. Unrealised losses are also eliminated unless the transaction provides evidence of the impairment of the asset transferred. Accounting policies of subsidiaries have been changed where necessary to ensure consistency with the policies adopted by the consolidated entity.

The acquisition of subsidiaries is accounted for using the acquisition method of accounting. A change in ownership interest, without  the  loss  of  control,  is  accounted  for  as  an  equity  transaction,  where  the  difference  between  the  consideration transferred and the book value of the share of the non-controlling interest acquired is recognised directly in equity attributable to the parent.

Where the consolidated entity loses control over a subsidiary, it derecognises the assets including goodwill, liabilities and non-controlling  interest  in  the  subsidiary  together  with  any  cumulative  translation  differences  recognised  in  equity.  The consolidated entity recognises the fair value of the consideration received and the fair value of any investment retained together with any gain or loss in profit or loss.


## Operating segments

Operating segments are presented using the 'management approach', where the information presented is on the same basis as the internal reports provided to the Chief Operating Decision Makers ('CODM'). The CODM is responsible for the allocation of resources to operating segments and assessing their performance.


## Foreign currency translation

The financial statements are presented in Australian dollars, which is Rectifier Technologies Ltd's functional and presentation currency.


## Foreign currency transactions

Foreign currency transactions are translated into the entity's functional currency using the exchange rates prevailing at the dates of the transactions. Foreign exchange gains and losses resulting from the settlement of such transactions and from the translation at financial year-end exchange rates of monetary assets and liabilities denominated in foreign currencies are recognised in profit or loss.


## Foreign operations

The assets and liabilities of foreign operations are translated into Australian dollars using the exchange rates at the reporting date. The revenues and expenses of foreign operations are translated into Australian dollars using the average exchange rates, which approximate the rates at the dates of the transactions for the period. All resulting foreign exchange differences are recognised in other comprehensive income through the foreign currency reserve in equity.

The foreign currency reserve is recognised in profit or loss when the foreign operation or net investment is disposed of.


## Revenue recognition

The consolidated entity recognises revenue as follows:


## Revenue from contracts with customers

Revenue is recognised at an amount that reflects the consideration to which the consolidated entity is expected to be entitled in exchange for transferring goods or services to a customer. For each contract with a customer, the consolidated entity: identifies the contract with a customer; identifies the performance obligations in the contract; determines the transaction price which takes into account estimates of variable consideration and the time value of money; allocates the transaction price to the separate performance obligations on the basis of the relative stand-alone selling price of each distinct good or service to be delivered; and recognises revenue when or as each performance obligation is satisfied in a manner that depicts the transfer to the customer of the goods or services promised.

For personal use only

---

# Page 22

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 2. Significant accounting policies (continued)

Variable consideration within the transaction price, if any, reflects concessions provided to the customer such as discounts, rebates and refunds, any potential bonuses receivable from the customer and any other contingent events. Such estimates are determined using either the 'expected value' or 'most likely amount' method. The measurement of variable consideration is subject to a constraining principle whereby revenue will only be recognised to the extent that it is highly probable that a significant reversal in the amount of cumulative revenue recognised will not occur. The measurement constraint continues until the uncertainty associated with the variable consideration is subsequently resolved. Amounts received that are subject to the constraining principle are recognised as a refund liability.


## Sale of goods

Revenue from the sale of power rectifiers and the related after-sales services is recognised at the point in time when the consolidated entity satisfies performance obligations by transferring the promised products and services, which is generally at the time of delivery.

The  consolidated  entity  recognises  contract  liabilities  for  consideration  received  in  respect  of  unsatisfied  performance obligations and reports these amounts as other liabilities in the statement of financial position. Similarly, if the consolidated entity satisfies a performance obligation before it receives the consideration, the consolidated entity recognises either a contract asset or a receivable in its statement of financial position, depending on whether something other than the passage of time is required before the consideration is due.


## Other revenue

Other revenue is recognised when it is received or when the right to receive payment is established.

Interest revenue is recognised as interest accrued using the effective interest method. This is a method of calculating the amortised cost of a financial asset and allocating the interest income over the relevant period using the effective interest rate, which is the rate that exactly discounts estimated future cash receipts through the expected life of the financial asset to the net carrying amount of the financial asset.


## Income tax

The income tax expense or benefit for the period is the tax payable on that period's taxable income based on the applicable income tax rate for each jurisdiction, adjusted by the changes in deferred tax assets and liabilities attributable to temporary differences, unused tax losses and the adjustment recognised for prior periods, where applicable.


- Deferred tax assets and liabilities are recognised for temporary differences at the tax rates expected to be applied when the assets are recovered or liabilities are settled, based on those tax rates that are enacted or substantively enacted, except for:
- ● When the deferred income tax asset or liability arises from the initial recognition of goodwill or an asset or liability in a transaction that is not a business combination and that, at the time of the transaction, affects neither the accounting nor taxable profits; or


● When the taxable temporary difference is associated with interests in subsidiaries, associates or joint ventures, and the timing of the reversal can be controlled and it is probable that the temporary difference will not reverse in the foreseeable future.

Deferred tax assets are recognised for deductible temporary differences and unused tax losses only if it is probable that future taxable amounts will be available to utilise those temporary differences and losses.

The carrying amount of recognised and unrecognised deferred tax assets are reviewed at each reporting date. Deferred tax assets recognised are reduced to the extent that it is no longer probable that future taxable profits will be available for the carrying amount to be recovered. Previously unrecognised deferred tax assets are recognised to the extent that it is probable that there are future taxable profits available to recover the asset.

Interest For personal use only

Deferred tax assets and liabilities are offset only where there is a legally enforceable right to offset current tax assets against current tax liabilities and deferred tax assets against deferred tax liabilities; and they relate to the same taxable authority on either the same taxable entity or different taxable entities which intend to settle simultaneously.

---

# Page 23

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 2. Significant accounting policies (continued)

Rectifier  Technologies  Ltd  (the  'head  entity')  and  its  wholly-owned  Australian  subsidiaries  have  formed  an  income  tax consolidated group under the tax consolidation regime. The head entity and each subsidiary in the tax consolidated group continue to account for their own current and deferred tax amounts. The tax consolidated group has applied the 'separate taxpayer  within  group'  approach  in  determining  the  appropriate  amount  of  taxes  to  allocate  to  members  of  the  tax consolidated group.

In addition to its own current and deferred tax amounts, the head entity also recognises the current tax liabilities (or assets) and the deferred tax assets arising from unused tax losses and unused tax credits assumed from each subsidiary in the tax consolidated group.

Assets or liabilities  arising  under  tax  funding  agreements  with  the  tax  consolidated  entities  are  recognised  as  amounts receivable from or payable to other entities in the tax consolidated group. The tax funding arrangement ensures that the intercompany charge equals the current tax liability or benefit of each tax consolidated group member, resulting in neither a contribution by the head entity to the subsidiaries nor a distribution by the subsidiaries to the head entity.


## Current and non-current classification

Assets and liabilities are presented in the statement of financial position based on current and non-current classification.

An  asset  is  classified  as  current  when:  it  is  either  expected  to  be  realised  or  intended  to  be  sold  or  consumed  in  the consolidated entity's normal operating cycle; it is held primarily for the purpose of trading; it is expected to be realised within 12 months after the reporting period, or the asset is cash or cash equivalent unless restricted from being exchanged or used to settle a liability for at least 12 months after the reporting period. All other assets are classified as non-current.

A liability is classified as current when: it is either expected to be settled in the consolidated entity's normal operating cycle; it is held primarily for the purpose of trading; it is due to be settled within 12 months after the reporting period, or there is no unconditional right to defer the settlement of the liability for at least 12 months after the reporting period. All other liabilities are classified as non-current.

Deferred tax assets and liabilities are always classified as non-current.


## Cash and cash equivalents

Cash and cash equivalents include cash on hand, deposits held at call with financial institutions, other short-term, highly liquid investments with original maturities of three months or less that are readily convertible to known amounts of cash and which are subject to an insignificant risk of changes in value.


## Trade and other receivables

Trade receivables are initially recognised at fair value and subsequently measured at amortised cost using the effective interest method, less any allowance for expected credit losses. Trade receivables are generally due for settlement within 30 days.

The consolidated entity has applied the simplified approach to measuring expected credit losses, which uses a lifetime expected loss allowance. To measure the expected credit losses, trade receivables have been grouped based on days overdue.

Other receivables are recognised at amortised cost, less any allowance for expected credit losses.


## Inventories

Raw materials, work in progress and finished goods are stated at the lower of cost and net realisable value on a 'weighted average'  basis.  Cost  comprises  of  direct  materials  and  delivery  costs,  direct  labour,  import  duties  and  other  taxes,  an appropriate  proportion  of  variable  and  fixed  overhead  expenditure  based  on  normal  operating  capacity,  and,  where applicable, transfers from cash flow hedging reserves in equity. Costs of purchased inventory are determined after deducting rebates and discounts received or receivable.

For personal use only

Stock in transit is stated at the lower of cost and net realisable value. Cost comprises of purchase and delivery costs, net of rebates and discounts received or receivable.

Net realisable value is the estimated selling price in the ordinary course of business less the estimated costs of completion and the estimated costs necessary to make the sale.

---

# Page 24

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 2. Significant accounting policies (continued)


## Property, plant and equipment

Freehold land is stated at historical cost and is not depreciated but is subject to impairment testing if there is any indication of impairment.

Building and plant and equipment are stated at historical cost less accumulated depreciation and impairment. Historical cost includes expenditure that is directly attributable to the acquisition of the items.

Depreciation is calculated on a straight-line basis to write off the net cost of each item of property, plant and equipment (excluding land) over their expected useful lives as follows:

50 years

Leasehold improvement

10 years

Plant and equipment

2.5-5 years

Motor vehicle

5 years

The residual values, useful lives and depreciation methods are reviewed, and adjusted if appropriate, at each reporting date.

Leasehold improvements are depreciated over the unexpired period of the lease or the estimated useful life of the assets, whichever is shorter.

An item of property, plant and equipment is derecognised upon disposal or when there is no future economic benefit to the consolidated entity. Gains and losses between the carrying amount and the disposal proceeds are taken to profit or loss.


## Right-of-use assets

A right-of-use asset is recognised at the commencement date of a lease. The right-of-use asset is measured at cost, which comprises the initial amount of the lease liability, adjusted for, as applicable, any lease payments made at or before the commencement date net of any lease incentives received, any initial direct costs incurred, and, except where included in the cost of inventories, an estimate of costs expected to be incurred for dismantling and removing the underlying asset, and restoring the site or asset.

Right-of-use assets are depreciated on a straight-line basis over the unexpired period of the lease or the estimated useful life of the asset, whichever is shorter. Where the consolidated entity expects to obtain ownership of the leased asset at the end of the lease term, the depreciation is over its estimated useful life. Right-of-use assets are subject to impairment or adjusted for any remeasurement of lease liabilities.

The consolidated entity has elected not to recognise a right-of-use asset and corresponding lease liability for short-term leases with terms of 12 months or less and leases of low-value assets. Lease payments on these assets are expensed to profit or loss as incurred.


## Intangible assets


## Research and development

Research costs are expensed in the period in which they are incurred. Development costs are capitalised when: it is probable that the project will be a success considering its commercial and technical feasibility; the consolidated entity is able to use or sell the asset; the consolidated entity has sufficient resources and intent to complete the development; and its costs can be measured reliably. Capitalised development costs are amortised on a straight-line basis over the period of their expected benefit, being their finite life of 10 years.


## Impairment of non-financial assets

Non-financial assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount may not be recoverable. An impairment loss is recognised for the amount by which the asset's carrying amount exceeds its recoverable amount.

Building For personal use only

Recoverable amount is the higher of an asset's fair value less costs of disposal and value-in-use. The value-in-use is the present value of the estimated future cash flows relating to the asset using a pre-tax discount rate specific to the asset or cash-generating unit to which the asset belongs. Assets that do not have independent cash flows are grouped together to form a cash-generating unit.

---

# Page 25

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 2. Significant accounting policies (continued)


## Trade and other payables

Trade and other payables represent liabilities for goods and services provided to the consolidated entity prior to the end of the financial year and which are unpaid. Due to their short-term nature, they are measured at amortised cost and are not discounted. The amounts are unsecured and are usually paid within 30 days of recognition.


## Borrowings

Loans and borrowings are initially recognised at the fair value of the consideration received, net of transaction costs. They are subsequently measured at amortised cost using the effective interest method.


## Lease liabilities

A lease liability is recognised at the commencement date of a lease. The lease liability is initially recognised at the present value of the lease payments to be made over the term of the lease, discounted using the interest rate implicit in the lease or, if that rate cannot be readily determined, the consolidated entity's incremental borrowing rate. Lease payments comprise of fixed payments less any lease incentives receivable, variable lease payments that depend on an index or a rate, amounts expected to be paid under residual value guarantees, exercise price of a purchase option when the exercise of the option is reasonably certain to occur, and any anticipated termination penalties. The variable lease payments that do not depend on an index or a rate are expensed in the period in which they are incurred.

Lease liabilities are measured at amortised cost using the effective interest method. The carrying amounts are remeasured if  there  is  a  change  in  the  following:  future  lease  payments  arising  from  a  change  in  an  index  or  a  rate  used;  residual guarantee; lease term; the certainty of a purchase option and termination penalties. When a lease liability is remeasured, an adjustment is made to the corresponding right-of use asset, or to profit or loss if the carrying amount of the right-of-use asset is fully written down.


## Finance costs

Finance costs attributable to qualifying assets are capitalised as part of the asset. All other finance costs are expensed in the period in which they are incurred.


## Employee benefits


## Short-term employee benefits

Liabilities  for  wages and salaries, including non-monetary benefits, annual leave and long service leave expected to be settled wholly within 12 months of the reporting date are measured at the amounts expected to be paid when the liabilities are settled.


## Other long-term employee benefits

The liability for annual leave and long service leave not expected to be settled within 12 months of the reporting date are measured at the present value of expected future payments to be made in respect of services provided by employees up to the reporting date. Consideration is given to expected future wage and salary levels, the experience of employee departures and periods of service. Expected future payments are discounted using market yields at the reporting date on high-quality corporate bonds with terms to maturity and currency that match, as closely as possible, the estimated future cash outflows.


## Defined contribution superannuation expense

Contributions to defined contribution superannuation plans are expensed in the period in which they are incurred.


## Share-based payments

Equity-settled share-based compensation benefits are provided to employees.

Equity-settled transactions are awards of shares, or options over shares, that are provided to employees in exchange for the rendering of services.

For personal use only

The cost of equity-settled transactions are measured at fair value on grant date. Fair value is independently determined using the Black-Scholes option pricing model that takes into account the exercise price, the term of the option, the impact of dilution, the share price at grant date and expected price volatility of the underlying share, the expected dividend yield and the risk free  interest  rate  for  the  term  of  the  option,  together  with  non-vesting  conditions  that  do  not  determine  whether  the consolidated entity receives the services that entitle the employees to receive payment. No account is taken of any other vesting conditions.

---

# Page 26

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 2. Significant accounting policies (continued)

The cost of equity-settled transactions are recognised as an expense with a corresponding increase in equity at the vesting date which is at the grant date. The cumulative charge to profit or loss is calculated based on the grant date fair value of the award, the best estimate of the number of awards that are likely to vest and the expired portion of the vesting period. The amount recognised in profit or loss for the period is the cumulative amount calculated at each reporting date less amounts already recognised in previous periods.

If equity-settled awards are modified, as a minimum an expense is recognised as if the modification has not been made. An additional expense is recognised, over the remaining vesting period, for any modification that increases the total fair value of the share-based compensation benefit as at the date of modification.

If the non-vesting condition is within the control of the consolidated entity or employee, the failure to satisfy the condition is treated as a cancellation. If the condition is not within the control of the consolidated entity or employee and is not satisfied during the vesting period, any remaining expense for the award is recognised over the remaining vesting period, unless the award is forfeited.

If equity-settled awards are cancelled, it is treated as if it has vested on the date of cancellation, and any remaining expense is recognised immediately. If a new replacement award is substituted for the cancelled award, the cancelled and new award is treated as if they were a modification.


## Issued capital

Ordinary shares are classified as equity.

Incremental costs directly attributable to the issue of new shares or options are shown in equity as a deduction, net of tax, from the proceeds.


## Dividends

Dividends are recognised when declared during the financial year and no longer at the discretion of the Company.


## Earnings per share


## Basic earnings per share

Basic earnings per share is calculated by dividing the profit attributable to the owners of Rectifier Technologies Ltd, excluding any costs of servicing equity other than ordinary shares, by the weighted average number of ordinary shares outstanding during the financial year, adjusted for bonus elements in ordinary shares issued during the financial year.


## Diluted earnings per share

Diluted earnings per share adjusts the figures used in the determination of basic earnings per share to take into account the after income tax effect of interest and other financing costs associated with dilutive potential ordinary shares and the weighted average number of additional ordinary shares that would have been outstanding assuming conversion of all dilutive potential ordinary shares.


## Goods and Services Tax ('GST') and other similar taxes

Revenues, expenses and assets are recognised net of the amount of associated GST, unless the GST incurred are not recoverable from the tax authority. In this case, it is recognised as part of the cost of the acquisition of the asset or as part of the expense.

Receivables  and  payables  are  stated  inclusive  of  the  amount  of  GST  receivable  or  payable.  The  net  amount  of  GST recoverable from, or payable to, the tax authority is included in other receivables or other payables in the statement of financial position.

Cash flows are presented on a gross basis. The GST components of cash flows arising from investing or financing activities which are recoverable from, or payable to the tax authority, are presented as operating cash flows.

Commitments and contingencies are disclosed net of the amount of GST recoverable from, or payable to, the tax authority.

For personal use only

---

# Page 27

Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


# Note 2. Significant accounting policies (continued)


## New Accounting Standards and Interpretations not yet mandatory or early adopted

Australian Accounting Standards and Interpretations that have recently been issued or amended but are not yet mandatory, have not been early adopted by the consolidated entity for the annual reporting period ended 30 June 2022. The consolidated entity has not yet assessed the impact of these new or amended Accounting Standards and Interpretations.


## Note 3. Critical accounting judgements, estimates and assumptions

The preparation of the financial statements requires management to make judgements, estimates and assumptions that affect the reported amounts in the financial statements. Management continually evaluates its judgements and estimates in relation to assets, liabilities, contingent liabilities, revenue and expenses. Management bases its judgements, estimates and assumptions on historical experience and on other various factors, including expectations of future events, management believes to be reasonable under the circumstances. The resulting accounting judgements and estimates will seldom equal the related actual results. The judgements, estimates and assumptions that have a significant risk of causing a material adjustment to the carrying amounts of assets and liabilities (refer to the respective notes) within the next financial year are discussed below.


## Provision for impairment of inventories

The provision for impairment of inventories assessment requires a degree of estimation and judgement. The level of the provision is assessed by taking into account the recent sales experience, the ageing of inventories and other factors that affect inventory obsolescence.


## R & D tax rebate

The consolidated entity has recognised the R&D rebate on an accrual basis. As the return has not yet been submitted, the consolidated entity has made an estimate of the likely refund amount based on the preliminary number provided by external tax consultant.


## Income tax

The consolidated entity is subject to income taxes in the jurisdictions in which it operates. Significant judgement is required in determining the provision for income tax. There are many transactions and calculations undertaken during the ordinary course of business for which the ultimate tax determination is uncertain. The consolidated entity recognises liabilities for anticipated tax audit issues based on the consolidated entity's current understanding of the tax law. Where the final tax outcome of these matters is different from the carrying amounts, such differences will impact the current and deferred tax provisions in the period in which such determination is made.

For personal use only

---

# Page 28

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 4. Operating segments

Identification of reportable operating segments

The consolidated entity is organised into 4 operating segments as described below. These operating segments are based on the internal reports that are reviewed and used by the executive management committee (who are identified as the Chief Operating  Decision  Makers  ('CODM'))  in  assessing  performance  and  in  determining  the  allocation  of  resources.  The executive management committee considers the business from both a product and geographic perspective and assesses performance and allocates resources on this basis. There is no aggregation of operating segments.


## Description

Under this segment, Rectifier Technologies Pacific Pty Ltd and Rectifier Technologies Malaysia Sdn Bhd which is based in Malaysia manufacture electronic components for a number of industries.

Under this segment, Rectifier Technologies Pacific Pty Ltd and Rectifier Technologies Malaysia Sdn Bhd manufacture and distribute rectifiers, controllers, accessories and complete systems for the power generation, distribution industries and defence. Rectifier Technologies Singapore Pte Ltd only focuses on distribution.

Under this segment, Rectifier Technologies Pacific Pty Ltd and Rectifier Technologies Malaysia Sdn Bhd manufacture and distribute power supplies for the transport industries and telecommunications. Rectifier Technologies Singapore Pte Ltd only focuses on distribution.

Under this segment, Rectifier Technologies Pacific Pty Ltd, Rectifier Technologies Singapore Pte Ltd and Rectifier Technologies Malaysia Sdn Bhd manufacture and distribute electric vehicle charges, battery charges and power supplies for a number of industries. Rectifier Technologies Singapore Pte Ltd only focuses on distribution.

Electronic Components

Industrial Power Supplies (Electricity generation/ distribution and Defence)

Industrial Power Supplies (Transport and

Telecommunication) ('T&T')

Industrial Power Supplies (Electric vehicles) ('EV')

The CODM reviews earnings before interest, tax, depreciation and amortisation ('EBITDA'). This measure excludes nonrecurring expenditures such as restructuring costs, impairments and share-based payments as well as interest revenue and interest  expense and other items which are considered part of the corporate treasury function. The accounting policies adopted for internal reporting to the CODM are consistent with those adopted in the financial statements.

The information reported to the CODM is on a monthly basis. Refer to note 5 for geographic information.


## Intersegment transactions


- Intersegment transactions were made at market rates. Inter-segment revenue comprises sales between segments which are on arm's length terms. Intersegment transactions are eliminated on consolidation.


Intersegment receivables, payables and loans

Intersegment loans are initially recognised at the consideration received. Intersegment loans receivable and loans payable that earn or incur non-market interest are not adjusted to fair value based on market interest rates. Intersegment loans are eliminated on consolidation.


## Major customers

During the year ended 30 June 2022, the revenue of $10,562,830 (2021: $6,513,519) and $944,754 (2021: $1,164,100) were derived from two Australian customers, which are allocated to the Industrial Power Supplies (EV) and Industrial Power Supplies (E&D) segments respectively. Revenue of $1,482,138 (2021: $1,301,035) was derived from a single (2021: single) customer in Singapore under the Industrial Power Supplies (E&D) segment.

Segment ('E&D') For personal use only

---

# Page 29

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 4. Operating segments (continued)

Operating segment information


|                                          | Electronic  components   | Industrial  power  supplies  (E&D) $   | Industrial  power  supplies  (T&T)   | Industrial  power  supplies (EV)   | Eliminations/  Corporate   | Total      |
|------------------------------------------|--------------------------|----------------------------------------|--------------------------------------|------------------------------------|----------------------------|------------|
| Consolidated - 2022                      | $                        |                                        | $                                    | $                                  | $                          | $          |
| Revenue                                  |                          |                                        |                                      |                                    |                            |            |
| Sales to external customers              | 209,004                  | 3,305,291                              | 622,739                              | 10,810,151                         | -                          | 14,947,185 |
| Intersegment sales                       | 28,241                   | 1,629,441                              | 398,885                              | 8,608,629                          | (10,665,196)               | -          |
| Total revenue                            | 237,245                  | 4,934,732                              | 1,021,624                            | 19,418,780                         | (10,665,196)               | 14,947,185 |
| EBITDA                                   | 10,681                   | 168,920                                | 31,826                               | 552,465                            | 1,228,346                  | 1,992,238  |
| Depreciation and amortisation            | (305,349)                | (54,555)                               | (8,285)                              | (239,050)                          | -                          | (607,239)  |
| Finance costs                            | (172,100)                | (5,963)                                | (765)                                | (30,397)                           | 56,100                     | (153,125)  |
| Profit/(loss) before income              |                          |                                        |                                      |                                    |                            |            |
| tax expense                              | (466,768)                | 108,402                                | 22,776                               | 283,018                            | 1,284,446                  | 1,231,874  |
| Income tax expense                       |                          |                                        |                                      |                                    |                            | (739,919)  |
| Profit after income tax  expense         |                          |                                        |                                      |                                    |                            | 491,955    |
| Assets                                   |                          |                                        |                                      |                                    |                            |            |
| Segment assets                           | 351,462                  | 5,558,200                              | 1,047,201                            | 18,178,424                         | (2,205,734)                | 22,929,553 |
| Total assets                             |                          |                                        |                                      |                                    |                            | 22,929,553 |
| Liabilities                              |                          |                                        |                                      |                                    |                            |            |
| Segment liabilities                      | 222,148                  | 3,513,169                              | 661,904                              | 11,490,028                         | (2,312,403)                | 13,574,846 |
| Total liabilities                        |                          |                                        |                                      |                                    |                            | 13,574,846 |
| For personal use only                    | Electronic  components   | Industrial  power  supplies  (E&D)     | Industrial  power  supplies  (T&T)   | Industrial  power  supplies (EV)   | Eliminations/  Corporate   | Total      |
| Consolidated - 2021                      | $                        | $                                      | $                                    | $                                  | $                          | $          |
| Revenue                                  |                          |                                        |                                      |                                    |                            |            |
| Sales to external customers              | 249,272                  | 3,733,729                              | 1,857,809                            | 7,418,493                          | -                          | 13,259,303 |
| Intersegment sales                       | 8,209                    | 1,374,832                              | 1,439,791                            | 4,838,330                          | (7,661,162)                | -          |
| Total revenue                            | 257,481                  | 5,108,561                              | 3,297,600                            | 12,256,823                         | (7,661,162)                | 13,259,303 |
| EBITDA                                   | 24,444                   | 366,139                                | 182,182                              | 727,476                            | 437,377                    | 1,737,618  |
| Depreciation and amortisation            | (198,982)                | (138,247)                              | (27,363)                             | (190,247)                          | -                          | (554,839)  |
| Finance costs                            | (85,174)                 | (35,524)                               | (7,856)                              | (28,180)                           | 7,640                      | (149,094)  |
| Profit/(loss) before income  tax expense | (259,712)                | 192,368                                | 146,963                              | 509,049                            | 445,017                    | 1,033,685  |
| Income tax expense                       |                          |                                        |                                      |                                    |                            | (493,306)  |
| Profit after income tax                  |                          |                                        |                                      |                                    |                            |            |
| expense                                  |                          |                                        |                                      |                                    |                            | 540,379    |
| Assets                                   |                          |                                        |                                      |                                    |                            |            |
| Segment assets                           | 348,457                  | 5,219,368                              | 2,597,026                            | 10,370,288                         | (1,697,560)                | 16,837,579 |
| Total assets                             |                          |                                        |                                      |                                    |                            | 16,837,579 |
| Liabilities                              |                          |                                        |                                      |                                    |                            |            |
| Segment liabilities                      | 180,070                  | 2,697,172                              | 1,342,045                            | 5,358,973                          | (1,436,994)                | 8,141,266  |
| Total liabilities                        |                          |                                        |                                      |                                    |                            | 8,141,266  |

---

# Page 30

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 4. Operating segments (continued)


## Geographical information


|               | Sales to external customers   | Sales to external customers   | Geographical non-current  assets   | Geographical non-current  assets   |
|---------------|-------------------------------|-------------------------------|------------------------------------|------------------------------------|
|               | 2022                          | 2021                          | 2022                               | 2021                               |
|               | $                             | $                             | $                                  | $                                  |
|               | 12,218,517                    | 5,655,250                     | 986,901                            | 1,136,777                          |
|               | 1,643,041                     | 1,540,462                     | 4,505,020                          | 4,188,626                          |
| North America | 553,077                       | 1,745,298                     | -                                  | -                                  |
| South America | 17,353                        | 68,713                        | -                                  | -                                  |
| Europe        | 303,920                       | 2,810,016                     | -                                  | -                                  |
| Oceania       | 25,615                        | 21,972                        | -                                  | -                                  |
|               | 14,761,523                    | 11,841,711                    | 5,491,921                          | 5,325,403                          |


The geographical non-current assets above are exclusive of, where applicable, financial instruments, deferred tax assets, post-employment benefits assets and rights under insurance contracts.


## Note 5. Revenue


|                                      | Consolidated   | Consolidated   |
|--------------------------------------|----------------|----------------|
|                                      | 2022 $         | 2021 $         |
| Sale of goods                        | 14,761,523     | 11,841,712     |
| Disaggregation of revenue            |                |                |
|                                      | Consolidated   |                |
|                                      | 2022           | 2021           |
|                                      | $              | $              |
| Geographical regions                 |                |                |
| Australia                            | 12,218,517     | 5,655,250      |
| Asia                                 | 1,643,041      | 1,540,462      |
| North America                        | 553,077        | 1,745,298      |
| South America                        | 17,353         | 68,713         |
| Europe                               | 303,920        | 2,810,016      |
| Oceania                              |                | 21,973         |
|                                      | 25,615         |                |
| Timing of revenue recognition        |                |                |
| Goods transferred at a point in time | 14,761,523     | 11,841,712     |


Australia Asia For personal use only

---

# Page 31

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 6. Other income


|                                                                    | Consolidated   | Consolidated   |
|--------------------------------------------------------------------|----------------|----------------|
|                                                                    | 2022           | 2021           |
|                                                                    | $ $            | $ $            |
| Research and development tax rebate                                | 1,055,657      | 877,691        |
| Government grants (COVID-19)                                       | 38,851         | 435,900        |
| Foreign exchange gain                                              | 392,791        | -              |
| Other                                                              | 48,655         | 101,741        |
| Other income                                                       | 1,535,954      | 1,415,332      |
| Note 7. Expenses For personal use only                             |                |                |
|                                                                    | Consolidated   | Consolidated   |
|                                                                    | 2022           | 2021           |
|                                                                    | $              | $              |
| Profit before income tax includes the following specific expenses: |                |                |
| Cost of sales                                                      |                |                |
| Cost of sales                                                      | 7,352,827      | 5,799,730      |
| Depreciation                                                       |                |                |
| Building                                                           | 8,801          | 8,821          |
| Leasehold improvement                                              | 30,113         | 36,749         |
| Plant and equipment                                                | 316,386        | 263,433        |
| Motor vehicle                                                      | 2,284          | -              |
| Building right-of-use assets                                       | 164,106        | 157,808        |
| Plant and equipment right-of-use assets                            | 72,855         | 73,017         |
| Motor vehicle right-of-use assets                                  | 12,694         | 15,011         |
| Total depreciation                                                 | 607,239        | 554,839        |
| Finance costs                                                      |                |                |
| Interest and finance charges paid/payable on borrowings            | 104,930        | 86,269         |
| Interest and finance charges paid/payable on lease liabilities     | 48,195         | 62,825         |
| Finance costs expensed                                             | 153,125        | 149,094        |
| Foreign exchange loss                                              |                |                |
| Foreign exchange loss                                              | -              | 457,220        |
| Superannuation expense                                             |                |                |
| Defined contribution superannuation expense                        | 609,388        | 515,573        |
| Research costs                                                     |                |                |
| Research costs                                                     | 2,380,792      | 1,983,728      |

---

# Page 32

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 8. Income tax


|                                                                                                               | Consolidated   | Consolidated   |
|---------------------------------------------------------------------------------------------------------------|----------------|----------------|
|                                                                                                               | 2022 $         | 2021 $         |
| Current tax                                                                                                   | 776,974        | 608,499        |
| Deferred tax - origination and reversal of temporary differences                                              | (37,055)       | (115,193)      |
| Aggregate income tax expense                                                                                  | 739,919        | 493,306        |
| Numerical reconciliation of income tax expense and tax at the statutory rate Profit before income tax expense | 1,231,874      | 1,033,685      |
| Tax at the statutory tax rate of 25% (2021: 26%)                                                              | 307,969        | 268,758        |
| Tax effect amounts which are not deductible/(taxable) in calculating taxable income:                          |                |                |
| Research and development expenditures                                                                         | 6,826          | 515,769        |
| Controlled foreign company attributed income                                                                  | 595,198        | 129,068        |
| Other non-allowable items                                                                                     | 195,127        | 41,697         |
| Foreign tax offset                                                                                            | 55,022         | 28,313         |
| Other non-assessable items                                                                                    | (420,223)      | (490,299)      |
| Income tax expense                                                                                            | 739,919        | 493,306        |


The corporate tax rate applicable to base rate entities reduces from 27.5% to 26% for the 2020-21 income year and further reduces to 25% prospectively from the 2021-22 income year. The Company qualifies as a base rate entity as it has a turnover of less than $50 million and less than 80% of its assessable income is derived from base rate entity passive income. The Company has remeasured its deferred tax balances, and any unrecognised potential tax benefits arising from carried forward tax losses, based on the effective tax rate that is expected to apply in the year the temporary differences are expected to reverse or benefits from tax losses realised. The impact of the change in tax rate on deferred tax balances has been included as a reconciling item in table above in profit or loss or as an adjustment to equity to the extent to which the deferred tax relates to items previously recognised outside profit or loss.


|                                                                       | Consolidated   | Consolidated   |
|-----------------------------------------------------------------------|----------------|----------------|
|                                                                       | 2022           | 2021           |
|                                                                       | $              | $              |
| Tax losses not recognised                                             |                |                |
| Unused tax losses for which no deferred tax asset has been recognised | 18,409,592     | 18,409,592     |
| Potential tax benefit at statutory tax rates                          | 4,602,398      | 4,602,398      |


The above potential tax benefit for tax losses has not been recognised in the statement of financial position. These tax losses can only be utilised in the future if the continuity of ownership test is passed, or failing that, the same business test is passed.

For personal use only

---

# Page 33

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 8. Income tax (continued)


|                                                                          | Consolidated   | Consolidated   |
|--------------------------------------------------------------------------|----------------|----------------|
|                                                                          | 2022           | 2021           |
|                                                                          | $              | $              |
| Net deferred tax assets                                                  |                |                |
| Net deferred tax assets comprises temporary differences attributable to: |                |                |
| Employee benefits                                                        | 201,832        | 171,344        |
| Accrued expenses                                                         | 87,407         | 197,616        |
| Inventories                                                              | 146,133        | 92,734         |
| Unrealised foreign exchange losses                                       | (54,626)       | 48,938         |
| Property, plant and equipment                                            | (151,157)      | (318,098)      |
| Deferred tax asset                                                       | 229,589        | 192,534        |
| Movements:                                                               |                |                |
| Opening balance                                                          | 192,534        | 77,341         |
| Credited to profit or loss                                               | 37,055         | 115,193        |
| Closing balance                                                          | 229,589        | 192,534        |
|                                                                          | Consolidated   |                |
|                                                                          | 2022           | 2021           |
|                                                                          | $              | $              |
| Current tax assets                                                       |                |                |
| Current tax assets                                                       | 734,150        | 1,066,189      |
|                                                                          | Consolidated   |                |
|                                                                          | 2022           |                |
|                                                                          |                | 2021           |
|                                                                          | $              | $              |
| Current tax liabilities                                                  |                |                |
| Current tax liabilities                                                  | 795,256        | 934,751        |
| Note 9. Cash and cash equivalents For personal use only                  | $              | $              |
|                                                                          | Consolidated   |                |
|                                                                          | 2022           | 2021           |
| Current assets                                                           |                |                |
| Cash at bank                                                             | 7,295,534      | 6,241,106      |

---

# Page 34

# Rectifier Technologies Ltd


## Notes to the financial statements 30 June 2022


## Note 10. Trade and other receivables


|                                         | Consolidated   | Consolidated   |
|-----------------------------------------|----------------|----------------|
|                                         | 2022           | 2021           |
|                                         | $              | $              |
| Current assets                          |                |                |
| Trade receivables                       | 891,338        | 514,635        |
| Other receivables                       | 46,687         | 216,338        |
| Research and development tax incentives | 1,035,645      | 862,922        |
| Prepayments                             | 936,547        | 134,637        |
|                                         | 1,972,192      | 997,559        |
|                                         | 2,910,217      | 1,728,532      |



## Allowance for expected credit losses

The consolidated entity has recognised a loss of $nil (2021: $nil) in profit or loss in respect of the expected credit losses for the year ended 30 June 2022.


The ageing of the receivables and allowance for expected credit losses provided for above are as follows:
|                       | Carrying amount   | Carrying amount   |
|-----------------------|-------------------|-------------------|
|                       | 2022              | 2021              |
| Consolidated          | $                 | $                 |
| Not overdue           | 868,229           | 425,008           |
| 0 to 3 months overdue | 9,900             | 71,113            |
| Over 3 months overdue | 13,209            | 18,514            |
|                       | 891,338           | 514,635           |


Payment terms on receivables past due but not considered impaired have not been re-negotiated. The consolidated entity has been in direct contact with the relevant customers and are reasonably satisfied that payment will be received in full. The consolidated entity estimate of impairment losses is based on the expected credit loss.


## Note 11. Inventories


|                                     | Consolidated   | Consolidated   |
|-------------------------------------|----------------|----------------|
|                                     | 2022           | 2021           |
|                                     | $              | $              |
| Current assets                      |                |                |
| Raw materials                       | 3,574,937      | 1,700,837      |
| Finished goods and work in progress | 1,220,126      | (78,347)       |
| Stock in transit                    | 1,082,816      | 283,600        |
|                                     | 5,877,879      | 1,906,090      |


For personal use only

Inventories are recognised net of a provision for obsolescence of $702,984 (2021: $534,786) as at 30 June 2022.

---

# Page 35

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 12. Property, plant and equipment


|                                 | Consolidated   | Consolidated   |
|---------------------------------|----------------|----------------|
|                                 | 2022           | 2021           |
|                                 | $ $            | $ $            |
| Non-current assets              |                |                |
| Land - at cost                  | 2,207,392      | 2,146,230      |
| Building - at cost              | 1,493,058      | 1,369,567      |
| Less: Accumulated depreciation  | (1,085,057)    | (964,230)      |
|                                 | 408,001        | 405,337        |
| Leasehold improvement - at cost | 235,873        | 216,441        |
| Less: Accumulated depreciation  | (99,486)       | (69,398)       |
|                                 | 136,387        | 147,043        |
| Plant and equipment - at cost   | 3,655,900      | 2,047,266      |
| Less: Accumulated depreciation  | (1,805,507)    | (580,330)      |
|                                 | 1,850,393      | 1,466,936      |
| Motor vehicle - at cost         | 132,493        | 50,200         |
| Less: Accumulated depreciation  | (129,418)      | (45,155)       |
|                                 | 3,075          | 5,045          |
|                                 | 4,605,248      | 4,170,591      |



## Reconciliations


Reconciliations of the written down values at the beginning and end of the current and previous financial year are set out below:
| Consolidated            | Land $    | Building $   | Leasehold  improvement $   | Plant and  equipment $   | Motor vehicle $   | Total $   |
|-------------------------|-----------|--------------|----------------------------|--------------------------|-------------------|-----------|
| Balance at 1 July 2020  | 2,280,963 | 614,492      | 183,792                    | 1,159,365                | -                 | 4,238,612 |
| Additions               | -         | -            | -                          | 466,451                  | -                 | 466,451   |
| Disposals               | -         | -            | -                          | (106)                    | -                 | (106)     |
| Exchange differences    | (134,733) | (200,334)    | -                          | 104,659                  | -                 | (230,408) |
| Transfer from ROUA      | -         | -            | -                          | -                        | 5,045             | 5,045     |
| Depreciation expense    | -         | (8,821)      | (36,749)                   | (263,433)                | -                 | (309,003) |
| Balance at 30 June 2021 | 2,146,230 | 405,337      | 147,043                    | 1,466,936                | 5,045             | 4,170,591 |
| Additions               | -         | 11,465       | 19,540                     | 574,423                  | -                 | 605,428   |
| Disposals               | -         | -            | (83)                       | (48,060)                 | -                 | (48,143)  |
| Exchange differences    | 61,162    | -            | -                          | 44,772                   | 122               | 106,056   |
| Transfer from ROUA      | -         | -            | -                          | 128,708                  | 192               | 128,900   |
| Depreciation expense    | -         | (8,801)      | (30,113)                   | (316,386)                | (2,284)           | (357,584) |
| Balance at 30 June 2022 | 2,207,392 | 408,001      | 136,387                    | 1,850,393                | 3,075             | 4,605,248 |


For personal use only

---

# Page 36

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 13. Right-of-use assets


|                                    | Consolidated   | Consolidated   |
|------------------------------------|----------------|----------------|
|                                    | 2022           | 2021           |
|                                    | $              | $              |
| Non-current assets                 |                |                |
| Building - right-of-use            | 564,576        | 632,317        |
| Plant and equipment - right-of-use | 314,808        | 502,760        |
| Motor vehicle - right-of-use       | 7,289          | 19,737         |
|                                    | 886,673        | 1,154,814      |


The consolidated entity leases land and buildings for its offices and staff accommodations and plant and equipment under agreements of between 3 to 5 years with, in some cases, options to extend. The leases have various escalation clauses. On renewal, the terms of the leases are renegotiated.


## Reconciliations


Reconciliations of the written down values at the beginning and end of the current and previous financial year are set out below:
| Consolidated            | Building $   | Plant and  equipment $   | Motor vehicle $   | Total $   |
|-------------------------|--------------|--------------------------|-------------------|-----------|
| Balance at 1 July 2020  | 760,844      | 610,344                  | 41,967            | 1,413,155 |
| Additions               | 19,149       | -                        | -                 | 19,149    |
| Exchange differences    | 10,132       | (34,567)                 | (2,174)           | (26,609)  |
| Transfer to PPE         | -            | -                        | (5,045)           | (5,045)   |
| Depreciation expense    | (157,808)    | (73,017)                 | (15,011)          | (245,836) |
| Balance at 30 June 2021 | 632,317      | 502,760                  | 19,737            | 1,154,814 |
| Additions               | 100,525      | -                        | -                 | 100,525   |
| Exchange differences    | (4,160)      | 13,611                   | 438               | 9,889     |
| Transfer to PPE         | -            | (128,708)                | (192)             | (128,900) |
| Depreciation expense    | (164,106)    | (72,855)                 | (12,694)          | (249,655) |
| Balance at 30 June 2022 | 564,576      | 314,808                  | 7,289             | 886,673   |



For other lease disclosures refer to:
- ● note 7 for interest on lease liabilities
- ● note 17 for lease liabilities; and
- ● consolidated statement of cash flows for repayment of lease liabilities.



## Note 14. Intangibles


|                       | Consolidated   | Consolidated   |
|-----------------------|----------------|----------------|
|                       | 2022           | 2021           |
|                       | $              | $              |
| Non-current assets    |                |                |
| Development - at cost | 94,859         | 106,048        |


For personal use only

---

# Page 37

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 14. Intangibles (continued)


## Reconciliations


Reconciliations of the written down values at the beginning and end of the current and previous financial year are set out below:
|                                 | Development  cost   |
|---------------------------------|---------------------|
| Consolidated                    | $                   |
| Balance at 1 July 2020          | -                   |
| Additions                       | 106,048             |
| Balance at 30 June 2021         | 106,048             |
| Additions                       | 61,844              |
| Research and development rebate | (73,033)            |
| Balance at 30 June 2022         | 94,859              |



## Note 15. Trade and other payables


|                                       | Consolidated   | Consolidated   |
|---------------------------------------|----------------|----------------|
|                                       | 2022           | 2021           |
|                                       | $              | $              |
| Current liabilities                   |                |                |
| Trade payables                        | 4,463,965      | 2,134,083      |
| Sundry creditors and accrued expenses | 1,085,956      | 515,895        |
|                                       | 5,549,921      | 2,649,978      |


Refer to note 22 for further information on financial instruments.


## Note 16. Borrowings


|                         | Consolidated   | Consolidated   |
|-------------------------|----------------|----------------|
|                         | 2022           | 2021           |
|                         | $              | $              |
| Current liabilities     |                |                |
| Bank loans              | 1,122,142      | 154,710        |
| Non-current liabilities |                |                |
| Bank loans              | 4,151,846      | 2,439,390      |
|                         | 5,273,988      | 2,594,100      |


Refer to note 22 for further information on financial instruments.

The bank loans consist of the following:

For personal use only

---

# Page 38

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 16. Borrowings (continued)


- (i) A loan of MYR 5,460,000 (AUD 1,629,851). The term of the loan is 20 years, and the loan interest is calculated using the Base Lending Rate (Variable Rate) less a discount of 2.20% at the bank's discretion from time to time. The monthly repayment includes the payment of loan principal and interest. The first monthly instalment commenced on 1 May 2017, subsequent instalments are to be paid on or before the 1st of each calendar month and total repayments are 240 instalments in 240 months. The carrying amount of the loan was MYR 4,648,453 (AUD 1,531,464) as at 30 June 2022 (2021: MYR 4,899,598 (AUD 1,569,479)).
- (ii) A loan of MYR 2,730,000 (AUD929,393). The term of the loan is 20 years, and the loan interest is calculated using the Base Lending Rate (Variable Rate) less a discount of 2.20% at the bank's discretion from time to time. The monthly repayment includes the payment of loan principal and interest. The first monthly instalment commenced on 1 December 2019, subsequent instalments are to be paid on or before the 1st of each calendar month and total repayments are 240 instalments in 240 months. The carrying amount of the loan was MYR 2,552,538 (AUD 840,951) as at 30 June 2022 (2021: MYR 2,671,654 (AUD 855,806))
- (iii) A loan of MYR 498,800 (AUD 159,780). The term of the loan is 10 years, and the loan interest is calculated using the Base Lending Rate (Variable Rate) less a discount of 2% at the bank's discretion from time to time. The monthly repayment includes the payment of loan principal and interest. The first monthly instalment commenced on 1 October 2020, subsequent instalments are to be paid on or before the 1st of each calendar month and total repayments are 120 instalments in 120 months. The carrying amount of the loan was MYR 428,740 (AUD141,252) as at 30 June 2022 (2021: MYR 472,008 (AUD151,197)).
- (iv) A loan of AUD 3,000,000.The term of the loan is 3 years, and the loan interest is calculated using the Business Mortgage Index rate (Variable Rate) less a margin of 3.75% at the bank's discretion from time to time. The monthly repayment includes  the  payment  of  loan  principal  and  interest.  The  first  monthly  instalment  commenced  on  30  April  2022, subsequent instalments are to be paid on or before the 1st of each calendar month and total repayments are 36 instalments in 36 months. The carrying amount of the loan was AUD 2,760,321 as at 30 June 2022.
- (v) Prior year's trade facilities of MYR 55,000 (AUD17,618) were fully paid on 31 August 2021.



## Note 17. Lease liabilities


|                                                           |                   | Consolidated   | Consolidated   | Consolidated   |
|-----------------------------------------------------------|-------------------|----------------|----------------|----------------|
|                                                           |                   |                | 2022           | 2021           |
|                                                           |                   |                | $              | $              |
| Current liabilities                                       |                   |                |                |                |
| Lease liability                                           |                   |                | 212,781        | 295,410        |
| Non-current liabilities                                   |                   |                |                |                |
| Lease liability                                           |                   |                | 457,534        | 588,464        |
|                                                           |                   |                | 670,315        | 883,874        |
| Future minimum lease payments at 30 June were as follows: |                   |                |                |                |
|                                                           | Less than 1  year | 1 - 5 years    | > 5 years      | Total          |
|                                                           | $                 | $              | $              | $              |
| 2022                                                      |                   |                |                |                |
| Lease Payments                                            |                   |                |                |                |
|                                                           | 244,812           | 499,855        | -              | 744,667        |
| Finance Charges                                           | (32,031)          | (42,321)       | -              | (74,352)       |
|                                                           | 212,781           | 457,534        | -              | 670,315        |
| 2021                                                      |                   |                |                |                |
| Lease Payments                                            | 339,532           | 634,238        | 23,673         | 997,443        |
| Finance Charges                                           | (44,122)          | (69,274)       | (173)          | (113,569)      |
|                                                           | 295,410           | 564,964        | 23,500         | 883,874        |


For personal use only

---

# Page 39

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 18. Employee benefits


|                                          |                 | Consolidated   | Consolidated   | Consolidated   |
|------------------------------------------|-----------------|----------------|----------------|----------------|
|                                          |                 |                | 2022           | 2021           |
|                                          |                 |                | $              | $              |
| Current liabilities                      |                 |                |                |                |
| Annual leave                             |                 |                | 636,605        | 494,718        |
| Long service leave                       |                 |                | 296,968        | 252,829        |
|                                          |                 |                | 933,573        | 747,547        |
| Non-current liabilities                  |                 |                |                |                |
| Long service leave                       |                 |                | 56,389         | 59,341         |
|                                          |                 |                | 989,962        | 806,888        |
| Note 19. Issued capital                  |                 |                |                |                |
|                                          |                 | Consolidated   | Consolidated   |                |
|                                          | 2022            | 2021           | 2022           | 2021           |
|                                          | Shares          | Shares         | $              | $              |
| Ordinary shares - fully paid             | 1,375,700,602   | 1,375,700,602  | 39,992,575     | 39,992,575     |
| Details                                  | Date            | Shares         | Issue price    | $              |
| Balance                                  | 1 July 2020     | 1,368,660,602  |                | 39,851,775     |
| Shares issued on the exercise of options | 12 October 2020 | 7,040,000      | $0.020         | 140,800        |
| Balance                                  | 30 June 2021    | 1,375,700,602  |                | 39,992,575     |
| Balance                                  | 30 June 2022    | 1,375,700,602  |                | 39,992,575     |



## Ordinary shares

Ordinary shares entitle the holder to participate in any dividends declared and any proceeds attributable to shareholders should the Company be wound up in proportions that consider both the number of shares held and the extent to which those shares are paid up. The fully paid ordinary shares have no par value and the Company does not have a limited amount of authorised capital.

On a show of hands every member present at a meeting in person or by proxy shall have one vote and upon a poll each share shall have one vote.


## Share buy-back

There is no current on-market share buy-back.


## Capital risk management

The consolidated entity's objectives when managing capital is to safeguard its ability to continue as a going concern, so that it can provide returns for shareholders and benefits for other stakeholders and to maintain an optimum capital structure to reduce the cost of capital.

For personal use only

Capital is regarded as total equity, as recognised in the statement of financial position, plus net debt. Net debt is calculated as total borrowings less cash and cash equivalents.

In  order  to  maintain  or  adjust  the  capital  structure,  the  consolidated  entity  may  adjust  the  amount  of  dividends  paid  to shareholders, return capital to shareholders, issue new shares or sell assets to reduce debt.

---

# Page 40

# Rectifier Technologies Ltd


## Notes to the financial statements 30 June 2022


## Note 19. Issued capital (continued)

The consolidated entity would look to raise capital when an opportunity to invest in a business or company was seen as value-adding relative to the current Company's share price at the time of the investment. The consolidated entity is not actively pursuing additional investments in the short term as it continues to integrate and grow its existing businesses in order to maximise synergies.

The consolidated entity is subject to certain financing arrangements covenants and meeting these is given priority in all capital risk management decisions. There have been no events of default on the financing arrangements during the financial year.

The capital risk management policy remains unchanged during the current reporting period.


## Note 20. Reserves


|                              | Consolidated   | Consolidated   |
|------------------------------|----------------|----------------|
|                              | 2022           | 2021           |
|                              | $              | $              |
| Foreign currency reserve     | 3,264          | (163,175)      |
| Share-based payments reserve | 510,000        | 630,000        |
|                              | 513,264        | 466,825        |



## Foreign currency reserve

The reserve is used to recognise exchange differences arising from the translation of the financial statements of foreign operations to Australian dollars. It is also used to recognise gains and losses on hedges of the net investments in foreign operations.


## Share-based payments reserve

The reserve is used to recognise the value of options granted under Employee Share Option Plan ('ESOP').


## Movements in reserves


Movements in each class of reserve during the current and previous financial year are set out below:
|                                                  | Foreign  currency  reserve   | Share-based  payments  reserve   | Total     |
|--------------------------------------------------|------------------------------|----------------------------------|-----------|
| Consolidated                                     | $                            | $                                | $         |
| Balance at 1 July 2020                           | 41,828                       | 630,000                          | 671,828   |
| Foreign currency translation                     | (205,003)                    | -                                | (205,003) |
| Balance at 30 June 2021                          | (163,175)                    | 630,000                          | 466,825   |
| Foreign currency translation                     | 166,439                      | -                                | 166,439   |
| Lapsed options transferred to accumulated losses | -                            | (120,000)                        | (120,000) |
| Balance at 30 June 2022                          | 3,264                        | 510,000                          | 513,264   |


For personal use only

---

# Page 41

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 21. Dividends


## Dividends


Dividends paid during the financial year were as follows:
|                                                                                                                       | Consolidated   | Consolidated   |
|-----------------------------------------------------------------------------------------------------------------------|----------------|----------------|
|                                                                                                                       | 2022           | 2021           |
|                                                                                                                       | $              | $              |
| Final dividend paid during 30 June 2022 of nil cents (for the year ended 30 June 2021: 0.1  cents) per ordinary share | -              | 1,375,701      |


The dividends paid on 8 December 2020, totalling to $1,375,701, refers to the 30 June 2020 financial year. There are no dividends declared in relation to the 30 June 2022 and 30 June 2021 financial years.


## Franking credits


|                                                                                             | Consolidated   | Consolidated   |
|---------------------------------------------------------------------------------------------|----------------|----------------|
|                                                                                             | 2022           | 2021           |
|                                                                                             | $              | $              |
| Franking credits available for subsequent financial years based on a tax rate of 25% (2021: | -              | 939,520        |



The above amounts represent the balance of the franking account as at the end of the financial year, adjusted for:
- ● franking credits that will arise from the payment of the amount of the provision for income tax at the reporting date
- ● franking debits that will arise from the payment of dividends recognised as a liability at the reporting date
- ● franking credits that will arise from the receipt of dividends recognised as receivables at the reporting date



## Note 22. Financial instruments


## Financial risk management objectives

The Board has overall responsibility for the determination of the consolidated entity and the parent entity's risk management objectives and policies and, whilst retaining ultimate responsibility for them, it has delegated the authority for designing and operating processes that ensure the effective implementation of the objectives and policies to the consolidated entity and the parent entity's finance function. The Board receives monthly reports from the Chief Financial Officer through which it reviews the effectiveness of the processes put in place and the appropriateness of the objectives and policies it sets.

The overall objective of the Board is to set policies that seek to reduce risk as far as possible without unduly affecting the consolidated entity's competitiveness and flexibility.


## Market risk

Foreign currency risk

The consolidated entity undertakes certain transactions denominated in foreign currency and is exposed to foreign currency risk through foreign exchange rate fluctuations.

The only currency where receivables are not denominated in their functional currency is US dollars (USD). Cash balances in USD are kept at levels only sufficient to pay the amounts owing. Since the local sales in Malaysia are made by foreign operations  in  their  individual  functional  currencies,  there  is  no  direct  foreign  currency  risk  exposure  involved.  The consolidated entity's exposure to foreign currency risk is primarily its exposure to trade receivables denominated in USD.

25%) For personal use only

---

# Page 42

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 22. Financial instruments (continued)


The carrying amount of the consolidated entity's foreign currency denominated financial assets and financial liabilities at the reporting date were as follows:
|                     | Assets           | Assets                        | Liabilities   | Liabilities                   |
|---------------------|------------------|-------------------------------|---------------|-------------------------------|
| Consolidated        | 2022 $           | 2021 $                        | 2022 $        | 2021 $                        |
| US dollars          | 532,730          | 328,330                       | 651,586       |                               |
|                     |                  |                               |               | 177,173                       |
|                     | AUD strengthened | AUD strengthened              | AUD weakened  | AUD weakened                  |
| Consolidated - 2022 | % change         | Effect on  profit before  tax | % change      | Effect on  profit before  tax |
|                     | 10%              | 70,300                        | (10%)         | (85,923)                      |
|                     | 10%              | 85,985                        | (10%)         | (105,093)                     |
|                     |                  | 156,285                       |               | (191,016)                     |
|                     | AUD strengthened | AUD strengthened              | AUD weakened  | AUD weakened                  |
| Consolidated - 2021 | % change         | Effect on  profit before  tax | % change      | Effect on  profit before  tax |
| Assets              | 10%              | 39,702                        | (10%)         | (48,525)                      |
| Liabilities         | 10%              | 21,424                        | (10%)         | (26,185)                      |
|                     |                  | 61,126                        |               | (74,710)                      |


The consolidated entity is not exposed to any significant price risk.


## Interest rate risk

The consolidated entity's exposure to interest rate risk is limited to cash balances, as these are at a floating rate. Cash balances that are held at call for day to day activities are non-interest bearing.

An analysis of remaining contractual maturities is shown in 'liquidity and interest rate risk management' below.

Credit  risk  arises  principally  from  the  consolidated  entity's  trade  receivables.  It  is  the  risk  that  the  counterparty  fails  to discharge its obligation in respect of the instrument.

Prior to accepting new customers, a credit check is obtained from a reputable external source. Based on this information, credit limits and payment terms are established. Customers who subsequently fail to meet their credit terms are required to make purchases on a prepayment basis until creditworthiness can be re-established.

The nature of the consolidated entity's operations means that approximately 92% (2021: 92%) of its sales are made to 5 (2021: 5) key customers in Australia, Singapore and America. Whilst credit risk is mainly influenced by factors specific to these individual customers, the concentration of sales geographically is a contributory factor.

Assets Liabilities Price risk Credit risk For personal use only

---

# Page 43

# Rectifier Technologies Ltd


## Notes to the financial statements 30 June 2022


## Note 22. Financial instruments (continued)


The maximum exposure to credit risk for trade receivables at the end of reporting period by geographic region is as follows:
| Consolidated   | Consolidated   |
|----------------|----------------|
| 2022           | 2021           |
| $              | $              |
| 702,808        | 414,172        |
| 145,385        | 69,856         |
| 52,535         | 1,600          |
| (9,390)        | 29,007         |
| 891,338        | 514,635        |



Past due analysis of trade receivables by geographic region is as follows:
|                  | Australia   | Asia    | Europe   | USA      | Total   |
|------------------|-------------|---------|----------|----------|---------|
|                  | $           | $       | $        | $        | $       |
| 2022             |             |         |          |          |         |
| Not past due     | 667,174     | 145,385 | 52,578   | 3,092    | 868,229 |
| Past due 30 days | 9,900       | -       | -        | -        | 9,900   |
| Past due 60 days | 25,734      | -       | (43)     | (12,482) | 13,209  |
| Total            | 702,808     | 145,385 | 52,535   | (9,390)  | 891,338 |
| 2021             |             |         |          |          |         |
| Not past due     | 356,374     | 67,467  | 86       | 1,081    | 425,008 |
| Past due 30 days | 44,511      | -       | -        | 26,602   | 71,113  |
| Past due 60 days | 13,287      | 2,389   | 1,514    | 1,324    | 18,514  |
| Total            | 414,172     | 69,856  | 1,600    | 29,007   | 514,635 |



## Liquidity risk

Liquidity risk arises from the consolidated entity's management of working capital and the finance charges and principal repayments on its debt instruments. It is the risk that the consolidated entity will encounter difficulty in meeting its financial obligations as they fall due. The consolidated entity aims to have sufficient cash to allow it to meet its liabilities when they become due.

The Board receives cash flow projections monthly as well as information regarding cash balances.


## Remaining contractual maturities

The following tables detail the consolidated entity's remaining contractual maturity for its financial instrument liabilities. The tables have been drawn up based on the undiscounted cash flows of financial liabilities based on the earliest date on which the financial liabilities are required to be paid. The tables include both interest and principal cash flows disclosed as remaining contractual maturities and therefore these totals may differ from their carrying amount in the statement of financial position.


| Consolidated - 2022         | 6 months or  less $   | Between 6  and 12  months $   | Between 1  and 3 years $   | Over 3 years $   | Remaining  contractual  maturities $   |
|-----------------------------|-----------------------|-------------------------------|----------------------------|------------------|----------------------------------------|
| Non-derivatives             |                       |                               |                            |                  |                                        |
| Non-interest bearing        |                       |                               |                            |                  |                                        |
| Trade payables              | 4,463,965             | -                             | -                          | -                | 4,463,965                              |
| Other payables              | 1,085,956             | -                             | -                          | -                | 1,085,956                              |
| Interest-bearing - variable |                       |                               |                            |                  |                                        |
| Bank loans                  | 636,349               | 636,648                       | 2,285,531                  | 2,502,753        | 6,061,281                              |
| Lease liability             | 143,026               | 101,786                       | 329,272                    | 170,583          | 744,667                                |
| Total non-derivatives       | 6,329,296             | 738,434                       | 2,614,803                  | 2,673,336        | 12,355,869                             |


Australia Asia Europe USA For personal use only

---

# Page 44

## Rectifier Technologies Ltd Notes to the financial statements


# 30 June 2022


## Note 22. Financial instruments (continued)


|                             | 6 months or  less   | Between 6  and 12  months   | Between 1  and 3 years   | Over 3 years   | Remaining  contractual  maturities   |
|-----------------------------|---------------------|-----------------------------|--------------------------|----------------|--------------------------------------|
| Consolidated - 2021         | $                   | $                           | $                        | $              | $                                    |
| Non-derivatives             |                     |                             |                          |                |                                      |
| Non-interest bearing        |                     |                             |                          |                |                                      |
| Trade payables              | 2,134,083           | -                           | -                        | -              | 2,134,083                            |
| Other payables              | 515,895             | -                           | -                        | -              | 515,895                              |
| Interest-bearing - variable |                     |                             |                          |                |                                      |
| Bank loans                  | 126,901             | 109,283                     | 437,132                  | 2,606,858      | 3,280,174                            |
| Lease liability             | 178,217             | 161,315                     | 350,158                  | 307,753        | 997,443                              |
| Total non-derivatives       | 2,955,096           | 270,598                     | 787,290                  | 2,914,611      | 6,927,595                            |


The cash flows in the maturity analysis above are not expected to occur significantly earlier than contractually disclosed above.


## Fair value of financial instruments

Unless otherwise stated, the carrying amounts of financial instruments reflect their fair value.


## Note 23. Remuneration of auditors


During the financial year the following fees were paid or payable for services provided by Grant Thornton, the auditor of the Company:
|                                              | Consolidated   | Consolidated   |
|----------------------------------------------|----------------|----------------|
|                                              | 2022           | 2021           |
|                                              | $              | $              |
| Audit services - Grant Thornton              |                |                |
| Audit and review of the financial statements | 79,131         | 79,883         |



## Note 24. Contingent liabilities

The consolidated entity had no contingent liabilities as at 30 June 2022 and 30 June 2021.


## Note 25. Commitments


|                                                                             | Consolidated   | Consolidated   |
|-----------------------------------------------------------------------------|----------------|----------------|
|                                                                             | 2022           | 2021           |
|                                                                             | $              | $              |
| Committed at the reporting date but not recognised as liabilities, payable: |                |                |
| Inventories                                                                 | 10,903,918     | 1,898,436      |
| Property, plant and equipment                                               | 97,953         | 155,570        |
| Research and development                                                    | -              | 158,835        |


For personal use only

---

# Page 45

# Rectifier Technologies Ltd


## Notes to the financial statements 30 June 2022


## Note 26. Key management personnel disclosures


## Compensation


The aggregate compensation made to directors and other members of key management personnel of the consolidated entity is set out below:
|                              | Consolidated   | Consolidated   |
|------------------------------|----------------|----------------|
|                              | 2022           | 2021           |
|                              | $              | $              |
| Short-term employee benefits | 1,235,995      | 1,162,928      |
| Post-employment benefits     | 115,829        | 109,196        |
| Long-term benefits           | 11,951         | 9,163          |
|                              | 1,363,775      | 1,281,287      |



## Note 27. Related party transactions


## Parent entity

Rectifier Technologies Ltd is the parent entity.


## Subsidiaries

Interests in subsidiaries are set out in note 28.


## Key management personnel

Disclosures  relating  to  key  management  personnel  are  set  out  in  note  26  and  the  remuneration  report  included  in  the directors' report.


## Transactions with related parties

Transactions between related parties are on normal commercial terms and conditions no more favourable to other parties unless otherwise stated. There is no requirement for transactions and balances between the entities within the consolidated Group to be disclosed.


## Note 28. Interests in subsidiaries

The consolidated financial statements incorporate the assets, liabilities and results of the following subsidiaries in accordance with the accounting policy described in note 2:

Protran Technologies Pty Ltd Rectifier Technologies Pacific Pty Ltd Rectifier Technologies Singapore Pte Ltd ICERT Inc Rectifier Technologies (M) Sdn Bhd ICERT (HK) Co. Ltd


|                               | Ownership interest   | Ownership interest   |
|-------------------------------|----------------------|----------------------|
| Principal place of business / | 2022                 | 2021                 |
| Country of incorporation      | %                    | %                    |
| Australia                     | 100%                 | 100%                 |
| Australia                     | 100%                 | 100%                 |
| Singapore                     | 100%                 | 100%                 |
| USA                           | 100%                 | 100%                 |
| Malaysia                      | 100%                 | 100%                 |
| Hong Kong                     | 100%                 | 100%                 |


Name For personal use only

---

# Page 46

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 29. Earnings per share


|                                                                                              | Consolidated   | Consolidated   |
|----------------------------------------------------------------------------------------------|----------------|----------------|
|                                                                                              | 2022           | 2021           |
|                                                                                              | $              | $              |
| Profit after income tax attributable to the owners of Rectifier Technologies Ltd             | 491,955        | 540,379        |
|                                                                                              | Number         | Number         |
| The weighted average number of ordinary shares used in calculating basic earnings per  share | 1,375,700,602  | 1,375,700,602  |
| Adjustments for calculation of diluted earnings per share: Options over ordinary shares      | 46,840,000     | 54,840,000     |
| The weighted average number of ordinary shares used in calculating diluted earnings per      | 1,422,540,602  | 1,430,540,602  |
|                                                                                              | Cents          | Cents          |
| Basic earnings per share                                                                     | 0.04           | 0.04           |
| Diluted earnings per share                                                                   | 0.03           | 0.04           |



## Note 30. Reconciliation of profit after income tax to net cash from/(used in) operating activities


|                                                    | Consolidated   | Consolidated   |
|----------------------------------------------------|----------------|----------------|
|                                                    | 2022 $         | 2021 $         |
| Profit after income tax expense for the year       | 491,955        | 540,379        |
| Adjustments for:                                   |                |                |
| Depreciation and amortisation                      | 607,239        | 554,839        |
| Provision for stock obsolescence                   | 148,622        | (60,182)       |
| Unrealised currency (gain)/loss                    | (86,192)       | 179,255        |
| Net loss/(gain) on sale/acquisition of assets      | (34,956)       | (19)           |
| Capitalised interest                               | 87,200         | 14,772         |
| Change in operating assets and liabilities:        |                |                |
| Decrease/(increase) in trade and other receivables | (1,441,878)    | 1,238,435      |
| Decrease/(increase) in inventories                 | (3,861,912)    | 551,026        |
| Increase/(decrease) in net deferred tax assets     | 35,949         | 40,902         |
| Increase/(decrease) in trade and other payables    | 2,746,773      | (1,207,650)    |
| Increase/(decrease) in provision for income tax    | 404,843        | (390,722)      |
| Increase in employee benefits                      | 176,357        | 136,424        |
| Net cash from/(used in) operating activities       | (726,000)      | 1,597,459      |


share For personal use only

---

# Page 47

## Rectifier Technologies Ltd


## Notes to the financial statements


# 30 June 2022


## Note 31. Changes in liabilities arising from financing activities


| Consolidated                                 | Bank loans $   | Lease  liabilities $   | Total $   |
|----------------------------------------------|----------------|------------------------|-----------|
| Balance at 1 July 2020                       | 2,700,859      | 1,190,842              | 3,891,701 |
| Net cash used in financing activities        | (34,670)       | (387,290)              | (421,960) |
| Finance costs                                | 86,269         | 62,825                 | 149,094   |
| Other changes                                | (158,358)      | 17,497                 | (140,861) |
| Balance at 30 June 2021                      | 2,594,100      | 883,874                | 3,477,974 |
| Net cash from/(used in) financing activities | 2,505,974      | (365,513)              | 2,140,461 |
| Finance costs                                | 104,930        | 48,195                 | 153,125   |
| Other changes                                | 68,984         | 103,759                | 172,743   |
| Balance at 30 June 2022                      | 5,273,988      | 670,315                | 5,944,303 |



## Note 32. Share-based payments

A share option plan has been established by the consolidated entity and approved by shareholders at a general meeting, whereby the consolidated entity may, at the discretion of the Board, grant options over ordinary shares in the Company to certain key management personnel of the consolidated entity. The options are issued for nil consideration and are granted in accordance with performance guidelines established by the Board.

On 22 July 2019, the Company granted 42,000,000 share options of its common stock to employees under its Employee Share Option Plan (ESOP) at an exercise price of $0.07. Options under this plan vest immediately allowing the holder to purchase one ordinary share per option, exercisable in multiples of 100,000. The maximum term of the options granted under the ESOP ends on 13 September 2022. The weighted average fair value of options granted has been calculated as $0.015 per option. All granted employee options were immediately recognised as an expense in the statement of profit or loss with a corresponding credit to share option reserve for the value of $630,000.

Set out below are summaries of options granted under the plan:

2022


| Grant date      | Expiry date   | Exercise  price   | Balance at  the start of  the year   | Granted   | Exercised   | Expired/  forfeited/  other   | Balance at  the end of  the year   |
|-----------------|---------------|-------------------|--------------------------------------|-----------|-------------|-------------------------------|------------------------------------|
| 22/07/2019      | 13/09/2022    | $0.070            | 42,000,000                           | -         | -           | (8,000,000)                   | 34,000,000                         |
|                 |               |                   | 42,000,000                           | -         | -           | (8,000,000)                   | 34,000,000                         |
| 2021 Grant date | Expiry date   | Exercise  price   | Balance at  the start of  the year   | Granted   | Exercised   | Expired/  forfeited/  other   | Balance at  the end of  the year   |
| 22/07/2019      | 13/09/2022    | $0.070            | 42,000,000                           | -         | -           | -                             | 42,000,000                         |
|                 |               |                   | 42,000,000                           | -         | -           | -                             | 42,000,000                         |


The weighted average share price during the financial year was $0.015 (2021: $0.015).

For personal use only

The weighted average remaining contractual life of options outstanding at the end of the financial year was 0.21 years (2021: 0.57 years).

---

# Page 48

# Rectifier Technologies Ltd Notes to the financial statements 30 June 2022


## Note 33. Parent entity information

Set out below is the supplementary information about the parent entity.

Statement of profit or loss and other comprehensive income


|                                 | Parent       | Parent       |
|---------------------------------|--------------|--------------|
|                                 | 2022 $       | 2021 $       |
| Profit after income tax         | 229,496      | 573,048      |
| Total comprehensive income      | 229,496      | 573,048      |
| Statement of financial position |              |              |
|                                 | Parent       | Parent       |
|                                 | 2022         | 2021         |
|                                 | $            | $            |
| Total current assets            | 2,287,673    | 1,993,700    |
| Total assets                    | 3,661,150    | 2,090,405    |
| Total current liabilities       | 2,292,003    | 318,016      |
| Total liabilities               | 1,669,157    | 327,908      |
| Issued capital                  | 39,992,575   | 39,992,575   |
| Foreign currency reserve        | 50,647       | 50,647       |
| Share-based payments reserve    | 510,000      | 630,000      |
| Accumulated losses              | (38,561,229) | (38,910,725) |
| Total equity                    | 1,991,993    | 1,762,497    |



- a. Guarantees entered into by the parent entity in relation to the debts of its subsidiaries
- The parent entity had no guarantees in relation to the debts of its subsidiaries as at 30 June 2022 and 30 June 2021.



## b. Contingent liabilities

The parent entity had no contingent liabilities as at 30 June 2022 and 30 June 2021.


## c. Capital commitments - Property, plant and equipment


- The parent entity had no capital commitments for property, plant and equipment as at 30 June 2022 and 30 June 2021.



## d. Significant accounting policies


The accounting policies of the parent entity are consistent with those of the consolidated entity, as disclosed in note 2, except for the following:
- ● Investments in subsidiaries are accounted for at cost, less any impairment, in the parent entity.
- ● Dividends received from subsidiaries are recognised as other income by the parent entity and its receipt may be an indicator of an impairment of the investment.


Equity For personal use only


## Note 34. Events after the reporting period

On 2 September 2022, the loan from ANZ with the carrying amount of the loan AUD 2,760,321 as of 30 June 2022 was discharged and fully paid.

On 2 September 2022, a loan from WBC of $5,000,000 was drawn. The term of the loan is 5 years and the indicative loan interest is 4.13% p.a. (variable rate). The repayment arrangement is principal and interest up to 28 July 2027.

---

# Page 49

# Rectifier Technologies Ltd Directors' declaration 30 June 2022


In the directors' opinion:
- ● the attached financial statements and notes comply with the Corporations Act 2001, the Accounting Standards, the Corporations Regulations 2001 and other mandatory professional reporting requirements;
- ● the attached financial statements and notes comply with International Financial Reporting Standards as issued by the International Accounting Standards Board as described in note 2 to the financial statements;
- the attached financial statements and notes give a true and fair view of the consolidated entity's financial position as at 30 June 2022 and of its performance for the financial year ended on that date; and
- there are reasonable grounds to believe that the Company will be able to pay its debts as and when they become due and payable.
- The directors have been given the declarations required by section 295A of the Corporations Act 2001.


Signed in accordance with a resolution of directors made pursuant to section 295(5)(a) of the Corporations Act 2001.

On behalf of the directors

___________________________

30 September 2022 Melbourne

● ● Director For personal use only

---

# Page 50

# Independent Auditor's Report


## To the Members of Rectifier Technologies Ltd


## Report on the audit of the financial report


## Opinion

We have audited the financial report of Rectifier Technologies Ltd (the Company) and its subsidiaries (the Group), which comprises the consolidated statement of financial position as at 30 June 2022, the consolidated statement of profit or loss and other comprehensive income, consolidated statement of changes in equity and consolidated statement of cash flows for the year then ended, and notes to the consolidated financial statements, including a summary of significant accounting policies, and the Directors' declaration.


In our opinion, the accompanying financial report of the Group is in accordance with the Corporations Act 2001 , including:
- a giving a true and fair view of the Group's financial position as at 30 June 2022 and of its performance for the year ended on that date; and
- b complying with Australian Accounting Standards and the Corporations Regulations 2001 .



## Basis for opinion

We conducted our audit in accordance with Australian Auditing Standards. Our responsibilities under those standards are further described in the Auditor's Responsibilities for the Audit of the Financial Report section of our report. We are independent of the Group in accordance with the auditor independence requirements of the Corporations Act 2001 and the ethical requirements of the Accounting Professional and Ethical Standards Board's APES 110 Code of Ethics for Professional Accountants (including Independence Standards) (the Code) that are relevant to our audit of the financial report in Australia. We have also fulfilled our other ethical responsibilities in accordance with the Code.

We believe that the audit evidence we have obtained is sufficient and appropriate to provide a basis for our opinion.

www.grantthornton.com.au

ACN-130 913 594

Grant Thornton Audit Pty Ltd ACN 130 913 594 a subsidiary or related entity of Grant Thornton Australia Limited ABN 41 127 556 389 ACN 127 556 389. 'Grant Thornton' refers to the brand under which the Grant Thornton member firms provide assurance, tax and advisory services to their clients and/or refers to one or more member firms, as the context requires. Grant Thornton Australia Limited is a member firm of Grant Thornton International Ltd (GTIL). GTIL and the member firms are not a worldwide partnership. GTIL and each member firm is a separate legal entity. Services are delivered by the member firms. GTIL does not provide services to clients. GTIL and its member firms are not agents of, and do not obligate one another and are not liable for one another's acts or omissions. In the Australian context only, the use of the term 'Grant Thornton' may refer to Grant Thornton Australia Limited ABN 41 127 556 389 ACN 127 556 389 and its Australian subsidiaries and related entities. Liability limited by a scheme approved under Professional Standards Legislation.

w


## Grant Thornton Audit Pty Ltd

Level 22 Tower 5 Collins Square 727 Collins Street Melbourne VIC 3008 GPO Box 4736 Melbourne VIC 3001

T +61 3 8320 2222

---

# Page 51

# Key audit matters

Key audit matters are those matters that, in our professional judgement, were of most significance in our audit of the financial report of the current period. These matters were addressed in the context of our audit of the financial report as a whole, and in forming our opinion thereon, and we do not provide a separate opinion on these matters.


| Key audit matter                                                                                                                                                                                                                                                                                                                                                                            | How our audit addressed the key audit matter                                                                                                                                                                                                                                                                                                                                                |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Recognition of R&D tax incentive  (Note 6 and Note 10)                                                                                                                                                                                                                                                                                                                                      |                                                                                                                                                                                                                                                                                                                                                                                             |
| The Group receives a corporate tax rate plus 18.5%  (43.5%) refundable tax offset of eligible expenditure  under the research and development ('R&D') scheme  if its turnover is less than $20 million per annum,  provided it is not controlled by income tax-exempt                                                                                                                       | Our procedures included, amongst others:  · Obtaining and documenting through discussions with  management an understanding of the process to estimate the claim;                                                                                                                                                                                                                           |
| A registration of R&D activities is filed with AusIndustry                                                                                                                                                                                                                                                                                                                                  | objectivity of management's expert;                                                                                                                                                                                                                                                                                                                                                         |
| in the following financial year, and based on this filing,  the group receives the incentive in cash.                                                                                                                                                                                                                                                                                       | · Reviewing and testing the R&D estimate by: - reviewing the methodology used by                                                                                                                                                                                                                                                                                                            |
| detailed review of the Group's total R&D expenditure to  determine the potential claim under the R&D tax  incentive legislation. As at 30 June 2022, a receivable  totalling $1,035,645 has been recorded. This  represents the estimated claim for the period 1 July  2021 to 30 June 2022.  This is a key audit matter due to the size of the  receivable and the degree of judgement and | R&D tax offset rules; - performing testing on a sample of R&D expenses to supporting documents to assess eligibility and accuracy of the amounts recorded in the general ledger; - considering the nature of expenses against the eligibility criteria of the R&D tax incentive scheme  to assess whether the expense included in the estimate are likely to meet the eligibility criteria. |
| interpretation of the R&D tax legislation required by  management to assess the eligibility of the R&D  expenditure under the scheme.                                                                                                                                                                                                                                                       | · Comparing the eligible expenditure used in the receivable calculation to expenditure recorded in the general ledger;                                                                                                                                                                                                                                                                      |
|                                                                                                                                                                                                                                                                                                                                                                                             | · Considering the entity's history of successful claims;                                                                                                                                                                                                                                                                                                                                    |
|                                                                                                                                                                                                                                                                                                                                                                                             | · Inspecting copies of relevant correspondence with AusIndustry and the Australian Taxation Office related to the claims; and                                                                                                                                                                                                                                                               |

---

# Page 52

| Inventory valuation (Note 11)                                                                                                                                                                                                                                                                                              |                                                                                                                                                                                      |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| As at 30 June 2022, the Group holds inventory with a  carrying value of $5,877,879. The Group is required to  carry their inventory at the lower of cost or net  realisable value, in accordance with AASB 102                                                                                                             | Our procedures included, amongst others:  · Understanding and documenting management's process of calculating the inventory provision and evaluating the Group's compliance with the |
| Determining the value of inventory requires significant  judgement. Specifically, estimating inventory provisions  involves significant management judgement, including  predictions about market conditions, future sales, and                                                                                            | · Testing a sample of inventory items to assess the cost basis and net realisable value of inventories; · Analysing slow-moving inventory and evaluating                             |
| This is a key audit matter due to the materiality of the  inventory balance and the level of management  judgement required to determine the inventory value.                                                                                                                                                              | · Considering additional factors that may indicate inventory items require an adjustment to their carrying amount, including discontinued lines;  and                                |
|                                                                                                                                                                                                                                                                                                                            | · Assessing the adequacy of the related disclosures in                                                                                                                               |
| Revenue recognition (Note 5)                                                                                                                                                                                                                                                                                               |                                                                                                                                                                                      |
| Revenue recorded from the sale of products and  services to customers amounted to $14,761,523 for the  year ended 30 June 2022.  The Group enters into transactions for the sale of                                                                                                                                        | Our procedures included, amongst others:  · Reviewing revenue recognition policies for appropriateness in accordance with AASB 15 Revenue from Contracts with Customers ;            |
| contract is based on their relative stand-alone selling  price. Revenue is recognised at a point in time when  the Group satisfies the performance obligations, which  is generally at the point of delivery.  This is a key audit matter given the judgement applied  to determine the appropriate recognition of revenue | year and assessing whether revenue has been recognised in accordance with AASB 15, including: - Reviewing the relevant contracts with customers;                                     |
| and the material nature of revenue to the Group's  overall performance.                                                                                                                                                                                                                                                    | - Assessing management's determination of performance obligations within contracts and the allocation of the transaction price to those obligations;                                 |
|                                                                                                                                                                                                                                                                                                                            | · Evaluating sales transactions around reporting date to assess whether revenue is recognised in the correct period;                                                                 |
|                                                                                                                                                                                                                                                                                                                            | · Performing non-substantive analytical procedures to assess revenue recognised against known business factors and investigating variances to our                                    |
|                                                                                                                                                                                                                                                                                                                            | · Assessing the adequacy of related disclosures in the financial statements.                                                                                                         |

---

# Page 53

# Information other than the financial report and auditor's report thereon

The Directors are responsible for the other information. The other information comprises the information included in the Group's annual report for the year ended 30 June 2022, but does not include the financial report and our auditor's report thereon.

Our opinion on the financial report does not cover the other information and we do not express any form of assurance conclusion thereon.

In connection with our audit of the financial report, our responsibility is to read the other information and, in doing so, consider whether the other information is materially inconsistent with the financial report or our knowledge obtained in the audit or otherwise appears to be materially misstated.

If, based on the work we have performed, we conclude that there is a material misstatement of this other information, we are required to report that fact. We have nothing to report in this regard.


## Responsibilities of the Directors for the financial report

The Directors of the Company are responsible for the preparation of the financial report that gives a true and fair view in accordance with Australian Accounting Standards and the Corporations Act 2001 and for such internal control as the Directors determine is necessary to enable the preparation of the financial report that gives a true and fair view and is free from material misstatement, whether due to fraud or error.

In preparing the financial report, the Directors are responsible for assessing the Group's ability to continue as a going concern, disclosing, as applicable, matters related to going concern and using the going concern basis of accounting unless the Directors either intend to liquidate the Group or to cease operations, or have no realistic alternative but to do so.


## Auditor's responsibilities for the audit of the financial report

Our objectives are to obtain reasonable assurance about whether the financial report as a whole is free from material misstatement, whether due to fraud or error, and to issue an auditor's report that includes our opinion. Reasonable assurance is a high level of assurance, but is not a guarantee that an audit conducted in accordance with the Australian Auditing Standards will always detect a material misstatement when it exists. Misstatements can arise from fraud or error and are considered material if, individually or in the aggregate, they could reasonably be expected to influence the economic decisions of users taken on the basis of this financial report.

A further description of our responsibilities for the audit of the financial report is located at the Auditing and Assurance Standards Board website at: https://www.auasb.gov.au/auditors_responsibilites/ar1_2020.pdf. This description forms part of our auditor's report.


## Report on the remuneration report


## Opinion on the remuneration report

We have audited the Remuneration Report included in pages 7 to 12 of the Directors' report for the year ended 30 June 2022.

In our opinion, the Remuneration Report of Rectifier Technologies Ltd, for the year ended 30 June 2022 complies with section 300A of the Corporations Act 2001 .

---

# Page 54

# For personal use only


## Responsibilities

The Directors of the Company are responsible for the preparation and presentation of the Remuneration Report in accordance with section 300A of the Corporations Act 2001 . Our responsibility is to express an opinion on the Remuneration Report, based on our audit conducted in accordance with Australian Auditing Standards.

Grant Thornton Audit Pty Ltd Chartered Accountants

S C Trivett

Partner - Audit & Assurance

Melbourne, 30 September 2022

---

# Page 55

# Rectifier Technologies Ltd Shareholder information 30 June 2022

The shareholder information set out below was applicable as at 6 September 2022.


## Distribution of equitable securities


Analysis of number of equitable security holders by size of holding:
|                                       | Ordinary shares   | Ordinary shares          | Ordinary shares   |
|---------------------------------------|-------------------|--------------------------|-------------------|
|                                       | Number of holders | % of total shares issued | Number of units   |
| 1 to 1,000                            | 43                | -                        | 14,955            |
| 1,001 to 5,000                        | 29                | 0.01                     | 86,296            |
| 5,001 to 10,000                       | 260               | 0.17                     | 2,291,486         |
| 10,001 to 100,000                     | 2,073             | 5.65                     | 77,866,602        |
| 100,001 and over                      | 681               | 94.17                    | 1,295,441,263     |
|                                       | 3,086             | 100.00                   | 1,375,700,602     |
| Holding less than a marketable parcel | 414               | 0.20                     | 3,292,552         |


Substantial holders


Substantial holders in the Company are set out below:
|                                     | Ordinary shares   | Ordinary shares           |
|-------------------------------------|-------------------|---------------------------|
|                                     | Number held       | % of total  shares issued |
| PUDU INVESTMENT (AUSTRALIA) PTY LTD | 224,643,616       | 16.33                     |
| YUNG SHING                          | 150,000,000       | 10.90                     |
| YANBIN WANG                         | 70,000,000        | 5.09                      |
| Mr MALCOLM ALISTAIR DUNCAN          | 69,187,950        | 5.03                      |
| Mr LEI LI                           | 68,460,000        | 4.98                      |


For personal use only

---

# Page 56

# Rectifier Technologies Ltd Shareholder information 30 June 2022


## Equity security holders


## Twenty largest quoted equity security holders


The names of the twenty largest security holders of quoted equity securities are listed below:
|                                                      | Ordinary shares   | Ordinary shares           |
|------------------------------------------------------|-------------------|---------------------------|
|                                                      | Number held       | % of total  shares issued |
| PUDU INVESTMENT (AUSTRALIA) PTY LTD                  | 224,643,616       | 16.33                     |
| YUNG SHING                                           | 150,000,000       | 10.90                     |
| YANBIN WANG                                          | 70,000,000        | 5.09                      |
| Mr MALCOLM ALISTAIR DUNCAN                           | 69,187,950        | 5.03                      |
| MR LEI LI                                            | 68,460,000        | 4.98                      |
| MR SONGWU LU                                         | 66,841,260        | 4.86                      |
| MS ZHU FURONG                                        | 50,000,000        | 3.63                      |
| MR WEIGUO XIE                                        | 40,747,642        | 2.96                      |
| MR MAKRAM HANNA + MRS RITA HANNA                     | 38,637,542        | 2.81                      |
| V AND G SUPER PTY LTD                                | 37,040,000        | 2.69                      |
| BOND STREET CUSTODIANS LIMITED                       | 25,999,605        | 1.89                      |
| BNP PARIBAS NOMINEES PTY LTD SIX SIS LTD             | 23,428,478        | 1.70                      |
| MR NICHOLAS SENG TET YEOH                            | 20,500,000        | 1.49                      |
| MR NIGEL MACHIN                                      | 20,000,000        | 1.45                      |
| BNP PARIBAS NOMS PTY LTD                             | 19,773,056        | 1.44                      |
| AUSTRALIAN EXPORTS & INDUSTRIALISATION SUPER PTY LTD | 14,000,000        | 1.02                      |
| TOPAZ INVESTMENTS PTE LTD                            | 13,837,650        | 1.01                      |
| GENISTA COURT PTY LTD                                | 11,848,272        | 0.86                      |
| MR MAKRAM HANNA                                      | 11,134,134        | 0.81                      |
| MR RAYMOND ROCKMAN + MR ANTHONY ROCKMAN              | 9,677,106         | 0.70                      |
|                                                      | 985,756,311       | 71.65                     |


Unquoted equity securities


|                                     | Number on issue   |   Number of holders |
|-------------------------------------|-------------------|---------------------|
| Options over ordinary shares issued | 46,840,000        |                  30 |



## Voting rights

The voting rights attached to ordinary shares are set out below:


## Ordinary shares


- On a show of hands every member present at a meeting in person or by proxy shall have one vote and upon a poll each share shall have one vote.


There are no other classes of equity securities.


## On market buy-back

There is no current on market buy back

For personal use only