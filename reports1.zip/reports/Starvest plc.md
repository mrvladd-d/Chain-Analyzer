

---

# Page 1

Starvest plc


# Starvest plc

Report and Financial Statements

For the Year Ended 30 September 2022

---

# Page 2

Starvest plc


# CONTENTS


|                                       |   Page |
|---------------------------------------|--------|
| Officers and professional advisers    |      1 |
| Chairman's statement                  |      2 |
| Investing policy statement            |      3 |
| Review of trading portfolio           |      5 |
| Board of directors                    |     12 |
| Strategic report                      |     13 |
| Directors' report                     |     15 |
| Directors' responsibilities statement |     18 |
| Corporate governance statement        |     19 |
| Audit Committee report                |     26 |
| Remuneration Committee report         |     28 |
| Independent auditor's report          |     30 |
| Statement of comprehensive income     |     34 |
| Statement of financial position       |     35 |
| Statement of changes in equity        |     36 |
| Statement of cash flows               |     37 |
| Notes to the financial statements     |     38 |
| Notice of AGM                         |     48 |

---

# Page 3

# Starvest plc


## 2022 Annual Report and Financial Statements


## Officers and professional advisers

Clydesdale Bank/Virgin Money Banking Hall                                             Threadneedle Street 30 St.Vincent Place Glasgow G1 2HL Lloyds Bank London EC2R 5AU

Directors

Callum N Baxter - Non-Executive Chairman

Mark J Badros - Chief Executive Officer

Gemma Cryan - Executive Director

Secretary and registered office

Stephen Ronaldson Salisbury House London Wall London EC2M 5PS

Business address

33 St. James's Square London SW1Y 4JS info@starvest.co.uk

Tel: 02077 696 876

Auditor

PKF Littlejohn LLP 15 Westferry Circus Canary Wharf London E14 4HD

Registered number

03981468

Solicitors

Druces LLP Salisbury House London Wall London EC2M 5PS

Nominated adviser

Grant Thornton UK LLP 30 Finsbury Square

London EC2A 1AG

Banker

Broker

SI Capital Limited

46 Bridge Street Godalming Surrey GU7 1HL

Registrars

Share Registrars Limited Molex House Millennium Centre Crosby Way Farnham Surrey GU9 7XX Tel: 01252 821 390

Listing

AIM Market of the London Stock Exchange (AIM) Ticker: SVE

Website

www.starvest.co.uk

---

# Page 4

# Starvest plc


## 2022 Annual Report and Financial Statements


## Chairman's Statement

I am pleased to present my annual statement to Shareholders for the year ended 30 September 2022 and the twenty-second since the Company was formed in 2000.


## Results for the year

The continuing impact of the global pandemic and the ongoing war in Eastern Europe and its effect on energy supplies have dominated the financial news this year for Starvest and its portfolio companies. Starvest's strategy to steer its portfolio toward precious metal investments in recent years has enabled the Company to position itself attractively  for  the  current  environment.  Although improved investor sentiment  boosted certain  precious metal stocks and those of certain other natural resource companies, gold prices declined 5.5% for the year ended 30 September 2022. The post-pandemic global economy and interest rate hikes, particularly in the US, have kept prices flat recently but we continue to believe that there is a solid foundation for precious metals going forward.

Our investment portfolio decreased approximately 56% in the year to 30 September 2022 to £6 million. However, the discount to net asset value narrowed by 5 percentage points, from 34% to 29% as at 30 September 2022, which is a significant improvement for shareholders.

Greatland  Gold  plc  (AIM:GGP)  remains  our  primary  investment,  with  its  Havieron  gold-copper  discovery  in Australia. Havieron's initial inferred resource increased from 4.2M oz gold equivalent* to 6.5M oz gold equivalent** during  the  year.  The  company  secured  funding  through  to  production,  expanded  its  board,  and  delivered operational  and  financial  improvements.  While  the  share  price  has  decreased  over  the  last  year,  this  is  not uncommon for a company in pre-production and we continue to see potential gains here.

Ariana Resources continues to expand its exploration and development footprint in Europe. As the Kiziltepe mine has continued to meet production expectations, Ariana has focused on other projects in Turkey, such as Tavsan, which is scheduled for first production in H2 2023. The alliance with Newmont, via its West Tethyan holding, allows considerable scope to explore southeastern Europe over the next five years, and the recently acquired Kosovo licence shows an interesting start to this US$2.5m agreement. Together with the Asgard Metals Fund, Ariana's exploration and development projects have expanded considerably since the company's founding twenty years ago.

Cora Gold continued to de-risk its Sanankoro project as it completed further drilling and increased its mineral resource estimate by 14% while completing a feasibility study. After year-end the company announced that it had received the Environmental Permit required for the project, a significant step forward.

We believe  that  the  long-term  outlook  for  gold  prices  remains  favourable  and  we  remain  committed  to  our strategy.


- * GGP RNS dated 10 December 2020    ** GGP RNS dated 3 March 2022



## Investing policy

The  Company's  investing  policy  is  set  forth  on  page  3  of  this  report  and  made  available  on  our  website, www.starvest.co.uk.


## Trading portfolio valuation

A brief review of the major portfolio companies follows from page 6. Other investee companies are listed on the websites from which further information may be obtained.


## Shareholder information

The Company's shares are traded on AIM.

Announcements made to the London Stock Exchange are available from the Company's website, www.starvest.co.uk, where historical reports and announcements are also available.


## Callum N Baxter

Chairman

07 February 2023

---

# Page 5

# Starvest plc


## 2022 Annual Report and Financial Statements


## Investing policy statement


## About us

The previous Board commenced to manage the Company as an investment company in January 2002, largely investing in the natural resources sector. Following the appointment of Callum Baxter as Chairman in 2015, the Board continued to focus the Company's investment strategy on the natural resources sector.

Collectively, the current Board has significant experience investing in small-capitalisation new issues and pre-IPO opportunities in the natural resources and mineral exploration sectors.


## Company objective

The Company was established as a source of early-stage finance to fledgling businesses to maximise the capital value  of  the  Company  and  to  generate  benefits  for  Shareholders  in  the  form  of  capital  growth  and  modest dividends.


## Investing strategy

Natural resources: Whilst the Company's investment mandate is not exclusively limited to natural resources, the Board sees this sector as having considerable growth potential in the medium term. Historically, investments were generally made immediately prior to an initial public offering on AIM or AQSE as well as in the aftermarket.  As the nature of the public equity markets has changed since 2008, it is more likely that the future investment portfolio will  include  companies  that  have  completed  an  IPO  but  remain  in  the  early  stages  of  identifying  or,  with  the appropriate financial backing, developing a commercial resource.

Direct Projects: The Company's strategy is to invest predominantly through ownership of equity stakes in target companies. However, the Company believes there may be opportunities to take direct interests in mining projects and subsequently to acquire equity positions in target companies on favourable terms in exchange for these direct project interests. Those companies would therefore become Starvest investee companies. The projects will be operated by the investee company; Starvest does not intend to manage any projects. The addition of the Direct Project  strategy  to  the  Company's  Investing  Policy  was  approved  by  shareholders  at  the  Company's  annual general meeting held 1 December 2017.

Investment size: Initial investments are usually not greater than £100,000. Target companies invariably have an ongoing need for additional funding to continue exploration and development. Therefore, after appropriate due diligence, the Company may provide further funding support and make later market purchases, so that the total investment may exceed £100,000.

High risk: The business is inherently high risk and cyclical, dependent upon fluctuations in world economic activity which affects the demand for minerals. However, the Company affords investors the opportunity to participate in diverse  early-stage  ventures,  which  the  Board  believes  will  offer  the  potential  for  significant  returns  for  the foreseeable future.

Lack of liquidity: Shares of investee companies typically trade in small volumes, even if they are quoted on AIM, AQSE, ASX, or TSX-V. Therefore, during the early phase following an investment, it is rarely possible to liquidate a position at the quoted market price so investors must remain patient until the investee company develops and ultimately attracts greater market interest. If and when an exploration company finds a large exploitable resource, it typically presents greater liquidity to patient investors as an acquisition target by a third party or as a much larger and more actively traded independent entity.

Success rate: Of the multiple investments held at any one time, it is expected that no more than five will prove to be 'winners'; from half of the remainder we may expect to see modest share price improvements. Overall, we expect that over time portfolio returns will be acceptable if not substantial. Accordingly, the Board is unable to give any estimate of the magnitude or timing of returns.

Profit  distribution: When  profits  have  been  realised,  and  adequate  cash  is  available,  the  Board  intends  to distribute up to half the profits realised.

---

# Page 6

# Starvest plc


## 2022 Annual Report and Financial Statements


## Investing policy statement, continued


## Investing strategy, continued

Other  matters: The  Company  currently  has  an  investment  in  Equity  Resources  Limited,  which  itself  is  an investment company.

The Company takes no part in the active management of investee companies, although directors of the Company have served as directors on the boards of such companies.

---

# Page 7

# Starvest plc


## 2022 Annual Report and Financial Statements


## Review of trading portfolio


## Introduction

During the year to 30 September 2022, the portfolio comprised interests in the companies discussed below, as well as other active companies that are not discussed herein.

The economic shock of the global pandemic continued throughout 2022 and investors' desire for traditional safehaven assets boosted precious metals stocks at times. However, supply chain issues and European conflict led to rising energy prices, broader-based inflation and a shift in economic policies which caused market reactions and precious metal price fluctuations as well as an overall decline year on year in metal prices when forecasts for growth were downgraded. In this environment, we believe our strategy to focus on investments in gold producers will prove to be rewarding on a risk-adjusted basis for our shareholders. However, during the year to 30 September 2022, the value of our trading portfolio decreased ~56% due to lower market prices for major positions. Including our cash position, our net asset value ('NAV') and NAV per share decreased 53.4% and 53.7%, respectively, over the 12-month period to 30 September 2022. Given that Starvest's market capitalisation decreased approximately 49%, the discount to NAV narrowed to 29% compared to 34% a year ago.


## Transactions

During the year the Company did not raise capital through placing or subscription.

The Company disposed of its full holdings in Minera IRL during the year, along with a small portion of its positions in Greatland Gold (3.8m shares at an average price of 12.83p per share) and Ariana Resources (2.2m shares at an average price of 4.25p per share).


## Trading portfolio valuation

Although gold prices declined slightly (~5%) year on year, this change masked greater volatility during the 12month period. The Company's Net Asset Value decreased approximately 53% during the year to 30 September 2022  to  £6.6m  and  the  Company  made  a  loss  before  tax  of  £7,540,842  compared  with  a  loss  before  tax  of £3,861,014 in 2021.

However, we are pleased that the Company traded at an improved discount to its NAV of 29% compared to 34% the previous year.

As part of routine operations, the Board regularly reviews its portfolio positions and may make adjustments to its holdings  to  take  advantage  of  what  it  believes  to  be  temporary  weakness  in  prices  for  precious  metals. Alternatively, the Board may consider strategic opportunities to better align the Company's stock price with what it regards as the intrinsic value of the Company's portfolio.

Given the availability of actual trading prices for many of our portfolio assets, we value our holdings using closing market quotes for the periods shown.

In addition, the Company believes it has a strong financial position as it has no outstanding debt and is wellpositioned to  benefit  from  further  strength  in  the  natural  resources  sector  through  its  exposure  to  early-stage precious metal producers. We believe that worldwide economic growth and increasingly affluent consumers will fuel  demand for motor cars, air conditioning, consumer goods, computers, together with materials required in switching  to  'greener'  technologies  and  other  items  that  require  the  development  and  exploitation  of  natural resources in order both to produce and power.

---

# Page 8

# Starvest plc


## 2022 Annual Report and Financial Statements


## Review of trading portfolio, continued


## Trading portfolio valuation, continued


## Company statistics

The Company considers the following statistics to be its Key Performance Indicators (KPIs) and is satisfied with the results achieved in the year given the uncertain market conditions.


|    |                                         | 30 September  2022  at Closing  values   | 30 September  2021  at Closing  values   | Change  %            |
|----|-----------------------------------------|------------------------------------------|------------------------------------------|----------------------|
|   | Trading portfolio value                 | £6.2 m                                   | £14.0 m                                  | -55.7%               |
|   | Company net asset value                 | £6.6 m                                   | £14.1 m                                  | -53.2%               |
|   | Net asset value per share               | 11.3 p                                   | 24.4 p                                   | -53.7%               |
|   | Closing share price                     | 8.0 p                                    | 16.0 p                                   | -50%                 |
|   | Share price discount to net asset value | 29%                                      | 34%                                      | 5 percentage  points |
|   | Market capitalisation                   | £4.7 m                                   | £9.3 m                                   | -49.5%               |


Since the fiscal year end, values have improved. As at the close of business on 31 December 2022 the Company's Net Asset Value was £7.1m.


## Review of the current market

Global  markets  and  gold  prices  fluctuated  throughout  the  year;  with  economies  and  governments  trying  to rebalance and adjust to continuing post-pandemic and energy related uncertainties.

The price of gold fluctuated throughout the year with a peak of US$1,998 per troy ounce in March 2022 and a low of US$1,629 in September 2022 but has remained at elevated prices relative to the last decade. Copper, nickel, lead and zinc are all down year on year based on inflation and forecasted recessions.

Overall, investors are demonstrating greater interest in the natural resources sector, as the market looks forward to  economic growth, 'green' technology investments, and further government stimulus via major infrastructure projects; long-term natural resources are still vital commodities and demand is forecast to increase.

The  current  market  conditions  allow  for  measured,  strategic  investment  in  undervalued,  early-stage  natural resource projects.

---

# Page 9

# Starvest plc


## 2022 Annual Report and Financial Statements


## Portfolio review

Our primary investments in companies include the following:


## Greatland Gold plc ( www.greatlandgold.com )

Greatland Gold plc ('Greatland'), an AIM-listed exploration company, represents by far the largest part of the Company's portfolio and holds six exploration projects, four in Western Australia and two in Tasmania. Greatland also has farm-in and joint venture agreements in place with its major partner, Newcrest Mining Ltd.

The company, in conjunction with Newcrest, has continued to report excellent drilling results from the Havieron project and increased its Initial Inferred Mineral Resource estimate, independently of Newcrest, from 4.2Moz AuEq to 6.5Moz AuEq in March 2022. The increased estimate was ratified in August 2022 when Newcrest released its own resource upgrade. Neither resource takes into account drilling carried out after February 2022, which could yield a significant increase in resource if included. Drilling to date has not yet closed off the deposit, with Havieron remaining open at depth and in multiple directions, allowing for significant resource growth in the future.

In  addition,  Greatland  took  several  corporate  and  financial  actions  this  year.  Newcrest  boosted  its  stake  in Havieron  to  70%  but  declined  to  exercise  an  option  to  acquire  an  additional  5%  of  the  project.  Greatland subsequently raised US$35m in an over-subscribed placing and is well-funded to continue exploration and funding its part of the Havieron development. In September 2022, the company announced that two former Fortescue Metals Group executives would join the board in January 2023 and also added a former BHP executive, all of whom add a new dynamic to Greatland's leadership team and are able to take the company forward as a significant mid-tier  developer  in  the  near  term.  Around  the  same  time,  the  company  entered  into  a  significant  finance agreement, with a bank debt facility of A$200m committed through a syndicate of leading international banks and secured a strategic equity investment of up to A$120m from Wyloo Metals, which will fund Greatland fully through to production.

Significant activities since year end: Greatland announced that drilling permits have been granted on the Ernest Giles licence. Havieron drilling updates continue to confirm the potential to greatly expand the size of this deposit with high-grade extensions to mineralisation in the Eastern  Breccia, South East Crescent Zone and Northern Breccia. The mine decline is at over 900m development length and now in more competent rock. The feasibility study is due during 2023 and will likely include more up to date drilling data once completed thus further de-risking the project.

Greatland entered into an option agreement to sell its two Tasmania exploration licences to Flynn Gold for an initial purchase price of A$200,000 with deferred consideration and a royalty equal to 1% net smelter returns from any future production.


## Ariana Resources plc (www.arianaresources.com)

Ariana Resources PLC ('Ariana') is a United Kingdom-based company engaged in the exploration, development and mining of epithermal gold-silver and porphyry copper-gold deposits in Turkey and exploration in Cyprus and south-east Europe along with investments in other projects through its metals development fund, Asgard Metals.

During the year Ariana reported revenue of US$177m at Zenit Madencilik, its investee company, from continued successful production at the Kilitepe mine. Through the first half of 2022, with production of 13,378 oz Au, it was on track to exceed the company's annual guidance of 25,000 oz for the fifth year running. The company reported that this will allow them to sustain its business, enable growth and maintain its dividend rate. For the six months to June 2022 (the latest published but unaudited accounts), Ariana earned £2.5m in profits before tax.

Elsewhere in Turkey Ariana received a positive Environmental Impact Assessment at its Tavsan project which they are working to develop as its second gold mine, with a targeted annual production rate of approximately 30,000 oz Au. Construction of the mine is underway and scheduled for completion in H2 2023.

---

# Page 10

# Starvest plc


## 2022 Annual Report and Financial Statements

Portfolio review, continued Ariana Resources plc, continued

The Salinbas project has an inferred resource of 1.5Moz Au and the company is drilling at the Artvin gold project to develop an understanding of that area.

In  Cyprus, Ariana holds a 50% stake in Venus Minerals and the associated joint venture development of the permitted Apliki coper-gold mine. Venus Minerals are planning a London listing on AIM. Ariana has a 75% stake in  West  Tethyan  Resources  (WTR),  who  have  a  focus  on  southeastern  Europe  and  are  developing  licences primarily in Kosovo. During the year a strategic agreement was signed with Newmont who will invest US$2.5m to develop an Exploration Alliance Agreement via WTR  focusing on copper and gold in Bosnia and Herzegovina, Bulgaria, Greece, Kosovo, North Macedonia and Serbia running for an initial five-year term.

Ariana's Asgard Metals fund has made investments in Australia-focused Panther Metals, Kazakhstan-focused Pallas Resources and Indochina-focused Annamite Resources.

Significant activities since year end: Ariana Resources reported that gold production at the Kiziltepe mine was in line with guidance and drilling was completed which was testing extensions of the vein system near mine.

Geophysical programmes are also underway to further aid near mine exploration. Construction of a second mine at Tavsan is underway and the company has released an increase in JORC compliant resource for the Tavsan project of 6.6Mt at 1.44g/t Au and 5.6g/t Ag for 307,000oz Au and 1.1M oz Ag, a 22% increase on the previous resource.


## Alba Mineral Resources plc (www.albamineralresources.com)

Alba Mineral Resource is a diversified mineral exploration company focused on oil and gas, gold and base metals with holdings in UK (oil and gas, gold) and Ireland (base metals).

The company focused activities on its UK gold projects during the year, acquiring 100% of the Clogau property, continuing with drill programmes at the historical mine site and also testing material from a waste tip on site at Clogau  in  a  pilot  plant.  The  company's  application  to  dewater  the  Llechfraith  Shaft  was  rejected  by  Natural Resources  Wales  but  Alba  have  submitted  additional  supporting  data  and  analysis  and  have  extended  the programme  of  ecological  and  species  surveys.  Regional  exploration,  with  a  view  to  near-mine  resource expansion,  is  also  continuing,  with  an  application  for  an  unmanned  aeromagnetic  survey  following  up  on geochemical surveys carried out in 2019.

The Company's UK oil and gas investments at Horse Hill, where they hold a 11.8% stake, remains ongoing with production licences moving through legal channels and a Production Permit granted by the Environment Agency in May 2022.

The Company's Irish base metal licences have been extended through to May 2024, where they have three principal target areas for follow-up drilling.

Alba holds a 54% majority interest in AIM-listed GreenRoc Mining plc, which the company spun out in September 2021. GreenRoc hold licences for graphite, black sands iron and multi-elements in Greenland and announced a maiden JORC resource at its Amitsoq graphite deposit in March 2022 of 8.28Mt at 19.8% graphitic carbon. A revised resource at the Thule Black Sands now stands at 19Mt at 8.9% in-situ ilmenite.

With a reported £2 million in cash at its interim report at the end of May 2022 the company is well-funded to move forward this year.

Significant activities since year end: The company spun out GreenRoc to advance its Greenland graphite project. Metallurgical test work showed that the material could potentially be used in the electric vehicle battery market. In addition, the company appointed an adviser to assist in processing, sales and marketing going forward. On its own projects, primarily the Clogau gold project in Wales, the company has appointed a gold supply chain expert and completed a £0.5m placing in November.

---

# Page 11

# Starvest plc


## 2022 Annual Report and Financial Statements


## Cora Gold Limited ( www.coragold.com)

The company's exploration and development activities have continued in Mali on its flagship Sanankoro project. The company completed a drill programme converting additional ounces from the inferred to indicated category, increasing the total Mineral Resource Estimate by 14% and the oxide Indicated Minerals Resource by 22% in July 2022. Sanankoro comprises 24.9Mt of material grading at 1.15g/t Au of which 16.1Mt are indicated and 8.7Mt are inferred for a total 920koz Au.

Drilling also identified two new mineralised areas in close proximity to the existing resource at Sanankoro and the company carried out field work on a number of its other permits in southern Mali. The ongoing feasibility study for Sanankoro is due to be completed by Q4 2022.

With $2m in cash reported at the end of June 2022 in its unaudited interim report and funding agreements in place, the company is a good position to move forward with mine development over the next year.

Significant  activities  since  year  end:  Cora  announced  in  mid-October  2022  that  it  had  been  granted  the Environmental Permit for mining at its flagship Sanankoro project. The project's JORC Exploration Target was released in late November and contain between 26 and 35.2Mt Au with grades between 0.58 and 1.21g/t Au for potentially 490-1,370k oz Au. This is in addition to the indicated and inferred mineral resource of 24.9Mt at 1.15g/t Au for 920koz. The Exploration Target consists of 90% oxide and transitional material.

The company released a maiden reserve and definitive feasibility study in late November. Figures were based on a gold price of $1,650/oz Au providing 10.1Mt at 1.3g/t Au for 422koz Au, with 90% recovery rate.  Optimised DFS economics were based on $1,750/oz Au giving a 6.8 year mine life, 1.2 year payback period, 52.3% IRR, $997/oz AISC, 56,000oz pa average production. $234m free cash flow over life of mine.

Regional exploration has also continued with over 9km of gold structures identified from three separate zones. Grab samples of up to 6g/t Au have been reported and future reconnaissance drilling is planned.


## Oracle Power plc ( www.oraclepower.co.uk )

Oracle Power was originally focused on developing and operating a coal mine and a power plant in Pakistan and while those are still progressing it has recently diversified into green energy technology and gold projects.

In January 2022, Oracle signed a MoU with Aui Southern Gas Company Ltd, a company listed on the Pakistan Stock Exchange, relating to the buyback and joint development of a synthetic natural gas project using Thar Block VI coal.

In  October 2021 the company signed a non-exclusive cooperation agreement with PowerChina International Group to jointly develop a green hydrogen production facility in Pakistan, targeting a 400MW capacity plant. An update in December 2021 stated that a preliminary technical study was completed by PowerChina, establishing key  technical  and  commercial  aspects,  targeting  a  400MW  capacity  hydrogen  plant  with  planned  hydrogen production of 150,000kg per day. Technology suppliers were being sought and negotiations were underway with provincial governments regarding infrastructure. In March 2022 the company entered a joint venture agreement with His Highness Sheikh Ahmed Dalmook Al Maktoum (represented through Kaheel Energy) on the project and established  (a  joint  venture  company),  Oracle  Energy.  Oracle  raised  £800,000  in  April  2022  and  a  further £500,000 in August 2022 toward the project and an MoU was signed with Nuvera Fuel Cells LLC in June 2022 to jointly oversee a pilot hydrogen bus project. Oracle has also entered into an MoU with a hydrogen storage company in China to jointly explore storage and infrastructure development.

In  addition  to  its  Pakistan  projects,  Oracle  continued  to  develop  its  Australia  gold  projects  with  drilling  and metallurgical test work on samples from its Western Australia ground.

Significant activities since year end: Oracle has continued to focus on the green hydrogen project in Pakistan. It appointed Thyssenkruoo Uhde to lead a technical and commercial feasibility study for the project and signed a Memorandum of Understanding with Blue Carbon to collaborate on a decarbonisation roadmap.

---

# Page 12

# Starvest plc


## 2022 Annual Report and Financial Statements

Portfolio review, continued Oracle Power plc, continued

In addition, it signed a Letter of Intent with TUV SUD to explore green hydrogen and green ammonia certification and leased a land package of 7,000 acres for 30 years in the Thatta district to locate its flagship green hydrogen project.


## Kefi Gold and Copper plc (www.kefi-minerals.com)

Kefi Minerals is an exploration and development company focused on gold and copper deposits in the ArabianNubian Shield. Its main projects are Tulu Kapi in Ethiopia and the Jibal Qutmanand Hawiah projects in Saudi Arabia.

Operation on the Tula Kapi Mine in Ethiopia continued throughout the year. The Ministry of Mines completed an audit and endorsed historical project costs incurred through 2020 of circa US$80m which will now be reported to the Ethiopian central bank and allow for development banks to provide funds once the Ethiopian government ratifies this report.

While awaiting regulatory permissions to re-activate exploration for near-mine expansion in Ethiopia, the company has switched its main exploration efforts to Saudi Arabia. The Hawiah VMS Copper-Gold project has a JORC resource of 24.9Mt at 0.9% Cu and 0.62g/t Au. A preliminary feasibility study is due for completion by the end of 2022.  Jibal  Qutman  was  enlarged  this  year  with  a  +500,000oz  production  plan  over  ten  years  with  an  open pit/carbon-in-leach process. A mining licence and financing is being sought for the project. The company received additional exploration licences to bring its total to nine licences covering over 630km 2 .

Significant  activities  since  year  end:  The  Jibal  Qutman  licence  has  been  renewed  for  a  five-year  term.  The company intends to construct a pioneers camp and carry out environmental baseline studies and geotechnical and metallurgical diamond drilling going forward. The feasibility study remains on target for completion in early Q1 2023 with environmental permits targeted for Q1 2023 also. In January 2023 the company announced an increase in resources at the Hawiah project by 16% to 29mt as well as an expanded open pit domain to the project.


## Sunrise Resources plc ( www.sunriseresourcesplc.com )

Sunrise Resources hold ground in Nevada (USA) and Australia with commodities including precious and base metals as well as industrial minerals. Its main focus is developing pozzolan-perlite deposits while looking to enter into a JV or sell its other tenements.

Sunrise continued with development of its pozzolan-perlite project with discussions with companies in the cement and concrete industries. As natural pozzolan has a key role in cement decarbonisation strategies towards netzero CO2 emissions, it may benefit from California state legislation and Implementation Priorities under the Biden administration's $1.2 trillion infrastructure bill.

The company also extended its pozzolan footprint to a new project site at Hazen with due diligence field visits carried out by interested parties and sample testing underway. A permit was obtained during the year to extract 500 tons of sample material for commercial trials.

A new Mining Lease application was submitted on the company's Bakers Gold project in Western Australia to cover high-grade gold mineralisation intersected in a 2021 drill programme, with a highlight of 2m at 14.36g/t Au from 64m downhole. The project is available for sale or JV according to the company's website.

Significant activities since year end: Sunrise announced it has entered into a collaborative arrangement with an existing pozzolan processor for mining and test grinding. It also announced funding of £480,000 through issue of equity with an investment from Towards Net Zero a US based institutional investor focused on the green economy.

---

# Page 13

# Starvest plc


## 2022 Annual Report and Financial Statements

Portfolio review, continued Sunrise Resources plc, continued

The company's Pioche sepiolite project is advancing under its agreement with Tolsa USA Inc with new approvals for trenching on the licence received.


## Other investments

The remaining non-core investments are available for sale when the conditions are deemed to be right.  These include Block Energy plc (www.blockenergy.co.uk) and Kendrick Resources plc (www.kendrickresources.com).  In addition, there are a number of failed or almost failed ventures to which we attribute no value, although we always hope and seek to crystallise value where possible.

---

# Page 14

# Starvest plc


## 2022 Annual Report and Financial Statements


## Board of directors


## Callum N Baxter - Non-Executive Chairman

Mr. Baxter is a qualified Geologist (MSc Geol) and investor. His primary experience lies in early stage exploration geology and he has been involved in several discoveries throughout his more than 25 years in the industry. Callum has  more  than  20  years  of  experience  in  capital  markets  with  many  investments  focusing  on  early-stage exploration  opportunities.  He  was  an  Executive  Director  of  Starvest  investee  company,  Greatland  Gold  plc (AIM:GGP), from 2006 until 2021.


## Mark J Badros - Chief Executive Officer

Mr. Badros has more than 18 years of financial and investment experience in public and private equities as an analyst and investment manager at mutual funds and hedge funds, including Merrill Lynch Investment Managers, Zweig-DiMenna Associates, Highland Capital and Ironbound Capital. Mark graduated from Princeton University and received his law degree from Harvard Law School. He began his career practising securities, mergers and acquisitions, and corporate law in New York.


## Gemma M Cryan - Executive Director

Miss Cryan holds formal qualifications in geology (BSc Hons) and has over 20 years of industry experience in the oil  and  gas  industry,  followed  by  mineral  exploration,  in  both  private  and  public  companies  throughout  North America, Europe, Australasia and Africa. Her time has been spent in the field, and in management roles assisting with corporate matters. Gemma is well-versed in pre-IPO activities and early stage mineral exploration ventures and  she  is  a  Non-Executive  Director  of  Great  Western  Mining  Corporation  Plc  (AIM:GWMO)  and  First Development Resources Plc (unquoted).

---

# Page 15

# Starvest plc 2022 Annual Report and Financial Statements


## Strategic report


## Principal activities and business review

Since the company's inception in 2002, its principal trading activity has been to identify and, where appropriate, support small company new issues, pre-IPO and ongoing fundraising opportunities with a view to realising profit from disposals as the businesses mature in the medium term. The current directors have maintained this strategy of seeking out investment opportunities in small-cap and pre-IPO mining and metals companies.

The Company's investing policy is stated on page 3.

The  Company's  key  performance  indicators  and  developments  during  the  year  are  given  in  the  Chairman's statement and in the trading portfolio review, all of which form part of the Directors' & Strategic reports.


## Finance Review

Over the 12 months to 30 September 2022 the Company recorded a loss before tax of £7,540,842, equating to a loss of 12.96 pence per share with net cash inflow for the year of £327,830. This compares to a loss before tax of £3,861,014 in the previous year that equated to a loss of 6.69 pence per share. The Company's cash deposits stood at £406,106 at the period end.


## Key Performance Indicators

The Company's key measure of performance is the market value of its investment holdings. As a secondary metric, the Company seeks to manage the administrative and other expenses associated with achieving its investment results. The Company does not have any operating activities and thus the directors take the opinion that analysis using  operating  key  performance  indicators  is  not  necessary  for  an  understanding  of  the  performance, development or position of the business at the present time.


## Key risks and uncertainties

This business carries a high level of risk and uncertainty with commensurately high potential returns. The risk arises from the very nature of early-stage mineral exploration where there can be no certainty of outcome. In addition, often there is a lack of liquidity in the Company's trading portfolio, even for securities quoted on AIM or AQSE, such that the  Company may have difficulty  in realising  the  full  value  in  an  immediate  or  forced  sale. Accordingly, a commitment is only made after thorough research into both the management and the business of the target, both of which are closely monitored thereafter. Furthermore, the Company limits the total size of any single commitment, both as to the absolute amount and percentage ownership of the target company.


## Section 172 Statement


Section 172 (1) of the Companies Act obliges the Directors to promote the success of the Company for the benefit of  the  Company's members as a whole. This section specifies that the Directors must act in good faith when promoting the success of the Company and in doing so have regard (amongst other things) to:
- a) The likely consequences of any decision in the long term;
- b) The interests of the Company's employees;
- c) The need to foster the Company's business relationship with suppliers, customers and others;
- d) The impact of the Company's operations on the community and environment;
- e) The desirability of the Company maintaining a reputation for high standards of business conduct; and
- f) The need to act fairly as between members of the Company.


The Board of Directors is collectively responsible for formulating the Company's strategy, which is to invest in businesses  where  prospects  appear  to  be  exceptional  at  an  attractive  price  and  deliver  good  risk-adjusted investment  returns  to  its  shareholders.  Since  1  October  2021,  the  Board  took  the  decision  to  reduce  its concentration of risk in one project by divesting some of its position. The Board places equal importance on all shareholders and strives for transparent and effective external communications, within the regulatory confined of a listed company. The primary communication tool for regulatory matters and matters of material substance is through the Regulatory News Service ('RNS'). We also provide an environment where shareholders can interact with the Board and management, as questions and raise their

---

# Page 16

# Starvest plc


## 2022 Annual Report and Financial Statements


## Strategic report, continued

concerns. The Directors believe they have acted in a way they consider most likely to promote the success of the Company for the benefit of its members as a whole, as required by Section 172 (1) of the Companies Act 2006.

The Corporate Governance Statement, in particular Principles 2 and 3 of the Quoted Company Alliance's ('QCA') Corporate Governance Code for Small and Mid-Size Quoted Companies, available on pages 20-21 provides further evidence for how Section 172 (1) has been applied to strategic issues, risks or opportunities across key stakeholder groups. The Directors believe they have acted in the way they consider most likely to promote the success of the Company for the benefit of its shareholders and stakeholders as a whole, as required by Section 172 (1) of the Companies Act 2006.

By order of the Board


## Mark Badros

Chief Executive Officer 07 February 2023 Company registration number: 03981468

---

# Page 17

# Starvest plc


## 2022 Annual Report and Financial Statements


## Directors' report

The Directors present their twenty-first annual report on the affairs of the Company, together with the financial statements for the year ended 30 September 2022.


## Results and dividends

The Company's results are set out in the statement of comprehensive income on page 34. The audited financial statements for the year ended 30 September 2022 are set out on pages 34 to 47.

The Directors do not recommend the payment of a dividend for the year (2021: £nil).


## Directors

The Directors who served during the year are as follows:

Callum N Baxter Mark J Badros Gemma M Cryan


## Substantial shareholdings


At the close of business on 2 February 2023, the following were registered as being interested in 3% or more of the Company's ordinary share capital:
|                                                                                     | Ordinary shares  of £0.01 each   | Percentage of  issued share  capital   |
|-------------------------------------------------------------------------------------|----------------------------------|----------------------------------------|
| WB Nominees Limited (of which 12,670,000 representing                               | 12,692,261                       | 21.78%                                 |
| 21.74% are beneficially owned by Carole Rowan)                                      |                                  |                                        |
| Hargreaves Lansdown (Nominees) Limited                                              | 9,904,223                        | 16.99%                                 |
| Rock (Nominees) Limited (of which 8,090,753 representing                            | 8,698,668                        | 14.93%                                 |
| 13.90% are beneficially owned by Callum N Baxter)                                   |                                  |                                        |
| Interactive Investor Services Nominees Limited                                      | 8,693,666                        | 14.92%                                 |
| Winterflood Client Nominees Limited (of which 3,664,817                             | 4,106,434                        | 7.05%                                  |
| representing  6.29%  are  beneficially  owned  by  Philip  J  Milton & Company Plc) |                                  |                                        |
| Barclays Direct Investing Nominees Limited                                          | 1,918,843                        | 3.29%                                  |
| HSBC Nominees Limited                                                               | 1,822,125                        | 3.13%                                  |



## Charitable and political donations

During the year there were no charitable or political donations (2021: £nil).


## Payment of suppliers

The Company's policy is to settle terms of payment with suppliers when agreeing terms of business, to ensure that suppliers are aware of the terms of payment and to abide by them. It is usual for suppliers to be paid within 30 days of receipt of invoice. At 30 September 2022, the Company's trade creditors were equal to costs incurred of 44 days (2021: 80 days).


## Events after the end of the Reporting Period

There are no other material events to disclose other than those included in Note 20.


## Remuneration

The remuneration of the Directors has been fixed by the Board as a whole. The Board seeks to provide appropriate reward for the skill and time commitment required so as to retain the right calibre of director without paying more than is necessary.

Details of Directors' fees and of payments made for professional services rendered are set out in Note 6 to the financial statements.

---

# Page 18

# Starvest plc 2022 Annual Report and Financial Statements


## Directors' report, continued


## Management incentives

The Company has no share purchase, share option or other management incentive scheme.

As required by legislation, the Company has introduced a stakeholders' pension plan for the benefit of any future employees.


## Going concern

The  Company  finances  its  day-to-day  activities  from  its  available  cash  resources  and,  on  occasion,  by  part disposal of investments and the use of short-term loans.

The Directors are confident that adequate funding can be raised as required to meet the Company's current and future liabilities, which has been confirmed within the cash flow forecast prepared by the Board for the 12 months ending 28 February 2024. In the very unlikely event that suitable funding could not be raised, the Directors could raise  sufficient  funds  by  disposal  of  certain  of  its  current  asset  trade  investments.  Post-COVID-19  global economics has had an impact on the company's investments and their activities, however all investments held by the company are Level 1 investments and hence the value at the balance sheet date approximates the fair value which can be liquidated in order to settle the company's liabilities as they fall due for the foreseeable future.

As at 30 September 2022, the Company has no Borrowings.

For the reasons outlined above, the Directors are satisfied that the Company will be able to meet its current and future liabilities and continue trading for the foreseeable future and, in any event, for a period of not less than twelve months from the date of approving the financial statements. Therefore, the Company has prepared its financial statements on a going concern basis.


## Management of capital


The Company's objectives when managing capital are:
-  to  safeguard  its  ability  to  continue  as  a  going  concern,  so  that  it  can  continue  to  provide  returns for shareholders and benefits for other stakeholders, and
-  to provide an adequate return to shareholders by trading its current asset investments.


The Company sets the level of capital in proportion to risk. The Company manages the capital structure and makes adjustments to it in the light of changes in economic conditions and the risk characteristics of the underlying assets.


## Control procedures

The Board has approved financial budgets and cash forecasts; in addition, it has implemented procedures to ensure compliance with applicable accounting standards and effective reporting.


## Financial instruments

The Company uses financial instruments, comprising cash, trade investments and trade creditors, which arise directly from its operations. The main purpose of these instruments is to further the company's operations.


## Short-term debtors and creditors

Short-term debtors and creditors have been excluded from all the following disclosures.


## Trade investments

Trade investments are stated at market/fair value less any provision for impairment. The movements between fair and book value are set out in Note 10. The Board meets quarterly to consider investment strategy in respect of the Company's portfolio.


## Interest rate risk

The Company finances its operations through retained profits and new investment funds raised. The Board utilises short term floating rate interest bearing accounts to ensure adequate working capital is available whilst maximising returns on deposits.

---

# Page 19

# Starvest plc


## 2022 Annual Report and Financial Statements


## Directors' report, continued


## Liquidity risk

The Company seeks to manage financial risk, to ensure sufficient liquidity is available to meet foreseeable needs and to  invest  cash  assets  safely  and  profitably.  More  information  about  the  company's  liquidity  risk,  and  the management of that risk, is given under 'going concern' in Note 2 and in Note 18 to the financial statements.


## Borrowing facilities

As at 30 September 2022, the Company has no borrowings (2021: £25,000 unutilised overdraft facility).


## Currency risk

The Company trades substantially within the United Kingdom and all transactions are denominated in Sterling. Consequently, the Company is not significantly exposed to currency risk.


## Fair values

Except where shown above, the fair values of the Company's financial instruments are considered equal to the book value.


## Market price and credit risk

Management do not consider credit risk to be material to the Company. The Company is naturally exposed to market price risk, by the nature of its trade in investments, and the fluctuation of market and fair prices of its investment portfolio.


## Statement of disclosure of information to auditors


The Directors confirm that so far as each of the Directors is aware:
-  there is no relevant audit information of which the Company's auditor is unaware; and
-  the  Directors  have  taken  all  the  steps  that  they  ought  to  have  taken  as  directors  in  order  to  make themselves aware of any relevant audit information and to establish that the auditors are aware of that information.



## Independent Auditor

A resolution to appoint PKF Littlejohn LLP as auditor for the coming year will be proposed at the forthcoming AGM in accordance with section 489 Companies Act 2006.

By order of the Board


## Mark Badros

Chief Executive Officer 07 February 2023

Company registration number: 03981468

---

# Page 20

# Starvest plc


## 2022 Annual Report and Financial Statements


## Statement of directors' responsibilities


## Directors' responsibilities for the financial statements

The Directors are responsible for preparing the Directors' report, the strategic report and the financial statements in accordance with applicable law and regulations.


Company law requires the Directors to prepare financial statements for each financial year. Under that law the Directors have elected to prepare financial statements in accordance with United Kingdom Generally Accepted Accounting  Practice  (United  Kingdom  Accounting  Standards  and  applicable  law).  Under  company  law  the Directors must not approve the financial statements unless they are satisfied that they give a true and fair view of the state of affairs and profit or loss of the company for that period. In preparing those financial statements, the Directors are required to:
-  select suitable accounting policies and then apply them consistently;
-  make judgments and estimates that are reasonable and prudent;
-  state whether applicable UK accounting standards have been followed, subject to any material departures disclosed and explained in the financial statements;
-  prepare the financial statements on the going concern basis unless it is inappropriate to presume that the company will continue in business.


The Directors are responsible for keeping adequate accounting records that are sufficient to show and explain the company's transactions and disclose with reasonable accuracy at any time the financial position of the Company and enable them to ensure that the financial statements comply with the Companies Act 2006. They are also responsible for safeguarding the assets of the company and hence for taking reasonable steps for the prevention and detection of fraud and other irregularities.

The Directors are responsible for the maintenance and integrity of the corporate and financial information included on the Company's website. Legislation in the United Kingdom governing the preparation and dissemination of financial statements may differ from legislation in other jurisdictions.

The Company is compliant with AIM Rule 26 regarding the Company's website.

---

# Page 21

# Starvest plc


## 2022 Annual Report and Financial Statements


## Corporate governance statement

The  Board  of  Starvest  plc  are  committed  to  the  principles  of  good  corporate  governance  and  believe  in  the importance  and  value  of  robust  corporate  governance  and  in  our  accountability  to  our  shareholders  and stakeholders.

The AIM Rules for companies, updated in early 2018, required AIM companies to apply a recognised corporate governance code from 28 September 2018. Starvest has chosen to adhere to the Quoted Company Alliance's Corporate Governance Code for Small and Mid-Size Quoted Companies (the 'QCA Code') and listed below are the 10 broad principles of the QCA Code and the Company's disclosure with respect to each point.

The Board recognises the importance of good governance, agrees to the principals set out in the QCA Code, and is compliant with the vast majority of the QCA Code. However, the Company does not achieve full compliance with the QCA Code; specifically, Principles 5 and 7. The areas of non-compliance will be readily addressed as the Company grows and additional members are added to the Board.

The Board recognises that it is non-compliant with Principle 5 where the QCA Code recommends that at least two directors are independent. The QCA Code requires that the boards of AIM companies have an appropriate balance between executive and non-executive directors. The Board believes, at this time in the Company's development and with respect to the Company's size and goals of achieving good shareholder value through preserving cash for  investment  opportunities,  that  the  positions  within  the  Board  are  sufficient  to  carry  out  good  corporate governance with a balanced approach to decisions. As the Company grows this matter will be reviewed and addressed with the goal of appointing additional board members and filling a non-executive, independent role.

The Board recognises that it does not fully comply with Principle 7 in that Starvest currently does not have formal evaluation procedures for individual board members but the Board recognises that a formal evaluation process may become necessary in the near future.


## QCA CODE:


- 1: Establish a strategy and business model promoting long-term value for shareholders:


The Company is established as a source of early stage finance to fledgling businesses, to maximise the capital value of the Company and to generate benefits for Shareholders in the form of capital growth and modest dividends.


## Investing strategy

Natural resources: Whilst the Company's investment mandate is not exclusively limited to natural resources, the Board sees this sector as having considerable growth potential in the medium term. Historically, investments were generally made immediately prior to an initial public offering on AIM or AQSE as well as in the aftermarket.  As the nature of the market has changed since 2008, it is more likely that the future investment portfolio will include companies that have completed an IPO but remain in the  early stages of  identifying or, with  the appropriate financial backing, developing a commercial resource.

Direct Project: The Company's strategy is to invest predominantly through ownership of equity stakes in target companies. However, the Company believes there may be opportunities to take direct interests in mining projects and subsequently to acquire equity positions in target companies on favourable terms in exchange for these direct project interests; those companies would therefore become Starvest investee companies. The projects will be operated by the investee company; Starvest will not manage any project. Prior to selling any projects to corporate entities, Starvest may therefore have an interest in a number of projects. The addition of the Direct Project strategy to the Company's Investing Policy was approved by shareholders at the Company's annual general meeting held 1 December 2017.

Investment size: Initial investments are usually not greater than £100,000. Target companies are invariably not generating cash, but rather they have a constant need for additional funding in order to continue exploration and development. Therefore, after appropriate due diligence, the Company may provide further funding support and make later market purchases, so that the total investment may be greater than £100,000.

---

# Page 22

# Starvest plc


## 2022 Annual Report and Financial Statements


## Corporate governance statement, continued

High  risk: The  business  is  inherently  high  risk  and  cyclical  in  nature  dependent  upon  fluctuations  in  world economic  activity  which  impacts  on  the  demand  for  minerals.  However,  the  Company  affords  investors  the opportunity to  participate  in  diverse  early-stage  ventures,  which  the  Board  believes  will  offer  the  potential  for significant returns for the foreseeable future.

Lack of liquidity: The investee companies, being small, almost invariably lack share market liquidity, even if they are quoted on AIM, AQSE, ASX, or TSX-V. Therefore, in the early years it is rarely possible to sell an investment at the quoted market price with the result that extreme patience is required whilst the investee company develops and ultimately attracts market interest. If and when an explorer finds a large exploitable resource, it may become the object of a third party bid, or otherwise become a much larger entity; either way an opportunity to realise cash is expected to follow.

Success rate: Of the 15 to 20 investments held at any one time, it is expected that no more than five will prove to be 'winners'; from half of the remainder we may expect to see modest share price improvements. Overall, the expectation  is that in time  Shareholder returns will be acceptable if  not substantial.  Accordingly, the  Board is unable to give any estimate of the quantum or timing of returns.

Profit distribution: When profits have been realised and adequate cash is available, it is the intention of the Board to recommend the distribution of up to half the profits realised.

Other  matters: The  Company  currently  has  investments  in  the  following  companies,  which  themselves  are investment companies: Equity Investors plc and Equity Resources Limited. The Company takes no part in the active management of the companies in which it invests,


## 2: Seek to understand and meet shareholder needs and expectations

The Board recognises that it is accountable to Shareholders for the performance and activities of the Company and to this end is committed to providing effective communication with the Shareholders of the Company.

Unpublished price sensitive information is disclosed in as timely a manner as possible and in accordance with regulatory requirements for disclosure via a Regulatory Information Service provider.

Significant developments of investee companies are disseminated through stock exchange announcements and by regularly updating the Company's website, where descriptions of the investee company projects are available and updated quarterly or whenever there is a significant event. In addition, copies of any research notes are available.

The Board views the Annual General Meeting as an important forum for communication between the Company and its Shareholders and encourages Shareholders to express their views on the Company's business activities and performance. Previous shareholder engagements at AGMs and other functions have been productive with many questions answered by the Board. During other times of the year shareholder contact is primary through the executive directors at investor events and via the company's email: info@starvest.co.uk. Shareholder comments or issues are disseminated to the Board and taken into account when reviewing the performance and development of the Company.

The Board, through the Chief Executive Officer, the Executive Director and the Non-executive Chairman, also maintains regular contact with its advisors in order to ensure that the Board develops an understanding of the views of major Shareholders about the Company. The main point of shareholder contact is the CEO, Mr Mark Badros, and the other Executive Director, Ms Gemma  Cryan, who are contactable via email at info@starvest.co.uk, by telephone +44 (0)2077 696 876, or in writing to the following address; Starvest plc, 33 St.James's Square,  London UK,  SW1Y 4JS

---

# Page 23

# Starvest plc


## 2022 Annual Report and Financial Statements


## Corporate governance statement, continued


## 3: Take into account wider stakeholder and social responsibilities and their implications for long-term success.

The Board recognises that the success of the Company is reliant on the stakeholders of the business and, to this effect, the Company engages with these stakeholder groups, both internal and external on a regular basis.

The Company's strategy to investment immediately prior to an initial public offering, on AIM or AQSE dictates that we  foster  good  relationships  with  broking  firms,  other  professional  service  providers  to  the  natural  resource industry  and  members of  mining and exploration companies in  order to  keep  abreast  of  potential  investment opportunities.

The Company engages with numerous established broking firms and a network of professionals within the natural resource  industry  to  keep  abreast  of  new  companies  and  investment  opportunities  becoming  available.  The company deals only with ethically sound entities and, as such, reduces any risk to investment capital by unethical business practices.

Investee  companies  and  potential  investee  companies  are  reviewed  with  respect  to  country  and  community commitments to social and environmental responsibility. It is the company's belief that a good CSR (corporate social responsibility) policy enhances an investee company's standing and thus progress of a project/resource on a local, regional and government scale.

Investment by the Company in resource projects generally brings positive benefits to local communities who gain from employment, improved infrastructure and access to health facilities.


## 4:  Embed  effective  risk  management,  considering  both  opportunities  and  threats  throughout  the organisation

The business is inherently high risk and of a cyclical nature dependent upon fluctuations in world economic activity which impacts on the demand for minerals. However, it offers the investor a spread of investments in an exciting sector, which the Board believes will continue to offer the potential of significant returns for the foreseeable future.

Through  the  Board's  collective  industry  experience  and  thorough  research  and  investigation  into  potential investments, including but not limited to: geological setting, board and management experience, financial plans, jurisdictional risk and market conditions both current and forecast; we strive to minimise the inherent risks yet still avail of opportunities that will deliver good returns on investment capital in the medium to long term. The Company maintains  an  Audit  Committee  and  Remuneration  Committee  with  each  reporting  directly  to  the  Board.  Each Committee comprises one Executive Director and one Non-Executive Director.

The Company maintains a risk register that identifies key risks in the areas of corporate strategy, and finances as well as a comprehensive register for assessing investment opportunities. The register is reviewed periodically and updated as and when necessary. If there are any significant changes to the trading environment then the register is reviewed and updated as required.

Within the scope of the annual audit, specific financial risks are evaluated in detail, including in relation to foreign currency, liquidity and credit.


## 5: Maintain the board as a well-functioning, balanced team led by the chair

Information on the company board members is available on the following website page as well as in the company's annual reports and accounts disclosures.


## http://www.starvest.co.uk/board/


## Board of Directors

The Board of Directors currently comprises three Directors, two of whom are Executive Directors.

---

# Page 24

# Starvest plc


## 2022 Annual Report and Financial Statements


## Corporate governance statement, continued

Each member of the board is committed to spending sufficient time  to enable them to carry out their duties; Executive  Directors  commit  a  minimum  of  twenty  hours  per  week,  with  periods  where  this  is  increased considerably, such as mid-term and end of year reporting periods as well as times when investment transactions are being undertaken. Non-Executive Directors are expected to commit at least one hour per week to the company and, as with the executive team, are likely to exceed this many times throughout any twelve-month period.


## Role of the Board

The Board has a responsibility to govern the Company rather than to manage it and in doing so act in the best interests of the Company as a whole. Each member of the board is committed to spending sufficient time to enable them to carry out their duties as a Director; through various activities including but not limited to: researching and reviewing potential investments, shareholder engagement, stakeholder engagement, administrative and accounting tasks, monitoring of market conditions and investee company activities.


## Responsibilities of the Board

The Board is responsible for formulating, reviewing and approving the Company's strategy, financial activities and operating performance. Day-to-day management is devolved to the Executive Directors who are charged with consulting the Board on all significant financial and operational matters.


## Board meetings

All Directors are required to attend board and board committee meetings, every quarter at a minimum throughout the year and to be available at other times as required for face-to-face and telephone meetings. Board meetings are led by the Chair and follow an agenda that is circulated prior to the meeting. Every board meeting is minuted and every Director is aware of the right to have any concerns minuted and to seek independent advice at the Company's expense where appropriate.

The Board meets regularly throughout the year.


Board member attendance during the financial year to 30 September 2022:
| Position                                        | Member   | AGM  attendance   |   No. of  board  meetings |   Attended |
|-------------------------------------------------|----------|-------------------|---------------------------|------------|
| Non-Executive Chairman (formerly  Chairman/CEO) | C Baxter | Yes               |                        13 |         13 |
| Executive Director                              | G Cryan  | Yes               |                        13 |         13 |
| CEO (formerly Non-Executive Director)           | M Badros | Yes               |                        13 |         13 |



## Board committees

The Board has established an Audit committee and separate Remuneration Committee. There is no Nominations Committee as it is not seen relevant to the company at this stage of development.


## 6: Ensure that between them directors have the necessary up-to-date experience, skills and capabilities .

Information on the company board members is available on the following website page as well as in the company's annual reports and accounts disclosures.

http://www.starvest.co.uk/board/


## Directors

The Directors are of the opinion that the Board comprises a suitable balance. Current board members range in age from early 40's to early 50's and is well-balanced with both male and female members. The Board offers a range of backgrounds, experience and traits which when combined function well in delivering the Company's strategy.

---

# Page 25

# Starvest plc


## 2022 Annual Report and Financial Statements


## Corporate governance statement, continued

All  Directors  have  access  to  the  advice  of  the  Company's  solicitors  and  the  Company  Secretary;  necessary information is supplied to the Directors on a timely basis to enable them to discharge their duties effectively and all Directors have access to independent professional advice, at the Company's expense, as and when required.

Callum Baxter's active background in the mining industry (exploration geology) for more than 25 years and taking companies through the IPO process, as well as personal experience in investing in the natural resource sector, allows  for  an  in-depth  knowledge  of  the  challenges  potential  investee  companies  face  when  progressing  a company towards expansion and/or public listing. Callum also has a wide range of connections in the natural resource sector and supporting companies (e.g. brokering firms, NOMADs, corporate finance) from which to draw information on potential investments. His skill set allows seasoned evaluation  of the  investment opportunities presented  to  the  Company  before  an  informed  decision  is  made.  Callum  regularly  attends  conferences  and meetings to keep fully abreast of the sector.

Mark Badros has extensive experience in investment in public and private equities and corporate law, as well as a  background  in  economics  and  business,  including  securities,  mergers  and  acquisitions.  Gemma  Cryan's background in oil and gas and mineral exploration, both in the field and office environment, in numerous countries, allows her to draw on personal experience and professional connections for information on potential investments as  well  as  the  ability  to  review  projects  from  a  geological  and  corporate  perspective  with  regards  to  risk management. Her administrative and interpersonal skills are applied to corporate matters and seeking investment opportunities. Gemma regularly attends sector meetings and conferences and participates in courses on both technical and corporate matters.

The Directors remain active in their relevant sectors allowing them to keep their skills up to date. These activities are strengthened by Directors' regular attendance at relevant industry conferences and workshops throughout the year assisting Directors to keep their skills aligned to current industry standards.

All Directors, jointly or independently, have access to the Company's solicitor for external advice should they so choose. The Company Secretary role is managed by the Company's solicitor. Issues of compliance to government or government body regulations and requirements are brought to the Boards attention as necessary and advice is provided on methods required to comply fully. Matters arising with service contracts or agreements and general Company administration are also referred to the Company's solicitor and secretary for review and/or comment.

The  Company's  Non-Executive  Director  for  the  period  to  31 st   August  2022  is  considered  an  Independent Director. Mr. Badros has no ties to the major shareholders of the Company nor any significant personal investment in the Company or in its investee companies, except as disclosed; as such the Board considers his input, advice and support on the running of the Company and investment opportunities that arise as independent. Mr Baxter took the role of Non-executive Chairman 1st September 2022 and is not considered independent.


## 7: Evaluate board performance based on clear and relevant objectives seeking continuous improvement.

The Board evaluates its performance effectiveness based on reviews carried out at every board meeting where a critical review is carried out and performance objectives are benchmarked against current market dynamics.

During  the  year  these  critical  reviews  showed  the  Company  had  made  positive  progress  and  results  were presented to shareholders at the most recent AGM.

The  Company  does  not  currently  have  a  formal  evaluation  procedure  for  individual  board  members.  Board members are able to communicate effectively, and members are actively encouraged to participate in continuing professional development (CPD). The Directors remain active in their relevant sectors allowing them to keep their skills  up  to  date.  These  activities  are  strengthened  by  Directors'  regular  attendance  at  relevant  industry conferences and workshops throughout the year assisting Directors to keep their skills aligned to current industry standards.

---

# Page 26

# Starvest plc


## 2022 Annual Report and Financial Statements


## Corporate governance statement, continued

Board committees: The Company has a Remuneration Committee and Audit Committee. Each committee reviews relevant remuneration and audit matters and provides recommendations to the Board as a whole. Each Committee meets several times per year as required. Committee matters are minuted and items recommended to the Board are recorded in Minutes of meeting of the Board; significant events and matters are announced to market in a timely fashion and noted in each Annual Report.


## 8: Promote a corporate culture that is based on ethical values and behaviours


## Ethical decision making

In accordance with the engagement contracts board members enter into on joining Starvest, professional and personal ethics are expected to be maintained to a high standard with any misconduct subject to termination of their position. Requirements include maintaining high standards of business conduct; and acting fairly as between the members of the Company.


## Confidentiality

In  accordance  with  legal  requirements  and  agreed  ethical  standards,  the  Directors  have  agreed  to  maintain confidentiality of non-public information except where disclosure is authorised or legally mandated. The Company employs  no  other  staff,  although  the  accounting  function  is  delegated  to  a  suitably  qualified  professional accountant.


## Bribery

In accordance with the provisions of the Bribery Act, all Directors have been informed and have acknowledged that  it  is  an  offence  under  the  Act  to  engage  in  any  form  of  bribery.  The  Company  has  an  anti-bribery  and whistleblowing policy in force.


## 9:  Maintain  governance  structure  and  processes  that  are  fit  for  purpose  and  support  good  decisionmaking by the Board.

The Chairman's role is to communicate the strategy of the Board to shareholders of the Company. This role of the CEO is to ensure the implementation and execution of the Board's strategy. The Chairman and CEO are assisted in these  duties  by  an  Executive  Director.  Each  Executive  Director  is  charged  with  communication  with shareholders.

The existing Governance structures and Corporate Cultures are appropriate to the current size of the Company and adequate to address its capacity, appetite and tolerance for risk.

The  Company  currently  has  a  Remuneration  Committee  and  an  Audit  Committee.  Relevant  matters  are considered by each committee and recommendations are taken to the full board. Each committee meets several times per year as required.

Matters reserved for the Board are those directly related to implementing the Company's strategy. Good financial management is  a  high  priority  and  reviewed  frequently.  Market  dynamics  are  monitored  daily  and  long  term planning is key to delivering sound result.

The  Board  is  constantly  monitoring  its  state  of  affairs  and  intends  to  expand  the  Board  when  the  Company sufficiently  increases in size. Evolution of the Company's governance framework will follow growth and board expansion


## 10:  Communicate  how  the  company  is  governed  and  is  performing  by  maintaining  a  dialogue  with shareholders and other relevant stakeholders

The Board recognises that it is accountable to Shareholders for the performance and activities of the Company and to this end is committed to providing effective communication with the Shareholders of the Company.

---

# Page 27

# Starvest plc


## 2022 Annual Report and Financial Statements


## Corporate governance statement , continued

Significant developments are disseminated through stock exchange announcements and regular updates of the Company website where descriptions of the investee company projects are available and updated quarterly or whenever there is a significant event. In addition, copies of any third-party comment are available.

The Board views the Annual General Meeting as an important forum for communication between the Company and its Shareholders and encourages Shareholders to express their views on the Company's business activities and performance.

Outcomes of Audit Committee reports and Remuneration Committee reports are summarised in each Annual Report.

Historic annual reports and other governance-related material, including notices of all general meetings over the last 5 years can be found here:

http://www.starvest.co.uk/announcements/

http://www.starvest.co.uk/financial-results/

By order of the Board

Mark Badros Chief Executive Officer

07 February 2023

---

# Page 28

# Starvest plc


## 2022 Annual Report and Financial Statements


## Audit Committee Report


## Audit Committee

The primary purpose of the Company's Audit Committee is to provide oversight of the financial reporting process, the audit process, the Company's system of internal controls and compliance with laws and regulations.

The Audit Committee is authorised by the Board to investigate any activity within its Terms of Reference and to obtain  outside  legal  or  other  independent  professional  advice  and  to  secure  the  attendance  of  outsiders  with relevant experience and expertise, if it considers this necessary.

The Board has appointed the Audit Committee to include the sole Non-Executive Director as well as one Executive Director, given the current size of the Company and the board. During the year ended 30 September 2022 and up to the date of this report, the Audit Committee comprised Gemma Cryan and Mark Badros, who acted as Chairman until  31  August  2022. Upon Mr. Badros's appointment to CEO he stood down from the Audit Committee and Callum Baxter replaced him as Chairman. The Audit Committee formally met twice during the year.


## Dear Shareholder,

On behalf of the Board, I am pleased to present the Audit Committee Report for the year ended 30 September 2022.  The  Audit  Committee  is  primarily  responsible  for  providing  oversight  of  the  financial  reporting  process, the audit process, the Company's system of internal controls and compliance with laws and regulations and are outlined in more detail in the below report.


## The main role and responsibilities of the Audit Committee are:


-  to monitor the integrity of the financial statements of the company and any formal announcements relating to the company's financial performance, reviewing significant financial reporting judgements contained in them;
-  to review the company's internal financial controls;
-  to monitor and review the effectiveness of the company's internal control and risk management systems (including without limitation fraud risk);
-  to monitor and review the effectiveness of the company's internal and external audit arrangements;
-  to  make recommendations to the Board, for it to put to the shareholders for their approval in general meeting, in relation to the appointment of the external auditor and to approve the remuneration and terms of engagement of the external auditor;
-  to review and monitor the external auditor's independence and objectivity and the effectiveness of the audit process, taking into consideration relevant UK professional and regulatory requirements;
-  to report to the Board, identifying any matters in respect of which it considers that action or improvement is needed, and making recommendations as to the steps to be taken;
-  to consider the findings of internal investigations and management response; and
-  to report to the Board on any issues arising and how they may be dealt with.



## Audit Committee Membership and Activities

The Audit Committee's members during the year were Gemma Cryan, and Mark Badros as Chairman of the Committee from 1 October 2021 to 31 August 2022, and Callum Baxter as Chairman from 1   September 2022 to 30 September 2022.


The Committee met independently twice during the year to perform the following activities:
- 1) review key accounting and audit judgements;
- 2) review and consider whether the information provided was complete and appropriate based on its own knowledge;
- 3) review the external auditor issues that arose during the course of the audit and have subsequently been resolved and those issues that had been left unresolved were satisfactorily concluded;

---

# Page 29

# Starvest plc 2022 Annual Report and Financial Statements


## Audit Committee report, continued


- 4) review the management letter in order to assess whether it is based on a good understanding of the company's business and establish  whether recommendations have  been  acted upon and,  if  not, the reasons why they have not been acted upon;
- 5) review management's responsiveness to the external auditor's findings and recommendations;
- 6) review whether the auditor met the agreed audit plan and understand the reasons for any changes;
- 7) obtain feedback about the conduct of the audit from key people involved;
- 8) reported to the Board on the effectiveness of the external audit process;
- 9) review the appointment or reappointment of the external auditor, and information on the length of tenure of the current audit firm;
- 10) review any non-audit services provided by the external auditor during the financial year and what, if any effect that would have to the audit process; and
- 11) review the timing and timeline of the annual audit.


Mark Badros Former Committee Chairman 07 February 2023

---

# Page 30

# Starvest plc


## 2022 Annual Report and Financial Statements


## Remuneration Committee Report


## Remuneration Committee

The  Remuneration  Committee  is  responsible  for  establishing  and  proposing  to  the  Board  a  recommended framework for the remuneration of the Chairman, other directors and designated senior executives and, pursuant to the terms of the agreed framework, determining for such persons their total individual remuneration packages, including, where appropriate, bonuses, incentive payments and share options or other share awards.

The remuneration of Non-Executive Directors is a matter for the Chairman and the executive members of the Board. No Director is involved in any decision as to his or her own remuneration.

Details  on  the  activities  of  the  Remuneration  Committee  during  the  year  are  contained  in  the  Remuneration Committee Report below.

During the year ended 30 September 2022 and up to the signing of this report, the Remuneration Committee comprised Mark Badros, who acted as Chairman from 1 October 2021 - 31 August 2022; Callum Baxter, who acted as Chairman 1 September 2022 - 30 September 2022, and Gemma Cryan.  The Remuneration Committee formally met once during year and all members attended the meeting. Directors' roles and remuneration were also a point for general board meetings throughout the year.


## Dear Shareholder,

On behalf of the Board, I am pleased to present the Remuneration Committee Report for the year ended 30 September 2022. The Remuneration Committee is responsible for establishing and proposing to the Board a recommended framework for the remuneration of the Chairman, other Directors and designated senior executives and,  pursuant  to  the  terms  of  the  agreed  framework,  determining  for  such  persons  their  total  individual remuneration packages, including, where appropriate, bonuses, incentive payments and share options or other share awards.  The Remuneration Committee is also responsible for ensuring the Company is compliant with all relevant consultant and employment contracts and HMRC responsibilities.

As an AIM-listed company, Starvest is not required to comply with Schedule 8 of The Large and Medium-sized Companies and Groups (Accounts and Reports) Regulations 2008. The following disclosures are therefore made on a voluntary basis. The information is unaudited.


## Remuneration Committee Membership and Activities

The Remuneration Committee's members during the year were myself, as Former Chair of the Committee (1 October 2021 to 31 August 2022), Callum Baxter, current Chair and Gemma Cryan.


The Committee met once during the year to perform the following activities:
-  review Executive Director remuneration arrangements (including cash or shares in lieu)
-  review changes in remuneration in relation to board role changes
-  review and approve the Executive Directors' performance
-  review developments in corporate governance and best practice



## Remuneration Policy


The Company's remuneration policy is based on the following broad principles:
-  to  provide  competitive remuneration packages to enable the Company to recruit, retain and motivate individuals with the skills, capabilities and experience to achieve its objectives;
-  to align the interests of management with the interests of shareholders;
-  to ensure remuneration levels support the Company's strategy; and
-  to  align  pay  with  market  conditions  and  the  Company's  activities,  taking  due  account  of  (i)  pay  and conditions throughout the Company and (ii) best practices of corporate governance.


Executive remuneration consists of base pay. The Company does not currently have a bonus or incentive scheme in place.

---

# Page 31

# Starvest plc


## 2022 Annual Report and Financial Statements


## Remuneration Committee report, continued

Executive Directors' base pay is reviewed on an annual basis.

The individual salaries and benefits of Executive Directors are reviewed and adjusted taking into account individual performance, market factors and sector conditions.


The Committee reviews base salaries with reference to:
- · the individual's role, performance and experience;
- · business performance and the external economic environment; and
- · salary increases across the Company.


Any base salary increases are applied in line with the outcome of the review as part of which the Committee also considers average increases across the Company.


## Non-Executive Directors' fees

The Non-Executive Directors are paid a fee for carrying out their duties and responsibilities as disclosed in the table below.


## Service Contracts


## Callum Baxter

Mr. Baxter entered into an updated agreement with the Company on 1 September 2022 to continue to serve as its Chairman. The service contract provides for payments under PAYE in proportion to activities carried out on behalf of the Company within the UK as a non-resident Director at £27,000 per annum to be taken as cash or shares in lieu of cash payments (after any PAYE obligations are withheld).


## Gemma Cryan

Miss Cryan entered into an updated employment agreement with the Company on 1 October 2021 to continue to serve as an Executive Director The employment agreement provided for an annual salary of £53,000to be taken as cash or shares in lieu of cash payments (after any PAYE obligations are withheld).


## Mark Badros

Mr.  Badros  entered  into  an  updated  agreement  with  the  Company  on  1  September  2022  to  serve  as  Chief Executive Officer. The service contract provides for payments under PAYE in proportion to activities carried out on behalf of the Company within the UK as a non-resident Director at £60,000 per annum to be taken as cash or shares in lieu of cash payments (after any PAYE obligations are withheld).

All Directors are elected by the shareholders at an annual or special meeting, to serve until the next election and until their successors are elected and qualified, or until their earlier death, resignation or removal.


| Board Member   | Annual Remuneration £   |   Bonus £ | Shares  as  at  30  Sept 2022   |   % Holding as at 30  Sept 2022 |
|----------------|-------------------------|-----------|---------------------------------|---------------------------------|
| C Baxter       | 57,250                  |         0 | 8,098,753                       |                           13.9  |
| G Cryan        | 53,000                  |         0 | 1,490,254                       |                            2.56 |
| M Badros       | 29,750                  |         0 | 148,648                         |                            0.26 |



## Mark Badros

Former Committee Chairman 07 February 2023

---

# Page 32

# Starvest plc 2022 Annual Report and Financial Statements


## INDEPENDENT AUDITOR'S REPORT TO THE MEMBERS OF STARVEST PLC Opinion

We have audited the financial statements of Starvest Plc (the 'company') for the year ended 30 September 2022 which comprise the Statement of Comprehensive Income, the Statement of Financial Position, the Statement of Changes in  Equity,  the  Statement  of  Cash  Flows  and  notes  to  the  financial  statements,  including  significant accounting policies. The financial reporting framework that has been applied in their preparation is applicable law and United Kingdom Accounting Standards, including FRS 102 The Financial Reporting Standard applicable in the UK and Republic of Ireland (United Kingdom Generally Accepted Accounting Practice).


In our opinion, the financial statements:
-  give a true and fair view of the state of the company's affairs as at 30 September 2022 and of its loss for the year then ended;
-  have  been  properly  prepared  in  accordance  with  United  Kingdom  Generally  Accepted  Accounting Practice; and
-  have been prepared in accordance with the requirements of the Companies Act 2006.



## Basis for opinion

We conducted our audit in accordance with International Standards on Auditing (UK) (ISAs (UK)) and applicable law. Our responsibilities under those standards are further described in the Auditor's responsibilities for the audit of the financial statements section of our report. We are independent of the company in accordance with the ethical requirements that are relevant to  our audit of the financial statements in the UK, including the FRC's Ethical Standard as applied to listed entities, and we have fulfilled our other ethical responsibilities in accordance with these requirements. We believe that the audit evidence we have obtained is sufficient and appropriate to provide a basis for our opinion.


## Conclusions relating to going concern

In  auditing  the  financial  statements,  we  have  concluded that  the  Director's use of the going concern basis of accounting  in  the  preparation  of  the  financial  statements  is  appropriate.  Our  evaluation  of  the  Directors' assessment of the company's ability to continue to adopt the going concern basis of accounting included a review of the cash flow forecasts prepared by management, challenging the assumptions made therein and evaluating the ability of the company to realise its Level 1 investments, if required, to meet its liabilities as they fall due.

Based on the work we have performed, we have not identified any material uncertainties relating to events or conditions that, individually or collectively, may cast significant doubt on the company's ability to continue as a going concern for a period of at least twelve months from when the financial statements are authorised for issue.

Our responsibilities and the responsibilities of the Directors with respect to going concern are described in the relevant sections of this report.


## Our application of materiality

The scope of our audit was influenced by our application of materiality. The quantitative and qualitative thresholds for materiality determine the scope of our audit and the nature, timing and extent of our audit procedures.

Materiality for the company financial statements was set at £184,000 (2021: £422,000). This was calculated based on 3% of net assets, of which equity investments comprise the majority of the balance. The basis for calculating materiality  is  unchanged  from  the  previous  year,  with  the  reduction  reflecting  the  fall  in  fair  value  of  equity investments at year-end. The benchmark used is the one which we determined, in our professional judgment, to be the key benchmark within the financial statements relevant to shareholders of an investment management company in assessing financial performance. The key driver of the company and assessment of its performance is linked to the valuation of its equity investments held. Performance materiality has been set at £128,800 (2021: £295,400) being 70% of headline materiality, based upon our assessment of risk and the absence of any audit adjustments in previous periods.

We agreed to report to those charged with governance all corrected and uncorrected misstatements we identified through our audit with a value in excess of £9,000 (2021: £21,100). We also agreed to report any other audit misstatements below that threshold that we believe warranted reporting on qualitative grounds.

---

# Page 33

# Starvest plc


## 2022 Annual Report and Financial Statements


## INDEPENDENT AUDITOR'S REPORT TO THE MEMBERS OF STARVEST PLC, continued Our approach to the audit

In designing our audit, we determined materiality, and assessed the risk of material misstatement in the financial statements. In particular, we looked at areas where the Directors made significant judgements, comprising the fair value of investments at level 2 or 3 of the fair value hierarchy. We also assessed the risk of management override of internal controls.


## Key audit matters

Key audit matters are those matters that, in our professional judgment, were of most significance in our audit of the  financial  statements  of  the  current  period  and  include  the  most  significant  assessed  risks  of  material misstatement (whether or not due to fraud) we identified, including those which had the greatest effect on: the overall audit strategy, the allocation of resources in the audit; and directing the efforts of the engagement team. These matters were addressed in the context of our audit of the financial statements as a whole, and in forming our opinion thereon, and we do not provide a separate opinion on these matters.


| Key Audit Matter                                                                                                                                                                                                                   | How our scope addressed this matter                                                                                                                                      |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Financial assets at fair value through profit or loss  (Note 10)                                                                                                                                                                   |                                                                                                                                                                          |
| The Company holds equity investments with a car- rying value of £6m (2021: £14m) as at 30 September  2022. The portfolio consists largely of listed invest- ments, and thus are valued under Level 1 of the fair  value hierarchy. |  reviewing the valuation methodology for each  type of investment held and ensuring the carrying  values are supported by sufficient and appropri- ate audit evidence;  |
| Unlisted  investments  are  subject  to  management  valuation, and thus are exposed to significant levels  of  management judgement and estimation. These  investments have been written down to £Nil in pre- vious periods.      |  ensuring that investments are categorised and  disclosed correctly in accordance with UK GAAP;   agreeing year-end fair values to independent  sources of price data; |
| Based upon the significance of the value of the in- vestments held at the year end, this was determined  to be a Key Audit Matter.                                                                                                 |  ensuring that the company has legal title to the  investments held.; and                                                                                               |
|                                                                                                                                                                                                                                    |  performing tests of detail on investment disposals  in the year                                                                                                        |



## Other information

The other information comprises the information included in the annual report, other than the financial statements and our auditor's report  thereon. The  Directors are  responsible for the  other  information  contained  within  the annual report. Our opinion on the financial statements does not cover the other information and, except to the extent otherwise explicitly stated in our report, we do not express any form of assurance conclusion thereon. Our responsibility is to read the other information and, in doing so, consider whether the other information is materially inconsistent  with  the  financial  statements  or  our  knowledge  obtained  in  the  course  of  the  audit,  or  otherwise appears  to be materially misstated. If we  identify such  material inconsistencies or apparent  material misstatements, we are required to determine whether this gives rise to a material misstatement in the financial statements  themselves.  If,  based  on  the  work  we  have  performed,  we  conclude  that  there  is  a  material misstatement of this other information, we are required to report that fact.

---

# Page 34

# Starvest plc


## 2022 Annual Report and Financial Statements


## INDEPENDENT AUDITOR'S REPORT TO THE MEMBERS OF STARVEST PLC, continued

We have nothing to report in this regard.


## Opinions on other matters prescribed by the Companies Act 2006


In our opinion, based on the work undertaken in the course of the audit:
-  the information given in the strategic report and the directors' report for the financial year for which the financial statements are prepared is consistent with the financial statements; and
-  the  strategic  report  and  the  directors'  report  have  been  prepared  in  accordance  with  applicable  legal requirements.



## Matters on which we are required to report by exception

In the light of the knowledge and understanding of the company and its environment obtained in the course of the audit, we have not identified material misstatements in the strategic report or the directors' report.


We have nothing to report in respect of the following matters in relation to which the Companies Act 2006 requires us to report to you if, in our opinion:
-  adequate accounting records have not been kept, or returns adequate for our audit have not been received from branches not visited by us; or
-  the financial statements are not in agreement with the accounting records and returns; or
-  certain disclosures of directors' remuneration specified by law are not made; or
-  we have not received all the information and explanations we require for our audit.



## Responsibilities of directors

As  explained  more  fully  in  the  statement  of  directors'  responsibilities,  the  directors  are  responsible  for  the preparation of the financial statements and for being satisfied that they give a true and fair view, and for such internal control as the directors determine is necessary to enable the preparation of financial statements that are free from material misstatement, whether due to fraud or error.

In preparing the financial statements, the directors are responsible for assessing the company's ability to continue as a going concern, disclosing, as applicable, matters related to going concern and using the going concern basis of accounting unless the directors either intend to liquidate the company or to cease operations, or have no realistic alternative but to do so.


## Auditor's responsibilities for the audit of the financial statements

Our objectives are to obtain reasonable assurance about whether the financial statements as a whole are free from material misstatement, whether due to fraud or error, and to issue an auditor's report that includes our opinion. Reasonable assurance is a high level of assurance but is not a guarantee that an audit conducted in accordance with ISAs (UK) will always detect a material misstatement when it exists. Misstatements can arise from fraud or error  and  are  considered  material  if,  individually  or  in  the  aggregate,  they  could  reasonably  be  expected  to influence the economic decisions of users taken on the basis of these financial statements.


Irregularities, including fraud, are instances of non-compliance with laws and regulations. We design procedures in  line  with  our  responsibilities,  outlined  above,  to  detect  material  misstatements  in  respect  of  irregularities, including  fraud.  The  extent  to  which  our  procedures  are  capable  of  detecting  irregularities,  including  fraud  is detailed below:
-  We obtained an understanding of the company and the sector in which it operates to identify laws and regulations that could reasonably be expected to have a direct effect on the financial statements. We obtained our understanding in this regard through discussions with management and application of cumulative audit knowledge.

---

# Page 35

# Starvest plc


## 2022 Annual Report and Financial Statements


## INDEPENDENT AUDITOR'S REPORT TO THE MEMBERS OF STARVEST PLC, continued


-  We determined the principal laws and regulations relevant to the company in this regard to be those arising from:
- -Companies Act 2006
- -FRS 102
- -AIM Rules
-  We designed our audit procedures to ensure the audit team considered whether there were any indications of non-compliance by the company with those laws and regulations. These procedures included, but were not limited to:
- -Enquiries of management
- -Review of board minutes and other correspondence
- -Review of the company's related party transactions and disclosures
-  We also identified the risks of material misstatement of the financial statements due to fraud. We considered, in addition to the non-rebuttable presumption of a risk of fraud arising from management override of controls, that the existence and good title to investments represented the greatest risk of fraud.
-  We addressed the risk of fraud arising from management override of controls by performing audit procedures which included, but were not limited to: the testing of journals and evaluating the business rationale of any significant transactions that are unusual or outside the normal course of business.


Because of the inherent limitations of an audit, there is a risk that we will not detect all irregularities, including those leading to a material misstatement in the financial statements or non-compliance with regulation.  This risk increases the more that compliance with a law or regulation is removed from the events and transactions reflected in the financial statements, as we will be less likely to become aware of instances of non-compliance. The risk is also  greater  regarding  irregularities  occurring  due  to  fraud  rather  than  error,  as  fraud  involves  intentional concealment, forgery, collusion, omission or misrepresentation.

A further description of our responsibilities for the audit of the financial statements is located on the Financial Reporting Council's website at: www.frc.org.uk/auditorsresponsibilities . This description forms part of our auditor's report.


## Use of our report

This report is made solely to the company's members, as a body, in accordance with Chapter 3 of Part 16 of the Companies Act 2006. Our audit work has been undertaken so that we might state to the company's members those matters we are required to state to them in an auditor's report and for no other purpose. To the fullest extent permitted by law, we do not accept or assume responsibility to anyone, other than the company and the company's members as a body, for our audit work, for this report, or for the opinions we have formed.

David Thompson (Senior Statutory Auditor) For and on behalf of PKF Littlejohn LLP Statutory Auditor

15 Westferry Circus Canary Wharf London E14 4HD

07 February 2023

---

# Page 36

# Starvest plc


## 2022 Annual Report and Financial Statements


## STATEMENT OF COMPREHENSIVE INCOME


## FOR THE YEAR ENDED 30 SEPTEMBER 2022


|                                                                            | Note   | Year ended 30  September 2022  £   | Year ended 30  September 2021 £   |
|----------------------------------------------------------------------------|--------|------------------------------------|-----------------------------------|
| Administrative expenses                                                    | 7      | (305,944)                          | (290,993)                         |
| (Loss)/gain on disposal of financial assets                                | 7      | (53,398)                           | 19,339                            |
| Movement in fair value of financial assets   through profit or loss        | 7      | (7,234,928)                        | (3,645,360)                       |
| Investment income                                                          | 7      | 53,428                             | 56,000                            |
| Operating loss                                                             | 7      | (7,540,842)                        | (3,861,014)                       |
| Loss on ordinary activities before tax                                     | 7      | (7,540,842)                        | (3,861,014)                       |
| Tax on ordinary activities                                                 | 7      | 1,671,086                          | 332,532                           |
| Loss for the financial year attributable to  Equity holders of the Company | 7      | (5,869,756)                        | (3,528,482)                       |
| Earnings per share                                                         |        |                                    |                                   |
| Basic                                                                      | 8      | (10.09 pence)                      | (6.11 pence)                      |
| Diluted                                                                    | 8      | (10.09 pence)                      | (6.11 pence)                      |


There are no other recognised gains and losses in either year other than the result for the year.

All operations are continuing.

The accompanying accounting policies and notes form an integral part of these financial statements.

---

# Page 37

# Starvest plc


## 2022 Annual Report and Financial Statements


## STATEMENT OF FINANCIAL POSITION 30 SEPTEMBER 2022


|                                                       | Note   | Year ended 30  September 2022  £   | Year ended 30  September 2021 £   |
|-------------------------------------------------------|--------|------------------------------------|-----------------------------------|
| Non-current assets                                    |        |                                    |                                   |
| Financial assets at fair value through profit or loss | 10     | 6,156,173                          | 14,038,887                        |
| Total non-current assets                              |        | 6,156,173                          | 14,038,887                        |
| Current assets                                        |        |                                    |                                   |
| Trade and other receivables                           | 9      | 77,424                             | 63,539                            |
| Cash and cash equivalents                             |        | 406,106                            | 78,276                            |
| Total current assets                                  |        | 483,530                            | 141,815                           |
| Current liabilities                                   |        |                                    |                                   |
| Trade and other payables                              | 11     | (41,776)                           | (85,627)                          |
| Total current liabilities                             |        | (41,776)                           | (85,627)                          |
| Non-current liabilities                               |        |                                    |                                   |
| Provision for deferred tax                            | 7      | -                                  | (1,671,086)                       |
| Total non-current liabilities                         |        | -                                  | (1,671,086)                       |
| Net assets                                            |        | 6,597,927                          | 12,423,989                        |
| Capital and reserves                                  |        |                                    |                                   |
| Called up share capital                               | 12     | 582,824                            | 579,820                           |
| Share premium account                                 |        | 1,888,863                          | 1,848,173                         |
| Retained earnings                                     |        | 4,126,240                          | 9,995,996                         |
| Total equity shareholders' funds                      |        | 6,597,927                          | 12,423,989                        |


These financial statements were approved and authorised for issue by the Board of Directors on 07 February 2023.


## Signed on behalf of the Board of Directors


## Mark Badros


## Gemma M Cryan

Chief Executive Officer

Executive Director

Company No. 03981468

The accompanying accounting policies and notes form an integral part of these financial statements.

---

# Page 38

# Starvest plc 2022 annual report and financial statements


## STATEMENT OF CHANGES IN EQUITY


## FOR THE YEAR ENDED 30 SEPTEMBER 2022


|                                                     | Share capital Share premium  £   | £         | Retained  earnings   £   | Total Equity  attributable to  shareholders  £   |
|-----------------------------------------------------|----------------------------------|-----------|--------------------------|--------------------------------------------------|
| At 1 October 2020                                   | 575,740                          | 1,779,414 | 13,524,478               | 15,879,632                                       |
| Loss for the period                                 | -                                | -         | (3,528,482)              | (3,528,482)                                      |
| Total comprehensive income                          | -                                | -         | (3,528,482)              | (3,528,482)                                      |
| Shares issued                                       | 4,080                            | 68,759    | -                        | 72,839                                           |
| Total contributions by and distributions  to owners | 4,080                            | 68,759    | -                        | 72,839                                           |
| At 30 September 2021                                | 579,820                          | 1,848,173 | 9,995,996                | 12,423,989                                       |
| Loss for the period                                 | -                                | -         | (5,869,756)              | (5,869,756)                                      |
| Total comprehensive income                          | -                                | -         | (5,869,756)              | (5,869,756)                                      |
| Shares issued                                       | 3,004                            | 40,690    | -                        | 43,694                                           |
| Total contributions by and distributions  to owners | 3,004                            | 40,690    | -                        | 43,694                                           |
| At 30 September 2022                                | 582,824                          | 1,888,863 | 4,126,240                | 6,597,927                                        |

---

# Page 39

# Starvest plc


## 2022 annual report and financial statements


## STATEMENT OF CASH FLOWS FOR THE YEAR ENDED 30 SEPTEMBER 2022


|                                                                    | Note   | 30 September  2022  £   | 30 September  2021  £   |
|--------------------------------------------------------------------|--------|-------------------------|-------------------------|
| Cash flows from operating activities                               |        |                         |                         |
| Loss before tax                                                    |        | (7,540,842)             | (3,861,014)             |
| Shares issued in settlement of salary and fees                     |        | 43,694                  | 72,839                  |
| Movement in fair value of financial assets through profit  or loss |        | 7,234,928               | 3,645,360               |
| Loss/(profit) on sale of financial assets through profit or  loss  |        | 53,398                  | (19,339)                |
| Increase in debtors                                                |        | (13,885)                | (32,493)                |
| Decrease in creditors                                              |        | (43,851)                | (7,587)                 |
| Net cash used in operating activities                              |        | (266,558)               | (202,234)               |
| Cash flows from investing activities                               |        |                         |                         |
| Proceeds from sale of financial assets through profit of  loss     |        | 594,388                 | 160,145                 |
| Net cash generated from investing activities                       |        | 594,388                 | 160,145                 |
| Net increase/(decrease) in cash and cash  equivalents              |        | 327,830                 | (42,089)                |
| Cash and cash equivalents at beginning of period                   |        | 78,276                  | 120,365                 |
| Cash and cash equivalents at end of year                           | 14     | 406,106                 | 78,276                  |


The accompanying notes and accounting policies form an integral part of these financial statements.

---

# Page 40

# Starvest plc 2022 annual report and financial statements


## NOTES TO THE FINANCIAL STATEMENTS FOR THE YEAR ENDED 30 SEPTEMBER 2022


## 1. Company Information

Starvest plc is a Public Limited Company incorporated in England & Wales. The registered office is Salisbury House, London Wall, London, EC2M 5PS. The Company's shares are listed on the AIM market of the London Stock Exchange. These Financial Statements (the "Financial Statements") have been prepared and approved by the Directors on 07 February 2023 and signed on their behalf by Mark Badros and Gemma Cryan.


## 2. Basis of Preparation

These  financial  statements  have  been  prepared  in  accordance  with  applicable  United  Kingdom  accounting standards, including Financial Reporting Standard  102  -  'The Financial Reporting  Standard applicable in the United Kingdom and Republic of Ireland' ('FRS102'), and with the Companies Act 2006. The financial statements have been prepared on the historical cost basis. There are no fair value adjustments other than to the carrying value of the Company's trade investments. The financial statements are presented in pounds sterling, which is also the functional currency of the company.


## Going concern

The Company's day to day financing is from its available cash resources and, on occasion, by the part disposal of investments and use of short-term loans.

The Directors are confident that adequate funding can be raised as required to meet the Company's current and future liabilities, which has been confirmed within the cash flow forecast prepared by the Board for the 12 months ending 29 February 2024. In the unlikely event that such finance could not be raised, the Directors could raise sufficient funds by disposal of certain of its current asset trade investments.

As at the date of this report, the Company has no borrowings.

For the reasons outlined above, the Directors are satisfied that the Company will be able to meet its current and future liabilities, and continue trading, for the foreseeable future and, in any event, for a period of not less than twelve months from the date of approving the financial statements. The preparation of the financial statements on a going concern basis is therefore considered to remain appropriate.


## 3. Principal Accounting Policies


## Administrative expenses

All administrative expenses are stated inclusive of VAT, where applicable, as the company is not eligible to reclaim VAT incurred on its costs.


## Taxation

Corporation tax payable is provided on taxable profits at the current rates enacted or substantially enacted at the balance sheet date.

Under FRS102, investments are valued on a mark-to-market basis using publicly quoted trading prices at year end irrespective of whether they are classified as fixed or current assets.  However, pursuant to Part 3, Chapter 3, Corporation  Tax  Act  2009, any increase  in the value of  a  current  asset  is  recognised  as  a  trading  profit  and immediately subject to Corporation Tax when a company is classified as a trading company under HMRC rules and regulations, whereas an increase in the value of a fixed asset is not subject to taxation until the asset is disposed  of when  a  company  is classified as an investment  company.  Reported profit under UK GAAP is unaffected.

---

# Page 41

# Starvest plc 2022 annual report and financial statements


## NOTES TO THE FINANCIAL STATEMENTS


## FOR THE YEAR ENDED 30 SEPTEMBER 2022


## 3. Principal Accounting Policies, continued


## Taxation, continued

Historically, the Company's previous board had filed as a trading company and described its investment portfolio as a current asset. Following a comprehensive review of various factors related to the Company's investment portfolio  and  strategy,  including,  among  others, the  frequency,  timing,  liquidity,  trading  activities, development stage and investment  horizon of  such  investments  individually  and  the  portfolio  as  a  whole,  the Company's  current board have  determined  the Company  is  appropriately classified as an investment company, and the investment portfolio is properly accounted for among the Company's fixed assets. The Board do not consider this to be a change in accounting policy; rather, it is a correction in presentation to reflect more accurately the factual position.


## Deferred tax

Deferred tax is provided on an undiscounted full provision basis on all timing differences which have arisen but not reversed at the balance sheet date using rates of tax enacted or substantively enacted at the balance sheet date.

Deferred tax assets are only recognised to the extent that it is probable that they will be recovered against the reversal of deferred tax liabilities or other future taxable profits and are recognised within debtors. The deferred tax assets and liabilities all relate to the same legal entity and being due to or from the same tax authority are offset on the balance sheet.

FRS  102  requires  that  investments  are  valued  each  year  on  the  mark-to-market  basis  and  the  revaluation differences are reflected in the profit and loss account. However, the tax on any unrealised profit is calculated and shown in the accounts as if the profit had been realised, but there is then an adjustment in the deferred tax to move the tax that relates to the unrealised profit to the balance sheet.


## Foreign Currencies

Transactions in foreign  currencies are  recorded at the rate of exchange ruling  at the  date of the transaction. Monetary assets and liabilities denominated in a foreign currency are translated into the functional currency at the exchange rate ruling at the reporting date, unless specifically covered by foreign exchange contracts whereupon the contract rate is used.


## Investments

Current investments are stated at mid-market publicly quoted prices.

Investments in unlisted company shares are remeasured to available market values, or Directors' valuations at each balance sheet date.  Gains and losses on remeasurement are recognised in the statement of comprehensive income for the period. As at 30 September 2022 unlisted shares were valued at £nil (2021: £nil).

Investments in listed company shares are remeasured to market value at each balance sheet date under level 1 of the fair value hierachy. Gains and losses on remeasurement are recognised in the statement of comprehensive income for the period.

Dividend income is recognised in the income statement when the right to receive payment is established from investee companies.


## Financial instruments:


## Trade and other receivables

Trade and other receivables are not interest bearing and are recognised initially at fair value and subsequently measured at amortised cost using the effective interest method less provision for impairment.


## Cash and cash equivalents

Cash and cash equivalents include cash on hand and deposits held at call with banks.

---

# Page 42

# Starvest plc


## 2022 annual report and financial statements


## NOTES TO THE FINANCIAL STATEMENTS FOR THE YEAR ENDED 30 SEPTEMBER 2022


## 3. Principal Accounting Policies, continued


## Trade and other payables

Trade and other payables are not interest bearing and are recognised initially at fair value and subsequently measured at amortised cost.


## Financial liabilities

All financial liabilities are recognised initially at fair value and are subsequently measured at amortised cost. There are no financial liabilities classified as being at fair value through the statement of comprehensive income.


## Share capital

The Company's ordinary shares are classified as equity.


## Share premium

Represents premiums received on the initial issuing of the share capital. Any transaction costs associated with the issuing of shares are deducted from share premium, net of any related income tax benefits.


## Retained Earnings

Retained earnings is the cumulative profit or loss that is held or retained and saved for future use as recognised in the statement of comprehensive income.


## 4. Segmental Analysis


## Segmental information

An operating segment is a distinguishable component of the Company that engages in business activities from which it may earn revenues and incur expenses, whose operating results are regularly reviewed by the Company's chief  operating  decision  maker  to  make  decisions  about  the  allocation  of  resources  and  assessment  of performance and about which discrete financial information is available.

The Company is to continue to operate as a single UK based segment with a single primary activity to invest in businesses so as to generate a return for the shareholders. No segmental analysis has been disclosed as the Company has no other operating segments. The Directors will review the segmental analysis on a regular basis and update accordingly.

The Company has not generated any revenues from external customers during the period.


## 5. Operating Profit/(Loss)


|                                | September  2022  £   | Year ended 30  Year ended 30  September  2021  £   |
|--------------------------------|----------------------|----------------------------------------------------|
| This is stated after charging: |                      |                                                    |
| Auditor's remuneration:        |                      |                                                    |
| - audit services               | 19,200               | 18,600                                             |
| Director's emoluments - note 6 | 141,321              | 141,317                                            |


There are no employees, other than the Directors of the company (2021: Nil)

---

# Page 43

# Starvest plc


## 2022 annual report and financial statements


## NOTES TO THE FINANCIAL STATEMENTS FOR THE YEAR ENDED 30 SEPTEMBER 2022


## 6. Directors' Emoluments

There were no employees during the period apart from the directors. No directors had benefits accruing under money purchase pension schemes.


| Year ended 30 September 2022   | Salary and  Fees £   | Pension  £   | Shares  issued in  settlement  of fees - see note £   | Total £   |
|--------------------------------|----------------------|--------------|-------------------------------------------------------|-----------|
| C Baxter                       | 42,250               | -            | 15,000                                                | 57,250    |
| G Cryan                        | 46,153               | 1,321        | 6,847                                                 | 57,321    |
| M Badros                       | 29,750               | -            | -                                                     | 29,750    |
|                                | 118,153              | 1,321        | 21,847                                                | 141,321   |



| Year ended 30 September 2021   | Salary and  Fees £   | Pension  £   | Shares  issued in  settlement  of fees - see note £   | Total £   |
|--------------------------------|----------------------|--------------|-------------------------------------------------------|-----------|
| C Baxter                       | 15,000               | -            | 45,000                                                | 60,000    |
| G Cryan                        | 25,161               | 1,317        | 27,839                                                | 54,317    |
| M Badros                       | 27,000               | -            | -                                                     | 27,000    |
|                                | 67,161               | 1,317        | 72,839                                                | 141,317   |



## Amounts paid to third parties and shares issued in settlement of fees


Included in the above are the following amounts paid to third parties:
-  In  respect  Callum  Baxter's  total  remuneration,  £15,000  (2021:  £45,000)  was  settled  in  shares  in  the Company and at 30 September 2022 £nil (2021: £15,000) of his net salary remained outstanding.
-  In  respect of Gemma Cryan's total remuneration £6,847 (2021: £27,839) was settled in shares in the Company and at 30 September 2022 £nil (2021: £6,847) of her net salary remained outstanding.
-  In respect of Mark Badros's total remuneration, at 30 September 2022 £nil (2021: £6,750) of his net salary remained outstanding.



## 7. Corporation Tax


## a) Analysis of credit in the period


|                                                   | Year ended 30  September  2022   | Year ended 30  September  2021   |
|---------------------------------------------------|----------------------------------|----------------------------------|
| United Kingdom corporation tax at 19% (2021: 19%) | -                                | -                                |
| Deferred taxation at 25% (2021: 25%)              | (1,671,086)                      | (332,532)                        |
|                                                   | (1,671,086)                      | (332,532)                        |

---

# Page 44

# Starvest plc 2022 annual report and financial statements


## NOTES TO THE FINANCIAL STATEMENTS FOR THE YEAR ENDED 30 SEPTEMBER 2022


## 7. Corporation Tax, continued


## b) Factors affecting tax charge for the period


The tax assessed on the profit/(loss) on ordinary activities for the year differs from the standard rate of corporation tax in the UK of 19% (2020: 19%). The differences are explained below:
| Loss on ordinary activities before tax                       | Year ended 30  September  2022  £  (7,540,842)   | Year ended 30  September  2021  £  (3,861,014)   |
|--------------------------------------------------------------|--------------------------------------------------|--------------------------------------------------|
| Loss multiplied by standard rate of tax at 19% (2021: 19%)   | (1,432,760)                                      | (733,593)                                        |
| Effects of:                                                  |                                                  |                                                  |
| Utilised against carried forward losses                      | -                                                | -                                                |
| Losses carried forward not recognised as deferred tax assets | 1,432,760                                        | 733,593                                          |
| Deferred tax credit                                          | (1,671,086)                                      | (332,532)                                        |
|                                                              | (1,671,086)                                      | (332,532)                                        |
| c) Deferred tax                                              |                                                  |                                                  |
| Deferred tax liability b/fwd at 30 September 2021 and 2020   | 1,671,086                                        | 2,003,618                                        |
| Credit for the year                                          | (1,671,086)                                      | (332,532)                                        |
| Deferred tax liability c/fwd at 30 September 2022 and 2021   | -                                                | 1,671,086                                        |
| Capital losses b/fwd at 30 September 2021 and 2020           | (3,515,024)                                      | (3,548,493)                                      |
| Current year capital losses                                  | 191,959                                          | 33,469                                           |
| Capital losses c/fwd at 30 September 2022 and 2021           | (3,323,065)                                      | (3,515,024)                                      |
| Excess management expenses b/fwd at 30 September             | (2,249,467)                                      | (1,655,253)                                      |
| Current year excess management expenses                      | (305,944)                                        | (290,993)                                        |
| Adjustments in respect of prior periods                      | -                                                | (303,221)                                        |
| Excess management expenses c/fwd at 30 September             | (2,555,411)                                      | (2,249,467)                                      |
| Total losses                                                 | (5,878,476)                                      | (5,764,491)                                      |
| Profits b/fwd                                                | 6,684,345                                        | 10,545,359                                       |
| Current year pre-tax loss                                    | (7,540,842)  -                                   | (3,861,014)  6,684,345                           |
| Profit attributable to deferred tax                          |                                                  |                                                  |
| Deferred tax at 25% (2021:25%)                               | -                                                | 1,671,086                                        |

---

# Page 45

# Starvest plc


## 2022 annual report and financial statements


## NOTES TO THE FINANCIAL STATEMENTS


## FOR THE YEAR ENDED 30 SEPTEMBER 2022


## 7. Corporation Tax, continued


## c) Deferred tax, continued

A deferred tax liability provision of £1,671,086 has been released during the year (2021: £332,532) on the future tax payable on profits, on disposal of investments.

The Company has not recognised a deferred tax asset due to the inherent uncertainty that future investment gains will offset such a tax asset.

In May 2021, the UK Government enacted a budget that increased the corporation tax rate to 25% from the current rate of 19%. The deferred tax liabilities in these accounts have been adjusted to reflect these enacted tax rates.


## 8. Earnings Per Share

The basic earnings per share is derived by dividing the profit for the year attributable to ordinary shareholders by the weighted average number of shares in issue.


|                                                              | Year ended 30 September  2022  £   | Year ended 30 September  2021  £   |
|--------------------------------------------------------------|------------------------------------|------------------------------------|
| (Loss) for the year                                          | (5,869,756)                        | (3,528,482)                        |
| Weighted average number of Ordinary shares of £0.01 in issue | 58,181,646                         | 57,755,713                         |
| (Loss) per share - basic and diluted                         | (10.09 pence)                      | (6.11 pence)                       |


There are no potential dilutive shares in issue.


## 9. Trade and Other Receivables


|                       | Year ended 30 September  2022  £   | Year ended 30 September  2021  £   |
|-----------------------|------------------------------------|------------------------------------|
| Prepayments           | 49,904                             | 61,548                             |
| Funds held on account | 3,720                              | 1,991                              |
| Dividends receivable  | 23,800                             | -                                  |
|                       | 77,424                             | 63,539                             |



## Short term loans to related parties


-  At 30 September 2022 loans to Equity Resources Ltd ('EQR'), an associate of the company, totalling £20,000 (2021: £20,000) remain unpaid. The purpose of the loans was to assist EQR meet its necessary operational costs during a period when it seemed inappropriate that EQR should realise cash from its investments. The advances were made prior to appointment of the current board and approved by former directors at 0% interest with no formal agreement as to repayment date. The Company holds 28.41% of the equity in EQR. The Company has made a full provision for these loans, totalling £20,000.

---

# Page 46

# Starvest plc


## 2022 annual report and financial statements


## NOTES TO THE FINANCIAL STATEMENTS FOR THE YEAR ENDED 30 SEPTEMBER 2022


## 10. Financial assets at fair value through profit or loss


| Listed equity securities                                                 | 30 September  2022 £   | 30 September  2021 £   |
|--------------------------------------------------------------------------|------------------------|------------------------|
| Fair value of investments at 1 October                                   | 14,038,887             | 17,825,053             |
| Additions                                                                | -                      | -                      |
| Disposals                                                                | (647,786)              | (140,806)              |
| Fair value (loss) on financial assets through profit or loss             | (7,234,928)            | (3,645,360)            |
| Fair value at 30 September                                               | 6,156,173              | 14,038,887             |
| The fair value carrying values of the investments above were as follows: |                        |                        |
| Quoted on AIM                                                            | 6,156,173              | 14,029,001             |
| Quoted on foreign stock exchanges                                        | -                      | 9,886                  |
|                                                                          | 6,156,173              | 14,038,887             |



The Company has holdings in the companies described in the review of portfolio on pages 7 to 11.  Of these, the Company has holdings amounting to 20% or more of the issued share capital of the following companies:
| Name                                     | Country of  incorporation   | Class of  shares  held   | Percentage  of issued  capital   | (Loss) for the  last financial  year   | Capital and  reserves at  last  balance  sheet date   | Accounting  year end   |
|------------------------------------------|-----------------------------|--------------------------|----------------------------------|----------------------------------------|-------------------------------------------------------|------------------------|
| Equity Resources  Limited - see note [1] | England &  Wales            | Ordinary                 | 28.41%                           | (£2,181)                               | (£39,918)                                             | 31 May  2022           |


Note [1]: Equity Resources Limited is considered to be an associated undertaking. Equity accounting has not been used as Equity Resources Limited has a written down value of £nil.

The Company's share of the net liabilities of its Associates at 30 September 2022 is £11,341. The share of gross assets has been derived from the latest available financial information in respect of the Associates. The company's share of the items making up the profit and loss account and cash flow statements of its Associates has not been disclosed as the numbers are not considered material.


## 11. Trade and Other Payables: Amounts falling due within one year


|                                      | 30 September  2022    £   | 30 September  2021   £   |
|--------------------------------------|---------------------------|--------------------------|
| Trade creditors                      | 19,792                    | 33,143                   |
| Accruals                             | 21,470                    | 21,633                   |
| Employment and social security costs | 514                       | 30,841                   |
| Other payables                       | -                         | 10                       |
|                                      | 41,776                    | 85,627                   |

---

# Page 47

# Starvest plc


## 2022 annual report and financial statements


## NOTES TO THE FINANCIAL STATEMENTS FOR THE YEAR ENDED 30 SEPTEMBER 2022


## 12. Share Capital

The called up share capital of the Company was as follows:

Called up, allotted, issued and fully paid


|                                                  | Number of Shares   | £       |
|--------------------------------------------------|--------------------|---------|
| As at 30 September 2020                          | 57,573,986         | 575,740 |
| Issued 2 June 2021 in lieu of fees at 18.5p      | 275,635            | 50,992  |
| Issued 27 July 2021 in lieu of fees at 16.5p     | 132,410            | 21,847  |
| As at 30 September 2021                          | 57,982,031         | 648,579 |
| Issued 16 November 2021 in lieu of fees at 16.5p | 132,407            | 21,847  |
| Issued 7 April 2022 in lieu of fees at 13p       | 168,055            | 21,847  |
| As at 30 September 2022                          | 58,282,493         | 692,273 |



## Share Warrants

The Company currently has no unexercised warrants in issue.


## 13. Share options

During the year ended 30 September 2022 no new options were granted and the Company currently has no unexercised options in issue.


## 14.    Cash and Cash Equivalents

£


|                               | Year ended 30  September 2021  £   | Cash flow £   | Year ended 30  September 2022   |
|-------------------------------|------------------------------------|---------------|---------------------------------|
| Cash at bank                  | 78,276                             | 327,830       | 406,106                         |
| Net cash and cash equivalents | 78,276                             | 327,830       | 406,106                         |



## 15. Capital Commitments

As at 30 September 2022 and 30 September 2021, the Company had no commitments other than for expenses incurred in the normal course of business.


## 16. Contingent Liabilities

There were no contingent liabilities at 30 September 2022 (2021: £nil).


## 17. Related Party Transactions

During the year Greatland Gold plc, a company which Callum Baxter was formerly a director of, provided shared office space to the Company. At the year end there was £950 payable to Greatland Gold plc for October 2022 rent (2021: £1,908). This amount was settled in full on 27 October 2022.

There were no other related party transactions during the year other than those disclosed in notes 6 and 9.

The key  management of the Company  are considered to be the Directors,  the  compensation  for whom was £141,321 (2021: £141,317). Refer to note 6 for more information.


## 18. Financial Instruments

The  Company's  financial  instruments  comprise  investments,  cash  at  bank  and  various  items  such  as  other debtors, loans and creditors. The Company has not entered into derivative transactions nor does it trade financial instruments as a matter of policy.

---

# Page 48

# Starvest plc


## 2022 annual report and financial statements


## NOTES TO THE FINANCIAL STATEMENTS FOR THE YEAR ENDED 30 SEPTEMBER 2022


## 18. Financial Instruments, continued


## Credit Risk

The Company's credit risk arises primarily from short term loans to related parties and the risk the counterparty fails to discharge its obligations. At 30 September 2022 there were no loans outstanding (2021: £nil).


## Liquidity Risk

Liquidity risk arises from the management of cash funds and working capital. The risk is that the Company will fail to meet its financial obligations as they fall due. The Company operates within the constraints of available funds and cash flow projections are produced and regularly reviewed by management.


## Interest rate risk profile of financial assets

The only financial assets (other than short term debtors) are cash at bank and in hand, which comprises money at  call.  The  interest  earned  in  the  year  was  negligible.  The  Directors  believe  the  fair  value  of  the  financial instruments is not materially different to the book value.


## Foreign currency risk

The Company has no material exposure to foreign currency fluctuations.


## Market risk

The Company is exposed to market risk in that the value of its investments would be expected to vary depending on trading activity of its shares.


## Categories of financial instruments


|                                                         | Year ended 30  September 2022  £   | Year ended 30  September 2021    £   |
|---------------------------------------------------------|------------------------------------|--------------------------------------|
| Financial assets                                        |                                    |                                      |
| Trade investments at fair value through profit and loss | 6,156,173                          | 14,038,887                           |
| Dividends receivable at amortised cost                  | 23,800                             | -                                    |
| Cash and cash equivalents at amortised cost             | 406,106                            | 78,276                               |
| Investment funds held on account at amortised cost      | 3,720                              | 1,991                                |
|                                                         | 6,589,799                          | 14,119,154                           |
| Financial liabilities at amortised cost                 |                                    |                                      |
| Accruals and payables                                   | 41,776                             | 83,640                               |
|                                                         | 41,776                             | 83,640                               |



## 19. Capital Management

The Company's objective when managing capital is to safeguard the entity's ability to continue as a going concern and develop its investment activities to provide returns for shareholders. The Company's funding comprises equity and debt. The directors consider the Company's capital and reserves to be adequate. When considering the future capital requirements of the Company and the potential to fund specific investment activities, the directors consider the risk characteristics of all of the underlying assets in assessing the optimal capital structure.


## 20. Events After the End of the Reporting Period

There are no events after the end of the reporting period to disclose.


## 21. Ultimate controlling party

There is no ultimate controlling party.