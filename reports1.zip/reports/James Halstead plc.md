

---

# Page 1

# Report & Accounts 2022

---

# Page 2

# Directors and Advisers


## Directors

J A Wild FCA

M Halstead

G R Oliver FCA MCT

S D Hall

M J Halstead

R P Whiting


## Secretary

D N Fletcher ACMA ACG


## Registered office

Beechfield

Hollinhurst Road

Radcliffe

Manchester

M26 1JN

Company registration No.

140269


## Website

www.jameshalstead.com


## Bankers

National Westminster Bank plc 1 Hardman Boulevard Manchester M3 3AQ


## Registrars

Link Group

Central Square

29 Wellington Street Leeds

LS1 4DL


## Nominated adviser and stockbrokers

Panmure Gordon & Co One New Change London

EC4M 9AF


## Stockbrokers

WH Ireland

24 Martin Lane

London

EC4R 0DR


## Auditor

BDO LLP 3 Hardman Street Spinningfields Manchester M3 3AT

---

# Page 3

# HM Queen Elizabeth II 1926 - 2022

Polyflor was created in 1950. At the time it seemed to many as if Britain was losing its way in the post war world, but many more were optimistic. The newly formed NHS and the extension of the welfare state were part of what was to become the new Elizabethan age. Our company, and  many  others,  were  engaged  in  a  seller's  market  exporting  our  goods,  initially  to  the Commonwealth countries and then extending globally. HM Queen Elizabeth II travelled the world throughout the following years as our head of state. Her honesty, sincerity, sense of duty and service reflected back, in no small way, on the many businesses that exported from this relatively small nation.


## Trusted, reliable and constant.

I  had the honour to meet the Queen when we were presented with the Queen's Award for Enterprise, as did others from our business as further awards followed. I can speak for all our employees  from  the  shop  floors  of  Manchester  and  Teesside,  to  our  offices  in  Germany, Australia,  France, Asia,  Scandinavia,  New  Zealand,  Canada,  India  and  South America  -  you served us well your Majesty.

Thank you. May you Rest in Peace.

Geoffrey Halstead

President

---

# Page 4

# 1


## Contents

Strategic Report


| Chairman's Statement                                                                      2                                               |
|-------------------------------------------------------------------------------------------------------------------------------------------|
| Chief Executive's Review                                                                   5                                              |
| Financial Director's Review                                                                7                                              |
| Section 172 Statement                                                                   11                                                |
| Governance                                                                                                                                |
| Report of the Directors                                                                    13                                             |
| Board Report on Remuneration                                                       17                                                     |
| Corporate Governance                                                                    18                                                |
| Financial Statements                                                                                                                      |
| Independent Auditor's Report to the Members of James Halstead plc                                                                      24 |
| Consolidated Income Statement                                                     30                                                      |
| Consolidated Statement of Comprehensive Income                       31                                                                   |
| Consolidated Balance Sheet                                                            32                                                  |
| Consolidated Statement of Changes in Equity                                33                                                             |
| Consolidated Cash Flow Statement                                                34                                                        |
| Notes to the Consolidated Financial Statements                            35                                                              |
| Company Balance Sheet                                                                  61                                                 |
| Company Statement of Changes in Equity                                     62                                                             |
| Notes to the Company Financial Statements                                 63                                                              |
| Supplementary Information                                                                                                                 |
| Ten Year Summary                                                                           70                                             |
| Shareholder Information                                                                 71                                                |
| Notice of Annual General Meeting                                                  72                                                      |

---

# Page 5

# Chairman's Statement


## Results

Revenue for the year at £291.9m (2021: £266.4m) is 9.6% ahead of the comparative year.

Underlying  operating  profit  is  £51.1  million  (2021: £51.3m) - 0.4 % below last year. The reported profit for the year of £52.2m differed from this due to the one-off effect of insurance pay-outs in respect of the breakdown of one  of  the  major  production  lines  at  our  Radcliffe manufacturing plant in September 2019.

As  I  wrote  in  our  trading  update  on  1 August  2022,  the second half of the year has been, on the one hand, a period of full production for our factories in the UK but also with its challenges. The optimism at the start of the year on the decline of Covid-19, related supply problems and greater availability of labour was offset by a myriad of shortages/cost  increases  following  the  invasion  of  the Ukraine.  Transport, fuel and  energy  increases were immediately obvious and whilst a significant issue during the spring/summer period, we have been mindful that the autumn/winter  period  may  bring  deeper  problems.  The most obvious effect on our business has been our decision to  increase  stockholdings  as  we  sought  to  mitigate  the risks associated with the potential inability to manufacture.  This,  in  our  view,  seemed  judicious  and hopefully is over-cautious. In the event that the crisis does not escalate, then it is likely we will temporarily suspend some production for a period to bring stock levels back to normal.

Trading  margins  during  the  year  decreased  but  are acceptable given the flood of cost increases that we have in part passed on. As I noted in the last two years' trading updates, this period was again not normal. For example, in some flooring projects that have been severely delayed, we have honoured the prices originally quoted to preserve the volume  needed  to  feed  our  production  lines.  In  other instances,  we  have  re-priced  to  find  volume  still  goes elsewhere and in many cases we have re-priced again and retained  the  business. This  is  the  nature  of  our  industry with  over-capacity  of  supply  and  at  least  one  global competitor  has  fallen  into  receivership  on  the  back  of facing  similar  issues.  Whilst  some  other  industries  have priced daily on the back of this difficult situation, we have


## 2

walked a more cautious path and I commend our teams that  collectively  have  been  successful  in  managing  the challenges we face.

There have been some positives in the midst of a generally difficult trading  environment.  The  general  boycott  in Russian  trade  has  eased  the  widespread  shortage  of shipping  containers  that  has  prevailed  since  Covid-19 disrupted  normal  shipping  routes.  Similarly,  with  Russian bound  supplies  of  certain  raw  materials  facing  export restrictions  there  was,  at  times,  more  availability  to  our factories  as  these  were  diverted  back  into  the  European market. Overall it was a difficult period for manufacturing.


## The company and our strategy

James  Halstead  is  a  group  of  companies  involved  in  the manufacture  and  supply  of  flooring  for  commercial  and domestic purposes, based in Bury UK. James Halstead plc has been listed on the London Stock Exchange for nearly 75 years.

The  group  was  established  in  1914  and  continues  to operate out of the original premises in Bury. In its factories in Bury and Teesside it manufactures resilient flooring for distribution in the UK and worldwide.

The company's strategy is to constantly develop its brand identity and its reputation for quality, product innovation, durability and availability, thereby enhancing and maintaining  goodwill  with  the  aim  of  achieving  repeat business. Our focus is to work with stockists who in turn distribute those  bulk  deliveries  whilst  promoting  and representing the products to the end users and specifiers who will purchase the stock from those stockists.

This approach is designed to increase and secure revenue streams and drive profitability and cash flow which enables the continuation of dividends thereby creating shareholder wealth. In the normal course of business one key element of the company ethos is having dedicated sales personnel to present our product to our customers' clientele.

Over many years our strategy has also included a policy of continual investment in both process improvement and in product  development  to  improve  output  efficiency  and product offering.

---

# Page 6

# 3


## Chairman's Statement

continued


## Corporate governance and corporate social responsibility and the environment

The board has over many years recognised its responsibility towards  good  corporate  governance.  It  is  part  of  our character and, I believe, contributes to our ability to deliver long-term  shareholder  value.  Increasingly  companies  are, quite rightly, tasked with demonstrating  that  their environmental credentials and supply chain management are supported by social and sustainability dimensions with appropriate stewardship.

We  can  say,  with  some  pride,  that  almost  100%  of  our electric  usage  is  now  derived  from  renewables.  Our  biannual Sustainability Report was published in 2021 and we have  this  report  independently  audited  to  further  underline our credentials. (Available to download on our website).

PVC  polymer  is  one  of  our  main  raw  materials  and  we began recycling waste into our processes in the 1950s and have continued to use waste PVC as part of the process of manufacturing in ever increasing volumes. For many years we have funded waste collection with Recofloor - our UK joint  venture  that  collects  post  installation  waste  PVC within our industry. We are also founder members of the European PVC recycling venture, the AgPr, which funds the recycling  of  post-consumer PVC waste and diverts waste from landfill back into the manufacturing process.

An important point to note about PVC is that it has evolved and it is no longer just derived from petrochemicals. It is increasingly produced from bio-mass. Indeed, many of the by-products of PVC manufacturing are indispensable to the medical  and  food  industries.  PVC  manufacture  has  the lowest consumption of primary energy of any of the major commodity plastics and our PVC flooring is made with over 80% renewable materials. Our recycling initiatives further reduce our footprint on the environment.

As part of our focus on the future and the footprint of our industry we are major partners in industry wide bodies. We are, for example,  active  members  of  the  ERFMI  (the European  Resilient  Flooring  Manufacturing  Institute). ERFMI activities range from involvement in the EU carbon neutral strategy through to funding new  recycling initiatives to extend the ability of PVC to be recovered and recycled.

The UK may have left the European Union but our work on standards, the circular economy, sustainability and meaningful  recycling  is  both  Europe  wide  and  globally focused and is progressing at pace. In no way has 'Brexit' lessened  our  involvement  as  Europeans  in  the  flooring industry.


## Dividend

Our  cash  balances  stand  at  £52.1  million  (2021:  £83.3 million)  with  the  major  reason  for  the  reduction  being, obviously, increased stock. The inventory at the year end is £112.3 million (2021: £60.7 million) which is about 85% higher than the prior year comparative.

Also of note regarding the cash flow for the year is taxation paid of £9.9 million (2021: £9.9 million) - unchanged and equity dividends paid of £32.3 million (2021: £34.1 million) - down 5.3%.

Having this large investment in our stockholdings and with the challenges facing our companies in terms of cash flow, the  Board  do  not  propose  to  increase  the  final  dividend which will remain at the level of last year and will be paid in December 2022.

The  interim  dividend  of  2.25p  (2021:  4.25p)  was  paid  in June 2022.


## Acknowledgements

As  is  customary,  I  would  like  to  thank  our  staff  for  their continued efforts in achieving this year's result.

In  addition,  I  feel  I  must  note  the  death  of  HM  Queen Elizabeth  II. The  brand  'Polyflor'  was  created  in  1950,  just prior  to  start  of  her  reign.  Her  Majesty's  service  over  the years  since  has  no  doubt  been  the  rock  on  which  the reputation of the United Kingdom has been built and helped in the growth of our exports over the last 70 years.

Our thanks also to the UK Contract Flooring Association for their members' accolades with Polyflor being awarded the 2022 Manufacturer of the Year, as well as the Healthcare Installation  of  the  Year  (Kitwood  House  Care  Home  in Cheshire)  and  International  Installation  of  the  Year  (Live Sport Offices, Prague).

---

# Page 7

# Outlook

Trading from the year-end to date has been positive. Post year  end,  prices  have  been  increased  and  demand  has remained strong.

Sales volume is higher and we have continued to pass on cost  increases.  Costs,  most  particularly  energy,  have continued  to  rise. The  fall  in  the  value  of  sterling,  most markedly against the US dollar, in recent days will no doubt have implications to certain input costs but equally, given our level of exports, will have some positives.

We  cannot  forecast  the  effects  of  energy  costs  on  the myriad  of  materials  and  goods  that  are  needed  to undertake  mass  volume  manufacture  but  with  the  vast array  of  skills,  knowledge  and  entrepreneurs  within  our collective, each challenge should be overcome.

In  the  light  of  current  demand,  with  the  accumulated industry experience at our disposal, I, and the Board, remain confident of progress over the medium term, notwithstanding the short term challenges I have highlighted in my statement.

Anthony Wild

Chairman

30 September 2022


## 4

---

# Page 8

# 5


## Chief Executive's Review

As noted by the Chairman, it has been a mixed year. For the largest  input  costs  to  our  manufacturing  we  have  had  to accept price increases. Be it energy or raw materials it has been  a  constant  adverse  situation.  The  simple  idea  that these costs are passed on is complicated.


- (a) Complicated  by  the  project  related  nature  of quotations  and  the  time  from  quotation  to supply of the stock, reality of losing business at high prices or maintaining it at a loss.
- (b) Complicated  by  the  fact  that  at  least  two generations  that  have  never  seen  inflation  of this scale and who are partly in denial as to its reality, duration and implications.
- (c) Complicated by the possibility that this may yet affect the  continuous  production  we  have enjoyed over many, many years.


These  challenges  are  faced  by  many  of  our  European competitors  and  inevitably  there  is  a  degree  of  margin erosion which manufacturers from all types of industry face.

Reviewing the businesses in more detail:


## Objectflor/Karndean and James Halstead France, our European operations

In  Germany sales  growth  of  near  12%  came  largely  from cost surcharges and price increases as costs increased during the  year.  In  one  of  the  most  competitive  markets  for flooring, volumes were maintained. The year was one of two halves  with  the  earlier  part  facing  stock  shortages  due  to adverse  shipping  conditions.  There  were  key  product launches  that  were  delayed  by  both  the  availability  of complete  stock  ranges  and  difficulties in supply of marketing materials to support launches. The stock situation improved as the year progressed.

In France  sales  were  increased  by  18%,  volumes  also increased  though  by  a  lesser  percentage.  Investments  in regional  sales  teams  were  key  to  the  sales  growth.  Stock levels have  grown,  once  again  largely  planned  in  the expectation of supply problems.


## Polyflor Pacific - encompassing Australia, New Zealand and Asia

In Australia,  sales  were  some  6%  ahead  of  the  prior  year with increases in profitability that resulted from increased margin  due  to  favourable  product  mix  and  staff  costs savings compared to the prior year. The staff savings were

the result of difficulties in recruitment leaving vacancies for periods  of  time.  The  favourable  product  mix  was  due  to higher margin domestic flooring sales having taken a larger proportion of sales than commercial flooring. This was, no doubt, in part because Covid-19 restrictions were in place for a long part of the first half financial year. Freight costs, as with all markets, were greater. Stock levels increased.

In New Zealand sales were lower than the comparative year. This market had the longest Covid restrictions of our major markets.  Operational  restrictions  impacted  the  economy and the building sector in particular. Supplying New Zealand was  challenging  with  shipments  of  flooring  from  the  UK taking  up  to  8  months  from  order  due  to  sea  freight complexities  such  as  shortages  of  shipping  containers  in Europe  and  severe  congestion  in  ports  such  as  Singapore. The  supply  of  flooring  into  nationwide  social  housing contracts continues to be an important source of revenue and  will  continue  as  backlogs  in  the  roll-out  programme alleviate. One negative was the supply of cushion vinyl from European  manufacturers  which  was  severely  disrupted. Nevertheless, it is pleasing to report increased market share and  customer  satisfaction  -  largely  due  to  our  company having  stock  and  offering  service  levels  far  better  than competitors. Stock levels have been increased.

This was the first full year of our Malaysian business (which also  covers  the  South  Eastern  markets  of  Indonesia, Singapore, Thailand, Vietnam  and  the  Philippines)  and  we can be satisfied with the progress made to date. The start of the  year  was  again  hampered  by  various  lockdowns  and travel  movements  across  the  territories,  but  as  the  year progressed, we saw the order book and sales grow, with sales across the region 153% ahead of last year.

The  order  book  remains  healthy,  and  we  have  every expectation that sales will continue to grow. At the end of the financial year, we strengthened the sales team further by employing salespeople directly in Vietnam and Thailand to support the distributors, and similar plans are in place for the Philippines before the end of 2022.


## Polyflor & Riverside Flooring, based in UK

We  continue  to  see  growth  in  the  heterogeneous  ranges manufactured  at Teesside,  and  a  falloff  in  certain  of  the 'older'  ranges  manufactured  in  Radcliffe.  Overall  volumes were maintained. Output was increased as we returned to a situation of being able to run all production lines, albeit with continued absenteeism levels that are above the 'normal' levels that existed prior to the Covid-19 pandemic.

The  increase  in  energy  and  raw  material  costs  have  put pressure on our margins and whilst we have a proportion of

---

# Page 9

our  energy  consumption  on  forward  contracts,  costs continue  to  rise  to  unprecedented  levels.  The  recent announcement  by  the  government,  whilst  welcome,  will only  limit  the  increase,  not  reduce  it.  Availability  of  raw materials has improved, but costs remain high. The impact of rising energy costs on the production costs has been a significant issue.

We have made several price increases during the year across our ranges and across all markets to pass on these increases. This continues to be the case after the year end.

Stocks in the UK also increased, both in manufactured and merchanted goods. Delays in product launches earlier in the year  compounded  the  issue  as  we  waited  for  marketing material, such as shade cards and display boards. This was another fallout of the Ukraine war due to the lack of wood pulp and related materials.


## Polyflor Nordic comprising Polyflor Norway based in Oslo and Falck Design based in Sweden

The markets have been re-organised to bring both Norway and Sweden under one reporting structure. In Norway sales are 17% ahead of the prior year largely supported by price increases. Net profit rose by just under 6%. Heterogeneous flooring  (supplied  by  Riverside)  grew  and  there  has  been investment in additional staff in internal sales and regional sales areas. In Sweden, sales increased 37% and the volume of product supplied from our UK factories increased by near 50%.  It  must  be  noted  that  the  prior  year  comparatives were subdued by Covid-19 but nevertheless this is a good result for both countries.


## Polyflor Canada, based in Toronto

A record year for sales and a significant increase in net profit against a generally sluggish economy. Our market share is still embryonic in this market but with the shadow of Covid19 having crippled travel for much of the financial year this was a creditable performance. Our Canadian business is very largely project based and these have faced delays in funding and  progress  but  the  business  is  well  placed  for  further growth.


## Rest of the World

Our products are sold in many markets across the globe and the preceding sections cover some of the key markets where we have a local presence and warehousing. These markets have been long established for the sales of our flooring and there  has  also  been  significant  growth  in  several  other markets  when  compared  to  last  year.  Spain  was  up  30%,


## 6

South America  up  48%  and  the  Middle  East  up  59%.  In some instances the comparative for 2021 was affected by the impact of the Covid-19 virus (most notably in Spain). It is  pleasing  to  see  these  markets  have  recovered,  this  has been hard to achieve with the cost of international freight and  equally  as  problematical  have  been  delays  and difficulties  in  available  shipping. The  markets  that  did  not grow in the year were Africa and North Asia.

The North Asia markets have experienced a challenging year due to the increase in Covid-19 cases and the 'zero-Covid' policy adopted across China.  This meant  our local warehouse  in  China,  which  became  operational  last  year supplying smaller and local orders, as well as being able to support other Asian markets, could not despatch products. Several larger Asian projects, which are shipped direct, have been  delayed.  Latterly  we  have  started  to  see  some improvement  but  sales  for  2022  fell  by  28%  against  the previous year.


## In conclusion

Given the circumstances we can only be pleased with the results for the  year.  The  hard  work,  dedication  and experience of our subsidiary directors and management has been a key factor in this achievement.

However, the challenges have not lessened.

Mark Halstead Chief Executive

30 September 2022

---

# Page 10

# 7


## Financial Director's Review

As  is usual, we  have  prepared  these  accounts  by  the consistent  application  of  accounting  standards  with  due appraisal and judicious accrual for known probable liabilities with  as  yet  uncertain  outcome  at  the  year  end.  As  in previous years we, as a board, look to be prudent.

The group operates through separate legal entities in certain areas  of  the  world  and  though  these  are  discussed  in  the Chief  Executive's  Review  we,  as  a  board,  have  concluded that these operations are one segment for the purposes of IFRS 8.


## Some key statistics:


- Group  turnover  at  £291.9  million  (2021:  £266.4 million) was 9.6% higher than last year.
- Profit  before  tax  was  £52.1  million  (2021:  £51.3 million) 1.6% higher than last year.
- Selling and distribution costs were 8.6% higher than last year. Administration expenses were 19.2% lower than last year
- Trade debtors increased to £46.7 million (2021: £39.3 million).  Trade  creditors  increased  to  £61.5  million (2021: £40.9 million).
- Stock  levels  stand  at  £112.3  million  (2021:  £60.7 million).
- Cash  stands  at  £52.1  million  (2021:  £83.3  million) even after the payment of £32.3 million in dividends, £9.9  million  in  tax  and  £3.2  million  of  capital expenditure.



## Key performance indicators

The board considers growth in profit before tax and growth in  dividend  key  targets  in  line  with  the  task  of  delivering shareholder value. Control of working capital continues to be important and the level of cash is monitored. Cash flow has been a key performance measure.

Rather than focus on individual working capital targets or ratios, the  board  are  informed  of  all  significant  issues directly  by  subsidiary  management  by  means  of  monthly reports  on  the  key  decisions  and  influences  on  working capital. Our focus at subsidiary level is on stock availability and appropriate credit given to and received from customers  and  suppliers  respectively.  Obviously  sales, margin  and  profitability  are  monitored  as  well  as  cash, which  is  the  final  result  of  our  economic  activities. Appropriate summaries of these statistics are collated into monthly group reports. These accounts contain analysis and more importantly we require each director to undertake a written  report  on  their  area  and  often  these  include  key

indicators (obvious examples are level of absenteeism in the factories, debtor days and margin by product line but these are backed up with detail of the key drivers of these ratios and the planned response).

No individual key performance indicator, or group thereof, is regarded  as  more  important  than  informed,  in-depth knowledge  of  the  underlying  businesses.  Subsidiaries present  key  performance  indicators  on  debtor  days,  stock turn and creditor days but the consolidation of these for the whole group offers no extra benefit as the component of mix can mask underlying effects. One such indicator that is under close scrutiny is absenteeism.

In terms of non-financial KPIs brand awareness, reputation, customer  satisfaction  and  market  share  are  all  important but difficult to assess. We do not believe that surveys and market share data, to the extent that they are collated by various  trade  bodies,  is  complete  and  wholly  accurate. Consequently  little  reliance  is  placed  upon  this  data. We subscribe  to  various  third  party  reports  on  the  flooring industry which to an extent match and compare us to our competitors and whilst valid snap-shots of the sector they are  limited. Customer  satisfaction  awards  are  always welcome and we note these in our strategic report.


## Principal decisions

The strategic report notes our approach to our Section 172 of  the  Companies  Act  2006  and  we  have  faced  many decisions in the year. We define principal decisions as those that have a significant impact on the company and/or group and/or  our  stakeholders.  Principal  decisions  that  are currently confidential to the group are not included in the list  below. Any  such  decision  would  be  included  in  future report and accounts if and when confidentiality is no longer a factor.

The potential impact of principal decisions on stakeholders is assessed  in  detail  by  the  board.  Obviously  a  significant number  of  decisions  had  to  be  made  in  the  period  of  the lockdown and principally the level of manufacturing activity. The executive directors kept the board appraised and these actions  are  described  in  the  strategic  review  and  in  our interim  reporting. To  the  extent  that  these  decisions  affect employees there is a bi-annual update on group performance. Each of the principal decisions has an effect on employment and hence employees as a whole so this high level update is important to provide context for the individuals.

During the year the following were considered by the board.


## Payment of dividends

The  board  considered  shareholder  expectations  in  setting these  dividends,  along  with  the  cash  position  of  the company.  Cash  flow  projections  are  an  important  part  of

---

# Page 11

this, particularly in the current economic environment - the executive  directors  were  tasked  with  keeping  the  board appraised of the working capital position.


# Defined benefit (DB) pension scheme

Further to the triennial valuation of the last year and the adoption of the new funding arrangements the DB scheme has remained under review. The board had discussed with the trustees the future accrual of benefits and the trustees made clear that an equitable payment by members would see an increase in member contributions of around 12-15%. The  view  was  that  the  members  would  not  consider  this appropriate  and  as  a  consequence  the  board  tasked  the executive  directors  with  entering  consultation  with  the employees  over  the  closure  to  future  accrual  of  the  final salary pension scheme.


## Post Covid-19 immunisation manufacturing

The success of the initial vaccine rollout in the UK, the very high  efficacy  of  this  vaccine  and  the  alteration  to  selfisolation rules provided the opportunity, in the early part of the financial year, to return to more normal shift patterns and  to  increase  output  from  our  UK  manufacturing  sites. The board, however, needed to consider the impact of the lesser  efficacy  of  vaccines  in  the  Far  East,  from  which  we also source goods, and the ongoing lock-downs of a region that continued to take a zero-tolerance approach to Covid19  cases.  In  order  to  mitigate  possible  supply  shortages stock levels were raised over a period of several months.


## Approval of group budget

A key process is to each year agree budgets with our trading subsidiaries and this is presented to the board towards the end of each trading year. Having regard to the unprecedented  situation  across  our  markets  regarding ongoing  supply  chain  issues  re  the  pandemic  and  the Ukrainian conflict with the energy crisis a budgetary process this year would be neither accurate nor a useful use of time. The Board, therefore, has assessed progress against the prior year  comparative.  This  year  a  budget  (i.e.  for  2022/23) process has been followed but, again, the flow of trade is still far from normal. In the normal course of budget preparation manning  levels  and  shift  patterns  are  assessed  and  this effect of working  hours  disseminated  to  the  various departmental  employees.  Our  business,  as  with  many others, is still experiencing unprecedented  levels of absenteeism  and  huge  increases  in  energy  costs  both  of which present challenges to the manufacturing process.


## Warehouse expansion

In 2020  the  board  appraised  the  need  for  increased warehouse capacity in the UK and plans are being finalised for final approval. The board has agreed this in principle and the cost of this expansion will be in excess of £15 million (excluding stock holdings).


## 8

Some  progress  has  been  made  on  this  project.  The  land identified  has  been  granted  approval  and  environmental considerations  are  being  addressed  and  the  scale  of  the project agreed.


## Price increases

The increase in costs over many months has been widely reported and, we, in common with many other companies have had to increase our prices and will undoubtedly have to  do  so  again.  The  board  has  been,  and  remains,  ever conscious of the effect of price increases on demand and it was resolved that price increases should, to an extent, lag cost  increases  to  mitigate  this  risk.  As  manufacturers  we make no holding  gain  on  stock  on  hand  subsequent  to  a price increase. Many stockists make gains on the stock they hold, in effect increasing  prices  to  their customers  in advance of the adverse margin effect and this can give us a degree of knowledge of the effect of increases. The increases in cost and availability concerns that were constant through the Covid-19 crisis did seem to alleviate in the autumn of 2021 though the cost of international freight continued to climb into early 2022. This situation significantly worsened since February 2022 - when the Ukraine was invaded.

Price  increases  have  been  several  during  the  year  and continue to the time of writing. Flooring contracts can take several months from initial quotation to supply and it has become ever more difficult to hold to the initial quotations. To the extent that we have tried to work with end users on these projects margins have eroded.


## Ukraine conflict

Since February 2022 the fragility of global supply markets has  worsened  as  the  implications  of  the  Ukraine  conflict became clearer.

The board resolved that we should cease to undertake sales of  flooring  to  Russia  and  given  the  close  involvement  of Belarus  to  only  supply  the  latter  with  healthcare  related products (after a review by the board of individual projects).

The effects on UK energy costs have been widely reported but  the  implications  to  UK  manufacture  go  much  deeper. Certainly  the  cost  of  our  UK  energy  of  both  gas  and electricity  has  been  significant  but  the  effects  on  raw material supplies have also been significant. The dependency  of  many  industries  in  Europe  on  the  large refinery  and  chemical  plants  being  fed  oil  and  gas  from Russia  made  it  immediately  apparent  that  the  conflict would lead to major disruptions in supply beyond the cost of  energy.  The  Nord  Stream  1  pipe  line  supplying  gas  is significant  but  more  disruptive  to  our  supply  chain  is  the Druzhba oil pipe line. For these reasons the board resolved to try and increase stock levels. The resultant record level of year end stock is a consequence.

---

# Page 12

# 9


## Financial Director's Review

continued


## Principal business risks and uncertainties

The  ongoing  pandemic  continues  to  be  an  uncertainty, though  very  much  lower  in  our  risk  analysis  given  the vaccine roll outs across the globe. The actions we take will necessarily evolve. We have detailed procedures to minimise risk  of  transmission  within  our  business.  During  the  year with  employees  self-isolating  and  shielding  we  have struggled to run all of our production lines at once and there has  been  overtime  costs  of  employees  covering  for  those absent. Many governments have offered a range of financial support packages to help companies and these have been taken advantage of where appropriate. There is little doubt that whilst we offered secure employment there was among a  number  of  people  a  degree  of  resentment  that  other people  were  paid  to  stay  at  home,  not  within  the organisation but within the economy in general.

The situation regarding the UK leaving the EU ('Brexit') is still an ongoing uncertainty. The availability and free flow of raw materials has been disrupted and where the complexities of the pandemic have superimposed themselves  on  the  issue  of  border  controls. The  transport industry has not seen a normal period of activity and in the melee  includes  a  mix  of  increased  paperwork,  employee shortages  and  excess  demand.  The  increases  in  fuel  and energy  costs,  most  particularly  since  February  2022,  has added to the uncertainties.

The  Ukraine  conflict  has  become  a  significant  risk  and uncertainty  and  the  inter-dependencies  of  global  markets goes far beyond energy. Just one example is the effect on wood pulp and the manufacture of wood laminate flooring. This is not a flooring that we manufacture or supply but it has vastly increased in cost as a direct result of the Ukraine invasion.  Across  Europe  the  production  of  urea  has  been disrupted in Croatia, Spain, Italy and Germany which affects to  availability  of  'ad-blue'  which  is  essential  to  vehicle transport.  Just  one  example  of  the  risks  that  indirectly impact  on  our  group.  The  point  is  reported  in  the  key decisions of the year.

The board constantly assesses risks and discusses business issues regularly. To the extent risk is insurable the board is risk averse and the group is widely insured. A comprehensive insurance  appraisal  takes  place  annually  to  mitigate exposure to risks, such as business interruption and fire but obviously  key  risks  such  as  escalating  raw  material  prices and energy costs fall outside any insurable event. Inevitably the unexpected cannot be anticipated but given the depth of  understanding  of  our  principal  business  by  the  senior management,  and  the  board,  risk  is  ameliorated  but  not eliminated.

Our  goals  are  simple  and  we  avoid  over-stretching  our capabilities. During the year the unknowns associated with the pandemic were a key unknown and consequently a key risk.  Our  plans  are  not  limited  to  a  twelve  month  set  of figures, though budgets are prepared and monitored, and we look to benefit from decisions over a longer time frame. A major  mitigation  of  risk  is  a  close  understanding  of  our people,  their  motivations,  experience  and  limitations.  In general  it  is  in  the  nature  of  the  board  to  talk  about  and focus on the problems of our business. This is the major way in which risk is not merely identified but mitigated. Excess capacity exists in our businesses and across Europe.

The  risks  identified  beyond  insured  events  include  foreign exchange risk, credit risk, liquidity risk and key management. There  are,  additionally,  key  customers  and  key  suppliers which  create  dependencies.  Sales  and  purchasing  policies are  under  regular  review  to  assess  these  dependencies.  In the main, risk and control are measured and assessed from a  financial  perspective,  but  this  is  not  to  the  exclusion  of non-financial  risks  and  uncertainties.  It  is  clear  that scenarios can be envisaged where the group's activities may be  disrupted  and  little  could  be  done  to  mitigate  the negative effects.

In terms of credit risk certain companies have insurance in place  and  where  there  is  no  insurance  we  often  require letters  of  credit  or  bills  of  exchange  but  fundamentally credit  control  and  market  awareness  are  important.  Our cash balances, and bank facilities  combined with a robust balance sheet are buffers against liquidity risk.

In respect of exchange risk, the group operates internationally and is exposed to foreign exchange risk on both sales and  purchases that are denominated  in currencies other than sterling. Those giving rise to the most significant risk are US dollar, euro and Australian dollar. To mitigate risk associated with exchange rate fluctuations the group's policy is to hedge known and forecast transactions. This hedging is at least 25% and on occasion, albeit rarely, more than 100% of the next year's anticipated exposure. IFRS  7  dictates  several  disclosures  on  risk  and  we  have undertaken a market risk sensitivity analysis on fluctuations in  our  major  currency  exposure  and  the  effects  on  the financial assets and liabilities in the balance sheet (which is included in the notes to the accounts).

Several external factors can be envisaged that would affect operating activities. These include technical failures, labour disputes outside our businesses, availability of raw materials, and import or customs delays. Given the spread of  our  operating  activities  there  is  a  reduced  risk  of  any single event being catastrophic, but external factors are an area  of  risk that  continues  to  be  monitored.  Certain suppliers would be difficult to replace or their products to substitute  and  delays  could  be  of  several  weeks  duration,

---

# Page 13

which  wouldn't  be  covered  by  our  current  levels  of  stock holding.  Given  the  length  of  service  of  many  senior managers,  succession  planning  becomes  a  risk  and/or  an uncertainty but again the open style of decision making and collaboration mitigate the risk.

The activity and progress of our competitors is a significant risk.  Whether  there  is  a  new  innovation  or  a  gain  in competitive  advantage  by  a  new  process,  or  the  loss  of market  share  by  any  means,  any  effect  on  our  volume throughput  will  have  an  effect  on  profitability. The  board looks for market intelligence, and devotes significant time to understanding  the  strategy  of  our  competitors.  It  is  clear that  the  success  this  business  has  achieved  over  the  last twenty years leads our competitors to scour all information we publish for data on our activities.

I would  note  that  we  have  overseas  subsidiaries  with significant profit and assets which are translated at average exchange rates (in the case of profit and loss items) and at year  end  rates  (in  the  case  of  balance  sheet  items).  The effect of this is shown  annually  in  the  Consolidated Statement of Comprehensive Income. Inevitably there is a translational exposure on these items and since they are not necessarily  cash  flows  (excepting  dividend  payments)  the consolidated net worth of the group varies over time. We do not hedge this translational exposure though we have in the past hedged overseas assets with matching debt. At present the cost and complexity in terms of arranging facilities and complying  with  local  taxation  rules  would  seem  to outweigh the benefits.


The  last five years  of these  exposures  in  terms  of increase/(decrease) in the value of our overseas assets are as follows:
|      | £'000   |
|------|---------|
| 2022 | 926     |
| 2021 | (615)   |
| 2020 | 336     |
| 2019 | (170)   |
| 2018 | (759)   |


Aside  from  the  strategic,  operational  and  financial  risks described  there  are  also  compliance  risks  relating  to  the legal and regulatory requirements of the various markets in which  we  operate.  Directors  and  senior  management  are involved in health and safety, duty and customs clearance, waste management and other such issues.


## Defined benefit pension scheme

In common with other long established businesses we have the complications and uncertainty associated with having a 'final salary' pension scheme. The scheme has been closed to new entrants  since  2002  and  was  only  offered  to  UK  based employees;  of  our  UK  based  work  force  around  20%  of employees are  members  of  this  scheme. We  are  currently  in


## 10

consultation with members over the closure of the scheme to ongoing accrual and given the large changes in interest rates, gilt yields and the upswing in non Covid-19 related excess death we have instigated another formal valuation of the scheme. It may well  be  that  the  'deficit'  identified  at  the  last  valuation  has significantly dwindled or may be a 'surplus'.

Accounting for this defined benefit scheme is prescribed by IAS 19  and  the  quantum  of  the  deficit  or  surplus  is  ever  more volatile  due  to  the  nature  of  using  current  (higher  -  but  still historically low) gilt yields and  arguably over prudent assumptions as driven by the actuarial profession.

The  scheme  comprises  active  members  (existing  employees), deferred members (past employees not yet in retirement) and pensioners. Under the current accounting standard for pensions the current service costs of active members are dealt with in the income statement with actuarial  gains/losses  on  the  accrued benefits  dealt  with  through  the  Consolidated  Statement  of Comprehensive Income. This year there is a net actuarial gain of £7.1 million against a net actuarial gain in 2021 of £12.7 million.

Gordon Oliver

Finance Director

30 September 2022

---

# Page 14

# 11


## Section 172 Statement

The directors and the board as a collective consider that they acted in a way that would be most likely to promote the success of the company for the benefit of its members as a whole (having regard to the stakeholders and matters set out in S172(1) (a) to (f) of the Act) in the decisions taken during the year ended 30 June 2022.

The group comprises business units in various locations worldwide, all of which have engagement with their local stakeholders and other companies within the group structure. The group's governance delegation of authority allows decisions to be made at business unit level up to defined limits, which allows them to take account of the needs of their local stakeholders through their decisions implemented locally. The board routinely monitors these decisions and ultimately takes responsibility for the interaction with all stakeholders.

In consideration of major matters discussed at board level, the likely impact on all stakeholders are carefully considered and where possible, decisions are carefully explained and discussed with affected stakeholders before actions are implemented to ensure they understand and have any necessary support.

The group's key stakeholders and how we engage with them are set out below.

Stakeholder group

Shareholders

Customers


We interact with our customers through:
- Regular visits and meetings
- Industry exhibitions
- Customer site tours and presentations
- Business unit websites
- Supplying extensive samples and supporting literature
- Delivering a high standard of technical support
- Providing enhanced digital design services and support


How do we engage with them?

Members of the board have regular dialogue with institutional Investors and individual shareholders in order to develop an understanding of their views.

The AGM is an important forum for private shareholders to meet the board and ask any questions they may have, directly.

The company's website has an investors section which gives investors direct access to reports, press releases and business information. There is also a contact mailbox facility.


## How has the board considered their interests?

The board understands that shareholders require sustainable growth and value creation. In recognising this, it has implemented a policy which has resulted in increasing dividend returns and incremental shareholder returns over a sustained period.

Shareholder views, together with movements in the shareholder base, are regularly reported to and discussed by the board and their views are considered.

Our NOMAD's views on market sentiment are fed back on a regular basis, and are considered by the board where it impacts strategy.

Our strategy of attaining sustainable growth in profit and building goodwill in our brands will only be achieved through an understanding of the needs of our customers and the markets we serve.

The board regularly considers the impact on customers when considering strategic decisions, for instance the major investment in a new warehousing facility has been driven by the need to improve customer service.

---

# Page 15

Suppliers

Employees

Communities

Engagement with suppliers and business partners is achieved by holding regular meetings, regular evaluation reviews and through audits of the supplier base.

We engage with our employees through site communications, briefings, performance reviews, newsletters and notice boards. Employees are also written to individually on matters which are deemed important.

We operate from multiple sites and seek to be a good neighbour with the local communities. Where possible we create opportunities to recruit and develop local people, which helps support the local economy and look after the environment. We also support local charities through fundraising and donations.

The board has a full understanding of the importance of good community relations with both internal and external stakeholders. The impact of our operations from an environmental perspective is recognised on a local and global level. Capital expenditure projects, for example, focus on improving energy efficiency and reducing environmental emissions.

The corporate social responsibility section of the latest Polyflor Sustainability Report outlines in further detail, the group's commitment to its stakeholders, including the supply chain, employees and the communities.

The principal decisions in the year are included in the Financial Director's Review.

The  strategic  report  was  approved  by  the board of directors and signed on behalf of the board.

D N Fletcher Secretary

30 September 2022


## 12

The board recognises that relationships with the supplier base is important to the reputation and long term success of the group. There is regular dialogue between our management team and our suppliers, where quality, price, sustainability and health and safety are key to the discussions. Any matters which the board needs to be aware of are reported back as appropriate.

The board is aware that our employees are critical to the successful achievement of the strategic aims. The group prides itself on providing a friendly and safe working environment for all employees, and given the nature of our manufacturing process, health and safety is taken extremely seriously. There are a number of employees who have achieved thirty, forty and even fifty years' service. The group has operated a share scheme which enabled employees to build up personal shareholding in James Halstead plc and participate in its expansion and success.

---

# Page 16

# 13


## Report of the Directors

The directors are pleased to present their report, together with the audited accounts for the year ended 30 June 2022.


## Results and dividends

The group results for the year and the financial position at 30  June  2022 are shown  in  the  consolidated  income statement on page 30 and the consolidated balance sheet on page 32.

The  directors  are  recommending  a  final  dividend  of 5.50p (2021: 11.00p)  per share  on  the  ordinary  share  capital  for payment on 16 December 2022 to those shareholders on the register  at 18 November 2022. This final dividend together with the interim dividend of 2.25p (2021: 4.25p) per share paid  on 10 June  2022 makes  a  total  dividend  of 7.75p (2021: 15.25p) per share for the year.


## Directors

The  directors  who  held  office  during  the  year  were  as follows:

J A Wild

M Halstead

G R Oliver

S D Hall

M J Halstead

R P Whiting

Mr G R Oliver and Mr S D Hall are the directors retiring by rotation, and offer themselves for re-election at the annual general meeting.


The interests of the directors and their families in the share capital of the company were as follows:
|                                                                                          | 30 June 2022                30 June 2021                            | 30 June 2022                30 June 2021   |
|------------------------------------------------------------------------------------------|---------------------------------------------------------------------|--------------------------------------------|
| Beneficial   As Trustee    Beneficial   As Trustee                                       |                                                                     |                                            |
|                                                                                          | J A Wild              300,600  23,950,720       150,300  11,975,360 |                                            |
| M Halstead   26,505,604  22,250,344  13,252,567  11,126,112                              |                                                                     |                                            |
| G R Oliver            430,988         258,188         215,259         130,034            |                                                                     |                                            |
| S D Hall               11,400                  -           5,700                  -      |                                                                     |                                            |
| M J Halstead   1,376,234                  -       688,117                  -             |                                                                     |                                            |
| R P Whiting                   -                  -                  -                  - |                                                                     |                                            |


The  directors  consider  that  the board  of directors  include key management for all areas of the business and that there are no other key management which require disclosure.

Details  of  the  directors'  options  under  the  terms  of  the executive share option scheme are set out in note 27.


## Substantial interests


As at 16 September 2022 the company had been notified of the following interests which represent 3% or more of the existing issued share capital:
| Number                %                                                 |
|-------------------------------------------------------------------------|
| Rulegale Nominees                           73,582,520            17.7  |
| John Halstead Settlement                70,894,436            17.0      |
| Octopus Investment Nominees        26,250,579              6.3          |
| Nortrust Nominees                           12,555,794              3.0 |



## Share capital


During  the  year  new  ordinary  shares  were  issued  and allotted as fully paid to enable share options to be exercised as follows:
| 11 November 2021   | 100,000   |
|--------------------|-----------|
| 12 November 2021   | 50,000    |
| 15 November 2021   | 62,110    |
|                    | 212,110   |


The issued share capital was increased by a bonus issue of one  ordinary  share  for  each  ordinary  share  held  at 14 January 2022, amounting to 208,372,026 shares.


## Special business at the annual general meeting

Resolution 6 renews  the  directors'  authority  to  offer ordinary  shareholders  the  opportunity  to  take  ordinary shares in lieu of any cash dividends which may be payable prior to the Annual General Meeting in 2023.

Resolution 7 authorises  the  directors  to  allot relevant securities  pursuant  to  section  551  of  the  Companies Act 2006  up  to  a  maximum  nominal  amount  of  £6,945,901 representing approximately  33.33%  of  the  total ordinary share capital. The authority will expire at the next Annual General Meeting of the company to be held in 2023 or six months  after  the  next  accounting  reference  date  of  the company (whichever is the earlier).

Except for the issue of shares to satisfy the exercise of share options granted under the share schemes, the board has no present intention of issuing any ordinary share capital of the company. As  at  the  date  of  this  document,  the  company holds no treasury shares.

Resolution 8 invites  shareholders  to  renew  the  board's authority  to  issue  shares  for  cash  without  first  being required  to  offer  them pro  rata to  existing  shareholders. The proposed authority will terminate at the next Annual General Meeting of the company to be held in 2023 or six

---

# Page 17

months  after  the  next  accounting  reference  date  of  the company (whichever is earlier). The authority is limited to equity  securities  up  to  an  aggregate  nominal  amount  of 5.0%  of  the  company's  issued  ordinary  share  capital. The resolution also contains provisions to enable the directors to deal  with  fractional  entitlements  and  other  practical difficulties which could arise in the event of a rights issue or similar pre-emptive offer.

Resolution 9 seeks to renew the authority of shareholders to allow the company to purchase its own shares in respect of up to 10% of the issued capital at prices not exceeding 5% above the average of the middle market quotations for the five  business  days  preceding  the  purchase. The  directors undertake that the authority would only be exercised if the directors were satisfied that a purchase would result in an increase in expected earnings per share and was in the best interests  of  the  company  at  that  time. The  directors  may choose to hold shares purchased under such authority in the form of treasury shares (subject to a maximum of 10% of the issued ordinary share capital at any one time).


# Going concern

The directors have reviewed current performance and forecasts, combined with capital investment and expenditure commitments, and a range of trading scenarios. The group has no  net  borrowings  and  owns  the  freeholds  on  many  of  its premises (the  most  significant  being  four  UK  operating  sites and two sites in Germany).

After  considering  current  trading  and  forward  forecasts,  the directors have the reasonable expectation that the group has adequate financial resources to continue in operation, including contractual and commercial commitments, for the foreseeable future.

As the global pandemic recedes, but with many markets now facing high energy costs and supply chain concerns, the directors have considered that there may be a weakening of demand for flooring products in arriving at the conclusion above.

Fluctuations  in  exchange  rates  have  been  a  constant  factor since sterling floated in 1971. Our hedging delays the effect of sharp changes.

Working  with  our  senior  executives  we  have  considered scenarios for the purpose of the statutory audit that involve layoffs and cessation of production in the winter months and, whilst we do not believe they are likely, have been considered to assess the going concern concept. The cost and availability of international freight has continued to frustrate export sales and as part of the going concern review we have factored in the scenario that this will continue for several months.


## 14

Based on the above the directors are satisfied the group has adequate resources to continue as a going concern for at least one year from the date of approval of the financial statements.


## Employment involvement

Within the UK we have both 25 year clubs and 40 year clubs for all employees. Many employees have worked their entire career for the group, and retaining an experienced workforce is important  to  our  long  term  success.  Our  workforce retention rate is very high. Recruitment is biased to the local area,  and  we  have  a  number  of  graduate  recruits  and  offer internships  to  support younger  people  looking  to  develop their employment skills. We look to pass on knowledge and we  are  involved  in  skills  training  to  the  flooring  industry, technical knowledge  to the industry in general and involvement in the Chartered Institute of Human Resource Management's 'Skills Ahead Mentoring Project'. We have a floor fitting school for the industry and this is accessible to employees allowing them to gain skills for use in their own homes.

Promotion  or  opportunities  in  different  departments  are often recruited from within the business and is preferred to external  candidates.  The  senior  management  and  the directors  having,  in  the  main,  come  from  lower  positions within the business, including the executive directors of the main company. Our recycling partnership presents to senior management and staff on a regular basis to promote a better understanding of achievements and goals to involve more of our staff in sustainability.

We have a firm belief in equality and our main subsidiaries are SA8000  accredited  (an  independent  standard  for  decent working environments). Also BS OHAS 18001 accredits our occupational and safety management protocols.

All  our  UK  employees  are  offered  pension  scheme  benefits with company  contribution  and  the  majority of UK employees are shareholders in the company by virtue of a long  standing  employee  participation  scheme.  This  is currently being reviewed to make it even more relevant to the group  today.  On  the  more  personal  level  we  operate  a company  supported  social  club  for  employees,  we  have outdoor  seating,  we  offer  bike  sheds  and  there  are  shower facilities  at  most  sites. Also  there  are  break  out  zones  and facilities  to  either  buy  or  prepare  food  at  all  our  sites. The company looks favourably on providing time for employees to undertake voluntary work.

---

# Page 18

# 15


## Report of the Directors

continued

Across our sites there are regular consultation meetings with employee representatives (some with trade union representatives). Our employees are an important asset and are kept abreast of group performance at least twice a year. In terms of decisions directly affecting employees, communication is by line managers in the first instance, but the  directors  will  discuss  overall  matters  with  designated representatives.  In  regard  to  the  principal  decisions  of  the business the board has considered the employees as a group and their wellbeing as a whole.


## Health and safety

The health and safety of the group's employees, customers and members of the general public who may be affected by the  group's  activities  continue  to  be  matters  of  primary concern.  It  is  therefore  the  group's  policy  to  manage  its activities  so  far  as  to  avoid  causing  any  unnecessary  or unacceptable  risk  to  the  health  and  safety  of  all  those affected by its activities. In order to ensure that the group's high  standards  in  this  area  are  maintained,  a  substantial programme  of  training  and  retraining  of  employees  took place throughout the year.


## Research and development

We remain totally committed to the continuing development  of  our  processes  and  our  products  to  both satisfy  the  needs  of  our  customers  and  ensure  that  we remain at the forefront of our industry.


## Environmental policy

A policy has been issued and implemented on safeguarding against air, water, noise and land pollution. The management team constantly reviews and implements at every opportunity the most effective use of materials and energy. A  number of  control  measures  have  been  introduced  and these, combined  with  materials  storage  and  handling methods,  together  with  training,  form  the  basis  of  the environmental programme. The policy is fully endorsed by the  directors  and  is  under  constant  review  to  ensure  full compliance with the UK Environmental Protection Act 1990. All employees, suppliers and contractors are made aware of the  environmental  policy  which  is  also  freely  available  to the general public and regulatory authorities.


## Emissions and energy consumption

Scope 1 and 2 consumption and carbon dioxide emission data  has  been  calculated  in  line  with  the  2019  UK

Government  environmental  reporting  guidance.  Emissions Factor Database 2021 version 1 has been used, utilising the published kWh  gross calorific volume and kgCO 2 e emissions factors relevant for the reporting period.


|                                                                          | Year ended 30 June    | Year ended 30 June    |
|--------------------------------------------------------------------------|-----------------------|-----------------------|
|                                                                          | 2022 Tonnes of CO 2 e | 2021 Tonnes of CO 2 e |
| Scope 1 - direct emissions                                               |                       |                       |
| (UK facilities and vehicles)                                             | 9,370                 | 9,488                 |
| Scope 2 - indirect emissions (UK purchased electricity)                  | 5,464                 | 5,775                 |
| Total Scope 1 and Scope 2 emissions                                      | 14,834                | 15,263                |
| Intensity metric - total scope 1 & 2 emissions per metric tonne produced | 0.25                  | 0.28                  |
| Total UK energy consumption (kWh)                                        | 74,936,963            | 74,343,719            |


Total  Scope  1  and  Scope  2  emissions  figures  for  the  year ended 30 June 2021 have been restated by 1,992 Tonnes of CO2 e for comparability.

The group is committed to year on year improvements in operational energy efficiency. A number of energy efficiency projects continued in the year. These included the installation of  LED  lighting,  in  conjunction  with  PIR  sensors  to  ensure that lighting is not in use when not required, and lagging for extruder barrels. The group is mandated to comply with the Energy  Savings  Opportunity  Scheme  (ESOS),  and  the available energy efficiency improvements identified in phase 2  reporting  are  being  reviewed  and  implemented  where possible. Training  in  energy  conservation  and  sustainability awareness is being considered for all staff across the business in the coming year. All these projects and initiatives reinforce the commitment to implementing an Energy & Environment strategy, which reduces energy and carbon usage, and is in line with the UK's 2050 net zero targets.


## Risk management

Information  in  relation  to  risk  management  and  future developments can be found in the financial director's review in the strategic report.


## Directors' responsibilities statement

The directors are responsible for preparing the annual report and the financial statements in accordance with applicable law and regulations.

---

# Page 19

Company  law  requires  the  directors  to  prepare  financial statements  for  each  financial  year.  Under  that  law  the directors have, as required by the AIM Rules of the London Stock  Exchange,  elected  to  prepare  the  group  financial statements  in  accordance  with UK  adopted  international accounting standards. The directors have elected to prepare the  parent  company  financial  statements  in  accordance with  United  Kingdom  Generally  Accepted  Accounting Practice (United  Kingdom  Accounting  Standards  and applicable law) including Financial Reporting Standard 101 Reduced  Disclosure  Framework.  Under  company  law  the directors must not approve the financial statements unless they are satisfied that they give a true and fair view of the state of affairs of the group and the company and of the profit or loss of the group for that period.

The  directors are also required to prepare  financial statements  in  accordance  with  the  rules  of  the  London Stock  Exchange  for  companies  trading  securities  on  the Alternative Investment Market.


In  preparing  these  financial  statements  the  directors  are required to:
- select  suitable  accounting  policies  and  then  apply them consistently;
- make judgements and accounting estimates that are reasonable and prudent;
- state  whether  the  group  financial  statements  have been  prepared  in  accordance  with UK  adopted international  accounting  standards subject  to  any material  departures  disclosed  and  explained  in  the financial statements; and
- prepare the financial statements on the going concern basis  unless  it  is  inappropriate  to  presume  that  the group and company will continue in business.


The directors are responsible for keeping adequate accounting records that are sufficient to show and explain the  company's  transactions,  to  disclose  with  reasonable accuracy at any time the financial position of the company and  enable  them  to  ensure  that  the  financial  statements comply  with  the  Companies  Act  2006.  They  are  also


## 16

responsible for safeguarding the assets of the company and the  group  and  hence  for  taking  reasonable  steps  for  the prevention and detection of fraud and other irregularities.

The directors are responsible for ensuring the annual report and financial statements are made available on a website. Financial  statements  are  published  on  the  company's website  in  accordance  with  legislation  in  the  United Kingdom  governing  the  preparation  and  dissemination  of financial  statements  which  may  vary  from  legislation  in other jurisdictions.

The  directors  are  responsible  for  the  maintenance  and integrity of the corporate and financial information included on  the  company's  website. The  directors'  responsibilities also extend  to  the  ongoing  integrity  of  the  financial statements contained therein.


## Auditor

A resolution  to  re-appoint BDO  LLP  as  auditor  will  be proposed at the forthcoming annual general meeting.


## Directors' statement as to the disclosure of information to the auditor

All of the current directors have taken all the steps that they ought  to  have  taken  to  make  themselves  aware  of  any information  needed  by  the  company's  auditor  for  the purposes  of  their  audit  and  to  establish  that  the  auditor  is aware of that information. The directors are not aware of any relevant audit information of which the auditor is unaware.

Approved by the board of directors and signed on behalf of the board.

D N Fletcher Secretary

30 September 2022

---

# Page 20

# 17


## Board Report on Remuneration


## Remuneration committee

The remuneration committee comprises the non-executive directors,  with  Mr S  D  Hall,  as  chairman. The  committee meets  at  least  once  a  year,  although  usually  more frequently, to determine the remuneration packages of the executive directors of the group.

The remuneration policy for the non-executive directors is determined by the board as a whole by reference to market rates. They do not participate in the group bonus scheme, pension  scheme  or  share  option  scheme.  No  director  can vote in regard to his own remuneration.


## Remuneration policy

The remuneration policy is to provide terms of employment such that the recruitment, motivation and retention of high calibre personnel is achieved and maintained to the mutual benefit  of  shareholders  and  employees. The  committee  is assisted from time to time by data supplied by independent professional  remuneration  consultants  as  to  comparable companies,  although  identical  circumstances  are  rarely found.


## Basic salary and bonus payments

The directors' salaries and fees for the year are disclosed in note 14. Annual bonus schemes are in place which reward the executive directors on achieving performance objectives. Performance is determined by index-linked profit improvements through a trend of earnings per share growth. UK based executives are eligible members of the employee share scheme. Performance bonuses of £500,000 to each of the group chief executive and group finance director were paid  during  the  year. These  related  to  the  2021  financial year.


## Share option schemes

The  remuneration  committee  believes  that  share  option plans  are  an  important  long  term  incentive  to  executive directors and other senior employees. They are intended to link the exercise of the option to a sustained and significant improvement in the underlying financial performance of the group.

The  share  option  plan  is  reviewed  by  the  remuneration committee and is open to executive directors and selected employees of the group. The option price per ordinary share will not be less than the market value on the day of grant. A limit of four times earnings has been placed on the value of

the aggregate price payable on the exercise of all options or rights to subscribe  for  ordinary  shares  granted  to  an individual employee under the share option plan and under all other discretionary schemes.


## Pensions

The  company  operates  Inland  Revenue  Approved  defined benefit  and  defined  contribution  pension  schemes. The group  chief  executive  and  group  finance  director  are members of the defined benefit scheme. Pension entitlements are calculated on basic salary only.

All  members  of  the  schemes  are  required  to  contribute  a percentage  of  their  pensionable  earnings. Increase  in pensionable  salary is restricted  to  the increase in the consumer price index.

Other benefits within the schemes are death in service lump sums, spouse's and dependant's pensions following death in service of the member and ill health early retirement where the appropriate circumstances arise.


## Service agreements

The  chairman  and  the  group  chief  executive  do  not  have service agreements. The group finance director has a service agreement which terminates within or is terminable by the company and the executive on not more than one year's notice.  The  remuneration  committee  has  taken  the  view that notice periods of one year are reasonable and in the interests  of  both  the  company  and  its  executive  directors having regard to prevailing  market  conditions  and  current practice. Mr S D Hall, Mr M J Halstead and Mr R P Whiting each has a service contract for an initial term of two years from the date of his appointment, which can be terminated by either party by one month's written notice.

S D Hall

Chairman of the Remuneration Committee

---

# Page 21

# Corporate Governance


## Chairman's introduction to governance

The board has over many years recognised its responsibility towards  good  corporate  governance.  It  is  part  of  our character and, I believe, contributes to our ability to deliver long-term  shareholder  value. The  Financial  Reporting Council and the Quoted Company Alliance have both issued guidance on governance and having assessed these codes we have aligned our approach to the latter. In many ways this is a continuing process but in the following paragraphs we  outline  how  we  effect  this  code  and  I  trust  our shareholders will take the time to review our comments.

It  is  my  belief  that  good  governance  is  accountability  to shareholders as a whole over time rather than being swayed by current short term objectives of individual holders. For many companies some shareholders are transient and focus short  term,  looking  for  ambitious  acquisitions  or  risky strategies and yet quick to exit at the first sign of problems. Management need to be focused on the medium to long term goal as much as current issues.

Anthony Wild Chairman


## Directors and committees

The company is  controlled  by  the  board  of  directors. The board consists of a non-executive chairman, two executive directors, a senior  independent  director  and  two  nonexecutive directors.

The  board  has  two  sub  committees:  a  remuneration committee and an audit committee.

The directors are named below along with their membership of board committees.


| Director            | Role          | Remuneration Committee   | Audit Committee   |
|---------------------|---------------|--------------------------|-------------------|
| Mr Anthony Wild     | Non-executive |                          |                   |
|                     | Chairman      | X                        | X                 |
| Mr Mark Halstead    | Chief         |                          |                   |
|                     | Executive     |                          |                   |
| Mr Gordon Oliver    | Finance       |                          |                   |
|                     | Director      |                          |                   |
| Mr Steve Hall       | Senior        |                          |                   |
|                     | Independent   |                          |                   |
|                     | Director      | X                        | X                 |
| Mr Michael Halstead | Non-executive |                          |                   |
|                     | Director      | X                        | X                 |
| Mr Russell Whiting  | Non-executive |                          |                   |
|                     | Director      | X                        | X                 |



## The board


The role of the board is summarised as follows:
- To establish and maintain the group's vision, mission and values
- Decide on the current and future strategy to ensure the group's longevity
- To delegate to management the implementation of policies, strategies and business plans while ensuring the framework of internal controls is effective
- Account to shareholders and stakeholders to promote their interests and the goodwill to the group


The board comprises two executive directors and four nonexecutive  directors.  The  roles  of  chairman  and  chief executive are separated.


## Directors


## Mr Anthony Wild - non-executive Chairman

Mr Wild was appointed to the board as senior independent director  in 2001 and chairman in 2017.  He  is  a  Chartered Accountant and was senior partner in a local firm for many years offering management consultancy services. He brings a long  and  in  depth  knowledge  of  James  Halstead  plc,  its heritage and strategy over many years along with business and commercial knowledge obtained in a career of business advice. A  key  responsibility  of  the  chairman  is  to  lead  the board effectively and to oversee the adoption, delivery and communication  of  the  company's  corporate  governance model.  The  chairman  as  a  non-executive  director  has adequate separation from the day-to-day business to be able to have an independent view. The chairman ensures that the board  receives  accurate,  timely  and  clear  information  and there should be good information flows within the board and its  committees  as  well  as  between  the  NEDs  and  senior management.


## Mr Mark Halstead - Chief Executive

Mr  Halstead  has  over  30  years'  experience  in  the  group holding senior management positions within Polyflor prior to his appointment as group chief executive in 2002. Having gained his grounding in many aspects of the group's flooring activities Mr Halstead focused on exports and founded our operations in Europe. He brings unparalleled knowledge of the  group's  activities, the  products  and  positioning  in markets  and  experience  to  allow  for  the  assessment  of future opportunities for the group both in commercial terms and product related. Mr Halstead is tasked with the delivery of the business model agreed within the strategy set by the board.


## 18

---

# Page 22

# 19


## Corporate Governance


## continued


## Mr Gordon Oliver - Finance Director

Mr Oliver is a Chartered Accountant. He trained with KPMG and held a number of financial positions in industry prior to joining James Halstead in 1987 as group financial controller. He was instrumental in the disposal of non-core businesses in the UK and overseas and became finance director of the group in 1999. He brings knowledge of financial management  and  control,  corporate  governance  and business acumen to the business as well as development of future strategy arising from a long period as a member of the  board.  During  his  time  with  the  company  Mr  Oliver's standing  has  been  recognised  by  several  awards  from  his peers  and  the  financial  press.  Mr  Oliver  is  tasked  with working  closely  with  the chief executive  to  progress  the business and to have regard to mitigation of risk. In addition a  key  role  is  integrity  of  the  financial  information  and communicating to the board the financial  implications  of areas of subjective judgement.


## Mr Steve Hall - Senior independent director

Mr  Hall  was  appointed  to  the  board  in  2012  as  a  nonexecutive director. He has 21 years' experience as a director of corporate banking for the Royal Bank of Scotland where he was responsible for corporate SMEs and quoted clients. For  several  years  he  has  acted  as  a  consultant  outside  of banking  and  is  a  non-executive  director  to  a  large  retail chemist chain. He brings with him this banking experience as  well  as  broad  experience  of  mergers,  acquisitions  and disposals  and  the  financing  thereof.  One  of  the  key responsibilities of the  SID  is leading  the  performance evaluation  of  the  chairman,  or  the  search  for  a  new chairman.  As SID, Mr Hall is an alternative route of access for  shareholders  and  other  directors  who  have  a  concern that cannot be raised through the normal channels of the chair or the executive directors. Mr Hall is chairman of the remuneration and the audit committees.


## Mr Michael Halstead - non-executive director

Mr Halstead was appointed to the board in 2017. He has many years' experience in the advertising industry having been an account director for Saatchi and Saatchi and more recently  running  his  own  company  HH&S  Group  Limited. He brings general business acumen to the board along with specifics  relating  to  marketing  and  public  relations  arising from  his  background.  Mr  Halstead  provides  oversight  and scrutiny  of  the  performance  of  the  executive  directors, whilst  both  constructively  challenging  and  inspiring  them, thereby ensuring the business develops, communicates and executes the agreed strategy and operates with reference to the risk management framework. Mr Halstead is in the 4th generation after the founder and has never worked within the business but is passionate to preserve the principles of the company and to contribute to its continued success.


## Mr Russell Whiting - non-executive director

Mr Whiting  was  appointed  to  the  board  in  2017.  He  is  a local businessman and is director of a company involved in leasing of assets, Associated Credits Holdings Ltd. As well as general business acumen he brings specific understanding of business and asset financing to a broad range of commercial enterprises. He has known the group for a number of years through his business. Mr Whiting possesses the critical skills that are relevant to modern companies, which includes both technical experience and the ability to positively challenge and to listen in equal measure.


Attendance at the six board meetings during the year was as follows:
| Possible         Actual                                                                  |
|------------------------------------------------------------------------------------------|
| J A Wild                                                             6                 6 |
| M Halstead                                                       6                 6     |
| G R Oliver                                                         6                 6   |
| S D Hall                                                             6                 5 |
| M J Halstead                                                     6                 6     |
| R P Whiting                                                       6                 6    |



## Senior management team


## Mr David Drillingcourt - Corporate development director

Mr Drillingcourt is a Chartered Accountant and trained with KPMG  before  joining  the company  in  1996  as group accountant.  He  served  as finance director  at  two  of  the company's subsidiaries, Phoenix Distribution (NW) Limited (1999-2005) and Polyflor Limited (2005 - 2013). He served as company secretary (2013  - 2021).  He  was  appointed corporate development director  in  2019. Working  closely with the board and subsidiary directors, the role is designed to help support the future growth of the business across the globe.


## Internal control

The  board  has  ultimate  responsibility  for  the  system  of internal  control  operating  throughout  the  group  and  for reviewing its effectiveness. Internal control systems in any group  are  designed  to  meet  the  particular  needs  of  that group and the risks  to  which  it  is  exposed.  No  system  of internal  control  can  provide  absolute  assurance  against material  misstatement  or  loss.  The  group's  system  is designed to manage rather than eliminate the risk of failure in order to achieve business objectives and to provide the board  with  reasonable  assurance  that  potential  problems will normally be prevented or will be detected in a manner which will enable appropriate action to be taken.

---

# Page 23

The  key  procedures  which  the  directors  have  established with  a  view  to  providing  effective  internal  control  are  as follows:
- the  group  directors  are  responsible  for  establishing, maintaining  and  reviewing  the  group's  system  of internal control and meet regularly to consider group financial performance,  business  development  and management  issues,  and  to  review  these  against predetermined objectives;
- the  group  board  establishes  corporate  strategy  and business objectives. Management  of  subsidiary companies  integrate  these  objectives  into  their business  strategies  for  presentation  to  the  group board with supporting financial objectives;
- subsidiary company budgets, containing financial and operating  targets,  capital  expenditure  proposals  and performance/profitability indicators, are presented to and  reviewed  by  the  group  executive  directors. The consolidated group budget is approved by the group board;
- there is an ongoing process for identifying, evaluating and managing the significant risks faced by the group. These risks are appraised and evaluated by responsible  executives  and  endorsed  by  subsidiary and  group  management.  This  process  has  been  in place  throughout  the  year  and  up  to  the  date  of approval of the annual accounts;
- as  part  of  the  regular  monitoring  and  review,  the group executive directors hold regular meetings with the  management  of  the  subsidiary  companies  at which  reports  covering  such  areas  as  forecasts, business development, strategic planning, risk exposure  and  performance  against  budget,  are presented and discussed. These are then reported to the group board, on a quarterly basis;
- the  group  board  reviews  and  considers  any  major problem which may have occurred and assesses how the risks have changed in the period under review;
- there is a group-wide policy governing appraisal and approval of capital expenditure and asset disposals;
- to  underpin  the  effectiveness  of  controls,  it  is  the group's  policy  to  recruit  management  and  staff  of high  calibre, integrity and  appropriate  disciplines. High  standards  of  integrity,  business  ethics  and compliance  with  laws,  regulations  and  internal policies are demanded from staff at all levels;



## 20


- the audit committee  keeps under review the effectiveness  of  the  system  of  internal  control  and reports its conclusions to the full board;
- the  board  also  conducts  an  assessment  of  the effectiveness of the internal control system. This assessment  consists  of  a  review  of  all  the significant  areas  of  internal  control,  including  risk assessment, the control environment, control activities, information  and  communication,  and monitoring.



## The Quoted Company Alliance Code ('QCA code')

The directors recognise the importance of good corporate governance and have chosen to apply the QCA code as their framework to do so. The QCA code was developed by the Quoted Company Alliance in consultation with a number of institutional small company investors as an alternative code applicable to AIM companies. The QCA code was published in April 2018.

The QCA code sets out ten principles which seek to ensure that  the  overall  framework  for  corporate  governance  is robust.  The  directors believe that this framework  is appropriate to the size and operations of the business and each of the principles is commented on below. Many of the disclosures  relevant  to  the  code  are  already  made  in  our annual report and accounts.

The chairman has the responsibility for corporate governance  and  has  taken  a  lead  on  this  matter.  The executive team are directed with day to day management and are accountable to the rest of the board. The chairman expects and demands open discussion of issues facing the business and in the application of this code has sought input from the auditors, the company's advisors and a review by the  company  lawyer. The  board  is  tasked  with  continuing the  success  of  the  business  over  time  and  through successive generations of management and the importance of corporate  governance  is  to  oversee  the  division  of ownership and stewardship. The executive directors have the day to day responsibility of stewardship and the chairman and non-executives monitor and evaluate this on behalf of the owners.

James  Halstead  plc  has  been  listed  on  the  London  stock exchange for over 70 years and continues to look for growth in sales and profit to continue its strong record of reward to shareholders in the form of dividend. Whilst this is a primary role, the board is proud of its reputation within its industry and the financial markets and corporate control is central to the ethos.

---

# Page 24

# 21


## Corporate Governance


## continued

The disclosures below were last reviewed and approved by the board on 30 September 2022.


## QCA Principles and James Halstead plc's approach


## 1. Establish a strategy and business model which promote long-term value for shareholders

James Halstead plc's strategy is explained fully within our Strategic  Report  section  in  our  Report  and Accounts  each financial year.

Our strategy is focussed on stable profitable growth from building the goodwill in our brands and products leading to increasing dividends over time.

Key  risks  and  mitigating  factors  to  our  business  are  also detailed annually in our Report and Accounts.


## 2. Seek  to  understand  and  meet  shareholder  needs  and expectations

The board has a track record of increasing  dividends  over many  years.  Where  the  business  has  generated  funds  in excess  of  its  medium-term  requirements  and  no  specific investment requirements exist the board has also encouraged the payment of special dividends over the years.

Members of the  board  talk  regularly  to  both  institutional and private investors and the financial press to ensure that company's strategy and objectives are communicated. The group has a large number of shareholders and regular broker updates are published.

The  company  regularly  hosts  institution  and  broker  site visits to update on progress and the executive directors are in ongoing  contact  with  the  nominated  advisor  who communicates more closely with the market.

Shareholders  can  contact  the company secretary  with questions and may be referred to the directors.

In addition, the AGM acts as a forum for all shareholders to meet with the board and raise any questions they may have.


- 3. Take into account wider stakeholder and social responsibilities  and  their  implications  for  long-term success.


The board recognises that the group has responsibilities to many stakeholders other than its shareholders. This includes employees, customers, suppliers and the wider societies in which we operate.

In terms of communications with stakeholders this is done in  ways  appropriate  to  the  stakeholder  and  may  take  the

form  of  formal  announcements,  individual  meetings  (for example appraisals with employees) and negotiations with other stakeholders.

The  environmental  impact  of  our  manufacturing  and  our output  is  of  significant  importance  to  our  medium  term prospects not only to demonstrate our commitment to the community at large but also to customers who increasingly, and rightly, look for suppliers with strong ethical values.

As a member of the communities in which we operate the board takes seriously the impact the business has, positively in  terms  of  being  an  employer  and  seeking  continuous improvement with respect to the impact on the environment  and  communities.  This  is  illustrated  by  our annual 'Sustainability Report' copies of which are available on  www.polyflor.com  which  outlines  the  impact  of  our manufacturing  operations  on  the  wider  environment  and improvements over time. Feedback from the local community  is  received  directly  to  the  head  office.  This report has been published for nearly two decades and is now an annual report.

We  understand  continuous  development  of  our  products also contributes to our responsibilities as well as the success of the business.  This is illustrated, for example,  by development of 'dementia friendly' flooring in recent years.

The operating businesses encourage feedback from customers  through  their  relationship  managers  in  the business and customer service teams.


## 4. Embed  effective  risk  management,  considering  both opportunities and threats, throughout the organisation.

Risk  management  is  reported  annually  in  our  Report  and Accounts along with how those risks are mitigated and how they change over time.

The board meets six times a year during which business and other  risks  are  assessed.  Key  subsidiaries  have  their  own management boards which meet regularly and assess the risks relevant  to  that  specific business  and  relevant responses.  These  are  communicated  to  the  main  board either  by  direct  representation  or  via  group  management structures  that  are  in  place.  There  are  also  formal  and informal  communication  routes  that  allow  for  risks  to  be communicated to board members in a timely manner from all operational entities.


## 5. Maintain  the  board  as  a  well-functioning,  balanced team led by the chair.

Anthony Wild, the non-executive chairman is responsible for the  running  of  the  board  and  Mark  Halstead  as  chief executive  has  responsibility  for  implementation  of  the board's direction.

---

# Page 25

A monthly report is provided to the board of the financial and operational performance  of  the  group.  Information  is provided in advance of meetings.

The  board  is  responsible  for  all  strategic  decisions  and  the overall governance and culture of the group.

All the directors have access to the services and advice of the company  secretary  and  are  able  to  take  independent professional advice to enable them to do so. This may be done at the group's expense.

The  board  has  a  majority  of  non-executive  directors  and consider that they bring independent thought and judgement to bear as well as business experience out-with the group.

The board has sub committees  with  specific remits, specifically remuneration and audit committees and detail of the number of meetings and attendance by directors is noted in the Annual Report.


## 6. Ensure  that  between  them  the  directors  have  the necessary up-to-date experience, skills and capabilities

The  board  evaluates consistently those skills that are required  and  whether  they  are  adequately  provided  for.  In doing so and where relevant it will consider guidance available on appointment and training of board members. The Company Secretary  has  the  responsibility  to  make  the  board  aware  of legal changes and will advise on the company's approach. For example  the  recent  GDPR  requirements  and  previously  the Market Abuse Regulations (MAR).

The company secretary supports the chairman in addressing the training and development needs of the directors. In the case of new directors there is an induction process to ensure they become aware of the operations of the group.

The  directors  are  aware  of  their  individual  responsibility  to undertake appropriate continuing development.


## 7. Evaluate board performance based on clear and relevant objectives seeing continuous improvement.

The  board  will  take  account  of  the  Financial  Reporting Council's Guidance on Board Effectiveness as it evaluates on a regular basis its performance. The remuneration committee meets formally and is tasked with not only the remuneration of the executive directors but also evaluation of performance. To this end the board is circulated with press comment and market feedback on the business. Market share data and peer group analysis is available.


## 22

In terms of the financial performance the auditors meet the audit  committee  (comprising  the  non-executives)  biannually and beyond the audit report do comment on the systems, procedures and efficacy of the management. The nominated advisor has access to the Chairman and meets the non-executives annually.

A  rigorous  recruitment  process  is  undertaken  for  new directors prior to their proposal and election. In terms of reelection  their  performance  is  reconsidered  prior  to  them being proposed to ensure they remain effective in their role and that they retain their independence.

Re-election is considered by the shareholders at the AGM at which  shareholders  have  the  opportunity  as  a  body  to approve  or  otherwise  board  membership.  Succession planning  for  the  board  and  as  importantly  the  key executives around the world who manage our businesses is an ongoing topic of discussion.


## 8. Promote  a  corporate  culture  that  is  based  on  ethical values and behaviours.

The  board  expects  the  highest  ethical  standards  of  its members and management across the group.

The group has documented procedures with respect to its responsibilities regarding  ethical  behaviour,  specifically bribery and corrupt practices and modern slavery and these are  applicable  across  its  operations  including  supply  and customer chains.

The  board  also  takes  seriously  its  responsibilities  towards sustainability  of  its  operations  and  the  impact  of  our operations  on  the  environment.  This  is  documented  and reported on annually in Polyflor's Sustainability Report.

As  an  employer  and  member  of  many  communities throughout the world, the board consider that strong ethical values to be a good member of these communities is a mindset not one underpinned by rules and procedures. Ensuring, via recruitment  processes  and  cultural  values  that  this cascades  through  the  business  is  critical  to  ensuring  the group is a 'good member of the community'. All directors of the group's companies are expected to comply and are given a manual  on  procedures  and  expectations.  This  covers authority levels and gives guidance on appropriate behaviour.

Ultimately  service  contracts  underpin  this  by  indicating behaviour that can be deemed a breach of contract and the directors are clear about their statutory duties as formally set out in sections 171 - 177 of the Companies Act 2006.

---

# Page 26

# 23


## Corporate Governance


## continued


- 9. Maintain governance structures and processes that are fit for purpose and support good decision making by the board


Corporate  governance  disclosures  are  assessed  at  least annually, including whether the structures and processes are fit for purpose.

The  board  retains  ultimate  accountability  for  maintaining good governance. The executive directors are responsible for the day-to-day operational management of the group and the  non-executive  directors  are  responsible  for  bringing their independent  and  objective  judgement  to  board discussions and decisions. The roles of chairman and chief executive  are  split  in  accordance  with  best  practice.  The board  are  responsible  for  the  implementation  of  strategy, the achievement of performance and ensuring the framework  of  internal  controls  is  effective. The  board  has delegated specific responsibilities to the audit and remuneration committees.

The audit committee assists the board by ensuring that the financial performance of the group is properly reported. It oversees  and  reviews  the  internal  control  processes,  its relationship  with  external  auditors  and  the  process  for ensuring  compliance  with  laws,  regulations  and  corporate governance.

The remuneration committee is responsible for establishing a formal and transparent procedure for developing policy on remuneration  and  to  set  the  remuneration  packages  of individual  directors,  including,  where  appropriate,  bonuses, incentive payments and share options.

Due the nature and size of the company, the directors have determined that a nomination committee is not necessary and that issues concerning the nomination of directors will be dealt with by the board directly.


- 10. Communicate  how  the  company  is  governed  and  is performing by maintaining a dialogue with shareholders and other relevant stakeholders


The  AGM  is  a  key  forum  for  communications  with  any shareholders  who  wish  to  attend,  and  the  directors  are available here to listen to views expressed both formally and informally.  This combined  with  the  normal  cycle  of announcements is the key method of communication. The outcome of resolutions put to the AGM are published and are available on the company website.

In terms  of  publication  of  results,  the  company  uses  the Stock Exchange regulatory news service (RNS) to advise the market  (i.e.  shareholders  and  others)  of  performance  and significant matters. As a group we do not find social media (Facebook, twitter etc.) an appropriate medium  for dissemination of news due to the 'sound-bite' nature of the medium. Brokers are updated and circulate notes regularly.

The  group  has,  where  appropriate,  communications  with major institutional and private shareholders and encourages dialogue.

---

# Page 27

# 24


## Independent  Auditor's  Report  to  the  Members  of James Halstead plc


## Opinion on the financial statements


In our opinion:
- the financial statements give a true and fair view of the state of the group's and of the parent company's affairs as at 30 June 2022 and of the group's profit for the year then ended;
- the  group  financial  statements  have  been  properly prepared in accordance with UK adopted international accounting standards;
- the parent company financial statements have been properly prepared in accordance with United Kingdom Generally Accepted Accounting Practice; and
- the  financial statements  have  been  prepared  in accordance with the requirements of the Companies Act 2006.


We  have  audited  the  financial  statements  of  James Halstead plc (the 'parent company') and its subsidiaries (the 'group') for the year ended 30 June 2022 which comprise the  Consolidated  Income  Statement,  the  Consolidated Statement of Comprehensive Income, the Consolidated and the Parent Company Balance Sheets, the Consolidated and Parent  Company  Statement  of  Changes  in  Equity,  the Consolidated  Cash  Flow  Statement  and  notes  to  the consolidated  and  Parent  Company  financial  statements, including a summary of significant accounting policies.

The financial reporting framework that has been applied in the  preparation  of  the  group  financial  statements  is applicable  law  and  UK  adopted  international  accounting standards. The financial reporting framework that has been applied in the preparation of the parent company financial statements is applicable law and United Kingdom Accounting Standards, including Financial Reporting Standard  101  Reduced  Disclosure  Framework  (United Kingdom Generally Accepted Accounting Practice).


## Basis for opinion

We conducted our audit in accordance with International Standards on Auditing (UK) (ISAs (UK)) and applicable law. Our  responsibilities  under  those  standards  are  further described in the Auditor's responsibilities for the audit of the financial statements section of our report. We believe that the  audit  evidence  we  have  obtained  is  sufficient  and appropriate to provide a basis for our opinion.


## Independence

We  remain  independent  of  the  group  and  the  parent company in accordance with the ethical requirements that are relevant to our audit of the financial statements in the UK, including the FRC's Ethical Standard as applied to listed entities, and we have fulfilled our other ethical responsibilities in accordance with these requirements.


## Conclusions relating to going concern


In auditing the financial statements, we have concluded that the directors' use of the going concern basis of accounting in the preparation of the financial statements is appropriate. Our  evaluation  of  the  directors'  assessment  of  the  group and the parent company's ability to continue to adopt the going concern basis of accounting included:
- Examining  the  directors'  business  plan  covering  the period to October 2023. We examined the cash flow forecasts for key judgements, verifying to source data as appropriate,  as  well  as  considering  downside sensitivities to these;
- Testing  their mechanical  accuracy  and  assessing historical forecast accuracy;
- Challenge  of  the  directors'  stress  test  scenarios including levers available to the directors to mitigate the impacts;
- Challenge  of  the  directors  on  the  key  assumptions included in the scenarios and confirmed the directors' mitigating actions are within their control; and
- Assessing the adequacy of the disclosures within the financial statements relating to the directors' assessment of the going concern basis of preparation.


Based  on  the  work  we  have  performed,  we  have  not identified  any  material  uncertainties  relating  to  events  or conditions  that,  individually  or  collectively,  may  cast significant  doubt  on  the  group  and  the  parent  company's ability to continue as a going concern for a period of at least twelve  months  from  when  the  financial  statements  are authorised for issue.

Our responsibilities and the responsibilities of the directors with respect to going concern are described in the relevant sections of this report.

---

# Page 28

# 25


## Independent Auditor's Report to the Members of James Halstead plc continued


## Overview


## Coverage


- 99% (2021: 97%) of Group profit before tax
- 90% (2021: 90%) of Group revenue
- 95% (2021: 96%) of Group total assets



## Key audit matters


|                            | 2022       | 2021       |
|----------------------------|------------|------------|
| Inventory provisioning     | /.notdef ✓ | /.notdef ✓ |
| Pension scheme assumptions | /.notdef ✓ | /.notdef ✓ |



## Materiality

Group  financial  statements  as  a  whole: £2.60m  (2021: £2.56m)  based  on  5%  of  profit  before  tax  (2021:  5%  of profit before tax).


## An overview of the scope of our audit

Our group audit was scoped by obtaining an understanding of  the  group  and  its  environment,  including  the  group's system  of  internal  control,  and  assessing  the  risks  of material misstatement in the financial statements. We also addressed  the  risk  of  management  override  of  internal controls, including assessing whether there was evidence of bias  by  the  directors  that  may  have  represented  a  risk  of material misstatement.

Our  group  audit  scope  focused  on  the  group's  principal operating  locations  being  the  United  Kingdom,  Germany and Australia. The operations in the United Kingdom, which were deemed to be significant components, were subject to a  full  scope  audit  given  the  statutory  audit  requirements whilst the significant components in Germany and Australia were  also  subject  to  a  full  scope  audit  to  component materiality. The German component was audited by a nonBDO member firm. The Australian component was audited by a BDO member firm. The remaining components of the group were considered non-significant and these components  were  principally  subject  to  analytical  review procedures by the group engagement team.


## Our involvement with component auditors

For  the  work  performed  by  component  auditors,  we determined the level of involvement needed in order to be able  to  conclude  whether  sufficient  appropriate  audit evidence has been obtained as a basis for our opinion on the group  financial  statements  as  a  whole.  Our  involvement with component auditors included the following:

The  German  operations  form  a  significant  part  of  group turnover and profitability. As part of our audit strategy, the Responsible  Individual  and  senior  members  of  the  group audit  team  were  involved  during  the  planning  and  risk assessment process of the German component in addition to during the completion of detailed audit procedures. We attended key meetings with component management and auditors, and reviewed component auditor work papers.

The Australian operations form a further significant part of group turnover and profits. Again the Responsible Individual and senior members of the group audit team were involved at all stages of the audit process, directing the planning and risk  assessment  work  performed  through  calls  with  the component auditors and local management. Reviews of the component auditor working papers were also completed.


## Key audit matters

Key audit matters are those matters that, in our professional judgement,  were  of  most  significance  in  our  audit  of  the financial statements of the current period and include the most  significant  assessed  risks  of  material  misstatement (whether or not due to fraud) that we identified, including those  which  had  the  greatest  effect  on:  the  overall  audit strategy, the  allocation  of  resources  in  the  audit,  and directing the efforts of the engagement team. These matters were addressed in the context of our audit of the financial statements as a whole, and in forming our opinion thereon, and we do not provide a separate opinion on these matters.


## Key audit matter - Inventory provisioning

As described in Note 2 (accounting policies) and Note 19 (inventories),  the  group  carries  inventory  at  the  lower  of cost and net realisable value.

Provision  is made  against  slow  moving,  obsolete  and damaged inventories. As  at  30  June  2022,  the  group  held inventories of £112.3m (2021: £60.7m).

This  area  represented  a  key  audit  matter  as  significant management judgement is required to assess the appropriate  level  of  provisioning  for  items  which  may  be sold below cost or written off as a result of a reduction in consumer  demand  particularly in light of changing consumer tastes and new products being developed. Such judgements include management's expectations for future sales.

---

# Page 29

# How  the  scope  of  our  audit  addressed  the  key audit matter

We obtained evidence concerning management's assumptions  applied  in  calculating  the  value  of  inventory provisions by:

Challenging the group's inventory provisioning policy with specific consideration given to slow moving or obsolete  stock  lines.  This  involved  a  review  of production and sales records for a sample of products to ascertain when they were last made or sold and whether they had been appropriately provided for;

assessing  the  appropriateness  of  the  percentages applied  within  the  provision  by  reviewing  historic sales and the ageing of stock; and

testing of a sample of inventory to confirm it is held at the lower of cost and net realisable value, through comparison to invoices for cost and sales prices.

We also audited the basis of stock provisioning applied by all group entities and considered whether these were being applied consistently and reflected the nature of the stock held in each location.

Key observation: Our work did not highlight evidence that the method of inventory provision was inappropriate.


## Key audit matter - Pension scheme assumptions

As described in Note 2 (accounting policies) and Note 26 (retirement  benefit  obligations),  the  group  has  a  defined benefit pension plan in the UK.

At  30  June  2022,  the  group  recorded  a  net  retirement benefit  of  £6.1m  (2021:  £4.4m  obligation),  comprising scheme  assets  of  £69.2m  (2021:  £77.3m)  and  scheme liabilities of £63.1m (2021: £81.6m).

The pension valuation is  dependent  on  market  conditions and  key  assumptions  made  by  management,  in  particular relating  to  investment  markets,  discount  rate,  inflation expectations and life expectancy assumptions.

This area and the related disclosures represented a key audit matter  given  that  the  setting  of  these  assumptions  is complex and requires the exercise of significant management  judgement  with  the  support  of  third  party actuaries.


## 26

In testing the pension valuation, with the help of external pension  actuarial  experts,  we  reviewed  the  key  actuarial assumptions  used,  both  financial  and  demographic,  and considered the appropriateness of the methodology utilised to derive these assumptions.

We  benchmarked  the  scheme  assumptions  against  other schemes  of  a  similar  size  and  profile.  Specifically, we challenged  the  discount  rate,  inflation  and  mortality assumptions  applied  in  the  calculation  by  using  pension experts  to  benchmark  the  assumptions  applied  against comparable third party data and assessed the appropriateness  of  the  assumptions  in  the  context  of  the group's  own  position. We  have  also  performed  sensitivity analysis on the assumptions determined by the directors.

We  have  tested  the  accuracy  of  the  scheme  asset statements  by  reference  to  service  organisation  control reports  to  gain  assurance  over  the  robustness  of  the provider's internal controls. Further, we have sample tested assets to third party sources in order to confirm ownership and valuation

Furthermore,  we  have  assessed  the  disclosure  of  the  net pension asset and the related assumptions and sensitivities in the financial statements against the relevant accounting framework.

Key  observation:  We  have  not  identified  any  evidence  to suggest that the methodology and assumptions applied in relation to determining the pension valuation are not within an acceptable range. Furthermore, the disclosures made are in accordance with the relevant accounting framework.


## Our application of materiality

We apply the concept of materiality both in planning and performing  our  audit,  and  in  evaluating  the  effect  of misstatements. We consider materiality to be the magnitude  by  which  misstatements,  including  omissions, could influence the economic decisions of reasonable users that are taken on the basis of the financial statements.

In order  to  reduce  to  an  appropriately  low  level  the probability that any misstatements exceed materiality, we use  a  lower  materiality  level,  performance  materiality,  to determine  the  extent  of  testing  needed.  Importantly, misstatements  below  these  levels  will  not  necessarily  be evaluated  as  immaterial  as  we  also  take  account  of  the nature  of  identified  misstatements,  and  the  particular circumstances  of  their  occurrence,  when  evaluating  their effect on the financial statements as a whole.

---

# Page 30

# 27


## Independent Auditor's Report to the Members of James Halstead plc continued

Based  on  our  professional  judgement,  we  determined materiality  for  the  financial  statements  as  a  whole  and performance materiality as follows:

Group financial statements

2022

2021

Materiality

£2.60m

£2.56m

Basis for determining

materiality

5% of profit before tax

5% of profit before tax

Performance materiality

£1.69m

£1.67m

Parent company financial statements

2022

2021

Materiality

£1.61m

£1.66m

Basis for determining materiality

5% of profit before tax.

5% of profit before tax. For the purposes of the group audit, the amount above was restricted to component materiality.

.

Performance materiality £1.05m

£1.08m

Rationale  for  the  benchmark  applied -Pre-tax  profit  is determined  to  be  a  stable  basis  of  assessing  business performance and is considered to be the most significant determinant of performance used by shareholders.

Basis for determining performance materiality - 65% of the above  materiality  level. This  is  considered  the  appropriate basis given the multiple significant components across three geographic regions (United Kingdom, Germany and Australia),  the  level  of  misstatements  in  the  past  and  our overall risk assessment.


## Component materiality

We set materiality  for  each  significant  component  of  the group based on a percentage of between 20% and 70% of group materiality dependent on the size and our assessment of  the  risk  of  material  misstatement  of  that  component. Component materiality ranged from £0.52m to £1.82m. In the audit of each component, we further applied performance  materiality  levels  of  65%  of  the  component materiality to our testing to ensure that the risk of errors exceeding component materiality was appropriately mitigated.


## Reporting threshold

We agreed with the Audit Committee that we would report to them all individual audit differences in excess of £52,000 (2021: £51,260). We also agreed to report differences below this  threshold  that,  in  our  view,  warranted  reporting  on qualitative grounds.


## Other information

The directors are responsible for the other information. The other  information  comprises  the  information  included  in the  Report  and  Accounts  2022  other  than  the  financial statements and our auditor's report thereon. Our opinion on  the  financial  statements  does  not  cover  the  other information and, except to the extent otherwise explicitly stated  in  our  report,  we  do  not  express  any  form  of assurance conclusion thereon. Our responsibility is to read the other information and, in doing so, consider whether the other  information  is  materially  inconsistent  with  the financial  statements  or  our  knowledge  obtained  in  the course of the audit, or otherwise appears to be materially misstated.  If  we  identify  such  material  inconsistencies  or apparent  material  misstatements,  we  are  required  to determine whether this gives rise to a material misstatement  in  the  financial  statements  themselves.  If, based on the work we have performed, we conclude that there is a material misstatement of this other information, we are required to report that fact.

We have nothing to report in this regard.


## Other Companies Act 2006 reporting

Based on the responsibilities described below and our work performed during the course of the audit, we are required by the Companies Act 2006 and ISAs (UK) to report on certain opinions and matters as described below.


## Strategic report and directors' report


In our opinion, based on the work undertaken in the course of the audit:
- the information given in the Strategic report and the Directors' report for the financial year for which the financial statements are prepared is consistent with the financial statements; and
- the  Strategic  report  and  the  Directors'  report  have been  prepared  in  accordance  with  applicable  legal requirements.


In  the  light  of  the  knowledge  and  understanding  of  the group and parent company and its environment obtained in the  course  of  the  audit,  we  have  not  identified  material misstatements  in  the  Strategic  report  or  the  Directors' report.

---

# Page 31

# Matters  on  which  we  are  required  to  report  by exception


We  have  nothing  to  report  in  respect  of  the  following matters  in  relation  to  which  the  Companies  Act  2006 requires us to report to you if, in our opinion:
- adequate accounting records have not been kept by the  parent  company,  or  returns  adequate  for  our audit  have  not  been  received  from  branches  not visited by us; or
- the parent company financial statements are not in agreement with the accounting records and returns; or
- certain disclosures of directors' remuneration specified by law are not made; or
- we  have  not  received  all  the  information  and explanations we require for our audit.



## Responsibilities of directors

As  explained  more  fully  in  the  directors'  responsibilities statement, the directors are responsible for the preparation of the financial statements and for being satisfied that they give a true and fair view, and for such internal control as the directors determine is necessary to enable the preparation of financial statements  that  are  free  from  material misstatement, whether due to fraud or error.

In  preparing  the  financial  statements,  the  directors  are responsible  for  assessing  the  group's  and  the  parent company's ability to continue as a going concern, disclosing, as  applicable,  matters  related  to  going  concern  and  using the going concern basis of accounting unless the directors either intend to liquidate the group or the parent company or to cease operations, or have no realistic alternative but to do so.


## Auditor's responsibilities for the audit of the financial statements

Our  objectives  are  to  obtain  reasonable  assurance  about whether the financial statements as a whole are free from material misstatement, whether due to fraud or error, and to  issue  an  auditor's  report  that  includes  our  opinion. Reasonable assurance is a high level of assurance, but is not a  guarantee  that  an  audit  conducted  in  accordance  with ISAs (UK) will always detect a material misstatement when it exists. Misstatements can arise from fraud or error and are considered material if, individually or in the aggregate, they could  reasonably  be  expected  to  influence  the  economic decisions  of  users  taken  on  the  basis  of  these  financial statements.


## 28


## Extent to which the audit was capable of detecting irregularities, including fraud

Irregularities, including fraud, are instances of noncompliance with laws and regulations. We design procedures in line with our responsibilities, outlined above, to detect material misstatements in respect of irregularities, including  fraud.  The  extent  to  which  our  procedures  are capable of detecting irregularities, including fraud is detailed below.

Based on our understanding and accumulated knowledge of the group and the sector in which it operates we considered the  risk  of  acts  by  the  group  which  were  contrary  to applicable laws and regulations, including fraud and whether such  actions  or  non-compliance  might  have  a  material effect on the financial statements. These included but were not limited to those that relate to the form and content of the  financial  statements,  such  as  the  group  accounting policies, international accounting standards, the UK Companies Act 2006 and the QCA Code; those that relate to the  payment  of  employees;  and  industry  related  such  as compliance with health and safety requirements.

We assessed the susceptibility of the financial statements to  material  misstatement  including  fraud  and  evaluated management's incentives and opportunities for fraudulent manipulation of the financial statements (including the risk of  override  of  controls)  and  determined  that  the  principal risks  were  related  to  posting  inappropriate  journal  entries, revenue  recognition  and  management  bias  in  accounting estimates.


Our audit procedures included, but were not limited to:
- Obtaining an understanding of the control environment in monitoring compliance with laws and regulations;
- Enquiring  of management  concerning  potential litigations and claims;
- Performing  analytical  procedures  to  identify  any unusual or unexpected  relationships that may indicate risks of material misstatement due to fraud;
- Reading minutes of meetings of those charged with governance;
- Challenging  assumptions  and  judgements  made  by management in their significant accounting estimates,  in  particular  in  relation  to  the  group's defined  benefit  pension  scheme  liabilities,  accruals, stock provisions (as set out in the key audit matters section above) and forecasts used within impairment models utilised to assess goodwill impairment;

---

# Page 32

# 29


## Independent Auditor's Report to the Members of James Halstead plc continued


- A  critical assessment  of  the  consolidation  and consideration  of  manual  or  late  journals  posted  at consolidation level;
- Identification  and  testing  of  journal  entries,  in particular  any  journal  entries  posted  with  unusual account combinations or including specific keywords using data analytics; and
- Agreement of the financial statement disclosures to underlying supporting documentation.


We communicated relevant identified laws and regulations and potential fraud risks to all engagement team members, including  the  component  auditors,  and  remained  alert  to any indications of fraud or non-compliance with laws and regulations  throughout  the  audit.  Our  audit  procedures were designed to respond to risks of material misstatement in the financial statements, recognising that the risk of not detecting  a  material  misstatement  due  to  fraud  is  higher than the risk of not detecting one resulting from error, as fraud may involve deliberate concealment by, for example, forgery,  misrepresentations or through collusion. There are inherent limitations in the audit procedures performed and the  further removed  non-compliance  with  laws  and regulations is from the events and transactions reflected in the financial statements, the less likely we are to become aware of it.

A further description of our responsibilities is available on the Financial Reporting Council's website at: www.frc.org.uk/auditorsresponsibilities.  This  description forms part of our auditor's report.


## Use of our report

This  report  is made  solely  to  the  parent  company's members, as a body, in accordance with Chapter 3 of Part 16 of  the  Companies  Act  2006.  Our  audit  work  has  been undertaken so that we might state to the parent company's members those matters we are required to state to them in an auditor's report and for no other purpose. To the fullest extent  permitted  by  law,  we  do  not  accept  or  assume responsibility to anyone other than the parent company and the  parent  company's  members  as  a  body,  for  our  audit work, for this report, or for the opinions we have formed.

Stuart Wood (Senior Statutory Auditor) For and on behalf of BDO LLP, Statutory Auditor Manchester United Kingdom 30 September 2022

BDO  LLP  is  a  limited  liability  partnership  registered  in England and Wales (with registered number OC305127).

---

# Page 33

# Consolidated Income Statement

for the year ended 30 June 2022


| Note                                       2022                                   2021                                                                                                                 | £'000                                  £'000   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------|
| Revenue                                                                                                   5                                        291,860                              266,362        |                                                |
| Cost of sales                                                                                                                                     (178,355)                           (154,722)        |                                                |
| Gross profit                                                                                                                                        113,505                              111,640       |                                                |
| Selling and distribution costs                                                                                                             (50,316)                             (46,335)               |                                                |
| Administration expenses                                                                                                                    (10,931)                             (13,532)               |                                                |
| Operating profit                                                                                                                                  52,258                                51,773         |                                                |
| Finance income                                                                                       9                                                 42                                       48     |                                                |
| Finance cost                                                                                            10                                            (237)                                  (553)     |                                                |
| Profit before income tax                                                                         7                                          52,063                                51,268               |                                                |
| Income tax expense                                                                                11                                       (11,735)                             (11,407)               |                                                |
| Profit for the year attributable to equity shareholders                                                                      40,328                                39,861                              |                                                |
| Earnings per ordinary share of 5p                                                                                                                                                                      |                                                |
| - basic                                                                                                     12                                            9.7p                                    9.6p |                                                |
| - diluted                                                                                                  12                                            9.7p                                    9.6p  |                                                |


All amounts relate to continuing operations.

Details of dividends paid and proposed are given in note 13.

The earnings per ordinary share of 5p for the year ended 30 June 2021 have been restated for the effect of the one-for-one bonus issue on 14 January 2022


## 30

---

# Page 34

# 31


## Consolidated Statement of Comprehensive Income

for the year ended 30 June 2022


| Profit for the year                                                                                                                       40,328                             39,861   | Note                                       2022                                   2021                                                                                                                                                     £'000                                  £'000   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Other comprehensive income net of tax:                                                                                                                                                |                                                                                                                                                                                                                                                                                           |
| Items that will not be reclassified subsequently                                                                                                                                      |                                                                                                                                                                                                                                                                                           |
| to the income statement:                                                                                                                                                              |                                                                                                                                                                                                                                                                                           |
| Remeasurement of the net defined benefit liability                          26                                          7,090                                12,708                   |                                                                                                                                                                                                                                                                                           |
| 7,090                                12,708                                                                                                                                           |                                                                                                                                                                                                                                                                                           |
| Items that could be reclassified subsequently                                                                                                                                         |                                                                                                                                                                                                                                                                                           |
| to the income statement if specific conditions are met:                                                                                                                               |                                                                                                                                                                                                                                                                                           |
| Foreign currency translation differences                                                                                             926                                   (615)      |                                                                                                                                                                                                                                                                                           |
| Fair value movements on hedging instruments                                                                                 (111)                                1,089                |                                                                                                                                                                                                                                                                                           |
| 815                                     474                                                                                                                                           |                                                                                                                                                                                                                                                                                           |
| Other comprehensive income for the year net of tax                                                                         7,905                                13,182                |                                                                                                                                                                                                                                                                                           |
| Total comprehensive income for the year                                                                                          48,233                                53,043         |                                                                                                                                                                                                                                                                                           |
| Attributable to:                                                                                                                                                                      |                                                                                                                                                                                                                                                                                           |
| Equity holders of the company                                                                                                          48,233                                53,043   |                                                                                                                                                                                                                                                                                           |


Items in the statement above are disclosed net of tax. The income tax relating to each component of other comprehensive income is disclosed in note 11.

---

# Page 35

# Consolidated Balance Sheet

as at 30 June 2022


| Note                                       2022                                   2021                                                                                                             |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| £'000                                  £'000                                                                                                                                                       |
| Non-current assets                                                                                                                                                                                 |
| Property, plant and equipment                                                               15                                        36,671                                37,242                 |
| Right of use assets                                                                                  16                                          5,634                                  6,015      |
| Intangible assets                                                                                      17                                          3,232                                  3,232    |
| Retirement benefit obligations                                                               26                                          6,144                                         -           |
| Deferred tax assets                                                                                  18                                             234                                     254    |
| 51,915                                46,743                                                                                                                                                       |
| Current assets                                                                                                                                                                                     |
| Inventories                                                                                               19                                      112,279                                60,684    |
| Trade and other receivables                                                                    20                                        51,171                                42,949              |
| Derivative financial instruments                                                             29                                          2,166                                     848             |
| Cash and cash equivalents                                                                      21                                        52,144                                83,261              |
| 217,760                              187,742                                                                                                                                                       |
| Total assets                                                                                                                                       269,675                              234,485    |
| Current liabilities                                                                                                                                                                                |
| Trade and other payables                                                                        22                                        84,507                                65,551             |
| Derivative financial instruments                                                             29                                             517                                       92           |
| Current income tax liabilities                                                                                                                2,097                                  1,160         |
| Lease liabilities                                                                                         23                                          2,166                                  2,948 |
| 89,287                                69,751                                                                                                                                                       |
| Non-current liabilities                                                                                                                                                                            |
| Retirement benefit obligations                                                               26                                                 -                                  4,357           |
| Other payables                                                                                        22                                             453                                     447   |
| Deferred tax liabilities                                                                             18                                          2,929                                         -   |
| Lease liabilities                                                                                         23                                          3,548                                  3,236 |
| Preference shares                                                                                    24                                             200                                     200    |
| 7,130                                  8,240                                                                                                                                                       |
| Total liabilities                                                                                                                                    96,417                                77,991  |
| Net assets                                                                                                                                         173,258                              156,494    |
| Equity                                                                                                                                                                                             |
| Equity share capital                                                                                 27                                        20,837                                10,408        |
| Equity share capital (B shares)                                                                27                                             160                                     160          |
| 20,997                                10,568                                                                                                                                                       |
| Share premium account                                                                                                                               -                                  4,122       |
| Capital redemption reserve                                                                                                                          -                                  1,174       |
| Currency translation reserve                                                                                                                 5,912                                  4,986          |
| Hedging reserve                                                                                                                                        941                                  1,052  |
| Retained earnings                                                                                                                              145,408                             134,592         |
| Total equity attributable to shareholders of the parent                                                               173,258                             156,494                                  |


The financial statements were approved and authorised for issue by the board and were signed on its behalf on 30 September 2022.

M Halstead                                                                                  G R Oliver

Director                                                                                       Director

James Halstead plc           Registration Number 140269


## 32

---

# Page 36

# 33


## Consolidated Statement of Changes in Equity

for the year ended 30 June 2022


| Capital                                                              Share             Share                                                            capital                                                              £'000             £'000   | redemption    translation        Hedging        Retained              Total      premium          reserve          reserve          reserve        earnings           equity            £'000   | £'000            £'000            £'000            £'000                                                                                                                                            |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Balance at 30 June 2020                       10,567              4,072              1,174              5,601                 (37)        116,098         137,475                                                                                      |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Profit for the year                                           -                     -                     -                     -                     -           39,861           39,861                                                              |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Remeasurement of the net defined                                                                                                                                                                                                                       |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| benefit liability                                                -                     -                     -                     -                     -            12,708           12,708                                                          |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Foreign currency translation differences                                                       -                     -                     -               (615)                    -                     -               (615)                        |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Fair value movements on                                                                                                                                                                                                                                |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| hedging instruments                                       -                     -                     -                     -              1,089                     -              1,089                                                              |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| the year                                                           -                     -                     -               (615)            1,089           52,569           53,043                                                                |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Total comprehensive income for                                                                                                                                                                                                                         |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Dividends                                                        -                     -                     -                     -                     -          (34,083)         (34,083)                                                          |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Issue of share capital                                      1                   50                     -                     -                     -                     -                   51                                                        |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Share based payments                                   -                     -                     -                     -                     -                     8                     8                                                           |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Balance at 30 June 2021                       10,568              4,122              1,174              4,986              1,052         134,592         156,494                                                                                       |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Remeasurement of the net defined                                                                                                                                                                                                                       |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| benefit liability                                                                                                                                                                                                                                      |                                                                                                                                                                                                 | -                     -                     -                     -                     -              7,090              7,090                                                                     |
| Foreign currency translation                                                                                                                                                                                                                           |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
|                                                                                                                                                                                                                                                        |                                                                                                                                                                                                 | differences                                                       -                     -                     -                 926                     -                     -                 926 |
| Fair value movements on                                                                                                                                                                                                                                |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| hedging instruments                                       -                     -                     -                     -               (111)                    -               (111)                                                             |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Total comprehensive income for                                                                                                                                                                                                                         |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Transactions with equity shareholders                                                                                                                                                                                                                  |                                                                                                                                                                                                 | the year                                                           -                     -                     -                 926               (111)          47,418           48,233           |
| Dividends                                                        -                     -                     -                     -                     -          (32,298)         (32,298)                                                          |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Issue of share capital                                    11                812                     -                     -                     -                     -                 823                                                            |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Bonus issue of share capital                  10,418            (4,934)           (1,174)                   -                     -            (4,310)                    -                                                                            |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Share based payments                                   -                     -                     -                     -                     -                     6                     6                                                           |                                                                                                                                                                                                 |                                                                                                                                                                                                     |
| Balance at 30 June 2022                       20,997                     -                     -              5,912                941         145,408         173,258                                                                                 |                                                                                                                                                                                                 |                                                                                                                                                                                                     |

---

# Page 37

# Consolidated Cash Flow Statement

for the year ended 30 June 2022


| 2022                                   2021                                                                                                                                                             |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Profit for the year attributable to equity shareholders                                                                      40,328                                39,861                               |
| Income tax expense                                                                                                                            11,735                                11,407              |
| Profit before income tax                                                                                                                     52,063                                51,268               |
| Finance cost                                                                                                                                              237                                     553   |
| Finance income                                                                                                                                         (42)                                    (48)     |
| Operating profit                                                                                                                                  52,258                                51,773          |
| Depreciation of property, plant and equipment                                                                                   3,794                                  3,541                            |
| Depreciation of right of use assets                                                                                                       3,139                                  3,115                  |
| Profit on sale of property, plant and equipment                                                                                    (198)                                    (64)                        |
| Defined benefit pension scheme service cost                                                                                         500                                     620                         |
| Defined benefit pension scheme employer contributions paid                                                          (1,970)                               (4,144)                                       |
| Changes in fair value of financial instruments                                                                                        703                                     (90)                      |
| Share based payments                                                                                                                                 6                                         8        |
| (Increase)/decrease in inventories                                                                                                     (50,272)                                6,346                    |
| (Increase) in trade and other receivables                                                                                             (7,451)                             (15,573)                      |
| Increase in trade and other payables                                                                                                  15,905                                20,248                      |
| Cash inflow from operations                                                                                                              16,414                                65,780                   |
| Taxation paid                                                                                                                                        (9,879)                               (9,895)      |
| Cash inflow from operating activities                                                                                                   6,535                                55,885                     |
| Purchase of property, plant and equipment                                                                                        (3,248)                               (2,811)                          |
| Proceeds from disposal of property, plant and equipment                                                                     280                                     131                                 |
| Cash outflow from investing activities                                                                                                (2,968)                               (2,680)                     |
| Interest received                                                                                                                                         42                                       48   |
| Interest paid                                                                                                                                              (20)                                    (26) |
| Lease interest paid                                                                                                                                  (143)                                  (173)       |
| Lease capital paid                                                                                                                                 (3,233)                               (3,010)        |
| Equity dividends paid                                                                                                                         (32,298)                             (34,083)             |
| Shares issued                                                                                                                                            823                                       51   |
| Cash outflow from financing activities                                                                                              (34,829)                             (37,193)                       |
| Net (decrease)/increase in cash and cash equivalents                                                                      (31,262)                              16,012                                  |
| Effect of exchange differences                                                                                                                 145                                   (196)              |
| Cash and cash equivalents at start of year                                                                                        83,261                                67,445                          |
| Cash and cash equivalents at end of year                                                                                          52,144                                83,261                          |



## 34

---

# Page 38

# 35


## Notes to the Consolidated Financial Statements


## 1. General information

James Halstead plc ('the company' or 'the parent company') is a limited liability company, registered in England and Wales, domiciled in the United Kingdom and listed on AIM on the London Stock Exchange. The address of its registered office is Beechfield, Hollinhurst Road, Radcliffe, Manchester, M26 1JN.


## 2. Accounting policies


## Basis of preparation

On 31 December 2020, IFRS as adopted by the European Union at that date was brought into UK Law and became UK adopted international accounting standards, with future changes being subject to endorsement by the UK Endorsement Board. The group transitioned to UK adopted international accounting standards in its consolidated financial statements on 1 July 2021. There was no impact or changes in accounting from the transition.

The group financial statements have been prepared in accordance with UK adopted international  accounting  standards. The company  financial  statements  have  been  prepared  in  accordance  with  Financial  Reporting  Standard  101  Reduced  Disclosure Framework, and are presented separately following the group financial statements.

The group financial statements have been prepared on a going concern basis and on the historical cost basis as modified by the valuation of certain financial assets and financial liabilities (being derivative instruments) at fair value.


## Going concern

The directors have reviewed current performance and forecasts, combined with capital investment and expenditure commitments, and a range of trading scenarios. The group has no net borrowings and owns the freeholds on many of its premises (the most significant being four UK operating sites and two sites in Germany).

After considering current trading and forward forecasts, the directors have the reasonable expectation that the group has adequate financial resources to continue in operation, including contractual and commercial commitments, for the foreseeable future.

As the global pandemic recedes, but with many markets now facing high energy costs and supply chain concerns, the directors have considered that there may be a weakening of demand for flooring products in arriving at the conclusion above.

Fluctuations in exchange rates have been a constant factor since sterling floated in 1971. Our hedging delays the effect of sharp changes.

Working with our senior executives we have considered scenarios for the purpose of the statutory audit that involve layoffs and cessation of production in the winter months and, whilst we do not believe they are likely, have been considered to assess the going concern concept. The cost and availability of international freight has continued to frustrate export sales and as part of the going concern review we have factored in the scenario that this will continue for several months.

Based on the above the directors are satisfied the group has adequate resources to continue as a going concern for at least one year from the date of approval of the financial statements.


## Recent accounting developments

The financial statements are prepared in accordance with UK adopted international accounting standards and interpretations in force at the reporting date. The group has not adopted any standards or interpretations in advance of the required implementation dates.

---

# Page 39

# 2. Accounting policies (continued)


## Recent accounting developments (continued)

The following standards were adopted in the period.

Amendments  to IFRS 9, IAS 39, IFRS 7, IFRS 4 and IFRS 16 Interest Rate Benchmark Reform - Phase 2

There were no new standards, interpretations and amendments, which are not yet effective and have not been adopted early in these financial statements, which will or may have an effect on the group's future financial statements.


## Basis of consolidation

The group financial statements consolidate the financial statements of the parent company and all its subsidiaries, as if they formed a single entity. Subsidiaries are entities controlled by the group. Control exists if all three of the following elements are present: power over the entity, exposure to variable returns from the entity, and the ability to affect those variable returns. Control is reassessed whenever facts and circumstances indicate that there may be a change in any of these elements of control. Control is normally achieved by a majority shareholding. The company, directly or through an intermediate subsidiary owned 100% of the share capital of all of its subsidiaries. The results of subsidiaries acquired are consolidated from the date on which control passes to the group. The results of disposed subsidiaries are consolidated up to the date on which control passes from the group. All intragroup transactions and balances are eliminated on consolidation.


## Segment reporting

Operating segments are those segments for which results are reviewed by the group's chief operating decision maker (CODM) to assess performance and make decisions about resources to be allocated. The CODM is the group board which meets regularly throughout the year to discuss the performance and results of the group as a whole. The business of the group is the manufacture and distribution of flooring products. The group operates through separate legal entities in certain areas of the world and in order to  provide  information  in  a  structured  manner  to  readers  of  the  accounts  who  are  unfamiliar  with  the  internal  management reporting of the group, these operations are discussed by the chief executive in his report. However, the directors consider that under the definitions contained within IFRS 8 there is only one reportable segment, which is the group as a whole. This is consistent with the core principle of IFRS 8, which is to disclose information to enable users of the financial statements to evaluate the nature and financial effects of the business activities in which the group engages and the economic activities in which it operates.


## Foreign currencies

Functional  and  presentation  currency  -  the  group's  consolidated  financial  statements  are  presented  in  pounds  sterling,  the functional currency of the parent company, being the currency of the primary economic environment in which the parent company operates.

Transactions  and  balances  -  transactions  in  foreign  currencies  are  recorded  at  the  rate  ruling  at  the  date  of  the  transaction. Monetary assets and liabilities denominated in foreign currencies are reported at the rates of exchange prevailing at the balance sheet date. Exchange differences on retranslating monetary assets and liabilities are recognised in the income statement except where they relate to qualifying cash flow hedges, in which case the exchange differences are deferred in equity.

Foreign subsidiaries - the results of foreign subsidiaries (none of which has the currency of a hyperinflationary economy), that have a functional currency different from the group's presentation currency, are translated at the average rates of exchange for the year.

Assets and liabilities of foreign subsidiaries, that have a functional currency different from the group's presentation currency, are translated at the exchange rates prevailing at the balance sheet date. Exchange differences arising from the translation of the results of foreign subsidiaries and their opening net assets are recognised as a separate component of equity.

When a foreign subsidiary is sold the cumulative exchange differences relating to the retranslation of the net investment in that foreign subsidiary are recognised in the income statement as part of the gain or loss on disposal. This applies only to exchange differences recorded in equity after 1 July 2006. Exchange differences arising prior to 1 July 2006 remain in equity on disposal as permitted by IFRS 1.


## 36

---

# Page 40

# 37


## Notes to the Consolidated Financial Statements continued


## 2. Accounting policies (continued)


## Intangible assets

Goodwill - goodwill arising on the acquisition of a subsidiary undertaking is the excess of the aggregate of the fair value of the consideration transferred, the fair value of any previously held interests, and the recognised value of the non-controlling interest in the acquiree over the net of the acquisition date amounts of the identifiable assets acquired and liabilities assumed. Goodwill is reviewed for impairment at least annually and when there are indications that the carrying amount may not be recoverable. For the  purpose  of  impairment  review,  goodwill  is  allocated  to  the  relevant  cash  generating  unit  (CGU)  within  the  group. An impairment loss is recognised if the carrying value of the goodwill or its CGU exceeds its recoverable amount. Any impairment loss  is  recognised  immediately  in  the  income  statement  and  is  not  subsequently  reversed.  On  disposal  of  a  subsidiary,  the attributable amount of goodwill is included in the calculation of the profit or loss on disposal. Goodwill arising on acquisitions before the date of transition to IFRS has been retained at the UK GAAP value as at that date having been reviewed for impairment at that date and subsequently at least annually.


## Taxation

Income tax on the profit for the year comprises current and deferred tax. Income tax is recognised in the income statement except to the extent that it relates to items recognised in other comprehensive income.


Current tax assets and liabilities are measured at the amount expected to be recovered from or paid to taxation authorities based on tax rates and laws that are enacted at the balance sheet date. Deferred income tax is provided in full, using the liability method, on temporary differences arising between the tax bases of assets and liabilities and their corresponding book values as recorded in the group's financial statements with the following exceptions:
- where the temporary difference arises from the initial recognition of goodwill or of an asset or liability in a transaction that is not a business combination that at the time of the transaction affects neither accounting nor taxable profit or loss;
- deferred income tax assets are recognised only to the extent that it is probable that taxable profit will be available against which the deductible temporary differences can be utilised;
- deferred income tax is not provided on unremitted earnings of foreign subsidiaries where there is no likelihood to remit the earnings.


Deferred income tax assets and liabilities are based on tax rates and laws that are substantively enacted at the balance sheet date.


## Share-based payments

The group grants share options to certain of its employees. An expense in relation to such options based on their fair value at the date of grant, is recognised over the vesting period. The group uses the Black Scholes model for the purpose of computing fair value.


## Inventories

Inventories are measured at the lower of cost and net realisable value on a weighted average cost basis. Cost includes expenditure incurred in acquiring the inventories and bringing them to their existing location and condition. In the case of finished and partly finished goods, cost represents the cost of raw materials, direct labour, other direct costs and related production overheads on bases consistently applied from year to year. In all cases provision is made for obsolete, slow-moving or defective items where appropriate.


## Financial assets and liabilities

Financial assets comprise trade and other receivables and cash and cash equivalents. Financial liabilities comprise trade and other payables.

---

# Page 41

# 2. Accounting policies (continued)


## Trade and other receivables

Trade and other receivables are non-interest bearing and are initially stated at fair value and then subsequently at amortised cost less provision for lifetime expected credit losses using the simplified approach in IFRS 9. Estimated irrecoverable amounts are based on historical experience and forward looking information, together with specific amounts that are not expected to be collectable. Individual amounts are written off when management deems them not to be collectible.


## Cash and cash equivalents

Cash and cash equivalents include cash in hand, deposits held at call with banks, short-term (with an original maturity of three months or less) deposits and bank overdrafts. Bank overdrafts are disclosed as current liabilities except where the group participates in  offset  arrangements  with  certain  banks  whereby  cash  and  overdraft  amounts  are  offset  against  each  other.  Cash  and  cash equivalents are held at amortised cost.


## Trade and other payables

Trade and other payables are non-interest bearing and are initially stated at fair value and then subsequently at amortised cost.


## Pension scheme arrangements

The group operates several defined contribution pension schemes and a defined benefit pension scheme for certain of its United Kingdom domiciled employees.

A defined contribution scheme is a scheme in which the group pays contributions into publicly or privately administered schemes on a voluntary, statutory or contractual basis. The group has no further payment obligations once the contributions have been made. The amount charged to the income statement is the contribution payable in the year. Differences between contributions payable in the year and contributions actually paid are shown as receivables or payables in the balance sheet.

A defined benefit scheme is a scheme in which the amount of pension benefit that an employee will receive on retirement is defined. For the defined benefit scheme, pension costs and the costs of providing other post retirement benefits are charged to the income statement in accordance with the advice of qualified independent actuaries. Past service costs are recognised immediately in the income statement. The service cost is charged against operating profit and the net interest cost is charged as a finance cost. The  net  interest  cost  is  calculated  using  the  discount  rate  at  the  beginning  of  the  period. The  retirement  benefit  obligations recognised on the balance sheet represent the difference between the fair value of the scheme's assets and the present value of the scheme's defined benefit obligations measured at the balance sheet date. The defined benefit obligation is calculated annually by independent actuaries using the projected unit method. Remeasurements of the net defined benefit obligations are recognised in the period in which they arise in other comprehensive income.A net defined benefit obligations asset is recognised to the extent that the group can realise an economic benefit from that asset.


## Property, plant and equipment

Property, plant and equipment is recorded at cost less subsequent depreciation and impairment except for land which is shown at cost less any impairment. Cost includes expenditure that is directly attributable to the acquisition of the asset. Depreciation is calculated on the depreciable amount (being cost less the estimated residual value) on a straight line basis over the estimated useful lives of the assets as follows:

Freehold land: Not depreciated Freehold buildings: 10 to 50 years Plant and equipment: 2 to 20 years

Residual values and useful lives are reviewed at each group balance sheet date for continued appropriateness and indications of impairment and adjusted if appropriate.


## 38

---

# Page 42

# 39


## Notes to the Consolidated Financial Statements

continued


## 2. Accounting policies (continued)


## Right of use assets and lease liabilities

A right of use asset and a lease liability are recognised for all leased asset contracts on their commencement, except for low value leases and short term leases of one year or less.

On recognition, the right of use asset and lease liability are measured at the present value of the lease payments discounted over the lease term. The discount rate used is the rate inherent in the lease if this can be determined, or the incremental borrowing rate.

Subsequent to initial recognition, the right of use assets are depreciated on a straight line basis over the shorter of the lease term or the useful life of the asset. The lease liabilities are increased by the interest cost and reduced by the lease payments made. A depreciation charge and an interest cost are recognised in the income statement.

The lease payments for low value and short term leases are expensed in the income statement on a straight line basis over the lease term.


## Revenue recognition

Revenue is from the sales of flooring products and is recognised at the point in time when control of the products has been transferred to the customer. Sales are recognised on despatch of the goods to the customer. Control passes to the customer at the point terms of despatch are met. Sales are invoiced at the time of despatch and payment terms are based on the invoice date. Payment terms vary by customer, but do not exceed six months. Revenue is stated after provision for trade discounts and rebates due on the sales. Revenue excludes VAT and sales taxes.


## Research and development

Expenditure  on  research  activities,  undertaken  with  the  prospect  of  gaining  new  scientific  or  technical  knowledge  and understanding, is recognised in the income statement as an expense as incurred.

Development expenditure not meeting all the criteria for capitalisation contained in IAS 38 - Intangible Assets, is recognised in the income statement as an expense as incurred.


## Grants

Grants that compensate for expenses are recognised in the income statement in the same period and category in which the expenses are recognised.


## Dividends

Interim dividends are recognised when they are paid. Final dividends are recognised when they are approved by the shareholders.


## Derivative financial instruments and hedging

The group uses derivative financial instruments to hedge its exposure to foreign currency transactional risk. In accordance with its treasury policy the group does not hold or issue derivative financial instruments for trading purposes.

Derivative financial instruments are recorded at fair value on the date the derivative contract is entered into and are subsequently remeasured at fair value at each group balance sheet date.

The method by which any gain or loss arising from remeasurement is recognised depends on whether the instrument is designated as  a  hedging  instrument  and,  if  so,  the  nature  of  the  item  being  hedged. The  group  recognises  an  instrument  as  a  hedging instrument by documenting at the inception of the transaction the relationship between the instrument and the hedged items and the objectives and strategy for undertaking the hedging transaction. To be designated as a hedging instrument, an instrument must also be assessed, at inception and on an ongoing basis, to be highly effective in offsetting changes in cash flows of hedged items.

---

# Page 43

# 2. Accounting policies (continued)


## Derivative financial instruments and hedging (continued)

For derivatives not used in hedging transactions, the gain or loss on remeasurement of fair value is recognised immediately in the income statement.

Where a derivative financial instrument is designated as a hedge of the variability in cash flows of a recognised asset or liability, or of a highly probable forecast future transaction, the gain or loss on remeasurement which relates to the portion of the hedge which is deemed effective is recognised directly in equity, with the balance of the gain or loss, relating to the ineffective portion, being recognised immediately in the income statement.

Amounts accumulated in equity are recycled in the income statement in the periods when the hedged item affects profit or loss. The fair value of forward foreign exchange contracts is determined using forward exchange market rates at the balance sheet date.


## 3. Financial risk management


## Financial risk and treasury policies

A full description of the James Halstead plc group's treasury policy is contained in the financial director's review.

The group's activities expose it to a number of financial risks as detailed below. These risks are managed, with the objective of limiting adverse effects, from the group's head office in accordance with policies determined by and decisions made by the group board.

There have been no changes in financial risks from the previous year.


## Market risks

Market risk is the risk that changes in market prices, such as currency exchange rates and interest rates will affect the group's results. The objective of market risk management is to control it within suitable parameters.


## (a)    Foreign exchange risk

The group operates internationally and is exposed to foreign currency risk on sales and purchases that are denominated in a currency other than the functional currency of the entity making the sale or purchase. There are a range of currencies giving rise to this risk, but most significant is the euro. To mitigate risks associated with future exchange rate fluctuations, the group's policy is to use forward exchange contracts to hedge its known and certain forecast transaction exposures based on historical experience and projections. The group hedges at least 25% but rarely more than 100% of the next twelve months' anticipated exposure.


## (b)    Interest rate risk

The group does not use derivative financial instruments to mitigate its exposure to interest rate risk. The main element of interest rate risk concerns sterling deposits which are made on floating market based rates and short-term overdrafts in foreign currencies which are also on floating rates.


## 40

---

# Page 44

# 41


## Notes to the Consolidated Financial Statements continued


## 3. Financial risk management (continued)


## Credit risk

Credit  risk  is  the  risk  of  financial  loss  to  the  group  if  a  customer  or  counterparty  to  a  financial  instrument  fails  to  meet  its contractual  obligations  and  arises  principally  from  the  group's  trade  receivables  from  customers  and  monies  on  deposit  with financial institutions.

With regard to trade receivables, the group is not subject to significant concentration of credit risk. Exposure is spread across a large number of companies and the underlying local economic and sovereign risks vary across the world. Trade receivable exposures are managed  locally  in  the  individual  operating  units  where  they  arise  and  credit  limits  are  set  as  deemed  appropriate. Where practicable and deemed necessary the group endeavours to minimise credit risks by the use of trade finance instruments such as letters of credit and insurance.

The group controls credit risk in relation to counterparties to other financial instruments by dealing only with highly rated financial institutions.

The group's maximum credit exposure on financial assets is represented by their book value.


## Liquidity risk

Liquidity risk is the risk that the group will not be able to meet its financial obligations as they fall due. The group's approach to managing liquidity is to ensure, as far as possible, that it will always have sufficient liquidity to meet its liabilities when due.


## Capital risk

The group's objectives in managing capital are to safeguard the ability of all entities within the group to continue as going concerns, whilst maximising the overall return to shareholders over time. The capital structure of the group consists of equity attributable to equity holders of the parent company less cash and cash equivalents.

The group will only usually take on borrowings where those borrowings would be financed by the cash expected to be generated by the related investment opportunity and where the borrowing would not significantly increase the group's exposure to risk.

At the year end the group had preference shares classified as debt of £200,000.


## 4. Critical accounting estimates and judgements

The preparation of financial statements in conformity with generally accepted accounting principles requires the use of certain estimates and associated assumptions that affect the application of policies, the reported amounts of assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Although these estimates are based on management's best assessments of amounts, events or actions, actual results may ultimately differ from those estimates. The estimates and underlying assumptions are reviewed on a regular and ongoing basis. There are no significant judgements.

The estimates that have had the most significant effect on the amounts included in these consolidated financial statements are as follows:

---

# Page 45

# 4. Critical accounting estimates and judgements (continued)


## Inventories

For financial reporting purposes the group evaluates its inventory to ensure it is carried at the lower of cost or net realisable value. Provision is made against slow moving, obsolete and damaged inventories. Damaged inventories are identified and written down through the inventory counting procedures conducted within each business. Provision for slow moving and obsolete inventories is assessed by each business as part of their ongoing financial reporting. Obsolescence is assessed based on comparison of the level of inventory holding to the projected likely future sales. Future sales are assessed based on historical experience, and adjusted where the market conditions are known to have changed. To the extent that future events impact the saleability of inventory these provisions could vary significantly. For example, changes in specifications or regulations may render inventory, previously considered to have a realisable value in excess of cost, obsolete and require such inventory to be fully written off.


## Expected credit losses

Provision is made against trade receivables for lifetime expected credit losses using the simplified approach in IFRS 9. Within each of the operating units, assessment is made locally of the recoverability of trade receivables based on a range of factors including the age of the receivable, the creditworthiness of the customer and forward looking information. Determining the recoverability of an account involves estimation as to the likely financial condition of the customer and their ability to subsequently make payment. If the group is cautious as to the financial condition of the customer the group may provide for accounts that are subsequently recovered. Similarly, if the group is optimistic as to the financial condition of the customer, the group may not provide for an account that is subsequently determined to be irrecoverable. In recent years the group has not experienced significant variation in the amount charged to the income statement in respect of doubtful accounts, when compared to sales. Further details are provided in note 20.


## Income taxes

In determining the group's provisions for income tax and deferred tax it is necessary to consider transactions in a small number of key tax jurisdictions for which the ultimate tax determination is uncertain. To the extent that the final outcome differs from the tax  that  has  been  provided,  adjustments  will  be  made  to  income  tax  and  deferred  tax  provisions  held  in  the  period  the determination is made.


## Retirement benefit obligations

The liability recognised in respect of retirement benefit obligations is dependent on a number of estimates including those relating to mortality, inflation, salary increases, and the rate at which liabilities are discounted. Any change in these assumptions would impact the retirement benefit obligations recognised. Further details on these estimates are provided in note 26.


## 42

---

# Page 46

# 43


## Notes to the Consolidated Financial Statements

continued


## 5. Segmental information

Operating segments are  those segments for which results are reviewed by the group's chief operating decision maker (CODM) to assess performance and make decisions about resources to be allocated. The CODM is the group board which meets regularly throughout the year to discuss the performance and results of the group as a whole. The business of the group is focussed almost entirely on the manufacture and distribution of flooring products. The directors consider that under the definitions contained within IFRS 8 there is only one reportable segment, which is the group as a whole. This is consistent with the core principle of IFRS 8, which is to disclose information  to enable users of the financial statements to evaluate the nature and financial effects of the business activities in which the group engages and the economic activities in which it operates. Therefore the majority of the disclosures required under IFRS 8 have already been given in these financial statements.

Segment assets comprise property, plant and equipment, right of use and intangible assets. Geographical disclosures in respect of revenues and segment assets are provided below and include revenue for Germany of £62,553,000 (2021: £55,656,000) and assets in Germany of £9,016,000 (2021: £10,560,000).


|                                | 2022    | 2021    |
|--------------------------------|---------|---------|
| Revenue                        | £'000   | £'000   |
| United Kingdom                 | 110,612 | 98,243  |
| Europe and Scandinavia         | 121,109 | 111,863 |
| Australasia and Asia           | 38,021  | 38,386  |
| Rest of the World              | 22,118  | 17,870  |
|                                | 291,860 | 266,362 |
|                                | 2022    | 2021    |
| Assets                         | £'000   | £'000   |
| United Kingdom                 | 30,018  | 30,213  |
| Europe and Scandinavia         | 10,544  | 12,021  |
| Australasia and Asia           | 4,870   | 3,900   |
| Rest of the World              | 105     | 355     |
| Retirement benefit obligations | 6,144   | -       |
| Deferred tax assets            | 234     | 254     |
| Total non-current assets       | 51,915  | 46,743  |


Revenue is by location of customer. Assets are by location of asset.


## 6. Employee profit share

Profit for the year is after charging the cost of the James Halstead plc share ownership plan. Since 1980 the group has operated an employee share scheme, approved under the Finance Act 1978. In December 2001 the shareholders approved a new share ownership plan in line with the requirements of legislative changes. The aim of this scheme is to enable employees to build up a personal shareholding in James Halstead plc and to participate in its continued expansion and success as shareholders as well as employees.

As members of the scheme the following directors received shares to the value of, Mr M Halstead £nil and Mr G R Oliver £nil.

---

# Page 47

# 7. Profit before income tax


Profit before tax is stated after charging/(crediting) the following:
|                                                                                                               | 2022   | 2021    |
|---------------------------------------------------------------------------------------------------------------|--------|---------|
|                                                                                                               | £'000  | £'000   |
| Depreciation of property, plant and equipment                                                                 | 3,794  | 3,541   |
| Depreciation of right of use assets                                                                           | 3,139  | 3,115   |
| Profit on disposal of property, plant and equipment                                                           | (198)  | (64)    |
| Research and development                                                                                      | 1,549  | 1,484   |
| Government grant income for business support UK and overseas                                                  | (112)  | (1,668) |
| Fees payable to the group's auditor for the audit of the parent company and consolidated financial statements | 55     | 50      |
| Fees payable to the group's auditor and its associates for other services:                                    |        |         |
| The audit of the group's subsidiaries pursuant to legislation                                                 | 148    | 122     |
| Taxation compliance                                                                                           | -      | 39      |
| Other services                                                                                                | -      | 3       |
| 8. Staff costs and numbers                                                                                    |        |         |
|                                                                                                               | 2022   | 2021    |
|                                                                                                               | £'000  | £'000   |
| Social security costs                                                                                         | 4,564  | 4,353   |
| Pension costs - defined benefit scheme                                                                        | 500    | 620     |
| - defined contribution schemes                                                                                | 907    | 836     |
|                                                                                                               |        | 42,101  |
| The average monthly number of employees during the year was:                                                  | 43,069 |         |
|                                                                                                               | Number | Number  |
| Manufacturing, selling and distribution                                                                       | 654    | 660     |
| Administration                                                                                                | 165    | 159     |
|                                                                                                               | 819    | 819     |
| The directors' remuneration was:                                                                              | 2022   | 2021    |
|                                                                                                               | £'000  | £'000   |
| Salary or fees                                                                                                | 1,004  | 968     |
| Bonuses                                                                                                       | 1,000  | 926     |
| Benefits                                                                                                      | 25     | 24      |
| Total remuneration excluding pension contributions                                                            | 2,029  | 1,918   |
| Pension contributions                                                                                         | 25     | 25      |
| Social security costs related to this remuneration                                                            | 272    | 257     |



## 44

---

# Page 48

# 45


## Notes to the Consolidated Financial Statements

continued


## 9. Finance income


|                                                                                                                                       | 2022                                                                                                                                  | 2021                                                                                                                                  |
|---------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|
|                                                                                                                                       | £'000                                                                                                                                 | £'000                                                                                                                                 |
| Bank deposit interest                                                                                                                 | 36                                                                                                                                    | 44                                                                                                                                    |
| Other interest                                                                                                                        | 6                                                                                                                                     | 4                                                                                                                                     |
| Finance income                                                                                                                        | 42                                                                                                                                    | 48                                                                                                                                    |
| 10. Finance cost                                                                                                                      |                                                                                                                                       |                                                                                                                                       |
|                                                                                                                                       | 2022                                                                                                                                  | 2021                                                                                                                                  |
|                                                                                                                                       | £'000                                                                                                                                 | £'000                                                                                                                                 |
| Other interest                                                                                                                        | 9                                                                                                                                     | 15                                                                                                                                    |
| Preference share dividend                                                                                                             | 11                                                                                                                                    | 11                                                                                                                                    |
|                                                                                                                                       | 20                                                                                                                                    | 26                                                                                                                                    |
| Lease interest                                                                                                                        | 143                                                                                                                                   | 173                                                                                                                                   |
| Net pension interest cost                                                                                                             | 74                                                                                                                                    | 354                                                                                                                                   |
| Finance cost                                                                                                                          | 237                                                                                                                                   | 553                                                                                                                                   |
| 11. Income tax expense                                                                                                                |                                                                                                                                       |                                                                                                                                       |
|                                                                                                                                       | 2022                                                                                                                                  | 2021                                                                                                                                  |
|                                                                                                                                       | £'000                                                                                                                                 | £'000                                                                                                                                 |
| Current tax                                                                                                                           |                                                                                                                                       |                                                                                                                                       |
| Current tax - current year                                                                                                            | 11,310                                                                                                                                | 10,733                                                                                                                                |
| Current tax - adjustments in respect of prior years                                                                                   | (516)                                                                                                                                 | (415)                                                                                                                                 |
|                                                                                                                                       | 10,794                                                                                                                                | 10,318                                                                                                                                |
| Deferred tax                                                                                                                          |                                                                                                                                       |                                                                                                                                       |
| Deferred tax - current year temporary differences                                                                                     | 565                                                                                                                                   | 650                                                                                                                                   |
| Deferred tax - current year tax rate difference                                                                                       | 137                                                                                                                                   | 224                                                                                                                                   |
| Deferred tax - adjustments in respect of prior years                                                                                  | 239                                                                                                                                   | 215                                                                                                                                   |
|                                                                                                                                       | 941                                                                                                                                   | 1,089                                                                                                                                 |
| Total taxation                                                                                                                        | 11,735                                                                                                                                | 11,407                                                                                                                                |
| Current tax includes £3,737,000 (2021: £3,666,000) of overseas tax.                                                                   |                                                                                                                                       |                                                                                                                                       |
| The effective tax rate for the year to 30 June 2022 is higher (2021: higher) than the standard rate of corporation tax in the UK. The | The effective tax rate for the year to 30 June 2022 is higher (2021: higher) than the standard rate of corporation tax in the UK. The | The effective tax rate for the year to 30 June 2022 is higher (2021: higher) than the standard rate of corporation tax in the UK. The |
|                                                                                                                                       | 2022                                                                                                                                  | 2021                                                                                                                                  |
|                                                                                                                                       | £'000                                                                                                                                 | £'000                                                                                                                                 |
| Profit before tax                                                                                                                     | 52,063                                                                                                                                | 51,268                                                                                                                                |
| Profit before tax multiplied by the standard rate of corporation tax in                                                               |                                                                                                                                       |                                                                                                                                       |
| the UK of 19% (2021: 19%)                                                                                                             | 9,892                                                                                                                                 | 9,741                                                                                                                                 |
| Effects of:                                                                                                                           |                                                                                                                                       |                                                                                                                                       |
| Adjustments to tax in respect of prior periods                                                                                        | (277)                                                                                                                                 | (200)                                                                                                                                 |
| Overseas tax rates                                                                                                                    | 1,659                                                                                                                                 | 1,469                                                                                                                                 |
| Disallowable items                                                                                                                    | 324                                                                                                                                   | 173                                                                                                                                   |
| Deferred tax rate difference                                                                                                          | 137                                                                                                                                   | 224                                                                                                                                   |
| Total taxation                                                                                                                        | 11,735                                                                                                                                | 11,407                                                                                                                                |


In addition to the amounts above £2,015,000 has been charged (2021: £2,981,000 charged) as other comprehensive income in respect of the remeasurement of the net defined benefit liability, and has been netted off the amounts shown in the Consolidated Statement of Comprehensive Income.

At 30 June 2022 the UK corporation tax rate was enacted to change to 25% on 1 April 2023. The UK deferred tax balances at 30 June 2022 were measured at 25%. On 23 September 2022 the UK government proposed to keep the UK corporation tax at 19%, and this is still to be enacted.

---

# Page 49

# 46


## 12. Earnings per share


|                                                         | 2022 £'000   | 2021 £'000   |
|---------------------------------------------------------|--------------|--------------|
| Profit for the year attributable to equity shareholders | 40,328       | 39,861       |
| Weighted average number of shares in issue              | 416,586,675  | 416,283,040  |
| Dilution effect of outstanding share options            | 201,425      | 246,330      |
| Diluted weighted average number of shares               | 416,788,100  | 416,529,370  |
| Basic earnings per 5p ordinary share                    | 9.7p         | 9.6p         |
| Diluted earnings per 5p ordinary share                  | 9.7p         | 9.6p         |


The earnings per 5p ordinary share are attributable to equity shareholders.

The figures for the year ended 30 June 2021 have been restated for the effect of the one-for-one bonus issue on 14 January 2022.


## 13. Dividends


|                                                                        | 2022 £'000   | 2021 £'000   |
|------------------------------------------------------------------------|--------------|--------------|
| Equity dividends                                                       |              |              |
| Interim dividend for previous year of nil (2021: 2.125p)               | -            | 4,423        |
| Final dividend for previous year of 11.00p (2021: 10.00p)              | 22,921       | 20,814       |
| Interim dividend for current year of 2.25p (2021: 4.25p)               | 9,377        | 8,846        |
| Amounts recognised as distributions to equity shareholders in the year | 32,298       | 34,083       |


A final dividend of 5.50p per share for the year ended 30 June 2022, amounting to £22,921,000 will be proposed at the Annual General Meeting.


## 14. Profit of the parent company

The company has taken advantage of the provisions of Section 408 of the Companies Act 2006 and elected not to present its own profit and loss account. The profit after taxation for the  financial year dealt with in the financial statements of the company was £30,797,000 (2021:  £43,332,000). The  aggregate  amount  of  directors'  emoluments  excluding  pension  contributions  was £2,029,000 (2021: £1,918,000) of which the highest paid director's emoluments were £978,000 (2021: £922,000). The directors' salaries or fees for the year ended 30 June 2022 were Mr J A Wild £40,000, Mr M Halstead £463,000, Mr G R Oliver £436,000, Mr S D Hall £25,000, Mr M J Halstead £20,000 and Mr R P Whiting £20,000.

---

# Page 50

# 47


## Notes to the Consolidated Financial Statements

continued


## 15. Property, plant and equipment


| Cost                 | Freehold land and buildings £'000   | Plant and equipment £'000   | Total £'000   |
|----------------------|-------------------------------------|-----------------------------|---------------|
| At 30 June 2020      | 28,215                              | 74,399                      | 102,614       |
| Additions            | 406                                 | 2,405                       | 2,811         |
| Disposals            | -                                   | (733)                       | (733)         |
| Exchange differences | (579)                               | (341)                       | (920)         |
| At 30 June 2021      | 28,042                              | 75,730                      | 103,772       |
| Additions            | 311                                 | 2,937                       | 3,248         |
| Disposals            | -                                   | (783)                       | (783)         |
| Exchange differences | 27                                  | 119                         | 146           |
| At 30 June 2022      | 28,380                              | 78,003                      | 106,383       |
| Depreciation         |                                     |                             |               |
| At 30 June 2020      | 10,573                              | 53,521                      | 64,094        |
| Charge for the year  | 680                                 | 2,861                       | 3,541         |
| Disposals            | -                                   | (666)                       | (666)         |
| Exchange differences | (199)                               | (240)                       | (439)         |
| At 30 June 2021      | 11,054                              | 55,476                      | 66,530        |
| Charge for the year  | 676                                 | 3,118                       | 3,794         |
| Disposals            | -                                   | (701)                       | (701)         |
| Exchange differences | 13                                  | 76                          | 89            |
| At 30 June 2022      | 11,743                              | 57,969                      | 69,712        |
| Net book value       |                                     |                             |               |
| At 30 June 2020      | 17,642                              | 20,878                      | 38,520        |
| At 30 June 2021      | 16,988                              | 20,254                      | 37,242        |
| At 30 June 2022      | 16,637                              | 20,034                      | 36,671        |

---

# Page 51

# 48


## 16. Right of use assets


|                                                        | Right of use assets £'000   |
|--------------------------------------------------------|-----------------------------|
| Cost                                                   |                             |
| At 30 June 2020                                        | 8,883                       |
| Additions                                              | 3,471                       |
| Disposals                                              | (696)                       |
| Exchange differences                                   | (332)                       |
| At 30 June 2021                                        | 11,326                      |
| Additions                                              | 2,641                       |
| Disposals                                              | (1,276)                     |
| Exchange differences                                   | 251                         |
| At 30 June 2022                                        | 12,942                      |
| Depreciation                                           |                             |
| At 30 June 2020                                        | 3,011                       |
| Charge for the year                                    | 3,115                       |
| Disposals                                              | (675)                       |
| Exchange differences                                   | (140)                       |
| At 30 June 2021                                        | 5,311                       |
| Charge for the year                                    | 3,139                       |
| Disposals                                              | (1,276)                     |
| Exchange differences                                   | 134                         |
| At 30 June 2022                                        | 7,308                       |
| Net book value                                         |                             |
| At 30 June 2020                                        | 5,872                       |
| At 30 June 2021                                        | 6,015                       |
| At 30 June 2022                                        | 5,634                       |
| 17. Intangible assets                                  |                             |
|                                                        | Goodwill                    |
|                                                        | £'000                       |
| Cost and net book value at 30 June 2020, 2021 and 2022 | 3,232                       |


An impairment review of goodwill was done by reference to value in use. Value in use was determined using conservative five year plus terminal value cash flow projections, based on current levels of profitability and assumed conservative growth rates of 0% to 5% and discount rates of 7% to 11%. The result of the review indicated that no impairment was required with no reasonable sensitivities indicating an impairment.

---

# Page 52

# 49


## Notes to the Consolidated Financial Statements

continued


## 18. Deferred tax assets and liabilities

Deferred tax assets

234

254

Deferred tax liabilities

(2,929)

-

(2,695)

254


|                                       | Retirement benefit obligations £'000   | Accelerated tax depreciation £'000   | Other timing differences £'000   | Total £'000   |
|---------------------------------------|----------------------------------------|--------------------------------------|----------------------------------|---------------|
| At 30 June 2020                       | 4,411                                  | (1,124)                              | 1,047                            | 4,334         |
| Credited/(charged) to income          | (602)                                  | (585)                                | 98                               | (1,089)       |
| Charged to other comprehensive income | (2,981)                                | -                                    | -                                | (2,981)       |
| Exchange differences                  | -                                      | -                                    | (10)                             | (10)          |
| At 30 June 2021                       | 828                                    | (1,709)                              | 1,135                            | 254           |
| Credited/(charged) to income          | (349)                                  | (87)                                 | (505)                            | (941)         |
| Charged to other comprehensive income | (2,015)                                | -                                    | -                                | (2,015)       |
| Exchange differences                  | -                                      | -                                    | 7                                | 7             |
| At 30 June 2022                       | (1,536)                                | (1,796)                              | 637                              | (2,695)       |


Deferred tax assets and liabilities are offset where there is a legally enforceable right to offset current tax assets against current tax liabilities and the deferred income taxes relate to the same tax authority.All deferred tax assets and liabilities are analysed as noncurrent.


## 19. Inventories


|                               | 2022 £'000   | 2021 £'000   |
|-------------------------------|--------------|--------------|
| Raw materials and consumables | 8,161        | 4,726        |
| Work in progress              | 2,258        | 1,262        |
| Finished goods                | 101,860      | 54,696       |
|                               | 112,279      | 60,684       |


An amount of £1,283,000 has been charged (2021: £904,000 credited) to the income statement in respect of movements in inventory write-downs. The cost of inventory recognised as an expense was £178,355,000 (2021: £154,722,000).

2022

£'000

£'000

2021

---

# Page 53

# 20. Trade and other receivables

Trade receivables

46,734

39,262

Other receivables

1,781

1,258

Prepayments

2,656

2,429

51,171

42,949

All amounts within trade and other receivables are due within one year. The fair value of amounts included in trade and other receivables approximates to book value. The maximum exposure to credit risk at the reporting date is the fair value of each class of receivable. The group does not hold any collateral as security.

The group's trade receivables are stated after a provision for expected credit losses of £1,820,000 (2021: £1,746,000).The provision against trade receivables for expected credit losses is based on specific risk assessments taking into account past default experience and appropriate forward looking information. The provision is analysed as follows:

2022

2021

£'000

£'000

Opening balance

1,746

1,588

Exchange differences

12

(14)

Debts written off

(135)

(66)

Charged to income

197

238

Closing balance

1,820

1,746

Not past due

2

34,143

541

2

38,013

674

Up to three months past due

5

13,736

651

21

2,433

512

Over three months past due

93

675

628

100

562

560

48,554

1,820

41,008

1,746


The maximum exposure to credit risk for trade and other receivables by currency was:
|                    | 2022 £'000   | 2021 £'000   |
|--------------------|--------------|--------------|
| Sterling           | 22,896       | 19,852       |
| Euro               | 13,985       | 11,574       |
| Australian Dollar  | 3,650        | 3,429        |
| New Zealand Dollar | 844          | 1,012        |
| Canadian Dollar    | 792          | 1,057        |
| Norwegian Krone    | 977          | 586          |
| US Dollar          | 3,818        | 1,178        |
| Hong Kong Dollar   | 221          | 753          |
| Other currencies   | 1,332        | 1,079        |
| Total              | 48,515       | 40,520       |


Loss rate

Gross

Provision

Loss rate

Gross

Provision

2022

2022

2022

2021

2021

2021

%

£'000

£'000

%

£'000

£'000

2022

£'000

£'000


## 50

2021

---

# Page 54

# 51


## Notes to the Consolidated Financial Statements

continued


## 21. Cash and cash equivalents

The fair values of cash and cash equivalents approximate to book value due to their short maturities.

The currency analysis of cash and cash equivalents is as follows:

Sterling

29,483

64,530

Euro

3,533

3,258

Australian Dollar

2,023

2,615

New Zealand Dollar

599

161

Canadian Dollar

1,396

808

Norwegian Krone

335

805

US Dollar

13,223

10,061

Other currencies

1,552

1,023

Total

52,144

83,261


## 22. Trade and other payables

2022

2021

£'000

£'000

Amounts falling due within one year

Trade payables

61,466

40,949

Value added, payroll and other taxes

5,565

6,238

Other payables

1,355

2,594

Accruals

16,121

15,770

84,507

65,551

Amounts falling due after more than one year

Other payables

453

447

The fair value of amounts included in trade and other payables approximates to book value.


## 23. Lease liabilities


|                                            | 2022 £'000   | 2021 £'000   |
|--------------------------------------------|--------------|--------------|
| Opening balance                            | 6,184        | 5,939        |
| Leases started                             | 2,641        | 3,471        |
| Leases cancelled                           | -            | (21)         |
| Lease interest                             | 143          | 173          |
| Lease payments                             | (3,376)      | (3,183)      |
| Exchange differences                       | 122          | (195)        |
| Closing balance                            | 5,714        | 6,184        |
| Amounts payable in less than one year      | 2,166        | 2,948        |
| Amounts payable in more than one year      | 3,548        | 3,236        |
|                                            | 5,714        | 6,184        |
| All amounts are payable within five years. |              |              |


2022

£'000

£'000

2021

---

# Page 55

# 52


## 24. Preference shares


|                   |   2022 £'000 |   2021 £'000 |
|-------------------|--------------|--------------|
| Preference shares |          200 |          200 |


The cumulative preference shares have no fixed repayment date. They are not listed and therefore no market price is available. At 30 June 2022 and 30 June 2021 the fair value of the preference shares was not materially different from their book value.


## 25. Net cash analysis

Cash


|                      | and cash equivalents £'000   | Lease liabilities £'000   | Preference shares £'000   | Net cash £'000   |
|----------------------|------------------------------|---------------------------|---------------------------|------------------|
| At 30 June 2020      | 67,445                       | (5,939)                   | (200)                     | 61,306           |
| Cash flow            | 16,012                       | 3,183                     | -                         | 19,195           |
| Other changes        | -                            | (3,623)                   | -                         | (3,623)          |
| Exchange differences | (196)                        | 195                       | -                         | (1)              |
| At 30 June 2021      | 83,261                       | (6,184)                   | (200)                     | 76,877           |
| Cash flow            | (31,262)                     | 3,376                     | -                         | (27,886)         |
| Other changes        | -                            | (2,784)                   | -                         | (2,784)          |
| Exchange differences | 145                          | (122)                     | -                         | 23               |
| At 30 June 2022      | 52,144                       | (5,714)                   | (200)                     | 46,230           |



## 26. Retirement benefit obligations

In the UK the group operates a defined benefit pension scheme which was closed to new members in 2002. In addition some employees  both  in  the  UK  and  overseas  are  provided  with  retirement  benefits  through  defined  contribution  arrangements. Executive directors Mr M Halstead and Mr G R Oliver are members of the defined benefit scheme and the employer pension contributions  for  the  year  were  £25,000 and £nil respectively. At  30  June  2022 the accrued  pension  for  the  highest  paid director was £131,000 and the transfer value of this accrued benefit was £2,557,000.

Disclosures relating to the defined benefits pension scheme are as follows:

The company sponsors the Halstead Group Pension Scheme, a funded defined benefit pension scheme in the UK. The scheme is administered within a trust which is legally separate from the company. Trustees are appointed by both the company and the scheme's membership and act in the interest of the scheme and all relevant stakeholders, including the members and the company. The trustees are also responsible for the investment of the scheme's assets.

Existing members accrue an annual pension of 1/60th or 1/80th (depending on category) of final salary for each year of pensionable service, increasing in line with inflation whilst in payment. On the death of an active member the scheme provides the widow(er) a lump sum and a spouse's pension. Members who leave service before retirement are entitled to a deferred pension.

Active members of the scheme pay contributions at the rate of either 7.5% or 6% of salary depending on category and the company pays the balance of the cost as determined by regular actuarial valuations.

The scheme poses a number of risks to the company, for example, longevity risk, investment risk, interest rate risk, inflation risk and salary risk. The trustees are aware of these risks and use various techniques to control them. The trustees have a number of internal control policies including a risk register, which are in place to manage and monitor the various risks they face.

---

# Page 56

# 53


## Notes to the Consolidated Financial Statements

continued


## 26. Retirement benefit obligations (continued)

The scheme is subject to regular actuarial valuations, which are usually carried out every three years. These actuarial valuations are carried out in accordance with the requirements of the Pensions Act 2004 and so include margins for prudence. This contrasts with these accounting disclosures, which are determined using best estimate assumptions.

The last formal actuarial valuation was carried out as at 5 April 2020. The results of that valuation have been projected forward to 30 June 2022 by a qualified independent actuary. The figures in the following disclosure were measured using the Projected Unit Method.

On 26 October 2018, the High Court reached a judgement in relation to Lloyds Banking Group's defined benefit pension schemes which concluded that schemes should equalise pension benefits for men and women as regards guaranteed minimum pension benefits. The impact of this judgement on the scheme has been estimated and included in the pension liability.

At the end of the reporting period the scheme was in surplus as measured under the principles of IAS19. Under the accounting standard an entity is allowed to recognise a pension scheme surplus on its balance sheet to the extent that it is able to realise an economic benefit from that surplus.

The directors have reviewed the rules of the scheme and have concluded that the company can gain full economic benefit from the scheme on the basis that the rules provide it access to any surplus after the last member has no further benefits in the scheme (referred to in the standard as gradual settlement). Furthermore, the rules are such that the trustees are not able to take any actions that would reduce the accounting surplus, such as benefit augmentations or triggering a scheme wind-up, without the company's action or consent.


|                                                           | 2022       | 2021       |
|-----------------------------------------------------------|------------|------------|
| Principal actuarial assumptions at the balance sheet date |            |            |
| Discount rate at end of year                              | 4.00%      | 2.05%      |
| Future salary increases                                   | 2.45%      | 2.55%      |
| Future pension increases                                  | 2.95%      | 3.00%      |
| Rate of inflation - RPI                                   | 3.05%      | 3.15%      |
| - CPI                                                     | 2.45%      | 2.55%      |
| Future expected lifetime of current pensioner at age 65:  |            |            |
| Male born in 1957                                         | 21.0 years | 20.9 years |
| Female born in 1957                                       | 23.4 years | 23.3 years |
| Future expected lifetime of future pensioner at age 65:   |            |            |
| Male born in 1977                                         | 22.3 years | 22.3 years |
| Female born in 1977                                       | 24.9 years | 24.8 years |



The sensitivities of the principal assumptions used to measure the scheme liabilities are as follows:
| Assumption        | Change in assumption   | Impact on scheme liabilities   |
|-------------------|------------------------|--------------------------------|
| Discount rate     | Decrease by 0.1%       | Increase by £0.8m              |
| Rate of inflation | Increase by 0.1%       | Increase by £0.5m              |
| Expected lifetime | Increase by 1 year     | Increase by £2.7m              |


The sensitivities may not be representative of the actual change in the present value of the scheme obligations, as it is unlikely that the change in assumptions would occur in isolation of each other, as the assumptions may be linked.


|                                                | 2022     | 2021     |
|------------------------------------------------|----------|----------|
| Amounts recognised in the balance sheet        | £'000    | £'000    |
| Present value of funded obligations            | (63,092) | (81,622) |
| Fair value of scheme assets                    | 69,236   | 77,265   |
| Net asset/(liability) before deferred taxation | 6,144    | (4,357)  |
| Related deferred tax (liability)/asset         | (1,536)  | 828      |
| Net asset/(liability) after deferred taxation  | 4,608    | (3,529)  |

---

# Page 57

# 54


## 26. Retirement benefit obligations (continued)


|                                                                                                    | 2022     | 2021     |
|----------------------------------------------------------------------------------------------------|----------|----------|
| Amounts recognised in the income statement                                                         | £'000    | £'000    |
| Current service cost                                                                               | (500)    | (620)    |
| Net interest cost                                                                                  | (74)     | (354)    |
|                                                                                                    | (574)    | (974)    |
|                                                                                                    | 2022     | 2021     |
|                                                                                                    | £'000    | £'000    |
| Amounts recognised in other comprehensive income                                                   |          |          |
| Return on assets excluding amount included in net interest cost                                    | (8,553)  | 9,009    |
| Gain arising from changes in financial assumptions                                                 | 18,303   | 877      |
| Gain arising from changes in demographic assumptions                                               | -        | 3,405    |
| Experience (loss)/gain                                                                             | (645)    | 2,398    |
|                                                                                                    | 9,105    | 15,689   |
| Deferred tax                                                                                       | (2,015)  | (2,981)  |
| Remeasurement of the net defined benefit liability                                                 | 7,090    | 12,708   |
| The actual return on the scheme assets in the year was a £6,980,000 loss (2021: £10,118,000 gain). | 2022     | 2021     |
| Changes in the present value of the scheme assets                                                  |          |          |
| Opening fair value of scheme assets                                                                | 77,265   | 67,272   |
| Interest income                                                                                    | 1,573    | 1,109    |
| Return on assets excluding interest income                                                         | (8,553)  | 9,009    |
| Employer contributions                                                                             | 1,970    | 4,144    |
| Employee contributions                                                                             | 152      | 181      |
| Benefits paid                                                                                      | (3,171)  | (4,450)  |
|                                                                                                    | 69,236   | 77,265   |
|                                                                                                    | 2022     | 2021     |
|                                                                                                    | £'000    | £'000    |
| Changes in the present value of the scheme obligations                                             |          |          |
| Opening defined benefit obligations                                                                | (81,622) | (90,488) |
| Service cost                                                                                       | (500)    | (620)    |
| Interest cost                                                                                      | (1,647)  | (1,463)  |
| Employee contributions                                                                             | (152)    | (181)    |
| Gain arising from changes in financial assumptions                                                 | 18,303   | 877      |
| Gain arising from changes in demographic assumptions                                               | -        | 3,405    |
| Experience (loss)/gain                                                                             | (645)    | 2,398    |
| Benefits paid                                                                                      | 3,171    | 4,450    |
|                                                                                                    | (63,092) | (81,622) |

---

# Page 58

# 55


## Notes to the Consolidated Financial Statements

continued


## 26. Retirement benefit obligations (continued)


|                                                                                      | 2022    | 2021     |
|--------------------------------------------------------------------------------------|---------|----------|
|                                                                                      | £'000   | £'000    |
| Changes in the net defined benefit asset/(liability)                                 |         |          |
| Opening net defined benefit liability                                                | (4,357) | (23,216) |
| Service cost                                                                         | (500)   | (620)    |
| Net interest cost                                                                    | (74)    | (354)    |
| Return on assets excluding interest income                                           | (8,553) | 9,009    |
| Gain arising from changes in financial assumptions                                   | 18,303  | 877      |
| Gain arising from changes in demographic assumptions                                 | -       | 3,405    |
| Experience (loss)/gain                                                               | (645)   | 2,398    |
| Employer contributions                                                               | 1,970   | 4,144    |
|                                                                                      | 6,144   | (4,357)  |
| Major categories of scheme assets                                                    | 2022    | 2021     |
|                                                                                      | £'000   | £'000    |
| UK and overseas equities                                                             | -       | 17,023   |
| Diversified growth fund                                                              |         |          |
|                                                                                      | 55,154  | 51,090   |
| Cash                                                                                 | 7,826   | 1,095    |
| Total market value of assets                                                         | 69,236  | 77,265   |
| The scheme has no investments in the company or in property occupied by the company. |         |          |
| Scheme liabilities by category of membership                                         |         |          |
|                                                                                      | 2022    | 2021     |
|                                                                                      | £'000   | £'000    |
| Active members                                                                       | 22,559  | 28,842   |
| Deferred pensioners                                                                  | 7,883   | 11,877   |
| Pensions in payment                                                                  | 32,650  | 40,903   |
|                                                                                      | 63,092  | 81,622   |
| Average duration of scheme liabilities                                               |         |          |
|                                                                                      | 2022    | 2021     |
|                                                                                      | years   | years    |
| Active members                                                                       | 15      | 17       |
| Deferred pensioners                                                                  | 16      | 18       |
| Pensions in payment                                                                  | 9       | 11       |
| All scheme liabilities                                                               | 12      | 14       |


Normal company contributions of £1,907,000 are expected to be paid into the scheme during the year ended 30 June 2023.

---

# Page 59

# 56


## 27. Share capital


| Ordinary shares - allotted, issued and fully paid   | 2022 Number   | 2021 Number   | 2022 £'000   | 2021 £'000   |
|-----------------------------------------------------|---------------|---------------|--------------|--------------|
| Opening ordinary shares of 5p each                  | 208,159,916   | 208,141,108   | 10,408       | 10,407       |
| Ordinary shares of 5p each issued                   | 212,110       | 18,808        | 11           | 1            |
| Ordinary shares of 5p each bonus issue              | 208,372,026   | -             | 10,418       | -            |
| Closing ordinary shares of 5p each                  | 416,744,052   | 208,159,916   | 20,837       | 10,408       |
| Ordinary B shares of 1p each                        | 16,042,530    | 16,042,530    | 160          | 160          |
| Total allotted, issued and fully paid               |               |               | 20,997       | 10,568       |


The ordinary shares of 5p each were issued during the year for a consideration of £823,000 (2021: £51,000).

The issued share capital was increased by a bonus issue of one fully paid ordinary share for each fully paid ordinary share held on the register at 14 January 2022.

The preference shares detailed below are included as financial instruments within creditors. Full details of these are given in note 11 of the financial statements of the company.


|                                           | 2022 £'000   | 2021 £'000   |
|-------------------------------------------|--------------|--------------|
| Allotted, issued and fully paid           |              |              |
| 200,000 5.5% preference shares of £1 each | 200          | 200          |


Throughout the remainder of this note all share numbers and share prices have been adjusted for the effect of the one-for-one bonus issue on 14 January 2022.


## Ordinary shares under option


Under the terms of the executive share option scheme approved on 3 December 1998, share options were granted and exercised during the year. The share options outstanding are as follows:
| Director          | Date of grant   | Date exercisable   | Date of expiry   | price (pence)   | Number 30.06.21   | Exercised in the year   | Granted in the year   | Number 30.06.22   |
|-------------------|-----------------|--------------------|------------------|-----------------|-------------------|-------------------------|-----------------------|-------------------|
| M Halstead        | 21 Jul 14       | 21 Jul 17          | 20 Jul 24        | 135.145         | 17,802            | -                       | -                     | 17,802            |
|                   | 12 Jun 17       | 12 Jun 20          | 11 Jun 27        | 238.250         | 100,000           | -                       | -                     | 100,000           |
|                   | 18 Oct 18       | 18 Oct 21          | 17 Oct 28        | 195.415         | 120,000           | -                       | -                     | 120,000           |
| G R Oliver        | 21 Jul 14       | 21 Jul 17          | 20 Jul 24        | 135.145         | 24,582            | -                       | -                     | 24,582            |
|                   | 12 Jun 17       | 12 Jun 20          | 11 Jun 27        | 238.250         | 100,000           | -                       | -                     | 100,000           |
|                   | 18 Oct 18       | 18 Oct 21          | 17 Oct 28        | 195.415         | 120,000           | -                       | -                     | 120,000           |
| Total - directors |                 |                    |                  |                 | 482,384           | -                       | -                     | 482,384           |
| Employees         |                 |                    |                  |                 |                   |                         |                       |                   |
|                   | 21 Jul 14       | 21 Jul 17          | 20 Jul 24        | 135.145         | 10,000            | (10,000)                | -                     | -                 |
|                   | 12 Jun 17       | 12 Jun 20          | 11 Jun 27        | 238.250         | 340,000           | -                       | -                     | 340,000           |
|                   | 22 Dec 17       | 22 Dec 20          | 21 Dec 27        | 218.040         | 40,000            | -                       | -                     | 40,000            |
|                   | 18 Oct 18       | 18 Oct 21          | 17 Oct 28        | 195.415         | 650,000           | (414,220)               | -                     | 235,780           |
|                   | 4 Oct 21        | 4 Oct 24           | 3 Oct 31         | 262.665         | -                 | -                       | 690,000               | 690,000           |
|                   | 27 Jun 22       | 27 Jun 25          | 26 Jun 31        | 205.330         | -                 | -                       | 20,000                | 20,000            |
| Total - employees |                 |                    |                  |                 | 1,040,000         | (424,220)               | 710,000               | 1,325,780         |
| Grand total       |                 |                    |                  |                 | 1,522,384         | (424,220)               | 710,000               | 1,808,164         |

---

# Page 60

# 57


## Notes to the Consolidated Financial Statements

continued


## 27. Share capital (continued)

The market price of the shares at 30 June 2022 was 203p (2021: 260p).The share price during the year ranged from 200p to 314p.

Directors exercised nil (2021: 37,616) share options during the year. Aggregate gains on exercising the share options by directors in the year amounted to £nil (2021: £46,000) of which £nil (2021: £27,000) related to the highest paid director.


A summary of movements in numbers of share options is as follows:
|                       | Number of options   | Weighted average exercise price   |
|-----------------------|---------------------|-----------------------------------|
| At 30 June 2020       | 1,600,000           | 208p                              |
| Exercised in the year | (37,616)            | 135p                              |
| Lapsed in the year    | (40,000)            | 239p                              |
| At 30 June 2021       | 1,522,384           | 209p                              |
| Exercised in the year | (424,220)           | 194p                              |
| Granted in the year   | 710,000             | 261p                              |
| At 30 June 2022       | 1,808,164           | 231p                              |


At 30 June 2022 there were 1,098,164 (2021: 52,384) share options exercisable at a weighted average exercise price of 215p (2021: 135p).

The weighted average remaining contractual life of share options outstanding at 30 June 2022 was 7.0 years (2021: 6.7 years).


## Share based payments

The group's equity settled share based payments comprise the grant of share options to certain employees under the group's executive share option scheme. Details of such options are given above. The group calculated the fair value of the options at the date of grant using the Black Scholes model.

An expense based on the fair value calculated at the date of grant was recognised in the income statement over the vesting period of the options. The share based payment expense for the year ended 30 June 2022 was £6,000 (2021: £8,000).


The inputs into the Black Scholes model for the share options granted in the year were as follows:
| Expected life of option         | 3 Years   | 3 Years   |
|---------------------------------|-----------|-----------|
| Expected share price volatility | 17.5%     | 17.5%     |
| Expected dividend yield         | 3.5%      | 3.9%      |
| Risk free interest rate         | 0.8%      | 1.9%      |
| Exercise price                  | 263p      | 205p      |

---

# Page 61

# 28. Reserves

The nature and purpose of each reserve within equity is as follows.


## Reserve


## Description and purpose

Equity share capital

Nominal value of equity share capital issued.

Share premium account

Amount subscribed for equity share capital in excess of nominal value.

Capital redemption reserve

Amounts transferred from share capital on redemption of issued shares.

Currency translation reserve

Cumulative  currency  translation  gains  and  losses  arising  on  the retranslation of the net assets of the group's foreign operations.

Hedging reserve

Gains and losses arising on the fair value of financial instruments in an effective designated cash flow hedging relationship.

Retained earnings

All other  gains  and  losses  and  transactions  with  owners,  such  as dividends, not recognised in other reserves.

The share premium account and capital redemption reserve were utilised in paying up at par the new ordinary shares issued for the bonus issue on 14 January 2022.


## 29. Derivative financial instruments

The group is exposed to foreign currency risk on sales and purchases that are denominated in a currency other than the functional currency of the entity concerned. The currencies giving rise to this risk are various, but the most significant are the US Dollar and the Euro. Forward exchange contracts are used to manage this exposure to fluctuations in foreign exchange rates. The group buys or sells foreign currency at spot where necessary to address any short-term imbalances.

The group hedges, using forward exchange contracts, transactions denominated in a foreign currency which are not matched against other transactions in the same currency within the group.The forward exchange contracts have maturities of less than one year after the balance sheet date.

The group classifies its forward exchange contracts hedging forecasted transactions as cash flow hedges and states them at fair value. The hedged cash flows are expected to occur within one year after the balance sheet date.

The fair  values  have  been  calculated  by  applying  (where  relevant),  for  equivalent  maturity  profiles,  the  rate  at  which  forward currency contracts with the same principal amounts could be acquired at the balance sheet date.

Changes in the fair value of forward exchange contracts for which no hedge accounting is applied or where the hedge is considered ineffective are recognised in the income statement.

Other than the use of forward exchange contracts as detailed above,  the group does not make use of derivative financial instruments.


## 58

---

# Page 62

# 59


## Notes to the Consolidated Financial Statements

continued


## 30. Financial instruments

For cash and cash equivalents and trade and other payables and receivables the fair value approximates to their book value due to the short maturity profile of these financial instruments. On receivables, allowances are made within the book value for credit risk. The fair value of forward exchange contracts is determined by reference to spot rates adjusted for the forward points to the contract value date.


The book values and fair values of financial instruments are set out below:
|                             | 2022 Book value £'000   | 2022 Fair value £'000   | 2021 Book value £'000   | 2021 Fair value £'000   |
|-----------------------------|-------------------------|-------------------------|-------------------------|-------------------------|
| Current:                    |                         |                         |                         |                         |
| Trade and other receivables | 48,515                  | 48,515                  | 40,520                  | 40,520                  |
| Forward exchange contracts  | 2,166                   | 2,166                   | 848                     | 848                     |
| Cash and cash equivalents   | 52,144                  | 52,144                  | 83,261                  | 83,261                  |
| Trade and other payables    | (78,942)                | (78,942)                | (59,313)                | (59,313)                |
| Forward exchange contracts  | (517)                   | (517)                   | (92)                    | (92)                    |
| Lease liabilities           | (2,166)                 | (2,166)                 | (2,948)                 | (2,948)                 |
| Total                       | 21,200                  | 21,200                  | 62,276                  | 62,276                  |
| Non-current:                |                         |                         |                         |                         |
| Other payables              | (453)                   | (453)                   | (447)                   | (447)                   |
| Lease liabilities           | (3,548)                 | (3,548)                 | (3,236)                 | (3,236)                 |
| Preference shares           | (200)                   | (200)                   | (200)                   | (200)                   |
| Total                       | (4,201)                 | (4,201)                 | (3,883)                 | (3,883)                 |


Other than forward exchange contracts which are categorised as derivative instruments, all financial assets are categorised as financial assets measured at amortised cost and all financial liabilities are categorised as financial liabilities measured at amortised cost.

The following table provides an analysis of financial instruments that are measured subsequent to initial recognition at fair value. IFRS 7 requires that these be grouped into Levels 1 to 3 based on the degree to which the fair value is observable. All items in the table below are categorised as Level 2 which, as defined by IFRS 7, refers to those items whose fair value measurement is derived from inputs other than that are observable for the asset or liability either directly or indirectly.


|                                                                          | 2022 £'000   |   2021 £'000 |
|--------------------------------------------------------------------------|--------------|--------------|
| Forward exchange contracts at fair value through profit and loss account | 24           |            8 |
| Forward exchange contracts at fair value through hedging reserve         | 1,625        |          749 |
|                                                                          | 1,649        |          757 |



## Sensitivity analysis

The group's principal exposures in relation to market risks are to changes in the euro exchange rate against sterling and to changes in UK interest rates. The group does not fix the interest rate receivable on its sterling balances, and based on balances held at the year  end,  a  1%  increase  or  decrease  in  sterling  interest  rates  would  lead  to  an  increase  or  decrease  in  post-tax  earnings  of £239,000 (2021: £523,000). The table below details the notional impact of changes in the euro exchange rate against sterling on the group's post-tax profit and equity. The gains and losses arise from the translation of receivables, payables, cash and forward exchange contracts which are denominated in currencies other than each subsidiary's reporting currency.


|                                   | 2022             | 2022                    | 2021                    | 2021   |
|-----------------------------------|------------------|-------------------------|-------------------------|--------|
|                                   | Post-tax profits | Equity Post-tax profits | Equity Post-tax profits | Equity |
|                                   | £'000            | £'000                   | £'000                   | £'000  |
| Euro 5% stronger against sterling | 36               | 36                      | 2                       | 2      |
| Euro 5% weaker against sterling   | (32)             | (32)                    | (2)                     | (2)    |

---

# Page 63

# 31. Group companies


At 30 June 2022, the trading subsidiaries of the group were:
| Name of subsidiary                    | Activity                                | Country of  incorporation   |   Proportion owned (%) |
|---------------------------------------|-----------------------------------------|-----------------------------|------------------------|
| Polyflor Limited                      | Flooring manufacturing and distribution | England                     |                    100 |
| Riverside Flooring Limited            | Flooring manufacturing                  | England                     |                    100 |
| Polyflor Australia Pty Limited        | Flooring distribution                   | Australia                   |                    100 |
| Polyflor New Zealand Limited          | Flooring distribution                   | New Zealand                 |                    100 |
| Polyflor Canada Inc                   | Flooring distribution                   | Canada                      |                    100 |
| Polyflor India Pvt Limited            | Flooring distribution                   | India                       |                    100 |
| Polyflor (M) SDN BHD                  | Flooring distribution                   | Malaysia                    |                    100 |
| Objectflor Art und Design Belags GmbH | Flooring distribution                   | Germany                     |                    100 |
| Karndean International GmbH           | Flooring distribution                   | Germany                     |                    100 |
| James Halstead France SAS             | Flooring distribution                   | France                      |                    100 |
| Falck Design AB                       | Flooring distribution                   | Sweden                      |                    100 |


A complete list of the group's subsidiaries is provided in note 4 of the financial statements of the company.


## 32. Exchange rates


The currency exchange rates used to translate the results, assets and liabilities of foreign subsidiaries were:
|                    |   2022 Closing |   2022 Average |   2021 Closing |   2021 Average |
|--------------------|----------------|----------------|----------------|----------------|
| Euro               |           1.16 |           1.18 |           1.16 |           1.13 |
| Australian dollar  |           1.77 |           1.83 |           1.84 |           1.8  |
| New Zealand dollar |           1.95 |           1.96 |           1.98 |           1.94 |
| Canadian dollar    |           1.57 |           1.68 |           1.71 |           1.73 |
| Swedish krona      |          12.44 |          12.18 |          11.81 |          11.53 |
| Indian rupee       |          95.91 |         100.05 |         102.68 |          99.11 |
| Malaysian ringgit  |           5.35 |           5.62 |           5.74 |           5.55 |
| UAE dirham         |           4.46 |           4.89 |           5.07 |           4.95 |



## 33. Related parties

Transactions between the company and its subsidiaries have been eliminated on consolidation and are not disclosed in this note. The group's contributions to the defined benefit pension scheme are disclosed in note 26.

Details of other related party transactions for the group are shown in the directors' report, board report on remuneration and in the notes to the financial statements. The key management personnel are the directors.

Polyflor Limited, a subsidiary of the company, leases cars from a company of which Mr Russell Whiting is a director. The lease payments during the year were £41,000 (2021 £81,000) and the maximum outstanding lease commitments at 30 June 2022 were £128,000 (2021: £18,000).


## 60

---

# Page 64

# 61


## Company Balance Sheet

as at 30 June 2022


|                                        | Note   | 2022     | 2021     |
|----------------------------------------|--------|----------|----------|
|                                        |        | £'000    | £'000    |
| Fixed assets                           |        |          |          |
| Tangible fixed assets                  | 3      | 4,291    | 4,363    |
| Investments                            | 4      | 40,152   | 40,152   |
|                                        |        | 44,443   | 44,515   |
| Current assets                         |        |          |          |
| Debtors due within one year            | 5      | 63,042   | 36,148   |
| Debtors due after one year             | 5      | -        | 615      |
| Retirement benefit obligations         | 10     | 6,144    | -        |
| Total debtors                          |        | 69,186   | 36,763   |
| Derivative financial instruments       | 7      | 2,166    | 848      |
| Cash at bank and in hand               |        | 41,171   | 69,860   |
| Total current assets                   |        | 112,523  | 107,471  |
| Creditors due within one year          | 8      | (11,063) | (11,210) |
| Derivative financial instruments       | 7      | (517)    | (92)     |
| Net current assets                     |        | 100,943  | 96,169   |
| Total assets less current liabilities  |        | 145,386  | 140,684  |
| Creditors due after more than one year | 9      | (200)    | (200)    |
| Provision for liabilities              | 6      | (1,765)  | -        |
| Retirement benefit obligations         | 10     | -        | (4,357)  |
| Net assets                             |        | 143,421  | 136,127  |
| Capital and reserves                   |        |          |          |
| Equity share capital                   |        | 20,837   | 10,408   |
| Equity share capital (B shares)        |        | 160      | 160      |
| Called up share capital                | 11     | 20,997   | 10,568   |
| Share premium account                  |        | -        | 4,122    |
| Capital redemption reserve             |        | -        | 1,174    |
| Hedging reserve                        |        | 1,625    | 749      |
| Profit and loss account                |        | 120,799  | 119,514  |
| Total shareholders' funds              |        | 143,421  | 136,127  |


The company has taken advantage of the provisions of Section 408 of the Companies Act 2006 and has elected not to present its own profit and loss account. The profit after taxation for the financial year dealt with in the financial statements of the company was £30,797,000 (2021: £43,332,000).

The financial statements were approved and authorised for issue by the board and were signed on its behalf on 30 September 2022.

M Halstead

G R Oliver

Director

Director

James Halstead plc           Registration Number 140269

---

# Page 65

# Company Statement of Changes in Equity

for the year ended 30 June 2022


|                                       | Share  capital  £'000   | Share  premium  £'000   | Capital  redemption  reserve  £'000   | Hedging reserve £'000   | Profit and loss account £'000   | Total shareholders' funds £'000   |
|---------------------------------------|-------------------------|-------------------------|---------------------------------------|-------------------------|---------------------------------|-----------------------------------|
| Balance at 30 June 2020               | 10,567                  | 4,072                   | 1,174                                 | (805)                   | 97,549                          | 112,557                           |
| Profit for the year                   | -                       | -                       | -                                     | -                       | 43,332                          | 43,332                            |
| Remeasurement of the net defined      |                         |                         |                                       |                         |                                 |                                   |
| benefit liability                     | -                       | -                       | -                                     | -                       | 12,708                          | 12,708                            |
| Fair value movements on               |                         |                         |                                       |                         |                                 |                                   |
| hedging instruments                   | -                       | -                       | -                                     | 1,554                   | -                               | 1,554                             |
| Total comprehensive income for        |                         |                         |                                       |                         |                                 |                                   |
| the year                              | -                       | -                       | -                                     |                         |                                 | 57,594                            |
|                                       |                         |                         |                                       | 1,554                   | 56,040                          |                                   |
| Dividends                             | -                       | -                       | -                                     | -                       | (34,083)                        | (34,083)                          |
| Issue of share capital                | 1                       | 50                      | -                                     | -                       | -                               | 51                                |
| Share based payments                  | -                       | -                       | -                                     | -                       | 8                               | 8                                 |
| Balance at 30 June 2021               | 10,568                  | 4,122                   | 1,174                                 | 749                     | 119,514                         | 136,127                           |
| Profit for the year                   |                         |                         |                                       |                         |                                 |                                   |
|                                       | -                       | -                       | -                                     | -                       | 30,797                          | 30,797                            |
| Remeasurement of the net defined      |                         |                         |                                       |                         |                                 |                                   |
| benefit liability                     | -                       | -                       | -                                     | -                       | 7,090                           | 7,090                             |
| Fair value movements on               |                         |                         |                                       |                         |                                 |                                   |
| hedging instruments                   | -                       | -                       | -                                     | 876                     | -                               | 876                               |
| Total comprehensive income for        |                         |                         |                                       |                         |                                 |                                   |
| the year                              | -                       | -                       | -                                     | 876                     | 37,887                          | 38,763                            |
| Transactions with equity shareholders |                         |                         |                                       |                         |                                 |                                   |
| Dividends                             | -                       | -                       | -                                     | -                       | (32,298)                        | (32,298)                          |
| Issue of share capital                | 11                      | 812                     | -                                     | -                       | -                               | 823                               |
| Bonus issue of share capital          | 10,418                  | (4,934)                 | (1,174)                               | -                       | (4,310)                         | -                                 |
| Share based payments                  | -                       | -                       | -                                     | -                       | 6                               | 6                                 |
| Balance at 30 June 2022               | 20,997                  | -                       | -                                     | 1,625                   | 120,799                         | 143,421                           |



## 62

---

# Page 66

# 63


## Notes to the Company Financial Statements


## 1. Accounting policies


## Basis of preparation

The separate financial statements of the company are presented as required by the Companies Act 2006. The company meets the definition of a qualifying entity under FRS 100 Application of Financial Reporting Requirements issued by the Financial Reporting Council. Accordingly, the financial statements have been prepared in accordance with FRS 101 Reduced Disclosure Framework as issued by the Financial Reporting Council.

The company has used the disclosure exemptions available under FRS 101 in relation to presentation of a cash flow statement, comparative information for certain assets, capital management, transactions with other group companies, compensation of key management personnel and the effects of new but not yet effective IFRS.

As the consolidated financial statements include the equivalent disclosures, the company has used the disclosure exemptions available under FRS 101 in relation to share based payments, and financial instruments. The disclosures for the defined benefit retirement obligations are included in the consolidated financial statements.

The financial statements are prepared on a going concern basis and in accordance with the historical cost convention, except for certain financial instruments that have been measured at fair value.

The  statement  on  going  concern  in  the  consolidated  financial  statements  also  justifies  the  going  concern  basis  used  for  the company financial statements.

The  accounting  policies  of  the  company  are  the  same  as  those  set  out  in  the  consolidated  financial  statements. The  critical accounting estimates and judgements are income taxes and retirement benefit obligations as set out in the consolidated financial statements.

The following additional accounting policies are specific to the company's financial statements.


## Investments

Investments in subsidiaries are stated at cost less provision for impairment in value.


## Investment land and buildings

Investment land and buildings are stated at cost less depreciation and any provision for impairment. Depreciation is calculated to write off the buildings on a straight line basis over their estimated economic life of fifty years. No depreciation is charged in respect of land.


## Group debtors

Amounts owed by group undertakings are stated after any provision for expected credit loss in line with the three stage model in IFRS 9.

---

# Page 67

# 64


## 2. Staff costs and numbers


|                        | 2022 £'000   | 2021 £'000   |
|------------------------|--------------|--------------|
| Staff costs comprised: |              |              |
| Wages and salaries     | 3,493        | 3,105        |
| Social security costs  | 472          | 399          |
| Pension costs          | 98           | 99           |
| Share based payments   | 6            | 8            |
|                        | 4,069        | 3,611        |


The average monthly number of employees during the year was 22 (2021: 22).


## 3. Tangible fixed assets


|                     | Investment land and buildings £'000   | Freehold land and buildings £'000   | Plant and equipment £'000   | Total £'000   |
|---------------------|---------------------------------------|-------------------------------------|-----------------------------|---------------|
| Cost                |                                       |                                     |                             |               |
| At 30 June 2021     | 7,978                                 | 1,311                               | 581                         | 9,870         |
| Additions           | 113                                   | 15                                  | 15                          | 143           |
| At 30 June 2022     | 8,091                                 | 1,326                               | 596                         | 10,013        |
| Depreciation        |                                       |                                     |                             |               |
| At 30 June 2021     | 4,796                                 | 325                                 | 386                         | 5,507         |
| Charge for the year | 158                                   | 25                                  | 32                          | 215           |
| At 30 June 2022     | 4,954                                 | 350                                 | 418                         | 5,722         |
| Net book value      |                                       |                                     |                             |               |
| At 30 June 2022     | 3,137                                 | 976                                 | 178                         | 4,291         |
| At 30 June 2021     | 3,182                                 | 986                                 | 195                         | 4,363         |


The investment land and buildings relates to a freehold property that is occupied by a subsidiary company. The rental income was £600,000 (2021: £600,000).

---

# Page 68

# 65


## Notes to the Company Financial Statements

continued


## 4. Investments


|                          | Shares in subsidiary undertakings £'000   |
|--------------------------|-------------------------------------------|
| Cost                     |                                           |
| At 30 June 2021          | 49,552                                    |
| At 30 June 2022          | 49,552                                    |
| Provision for impairment |                                           |
| At 30 June 2021          | 9,400                                     |
| At 30 June 2022          | 9,400                                     |
| Net book value           |                                           |
| At 30 June 2022          | 40,152                                    |
| At 30 June 2021          | 40,152                                    |



At 30 June 2022, the company held directly and indirectly 100% of the equity and voting rights of the following undertakings:
| Subsidiary                              | Activity                                | Country of  incorporation   | Proportion owned (%)   |
|-----------------------------------------|-----------------------------------------|-----------------------------|------------------------|
| Owned by the company                    |                                         |                             |                        |
| Polyflor Limited                        | Flooring manufacturing and distribution | England                     | 100                    |
| Riverside Flooring Limited              | Flooring manufacturing                  | England                     | 100                    |
| Titan Leisure Group Limited             | Holding company                         | England                     | 100                    |
| Halstead Flooring International Limited | Dormant company                         | England                     | 100                    |
| Expona Limited                          | Dormant company                         | England                     | 100                    |
| JHL Limited                             | Dormant company                         | England                     | 100                    |
| Arai (UK) Limited                       | Dormant company                         | England                     | 100                    |
| James Halstead Pension Co Limited       | Dormant company                         | England                     | 100                    |
| Halstead Floorings Limited              | Dormant company                         | Ireland                     | 100                    |
| Halstead Flooring Concepts Pty Limited  | Holding company                         | Australia                   | 100                    |
| Polyflor Canada Inc                     | Flooring distribution                   | Canada                      | 100                    |
| Polyflor India Pvt Limited              | Flooring distribution                   | India                       | 100                    |
| Polyflor (M) SDN BHD                    | Flooring distribution                   | Malaysia                    | 100                    |
| Objectflor Art und Design Belags GmbH   | Flooring distribution                   | Germany                     | 100                    |
| James Halstead France SAS               | Flooring distribution                   | France                      | 100                    |
| Falck Design AB                         | Flooring distribution                   | Sweden                      | 100                    |
| Owned by subsidiaries                   |                                         |                             |                        |
| Phoenix Distribution (NW) Limited       | Dormant company                         | England                     | 100                    |
| Polyflor Australia Pty Limited          | Flooring distribution                   | Australia                   | 100                    |
| Colonia Flooring Pty Limited            | Dormant company                         | Australia                   | 100                    |
| Polyflor New Zealand Limited            | Flooring distribution                   | New Zealand                 | 100                    |
| Karndean International GmbH             | Flooring distribution                   | Germany                     | 100                    |
| Polyflor FZE                            | Sales office                            | UAE                         | 100                    |

---

# Page 69

# 4. Investments continued

Subsidiary

Registered office

Polyflor Limited Riverside Flooring Limited Titan Leisure Group Limited Halstead Flooring International Limited Expona Limited JHL Limited Arai (UK) Limited James Halstead Pension Co Limited Phoenix Distribution (NW) Limited

Beechfield Hollinhurst Road Radcliffe Manchester M26 1JN England

Halstead Floorings Limited

24/26 City Quay Dublin 2 D02NY19

Ireland

Halstead Flooring Concepts Pty Limited Polyflor Australia Pty Limited Colonia Flooring Pty Limited

101 Prosperity Way Dandenong VIC 3175

Australia

Polyflor Canada Inc

3209 Orlando Drive Mississauga Ontario L4V IC5

Canada

Polyflor India Pty Limited

B-408 Knox Plaza Mindspace, Malad West Mumbai 400 064 India

Polyflor (M) SDN BHD

802, 8th Floor, Block C Kelana Square 17 Jalan 557/26 Petaling Jaya Salangor 47301 Malaysia

Objectflor Art und Design Belags GmbH Karndean International GmbH

Wankelstrasse 50 D 50996 Koln Germany

James Halstead France SAS

Parc Saint Christophe 10 Avenue de l'Enterprise 95861 Cergy Pontoise France

Falck Design AB

Box 102 51 434 23 Kungsbacka Besoksadress Energigatan 9 Sweden

Polyflor New Zealand Limited

2 Narek Place Manukau City Auckland 2104 New Zealand

Polyflor FZE

Office No LB16112 PO Box 17054 Jafza 16 Building Jebel Ali Free Zone Dubai

UAE


## 66

---

# Page 70

# 67


## Notes to the Company Financial Statements

continued


## 5. Debtors


|                                    | 2022 £'000   | 2021 £'000   |
|------------------------------------|--------------|--------------|
| Trade debtors                      | 172          | 26           |
| Amounts owed by group undertakings | 62,084       | 35,691       |
| Corporation tax                    | 544          | 90           |
| Other debtors                      | 86           | 86           |
| Prepayments                        | 156          | 255          |
| Debtors due within one year        | 63,042       | 36,148       |
| Deferred tax assets (note 6)       | -            | 615          |
| Debtors due after one year         | -            | 615          |



## 6. Deferred tax assets/(liabilities)


|                                       | Retirement benefit obligations £'000   | Accelerated tax depreciation £'000   | Other timing differences £'000   | Total £'000   |
|---------------------------------------|----------------------------------------|--------------------------------------|----------------------------------|---------------|
| At 30 June 2021                       | 828                                    | (231)                                | 18                               | 615           |
| Charged to income                     | (349)                                  | 2                                    | (18)                             | (365)         |
| Charged to other comprehensive income | (2,015)                                | -                                    | -                                | (2,015)       |
| At 30 June 2022                       | (1,536)                                | (229)                                | -                                | (1,765)       |



## 7. Derivative financial instruments

Derivative financial instruments are forward foreign exchange contracts recognised in the balance sheet at fair value.


## 8. Creditors due within one year


|                                    | 2022 £'000   | 2021 £'000   |
|------------------------------------|--------------|--------------|
| Trade creditors                    | 370          | 241          |
| Amounts due to group undertakings  | 6,631        | 7,367        |
| Other taxation and social security | 122          | 117          |
| Other creditors                    | 427          | 601          |
| Accruals                           | 3,513        | 2,884        |
|                                    | 11,063       | 11,210       |

---

# Page 71

# 68


## 9. Creditors due after more than one year


|                                     | 2022 £'000   | 2021 £'000   |
|-------------------------------------|--------------|--------------|
| Preference shares                   | 200          | 200          |
| 10. Retirement benefit obligations  |              |              |
|                                     | 2022         | 2021         |
|                                     | £'000        | £'000        |
| Present value of funded obligations | (63,092)     | (81,622)     |
| Fair value of scheme assets         | 69,236       | 77,265       |
| Net asset/(liability)               | 6,144        | (4,357)      |


The company sponsors the Halstead Group Pension Scheme. Disclosure information is provided in note 26 to the consolidated financial statements.


## 11. Share capital


| Ordinary shares - allotted, issued and fully paid   | 2022 Number   | 2021 Number   | 2022 £'000   | 2021 £'000   |
|-----------------------------------------------------|---------------|---------------|--------------|--------------|
| Opening ordinary shares of 5p each                  | 208,159,916   | 208,141,108   | 10,408       | 10,407       |
| Ordinary shares of 5p each issued                   | 212,110       | 18,808        | 11           | 1            |
| Ordinary shares of 5p each bonus issue              | 208,372,026   | -             | 10,418       | -            |
| Closing ordinary shares of 5p each                  | 416,744,052   | 208,159,916   | 20,837       | 10,408       |
| Ordinary B shares of 1p each                        | 16,042,530    | 16,042,530    | 160          | 160          |
| Total allotted, issued and fully paid               |               |               | 20,997       | 10,568       |


The ordinary shares of 5p each were issued during the year for a consideration of £823,000 (2021: £51,000).

The issued share capital was increased by a bonus issue of one fully paid ordinary share for each fully paid ordinary share held on the register at 14 January 2022.

Shareholders approved a proposal for the return of capital ('return of capital') at an extraordinary general meeting on 6 December 2004. This resulted in the creation of the 1 pence B ordinary shares ('B shares'), which were issued on 14 January 2005. Following the issue of the B shares, holders received a single dividend of 60 pence per B share. The B shares are not listed, have extremely limited rights and are of negligible value.

The preference shares detailed below are included as financial instruments within creditors.


|                                           | 2022 £'000   | 2021 £'000   |
|-------------------------------------------|--------------|--------------|
| Allotted, issued and fully paid           |              |              |
| 200,000 5.5% preference shares of £1 each | 200          | 200          |

---

# Page 72

# 69


## Notes to the Company Financial Statements

continued


## 11. Share capital (continued)

The 5.5% cumulative preference shares of £1 shall confer on the holders thereof the right to receive in priority to all other shares in the capital of the company out of the profits of the company which it shall be determined to distribute, a fixed cumulative preferential dividend at the rate of 5.5% per annum on the capital for the time being paid up thereon and the right in the event of a winding up, in priority to all other shares in the capital of the company, to repayment of the capital paid up thereon together with a premium of 5p per share and a sum equivalent to any arrears and accruals of the said fixed cumulative preferential dividend thereon (whether earned or declared or not) calculated up to the date of such repayment of capital but shall not confer any further right to participate in profits or assets of James Halstead plc.


The company shall not be at liberty to create or issue any further shares ranking in priority to or pari passu with the preference shares  without  the  consent  in  writing  of  the  holders  of  three-fourths  of  the  issued  preference  shares  or  the  sanction  of  an extraordinary  resolution  of  the  holders  of  such  preference  shares  passed  at  a  separate  general  meeting  of  such  holders. The preference shares shall not confer upon the holders thereof the right to attend or vote at any general meeting of the company or to receive notice thereof, unless either:
- (i)  At the date of the notice convening the meeting the fixed cumulative preferential dividend on the preference shares is six months in arrears and then so long only as such dividend shall remain unpaid, and so that for this purpose the dividend on the preference shares shall be deemed to accrue due and be payable by equal half-yearly instalments on 30 June and 31 December in every year, or
- (ii)  The business of the meeting includes the consideration of a resolution for reducing the capital or winding up the company or for the sale of its undertaking or of any resolution directly abrogating or varying any of the special rights or privileges attached to the preference shares.


The  preference  shares  shall  nevertheless  entitle  the  holders  thereof  to  receive  notice  of  every  general  meeting. At  a  general meeting at which the holders of preference shares are entitled to attend and vote, the preference shares shall entitle a holder thereof, or his proxy, to vote only for every preference share held by him.


## 12. Related party transactions

The company has taken advantage of the exemption granted by FRS 101 not to disclose transactions and balances with other group companies.

---

# Page 73

# 70


## Ten Year Summary (Unaudited)


|                             | 2013 £'000   | 2014 £'000   | 2015 £'000   | 2016 £'000   | 2017 £'000   | 2018 £'000   | 2019 £'000   | 2020 £'000   | 2021 £'000   | 2022 £'000   |
|-----------------------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|
| Revenue                     | 217,082      | 223,488      | 227,261      | 226,141      | 240,784      | 249,510      | 253,038      | 238,630      | 266,362      | 291,860      |
| Profit before income tax    | 40,495       | 41,753       | 44,184       | 45,499       | 46,616       | 46,702       | 48,276       | 43,857       | 51,268       | 52,063       |
| Income tax                  | (10,446)     | (10,301)     | (10,250)     | (10,243)     | (10,106)     | (9,994)      | (10,484)     | (9,502)      | (11,407)     | (11,735)     |
| Profit after income tax     | 30,049       | 31,452       | 33,934       | 35,256       | 36,510       | 36,708       | 37,792       | 34,355       | 39,861       | 40,328       |
|                             | 2013         | 2014         | 2015         | 2016         | 2017         | 2018         | 2019         | 2020         | 2021         | 2022         |
| Basic earnings per 5p share | 7.3p         | 7.6p         | 8.2p         | 8.5p         | 8.8p         | 8.8p         | 9.1p         | 8.3p         | 9.6p         | 9.7p         |
| Dividends per 5p share      | 4.4p         | 5.0p         | 5.5p         | 6.0p         | 6.5p         | 6.8p         | 7.0p         | 7.1p         | 7.6p         | 7.8p         |


Special dividends are not included.

Figures for the previous years have been restated to take account of the one-for-one bonus share issue in the year ended 30 June 2022.

---

# Page 74

# 71


## Shareholder Information


## Financial calendar

Annual general meeting

1 December 2022


## Announcement of results

For the half year

March

For the full year

September


## Dividend payments

Ordinary shares - interim

June

- final

December

Preference shares

June and December


## Share dealing information

The ordinary shares of the company are traded on the Alternative Investment Market of the London Stock Exchange.

Information concerning the day-to-day movement of the share price can be found on the London Stock Exchange website.


## Shareholder analysis


| as at 16 September 2022                  | Number of holders   | Number of shares   | %     |
|------------------------------------------|---------------------|--------------------|-------|
| By size of holding                       |                     |                    |       |
| 1-20,000                                 | 1,392               | 8,566,346          | 2.1   |
| 20,001-100,000                           | 431                 | 19,697,283         | 4.7   |
| 100,001-200,000                          | 65                  | 8,887,594          | 2.1   |
| 200,001-1,000,000                        | 80                  | 35,349,844         | 8.5   |
| 1,000,001 and over                       | 52                  | 344,252,985        | 82.6  |
|                                          | 2,020               | 416,754,052        | 100.0 |
|                                          | Number of holders   | Number of shares   | %     |
| By category                              |                     |                    |       |
| Private individuals                      | 1,709               | 203,466,777        | 48.8  |
| Banks and nominee companies              | 268                 | 211,324,700        | 50.7  |
| Other limited companies/corporate bodies | 29                  | 1,463,777          | 0.4   |
| Miscellaneous bodies/pension funds       | 9                   | 333,966            | 0.1   |
| Investment trusts and funds              | 5                   | 164,832            | 0.0   |
|                                          | 2,020               | 416,754,052        | 100.0 |

---

# Page 75

# 72


## Notice of Annual General Meeting

NOTICE IS HEREBY GIVEN that the ONE HUNDREDTH and SEVENTH ANNUAL GENERAL MEETING of the company will be held at Platinum Suite, The University of Bolton Stadium, De Havilland Way, Bolton, BL6 6SF, on 1 December 2022 at 12pm.


## Ordinary business


- 1 To receive and adopt the report of the directors and the statement of accounts for the year ended 30 June 2022 together with the report of the auditors.
- 2 To declare a final dividend on the ordinary shares in the capital of the company for the year ended 30 June 2022.
- 3 To re-elect Mr G R Oliver who is retiring by rotation under the articles of association as a director.
- 4 To re-elect Mr S D Hall who is retiring by rotation under the articles of association as a director.
- 5 To  re-appoint BDO LLP as auditors of the company and authorise the directors to fix their remuneration for the ensuing year.



## Special business


To consider and, if thought fit, pass the following resolutions of which resolutions 6 and 7 shall be proposed as ordinary resolutions and resolutions 8 and 9 will be proposed as special resolutions:
- 6 That, subject to the passing of the ordinary and special resolutions numbered 8 and 9 below, the directors be and they are hereby authorised, pursuant to article 35.14 of the company's articles of association:
- (i) to exercise the power contained in article 35.14 so that, to the extent determined by the directors, the holders of ordinary shares be permitted to elect to receive new ordinary shares of 5.0p each in the capital of the company, credited as fully paid, instead of all or part of any interim or final dividends which shall be declared before the conclusion of the next annual general meeting of the company after the passing of this resolution; and
- (ii) to capitalise the appropriate amount of new ordinary shares falling to be allotted pursuant to any elections made as aforesaid out of profits, or sums standing to the credit of any share premium account or capital reserves of the company, to apply such sums in paying up such new ordinary shares and to allot such new ordinary shares to the members of the company making such elections in accordance with their respective entitlements.
- 7 That in substitution for all existing and unexercised authorities and powers, the directors of the company be and they are hereby generally and unconditionally authorised for the purpose of section 551 Companies Act 2006 (the 'Act') to exercise all or any of the powers of the company to allot shares of the company or to grant rights to subscribe for, or to convert any security into, shares of the company (such shares and rights being together referred to as 'Relevant Securities') up to an aggregate nominal value of £6,945,901 to such persons at such times and generally on such terms and conditions as the directors may determine (subject always to the articles of association of the company) PROVIDED THAT this authority shall, unless previously renewed, varied or revoked by the company in general meeting, expire  at  the  conclusion  of  the  next  annual  general  meeting  or  on  the  date  which  is  six  months  after  the  next accounting reference date of the company (if earlier) save that the directors of the company may, before the expiry of such period, make an offer or agreement which would or might require relevant securities or equity securities (as the case may be) to be allotted after the expiry of such period and the directors of the company may allot relevant securities  or  equity  securities  (as  the  case  may  be)  in  pursuance  of  such  offer  or  agreement  as  if  the  authority conferred hereby had not expired.
- 8 That  subject  to  the  passing  of  the  ordinary  resolution  numbered 8  above  the  directors  be  and  they  are  hereby empowered pursuant to Section 570 of the Companies Act 2006 to allot equity securities (within the meaning of Section 560 subsection (1) of the said Act) for cash pursuant to the authority conferred by resolution numbered 6 above as if Section 561 of the said Act did not apply to any such allotment provided that this power shall be limited to:
- (i) the allotment of equity securities in connection with an offer of such securities by way of rights to holders of ordinary shares in proportion (as nearly as may be practical) to their respective holdings of such shares, but subject to such exclusions or other arrangements as the directors may deem necessary or expedient in relation to  fractional  entitlements  or  any  legal  or  practical  problems  under  the  laws  of  any  territory,  or  the requirements of any regulatory body or stock exchange; and
- (ii) the allotment (otherwise than pursuant to sub-paragraph (i) above) of equity securities up to an aggregate nominal amount of 5% of the ordinary share capital of the company in issue at the date of the passing of this resolution

---

# Page 76

# 73


## Notice of Annual General Meeting


## continued

and shall expire at the conclusion of the next annual general meeting or on the date which is six months after the next accounting reference date of the company (if earlier) save that the company may before such expiry make an offer or agreement which would or might require equity securities to be allotted after such expiry and the directors may allot equity securities in pursuance of such an offer or agreement as if the power conferred hereby had not expired.


- 9 That the company is hereby generally and unconditionally authorised for the purposes of section 693 and 701 of the Companies Act 2006 to make one or more market purchases (within the meaning of section 693(4) of the said Act) of fully paid ordinary shares of 5 pence each in the capital of the company ('ordinary shares') provided that:
- (i) the maximum aggregate number of ordinary shares hereby authorised to be purchased is 10% of the ordinary shares in issue at the date of passing of this resolution;
- (ii) the maximum price (exclusive of any expenses) which may be paid for an ordinary share shall not be more than 5% above the average of the middle market quotations for an ordinary share as derived from the Daily Official List of The London Stock Exchange plc for the five business days immediately preceding the day on which the ordinary share is purchased;
- (iii) the minimum price which may be paid for each ordinary share is 5 pence (exclusive of any expenses);
- (iv) unless previously revoked or varied, the authority hereby conferred shall expire at the conclusion of the next annual general meeting of the company or twelve months from the date, if earlier, of passing this resolution;
- (v) the company may make a contract or contracts to purchase its ordinary shares under the authority hereby conferred prior to the expiry of such authority which will or may be executed wholly or partly after the expiry of such authority and the company may make a purchase of its ordinary shares in pursuance of such contract as if the authority hereby conferred had not expired; and
- (vi) the directors may elect to hold shares purchased under this authority in the form of treasury shares (subject to a maximum of 10% of the issued ordinary share capital of the company at any one time).


By order of the board D N Fletcher Secretary

Beechfield Hollinhurst Road Radcliffe Manchester M26 1JN

14 October 2022


## Notes


- 1 At the date of this notice, Covid-19 is still affecting people, although there are no public health restrictions in place. The situation will be continued to be monitored and the right to attend the meeting will be in accordance with the UK Government's guidance in force at the time.
- 2 Preference shareholders are advised that they are not entitled to attend or vote at the annual general meeting.
- 3 You can vote either:
- i. By  logging  on  to  www.signalshares.com  and  following  the  instructions.  If  you  experience  difficulties  in  logging  in  or  require assistance, please contact Link Group directly on Tel: 0371 664 0300 (Calls are charged at the standard geographic rate and will vary by provider. Calls outside the United Kingdom will be charged at the applicable international rate. Lines are open between 09:00 - 17:30, Monday to Friday excluding public holidays in England and Wales).
- ii By appointing a proxy to exercise all or any of their rights to attend and to speak and vote on their behalf at the meeting. A shareholder may appoint more than one proxy in relation to the meeting provided that each proxy is appointed to exercise the rights attached to a different share or shares held by that shareholder. A proxy need not be a shareholder of the company. Please consider appointing the Chairman of the AGM as your proxy, with voting instructions, to ensure your vote is counted. You may request  a form  of  proxy  directly  from  the  registrars,  Link  Group  using  the  telephone  number  above  (same  call  terms  and conditions apply). In order for a proxy appointment to be valid a form of proxy must be completed. In each case the form of proxy must be received by Link Group, Central Square, 29 Wellington Street, Leeds, LS1 4DL by 12pm on 29 November 2022.
- iii By  attending  the  meeting  in  person  at  the  address  and  time  set  out  at  the  beginning  of  this  notice,  bringing  either  your attendance  card  or  other  appropriate  form  of  identification  so  that  you  can  be  identified  by  the  company's  registrars.  It  is recommended that you arrive at least 15 minutes before the time appointed for the meeting to begin. To be entitled to attend and vote at the meeting (and for the purpose of the determination by the company of the votes they may cast), shareholders must be entered in the register of members of the company at close of business on 29 November 2022.
- iv. In the case of CREST members, by utilising the CREST electronic proxy appointment service in accordance with the procedures set out below.

---

# Page 77

# 74


- 4 If you return more than one proxy appointment, either by paper or electronic communication, the appointment received last by the Registrar before the latest time for the receipt of proxies will take precedence. You are advised to read the terms and conditions of use carefully. Electronic communication facilities are open to all shareholders and those who use them will not be disadvantaged
- 5 CREST members who wish to appoint a proxy or proxies through the CREST electronic proxy appointment service may do so for the Meeting  (and  any  adjournment  of  the  Meeting)  by  using  the  procedures  described  in  the  CREST  Manual  (available  from www.euroclear.com/site/public/EUI). CREST Personal Members or other CREST sponsored members, and those CREST members who have appointed a service provider(s), should refer to their CREST sponsor or voting service provider(s), who will be able to take the appropriate action on their behalf. In order for a proxy appointment or instruction made by means of CREST to be valid, the appropriate CREST message (a 'CREST Proxy Instruction') must be properly authenticated in accordance with Euroclear UK & Ireland Limited's specifications and must contain the information required for such instructions, as described in the CREST Manual. The message must be transmitted so as to be received by the issuer's agent (ID RA10) by 12pm on 29 November 2022. For this purpose, the time of receipt will be taken to mean the time (as determined by the timestamp applied to the message by the CREST application host) from which the issuer's agent is able to retrieve the message by enquiry to CREST in the manner prescribed by CREST. After this time, any change of instructions to proxies appointed through CREST should be communicated to the appointee through other means.
- 6 CREST members and, where applicable, their CREST sponsors or voting service providers should note that Euroclear UK & Ireland Limited does not make available special procedures in CREST for any particular message. Normal system timings and limitations will, therefore, apply in relation to the input of CREST Proxy Instructions. It is the responsibility of the CREST member concerned to take (or, if the CREST member is a CREST personal member, or sponsored member, or has appointed a voting service provider(s), to procure that their CREST sponsor or voting service provider(s) take(s)) such action as shall be necessary to ensure that a message is transmitted by means of the CREST system by any particular time. In this connection, CREST members and, where applicable, their CREST sponsors or voting system providers are referred, in particular, to those sections of the CREST Manual concerning practical limitations of the CREST system and timings. The Company may treat as invalid a CREST Proxy Instruction in the circumstances set out in Regulation 35(5)(a) of the Uncertificated Securities Regulations 2001.
- 7 Any corporation which is a shareholder can appoint one or more corporate representatives who may exercise on its behalf all of its powers as a shareholder provided that no more than one corporate representative exercises powers in relation to the same shares.
- 8 As at 29 September 2022 (being the latest practicable business day prior to the publication of this Notice), the company's ordinary issued share capital consisted of 416,754,052 ordinary shares, carrying one vote each. Therefore, the total voting rights in the company as at 29 September 2022 were 416,754,052.
- 9 You may not use any electronic address (within the meaning of Section 333(4) of the Companies Act 2006) provided in either this Notice or any related documents (including the form of proxy) to communicate with the company for any purposes other than those expressly stated.
- 10 A copy of this Notice, and other information required by Section 311A of the Companies Act 2006, can be found on the company's website at www.jameshalstead.com.
- 11 The documents listed below will be available for inspection at an agreed time at the registered office of the company during the usual business  hours  on  any  weekday  except  bank  holidays.  Please  e-mail  secretary@jameshalstead.plc.uk  (Label  your  e-mail  'AGM documents') to book an appointment to view the following documents:
- i. The register of interests of the directors in the share capital of the company: and
- ii. Copy of the service contract of Mr G R Oliver.
- 12 The final dividend, if approved, will be paid on 16 December 2022 to shareholders on the register as at 18 November 2022.

---

# Page 78

# 75

---

# Page 79



---

# Page 80

Beechfield Hollinhurst Road Radcliffe Manchester M26 1JN

Tel  +44 (0)161 767 2500 Fax +44 (0)161 766 7499

www.jameshalstead.com