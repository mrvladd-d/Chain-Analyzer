

---

# Page 1

# UNITED STATES SECURITIES AND EXCHANGE COMMISSION

Washington, D.C. 20549


## FORM 10-K

(Mark One)

☒

ANNUAL REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934

For the fiscal year ended December 31, 2022

or


## ☐ TRANSITION REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934

For the transition period from                      to

Commission File Number: 000-22873


## ARCA BIOPHARMA, INC.

(Exact Name of Registrant as Specified in Its Charter)

Delaware (State or Other Jurisdiction of Incorporation or Organization)

36-3855489 (I.R.S. Employer Identification No.)

10170 Church Ranch Way, Suite 100, Westminster, CO

80021 (Zip Code)

(Address of Principal Executive Offices)

(720) 940-2200

(Registrant's telephone number, including area code)

Securities registered pursuant to Section 12(b) of the Act:

Title of each class

Trading Symbol(s)

Name of each exchange on which registered

Common Stock, par value $0.001 per share

ABIO

Nasdaq Capital Market


## Securities registered pursuant to Section 12(g) of the Exchange Act: None

Indicate by check mark if the registrant is a well-known seasoned issuer, as defined in Rule 405 of the Securities Act.    Yes ☐

No ☒

Indicate by check mark if the registrant is not required to file reports pursuant to Section 13 and Section 15(d) of the Act.    Yes

☐ No ☒

Indicate by check mark whether the registrant (1) has filed all reports required to be filed by Section 13 or 15(d) of the Securities Exchange Act of 1934 during the preceding 12 months (or for such shorter period that the registrant was required to file such reports), and (2) has been subject to such filing requirements for the past 90 days.    Yes ☒ No ☐

Indicate by check mark whether the registrant has submitted electronically every Interactive Data File required to be submitted and posted pursuant to Rule 405 of Regulation S-T (§ 232.405 of this chapter) during the preceding 12 months (or for such shorter period that the registrant was required to submit such files).    Yes ☒ No ☐

Indicate by check mark whether the registrant is a large accelerated filer, an accelerated filer, a non-accelerated filer, smaller reporting company, or an emerging growth company. See the definitions of 'large accelerated filer,' 'accelerated filer,' 'smaller reporting company,' and 'emerging growth company' in Rule 12b-2 of the Exchange Act.

Large accelerated filer

☐

Accelerated filer

☐

Non-accelerated filer ☒

Smaller reporting company

☒

Emerging growth company

☐

If an emerging growth company, indicate by check mark if the registrant has elected not to use the extended transition period for complying with any new or revised financial accounting standards provided pursuant to Section 13(a) of the Exchange Act. ☐

Indicate by check mark whether the registrant has filed a report on and attestation to its management's assessment of the effectiveness of its internal control over financial reporting under Section 404(b) of the Sarbanes-Oxley Act (15 U.S.C. 7262(b)) by the registered public accounting firm that prepared or issued

its audit report. ☐

If securities are registered pursuant to Section 12(b) of the Act, indicate by check mark where the financial statements of the registrant included in the filing reflect the correction of an error to previously issued financial statements. ☐

Indicate by check mark whether any of those error corrections are restatements that required a recovery analysis of incentive-based compensation received by any of the registrant's executive officers during the relevant recovery period pursuant to §240.10D-1(b). ☐

Indicate by check mark whether the registrant is a shell company (as defined in Rule 12b-2 of the Act).    Yes

☐

No ☒

The aggregate market value of the common stock held by non-affiliates of the Registrant on June 30, 2022, the last business day of the most recently completed second fiscal quarter, was $29,189,204 based on the last sale price of the common stock as reported on that day by The Nasdaq Capital Market. As of February 23, 2023, the Registrant had 14,410,143 shares of common stock outstanding.


## DOCUMENTS INCORPORATED BY REFERENCE

Auditor Firm Id:

185

Auditor Name:

KPMG LLP

Auditor Location:

Denver, CO

---

# Page 2

TABLE OF CONTENTS


| PART I     |                                                                                                                                                                              |    |
|------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----|
| Item 1.    | Business ..............................................................................................................................................................      | 1  |
| Item 1A.   | Risk Factors.........................................................................................................................................................        | 15 |
| Item 1B.   | Unresolved Staff Comments.................................................................................................................................                   | 39 |
| Item 2.    | Properties.............................................................................................................................................................      | 40 |
| Item 3.    | Legal Proceedings................................................................................................................................................            | 40 |
| Item 4.    | Mine Safety Disclosures.......................................................................................................................................               | 40 |
| PART II    |                                                                                                                                                                              |    |
| Item 5.    | Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities.                                                                | 41 |
| Item 6.    | Reserved..............................................................................................................................................................       | 41 |
| Item 7.    | Management's Discussion and Analysis of Financial Condition and Results of Operations ...................................                                                    | 42 |
| Item 7A.   | Quantitative and Qualitative Disclosures About Market Risk................................................................................                                   | 47 |
| Item 8.    | Financial Statements and Supplementary Data......................................................................................................                            | 48 |
|            | REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM, KPMG LLP.............................                                                                               | 49 |
|            | BALANCE SHEETS...........................................................................................................................................                    | 50 |
|            | STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS.................................................................                                                             | 51 |
|            | STATEMENTS OF STOCKHOLDERS' EQUITY..............................................................................................                                             | 52 |
|            | STATEMENTS OF CASH FLOWS.....................................................................................................................                                | 53 |
|            | NOTES TO FINANCIAL STATEMENTS...........................................................................................................                                     | 54 |
| Item 9.    | Changes in and Disagreements with Accountants on Accounting and Financial Disclosure ...................................                                                     | 65 |
| Item 9A.   | Controls and Procedures.......................................................................................................................................               | 65 |
| Item 9B.   | Other Information ................................................................................................................................................           | 65 |
| Item 9C.   | Disclosure Regarding Foreign Jurisdictions that Prevent Inspections ...............................................................                                          | 65 |
| PART III   |                                                                                                                                                                              |    |
| Item 10.   | Directors, Executive Officers and Corporate Governance .....................................................................................                                 | 66 |
| Item 11.   | Executive Compensation......................................................................................................................................                 | 73 |
| Item 12.   | Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters..................                                                             | 79 |
| Item 13.   | Certain Relationships and Related Transactions, and Director Independence.........................................................                                           | 81 |
| Item 14.   | Principal Accountant Fees and Services................................................................................................................                       | 82 |
| PART IV    |                                                                                                                                                                              |    |
| Item 15.   | Exhibits and Financial Statement Schedules .........................................................................................................                         | 84 |
| SIGNATURES | ............................................................................................................................................................................ | 89 |

---

# Page 3

# PART I


## Item 1. Business

Some of the statements under 'Business,' 'Risk Factors,' 'Management's Discussion and Analysis of Financial Condition and Results of Operations' and elsewhere in this Annual Report constitute forward-looking statements. In some cases, you can identify forward-looking statements by the following words: 'may,' 'will,' 'could,' 'would,' 'should,' 'expect,' 'intend,' 'plan,' 'anticipate,' 'believe,' 'estimate,' 'predict,' 'project,' 'potential,' 'continue,' 'ongoing' or the negative of these terms or other comparable terminology, although not all forward-looking statements contain these words. Examples of these statements include, but are not limited to, statements regarding the following: potential future development plans for Gencaro our ability to secure sufficient financing to support any clinical trials of Gencaro,the likelihood that any Phase 3 clinical trial results for Gencaro will satisfy the requirements of our Special Protocol Assessment agreement, our likelihood to enter into an acquisition, merger, business combination or other strategic transaction, the expected features and characteristics of Gencaro, including the potential for genetic variations to predict individual patient response to Gencaro, Gencaro's potential to treat atrial fibrillation, or AF, future treatment options for patients with AF, the potential for Gencaro to be the first genetically-targeted AF prevention treatment, statements regarding potential Phase 3 development plans for Gencaro, including the timing and results thereof, and the ability of ARCA's financial resources to support its operations at the current levels through the middle of fiscal year 2024, our ability to obtain additional funding when needed or enter into a strategic or other transaction, the extent to which our issued and pending patents may protect our products and technology, the potential of such product candidates to lead to the development of safe or effective therapies, our ability to enter into collaborations, or our ability to maintain listing of our common stock on a national exchange. Actual results and performance could differ materially from those projected in the forward-looking statements as a result of many factors discussed herein and elsewhere. These statements involve known and unknown risks, uncertainties and other factors that may cause our actual results, levels of activity, performance or achievements to be materially different from the information expressed or implied by these forward-looking statements. While we believe that we have a reasonable basis for each forward-looking statement contained in this Annual Report, we caution you that these statements are based on a combination of facts and factors currently known by us and our projections of the future, about which we cannot be certain.

In addition, you should refer to the 'Risk Factors' section of this Annual Report for a discussion of other important factors that may cause our actual results to differ materially from those expressed or implied by our forward-looking statements. As a result of these factors, we cannot assure you that the forward-looking statements in this Annual Report will prove to be accurate. Furthermore, if our forward-looking statements prove to be inaccurate, the inaccuracy may be material. In light of the significant uncertainties in these forward-looking statements, you should not regard these statements as a representation or warranty by us or any other person that we will achieve our objectives and plans in any specified time frame, or at all.

We undertake no obligation to publicly update any forward-looking statements, whether as a result of new information, future events or otherwise. You are advised, however, to consult any further disclosures we make on related subjects in our Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and our website.

The terms 'ARCA,' 'the Company,' 'we,' 'us,' 'our' and similar terms refer to ARCA biopharma, Inc.


## Overview

We are a clinical-stage biopharmaceutical company applying a precision medicine approach to the development and commercialization of targeted therapies for cardiovascular diseases. Precision medicine refers to the tailoring of medical treatment to the individual characteristics of patients, using genomic, non-genomic biomarker and other information that extends beyond routine diagnostic categorization. We believe that when implemented correctly precision medicine can enhance therapeutic response, improve patient outcomes, and reduce healthcare costs.

In April 2022, the Board of Directors established a Special Committee and, in May 2022, retained Ladenburg Thalmann & Co. Inc. to evaluate strategic options, including transactions involving a merger, sale of all or part of our assets, or other alternatives with the goal of maximizing stockholder value. We believe there are multiple potential opportunities to enhance value for our shareholders. We do not have a defined timeline for the strategic review process and the review may not result in any specific action or transaction.

Our lead product candidate is Gencaro™ (bucindolol hydrochloride) for the treatment of atrial fibrillation, or AF, in patients with chronic heart failure, or HF. Gencaro is being developed for patients who have a genotype that identifies a drug target associated with heightened efficacy.


## Gencaro™ (bucindolol hydrochloride) for Atrial Fibrillation

Gencaro™ (bucindolol hydrochloride) is a pharmacogenetically-targeted beta-adrenergic receptor antagonist with mild vasodilator properties that we are developing for the treatment of atrial fibrillation in patients with heart failure. We believe the pharmacology of

---

# Page 4

Gencaro is unique and its efficacy can be enhanced by prescribing it to patients with a common genotypic variant that is present in approximately 50% of the North American and European general populations. This gene can be detected with a simple genetic test.

We are developing Gencaro to treat atrial fibrillation, or AF, in patients with chronic heart failure, or HF. AF is the most common form of cardiac arrhythmia, a disruption of the heart's normal rhythm or rate. HF is a chronic condition in which the heart is unable to pump enough blood to meet the body's needs. AF and HF commonly occur together. In HF patients, the development of AF leads to worsening symptoms, and increased risk of hospitalization and death. Current treatment options for AF in HF patients are limited, and can be invasive, costly and dangerous.

Our development plan for Gencaro focuses on the treatment of AF in patients with higher ejection fraction HF, those who have an ejection fraction, or EF, of 40% and higher who also have the genotype we believe is optimal for Gencaro efficacy. This population of HF encompasses more than half of all HF patients in the United States and Europe. There are currently few approved or effective drug therapies to treat AF or HF in this patient population.

Our development plan for Gencaro is based on our recently published analysis of the Phase 2b clinical trial of Gencaro for the prevention of AF in HF patients, known as GENETIC-AF. This analysis showed novel results for Gencaro in patients in the clinical trial with EF's of 40% and higher. We currently have an agreement with the FDA, known as a Special Protocol Assessment, or SPA, for the requirements of a Gencaro Phase 3 clinical trial, PRECISION-AF, that would support approval of Gencaro if successful. The Phase 3 pivotal clinical trial of Gencaro conducted under an SPA will include secondary endpoints that are intended to capture some of this new information, such as a reduction in the need to deploy rhythm control interventions including electrical cardioversion, catheter ablation and use of anti-arrhythmic drugs and avoidance of drug-related complications such as bradycardia. Based on these analyses, we were issued a United States patent in February 2021 for the use of Gencaro in this patient population. We believe this patent will substantially extend the patent protection for our planned development of Gencaro into 2039. We are seeking similar patent protection in other countries.

We believe that patients with HF and AF represent a major unmet medical need, and this need is most pronounced in patients with EF values of 40% and above. This EF range constitutes more than half of all chronic HF in the United States and Europe, as well as in Japan and China, and there are currently few approved, effective or guideline-recommended therapies for these patients to treat either their AF or HF. AF is a very common complication in these patients, with estimates of AF incidence ranging from 40% to 60%. Betablockers approved for HF are commonly used off-label to control heart rate in these patients, but they are not considered effective in preventing AF and none are approved for treating heart failure in pther contraindicated or have label warnings for use due to an increased risk of mortality or prolongation of QT internal (irregular heart rhythm that can be seen on an electrocardiogram). Interventional procedures for AF, such as catheter ablation and electrical cardioversion, are invasive, expensive, and often temporary; these interventions also typically require the continued use of beta blockers and other anti-arrhythmic drugs post-intervention.


We believe that Gencaro, if approved, may be a safe and more effective therapy for the treatment of higher ejection fraction HF patients with AF. We believe there are several potentially important attributes that would differentiate Gencaro from existing therapies, including:
- · More effective rhythm control compared to the current standard of care;
- · Reduction in the need for catheter ablation, electrical cardioversion, or toxic anti-arrhythmic drugs;
- · Maintenance of rhythm control after a successful AF catheter ablation;
- · Effective rate control with lower risk of treatment-limiting, adverse event producing bradycardia;
- · Reduction in symptoms and improvement in quality of life;
- · Reduced health care burden;
- · Foundational beta-blocker benefits for HF and unique evidence of efficacy in HF patients with AF;
- · One of the only drug therapies approved and shown effective for AF in HF patients with EF ≥ 40%, and the only one in its drug class.


We have an international patent portfolio for Gencaro in the United States, the EU, and other major markets, as well as new chemical entity status, including a new patent that we believe will give us a strong intellectual property position to at least approximately 2039 in the United States; we have filed applications similar to this new patent in international territories. We have developed a laboratory platform for the diagnostic test that would be used to prescribe Gencaro; this platform was approved by FDA for use in the Phase 2B clinical trial. We retain all rights to this test platform; we expect to use it in future clinical trials, and we believe it could be one of multiple diagnostic platforms used for commercialization.


## rNAPc2 (AB201) for treatment of COVID-19

Recombinant Nematode Anticoagulant Protein c2, or rNAPc2 (AB201), is a protein therapeutic in clinical development as a potential treatment for patients with COVID-19. Based on its unique mechanism of action, development history and the clinical evidence from the SARS-CoV-2 pandemic, we believe rNAPc2 has potential to be a beneficial therapy for patients with this serious viral disease. We

---

# Page 5

initiated a Phase 2b clinical trial of rNAPc2 as a potential treatment for patients hospitalized with COVID-19 in the fourth quarter of 2020 and completed patient enrollment in the fourth quarter 2021. In the clinical trial, both doses of rNAPc2 demonstrated a treatment benefit for patients based on the coagulation biomarker D-dimer, however, neither dose achieved statistical significance for the primary efficacy endpoint of change in D-dimer level from Baseline to Day 8 compared to standard of care heparin.

On the secondary endpoints measuring thrombotic events and time-to-recovery, there was a numerical imbalance in favor of rNAPc2 that was non-significant. rNAPc2 was well-tolerated at both doses. There were no serious treatment-related adverse events and no dose dependent increase in adverse events was observed. There was no difference between rNAPc2 and standard-of-care heparin in major or non-major clinically relevant bleeding. We currently do not plan additional clinical development of rNAPc2 unless we are able to find a commercial or government partner to pay for development and commercialization or expansion into clinical trials for other disease indications.

To support the continued development of Gencaro and rNAPc2, we will need additional financing to fully fund any clinical trials, and our general and administrative costs through the clinical trials' projected completion and potential commercialization. Considering the substantial time and costs associated with the development of Gencaro and rNAPc2 and the risk that we may be unable to raise a significant amount of capital on acceptable terms, we are also pursuing co-development and commercialization partnering opportunities with large pharmaceutical and/or specialty pharmaceutical companies and may pursue a strategic combination or other strategic transactions. If we are unable to obtain sufficient financing or are unable to complete a strategic transaction, we may discontinue our development activities on Gencaro or rNAPc2 or discontinue our operations.

We believe our cash and cash equivalents as of December 31, 2022 will be sufficient to fund our operations through the middle of fiscal year 2024. Our review of our strategic options may impact this projection. Conducting a Phase 3 PRECISION-AF trial would likely require additional financing. However, changing circumstances may cause us to consume capital significantly faster or slower than currently anticipated. We have based these estimates on assumptions that may prove to be wrong, and we could exhaust our available financial resources sooner than we currently anticipate; therefore, we may have to raise additional capital for other clinical trials. Initiating any Phase 3 clinical trial of Gencaro will require additional financing.


## Our Strategy


Our mission is to become a leading biopharmaceutical company developing precision targeted cardiovascular therapies to enhance therapeutic response, improve patient outcomes, and reduce healthcare costs. To achieve this goal, we are pursuing the following strategies:
- · Evaluate strategic options. In April 2022, the Board of Directors established a Special Committee and, in May 2022, retained Ladenburg Thalmann & Co. Inc. to evaluate strategic options, including transactions involving a merger, sale of all or part of our assets, or other alternatives with the goal of maximizing stockholder value. We believe there are multiple potential opportunities to enhance value for our shareholders. We do not have a defined timeline for the strategic review process and the review may not result in any specific action or transaction.
- · Advance the development of Gencaro for the treatment of AF in HF patients. We are planning a Phase 3 clinical trial for Gencaro as a therapy for AF in HF patients, focusing on patients with EF ≥ 40%, a patient population for whom few approved or effective drug therapies currently exist.
- · Partner the development of rNAPc2. We plan to pursue strategic development and partnering opportunities with commercial or government partners for rNAPc2 development and commercialization or expansion into clinical trials for other disease indications.
- · Build a cardiovascular pipeline. Our management and employees, including our chief executive officer, are experienced in cardiovascular research, molecular genetics and clinical development of cardiovascular therapies. We are seeking to leverage this expertise to identify, acquire and develop other cardiovascular products or candidates, particularly those with potential for targeted development based on genetic or other biomarkers.


The above strategies are dependent upon our ability to obtain additional funding through the sale of public or private equity or debt securities, the completion of a strategic transaction, or a combination thereof. If we are unable to secure additional funding or complete a strategic transaction, we may not be able to continue development of Gencaro or rNAPc2, or to continue operations.


## Atrial Fibrillation in Heart Failure


## Market Background and Opportunity

Heart failure is a chronic condition in which the heart is unable to pump enough blood to meet the body's needs. HF has numerous serious consequences, including severe impacts on quality of life, increased hospitalizations, loss of economic productivity, and premature death. HF is a leading cause of death in the developed world, and despite the availability of multiple effective drug classes, mortality due to HF is increasing. According to the 2020 American Heart Association, or AHA, Heart Disease and Stroke Statistics, there were an estimated 6.2 million Americans aged 20 years or more with HF in 2016, projected to increase to between 8.3 million

---

# Page 6

and 10.7 million by 2030. One of the fundamental classifications of heart failure is based on the percentage of blood in the left ventricle of the heart that is ejected with each heartbeat, known as ejection fraction or EF. The spectrum of HF includes HF in which EF is 50% or more and is considered preserved ejection fraction, known as HFpEF; HF in which the EF is less than 40%, considered reduced ejection fraction, or HFrEF; and HF in which the EF is at least 40%, but less than 50%, sometimes referred to as mid-range ejection fraction, known as HFmrEF. Together, HFmrEF and HFpEF, that is HF with EF ≥ 40%, comprise more than half of all chronic HF in the United States and Europe. In 2012, the economic cost of HF in the United States was estimated to be nearly $31 billion, of which two-thirds, or over $20 billion, was attributable to direct medical costs.

Atrial fibrillation, the most common sustained cardiac arrhythmia, is a serious disorder in which the normally regular and coordinated contraction pattern of the heart's two small upper chambers, or the atria, becomes irregular, rapid and uncoordinated. AF can have significant quality of life impacts and potentially serious medical consequences, including increasing the risk of stroke and other cardiovascular problems. In individuals with HF, AF contributes to the disease processes that lead to the progression of HF and worsening of clinical outcomes. AF is considered an epidemic cardiovascular disease and a major public health burden, similar to HF. The estimated number of individuals with AF globally in 2015 was 33.3 million. According to AHA Heart Disease and Stroke Statistics Reports from 2017-2020, the prevalence of AF in the United States was estimated to be 5.2 million people in 2015. In the European Union, the prevalence of AF was estimated to be 8.8 million (age 55 and over) in 2010. It is estimated that AF costs the U.S. economy about $6.0 billion annually.

AF and HF share many of the same risk factors and commonly occur together.   It has been estimated that 30-60% of HF patients will also develop AF, with this incidence increasing in HF patients with higher EF; we estimate that 40-60% of HF patients with EF ≥ 40% will also be diagnosed with AF.


## Medical Need and Current Therapy

The goals of current medical therapy for AF are to provide anticoagulation to reduce the risk of stroke, and also either maintain sinus rhythm (known as rhythm control), or reduce the high heart rate caused by AF (known as rate control), in both cases to minimize patient symptoms and reduce the risk of further complications and disease progression. Unfortunately, the current treatment options for treating AF in patients with HF have significant limitations.

Beta-blockers are considered standard of care for the treatment of HF patients, including in patients with co-morbid AF. They are also viewed as foundational therapy to treat AF in HF patients for their ability to provide rate control. Their safety in this patient population is well established.

However, current beta blockers approved for HF patients are only modestly effective at providing rhythm control, and none are FDA approved for this indication. Importantly, none of these drugs have been shown to be effective for treating HF in patients with EF ≥ 40%, so they are currently used off-label in this setting. When used for rate control, these drugs can cause bradycardia, a condition in which the heart rate drops below a safe threshold, which often leads to dose reductions and potential loss of the drug's treatment effect. Furthermore, recent evidence indicates that the mortality and other clinical benefits of these beta blockers in heart failure patients are uncertain when sustained or permanent AF is present.

Anti-arrhythmic drugs are a drug class that is often prescribed to provide rhythm control. These drugs are frequently used in patients with both HF and AF when a rate control strategy using a beta blocker fails to control the patient's symptoms. However, these agents have significant safety issues, For example, in the United States, anti-arrhythmic drug therapy for AF used in addition to beta-blockers is generally confined to the drugs amiodarone and dofetilide, which have multiple safety and toxicity concerns. Because of these concerns, physicians treating HF patients seek to limit the use of these anti-arrhythmic drugs.

Non-pharmacologic interventions such as catheter ablation and electrical cardioversion (ECV), are also used to treat AF in patients with HF. Catheter ablation is now guideline-recommended in this patient population and its use is increasing. However, it is not a replacement for drug therapy; it is invasive, expensive and generally impermanent. Drug therapy, including beta blockers, is generally continued in patients post-ablation, both for rhythm control and for HF benefit. ECV is expensive and less permanent than ablation, but like ablation, post-ECV patients will generally remain on drug therapy to treat their AF and HF, including beta-blockers.

In light of the serious medical consequences presented by AF in the presence of HF as well as, the limitations of current therapies, we believe there is an unmet need for a drug therapy that can provide greater rhythm control compared to the current standard of care; can reduce the need for toxic anti-arrhythmic drugs, catheter ablation, and electrical cardioversion; can provide effective rate control with a lower risk of treatment-limiting bradycardia; and can provide foundational beta-blocker benefits for HF. This need is particularly significant for HF patients with EF ≥ 40%, for whom there are few approved or Class I guideline-recommended drug therapies.


## Gencaro Clinical Development


## The GENETIC-AF Phase 2B Clinical Trial

GENETIC-AF enrolled 267 patients from the United States, Canada and Europe. The primary analysis compared the evidence of safety and efficacy of Gencaro versus an active comparator, TOPROL-XL. The primary endpoint of the trial was time to first event of

---

# Page 7

AF/atrial flutter (AFL) or All Cause Mortality (ACM) during a 24-week follow-up period after the establishment of sinus rhythm. Randomized patients had an EF ≤ 55%, a history of AF in the past 6 months, and the beta-1 389 arginine homozygous genotype that we believe responds best to Gencaro. Laboratory Corporation of America, or LabCorp, developed the genetic test, obtained an Investigational Device Exemption, or IDE, from the FDA and provided the companion diagnostic test and services to support our GENETIC-AF clinical trial.

For the primary endpoint of time to AF recurrence, Gencaro demonstrated a similar treatment benefit in the overall population (p = 0.961) compared to the active comparator, TOPROL-XL. However, based on further analysis of the trial, we believe we have identified a population that shows greater response to Gencaro compared to TOPROL-XL across multiple important clinical assessments, including the primary endpoint of time to AF recurrence, maintenance of normal sinus rhythm, cumulative AF burden, and AF-related clinical interventions and complications. We plan to study this population in our Phase 3 clinical trial.

These further analyses of the GENETIC-AF population (shown in the table below) demonstrated that Gencaro, as compared to metoprolol, reduced AF burden, improved maintenance of sinus rhythm and lowered the need for additional rhythm control interventions.


| Endpoint                                               | Endpoint                                               | Endpoint                                               | Entire GENETIC-AF Cohort                        | Entire GENETIC-AF Cohort       | Entire GENETIC-AF Cohort        |
|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|-------------------------------------------------|--------------------------------|---------------------------------|
| Time to 1 st  AF/AFL/ACM (Primary Endpoint)            | Time to 1 st  AF/AFL/ACM (Primary Endpoint)            | Time to 1 st  AF/AFL/ACM (Primary Endpoint)            | 1.01  (neutral)                                 | (0.71, 1.42) p = 0.961 N = 267 | (0.71, 1.42) p = 0.961 N = 267  |
| Cumulative 24-week AF Burden (substudy)                | Cumulative 24-week AF Burden (substudy)                | Cumulative 24-week AF Burden (substudy)                | 0.64 ( ↓ 36%)                                   | (0.46, 0.86) p = 0.002 N = 67  | (0.46, 0.86) p = 0.002 N = 67   |
| AF Burden at Week 24                                   | AF Burden at Week 24                                   | AF Burden at Week 24                                   | 0.45 ( ↓ 55%)                                   | (0.39, 0.50) p < 0.001 N = 67  | (0.39, 0.50) p < 0.001 N = 67   |
| ECGs in Normal Sinus Rhythm                            | ECGs in Normal Sinus Rhythm                            | ECGs in Normal Sinus Rhythm                            | 1.39 ( ↑ 39%)                                   | (1.22, 1.58) p < 0.001 N = 257 | (1.22, 1.58) p < 0.001 N = 257  |
| AF Interventions (ECVs, Ablations, & Class 3 AA Drugs) | AF Interventions (ECVs, Ablations, & Class 3 AA Drugs) | AF Interventions (ECVs, Ablations, & Class 3 AA Drugs) | 0.68 ( ↓ 32%)                                   | (0.50, 0.91) p = 0.011 N = 257 | (0.50, 0.91) p = 0.011 N = 257  |
| Bradycardia prevalence (Buc. vs. met., VR< 60 bpm)     | 0.39 ( ↓ 61%)                                          | (0.31, 0.49) P < 0.001 N = 256                         | Dose reductions (pts. w/bradycardia vs. non-b.) | 4.25 ( ↑ 4X)                   | (2.06,  9.60) P < 0.001 N = 257 |


Time to first AF/AFL/ACM treatment effect = hazard ratio (95% CI). AF burden = % time in AF per day. Cumulative AF burden treatment effect = AUC ratio (i.e., AUCBUC/AUCMET) over 24-week follow-up period with significance assessed via null permutation. AFB at Week 24 = Instantaneous estimates of average daily AF burden at week 24 with comparison between groups expressed as the ratio of the estimates and tested for significance using a Wald test. Normal Sinus Rhythm = total # ECGs in sinus rhythm with ventricular rate ≥ 60 and ≤ 100 bpm during efficacy follow-up period. AF Interventions = ECV, ablation, or guideline-recommended antiarrhythmic use during efficacy follow-up period. Treatment effect for normal sinus rhythm, AF interventions and bradycardia = prevalence rate ratio (i.e., PRRBUC/PRRMET) modeled to test significance using Poisson regression.

Treatment with Gencaro was associated with a 36% reduction in cumulative AF burden over 24 weeks of follow-up compared to metoprolol, leading to a 55% reduction in AF burden at the end of 24 weeks. Consistent with the results in the device substudy, there was a 39% increase in the prevalence of ECGs demonstrating normal sinus rhythm in the overall study population. Treatment with Gencaro also led to a 32% lower utilization of adjunctive rhythm control therapies, including electrical cardioversion, catheter ablation and antiarrhythmic drug therapy. There was also a 61% reduction in bradycardia with Gencaro versus metoprolol. The consequence of bradycardia is a reduction in beta-blocker dose, which 4.2-fold higher in patients exhibiting bradycardia than without bradycardia.


## The BEST Phase 3 Heart Failure Trial

The effect of Gencaro on heart failure endpoints in an advanced HFrEF population was evaluated in the 2,708 patient, placebo controlled Phase 3 BEST clinical trial co-sponsored by the NHLBI and Department of Veterans Affairs. In addition to the parent population, BEST included a 1,040 patient DNA substudy that evaluated the effects of adrenergic receptor, or AR, polymorphisms on Gencaro effectiveness. The BEST trial was terminated early because, after positive mortality results from two HF trials involving other beta-blockers had been reported, a substantial number of BEST trial investigators concluded that it was unethical to continue to give placebo to BEST trial participants. Our reanalysis of the BEST results in accordance with the FDA approved, pre-specified statistical analysis plans (which had not been performed by the sponsors of BEST) demonstrated a 13% risk reduction on the primary endpoint of ACM in the BEST trial with a p-value of 0.053. The risk reduction on HF clinical efficacy endpoints such as mortality and hospitalization ranged from 34% to 48% in this beta-1 389 arginine homozygous genotype. The DNA substudy revealed that Gencaro exhibited greater efficacy in patients homozygous for the beta-1 389 arginine homozygous genotype ( ADRB1 Arg389Arg), encoding for receptors that exhibit higher function and greater affinity for norepinephrine compared to the patients who did not have the beta-1 389 arginine homozygous genotype (i.e., beta-1 389 Gly carriers). In the 47% of BEST trial patients with a ADRB1 Arg389Arg

---

# Page 8

genotype Gencaro reduced (p <0.05) the primary endpoint of mortality or heart transplantation by 43%, all-cause mortality, cardiovascular mortality, heart failure hospitalizations, heart failure progression, development of atrial fibrillation, and incidence of ventricular tachycardia or ventricular fibrillation with degrees of reduction (effect sizes) ranging from 34% (heart failure progression) to 74% (atrial fibrillation). Beta-1 389 Gly carriers had no statistically significant reduction in any endpoint.


# Pharmacology and Pharmacogenetics of Gencaro

Gencaro (bucindolol hydrochloride) is a nonselective (blocks both beta-1 and beta-2 adrenergic receptors) beta- receptor blocking agent with mild vasodilator properties. This combination of properties initially placed Gencaro in the "3rd Generation" category of beta-blockers that is based on the strategy of their development. When its pharmacogenetic properties were elucidated and its development became pharmacogenetically based, we subsequently considered Gencaro a fourth-generation beta-blocker. The dominant beta-receptor on human heart cells is the beta-1, with smaller number of beta-2 receptors present. Importantly, beta-2 receptors are also present on adrenergic nerve terminals in the heart, where they regulate the release of the neurotransmitter norepinephrine, or NE. The blocking of these receptors prevents them from binding with other molecules, primarily NE, which activates these receptors to release more NE. We believe Gencaro has two unique anti-adrenergic properties not possessed by other beta-blockers currently approved for the treatment of HF: (1) it is moderately sympatholytic, i.e., by blocking beta-2 receptors on adrenergic nerves it lowers adrenergic drive to a level that can be detected on measurements of central or systemic venous NE levels, and, (2) through 'inverse agonism,' as it binds to a polymorphic "389 arginine" form of heart cell beta-1 receptor in isolated human heart preparations it promotes the inactivation of the active-state of this receptor. These properties, as described below, were observed to interact with receptor polymorphisms in such a way that we believe targeting a specific genotype of the beta-1 receptor gene (known as ADRB1) could improve the therapeutic response of patients. We believe Gencaro's efficacy is enhanced in patients with the beta-1 389 arginine homozygous genotype ( ADRB1 Arg389Arg), which has been shown to be present in approximately 50% of the North American and European general populations. To date no other beta-blocker has been shown to possess pharmacological sympatholysis, or beta-1 AR inverse agonism in human heart preparations. We believe that Gencaro's sympatholytic and beta-1 AR inverse agonist properties contribute to its enhanced lowering of HF and arrhythmia event rates in patients who have an ADRB1 Arg389Arg genotype.


## Gencaro Clinical and Regulatory Strategy

We intend to advance Phase 3 clinical development of Gencaro as a therapy for HF patients with AF, focusing on HF with EF ≥ 40%. The regulatory strategy for Gencaro is to obtain an initial approval to treat AF in a HF population with EF ≥ 40% and ≤ 55% and the beta-1 389 arginine homozygous genotype; the population demonstrating the greatest efficacy in the Phase 2B GENETIC-AF clinical trial. Indication expansion for Gencaro will focus on genotype-positive HF patients with EF >55%, which we believe would substantially expand the addressable patient population, if successful. We have obtained an SPA agreement with the FDA to conduct a single, 400-patient Phase 3 clinical trial that, if successful at a statistical threshold of p ≤ 0.01, may be sufficient to support an NDA for the marketing approval of Gencaro.

The clinical trial design is similar to GENETIC-AF, including the active comparator, TOPROL-XL, and the primary endpoint of time to AF or atrial flutter, or AF/AFL, recurrence or mortality during a 6-month follow-up period. The planned clinical trial will use a standard significance criterion of p ≤ 0.05 for the primary endpoint; however, if the primary endpoint is significant with a p-value ≤ 0.01, then this single Phase 3 clinical trial may be sufficient for regulatory approval per the SPA agreement. The NDA submission for Gencaro is eligible for expedited review in the United States under the Fast Track development program designation that was granted to Gencaro in 2015. Based on the use of this same endpoint in GENETIC-AF it is anticipated that ≥90% of the primary events will be due to recurrent AF/AFL. Secondary objectives will examine other important endpoints, such as AF burden and AF treatment-related interventions. The planned clinical trial will use a standard significance criterion of p ≤ 0.05 for the primary endpoint; however, if the primary endpoint is significant with a p-value ≤ 0.01, then this single Phase 3 clinical trial may be sufficient for regulatory approval per the SPA agreement.


## The Gencaro Test

If approved, we believe that Gencaro will be the first cardiovascular drug to be integrated with a companion diagnostic. This would be a test for the patient genotype approved for the drug, and could be performed by a variety of laboratory processes or platforms.

In collaboration with LabCorp, we developed one such genetic test, obtained an IDE from the FDA and used this test in our GENETIC-AF clinical trial. We retain all rights to this particular test platform, and we believe it could be used for commercialization. Future clinical trials of Gencaro, including PRECISION-AF, are expected to use a similar diagnostic test to identify the patient's receptor genotype. We believe the Gencaro Test could be developed and commercialized through one or more diagnostic providers, by the company potentially marketing Gencaro, or a combination of approaches. We also believe that point of care genetic tests, which could be performed during the patient's visit to the physician, will be part of the commercialization strategy for Gencaro.

---

# Page 9

# Development Pipeline

Our lead product candidate is Gencaro™ (bucindolol hydrochloride) for the treatment of atrial fibrillation in patients with chronic heart failure.

Gencaro, is a potential treatment for HF patients with AF. Gencaro (bucindolol hydrochloride) is a pharmacogenetic-targeted betaadrenergic receptor antagonist with mild vasodilator properties that is considered a fourth-generation beta-blocker based on its novel pharmacogenetic profile. We believe the treatment of AF in HF patients with EF ≥ 40% is an unmet medical need with a near term and straightforward regulatory pathway.

Our plan is to obtain an initial approval for Gencaro to treat AF in a genotype specific HF population; HF patients with EF between 40% and 55% in patients with the genotype we studied in the Phase 2B GENETIC-AF clinical trial. We believe that, if approved, there are additional indication expansion opportunities for Gencaro in other AF populations, including expanding the patient population to selected HF patients with EF >55%. We continue to evaluate the feasibility and potential timing for initiating PRECISION-AF relative to the COVID-19 pandemic. We may seek additional capital or a strategic partnership for the Phase 3 clinical trial and potential commercialization of Gencaro.

We plan to pursue strategic development and partnering opportunities with commercial or government partners for rNAPc2 development and commercialization or expansion into clinical trials for other disease indications.

We also have exclusive pharmacogenetic and other patent rights to drug targets and candidates that have potential indications in cardiovascular disease, oncology and other therapeutic areas. We may seek partners to assist us in the development of these candidates or who may license them. We may also seek funds to advance the development of the compounds on our own.


## Financial Resources

To support the continued development of Gencaro and rNAPc2, we will need additional financing to fully fund any clinical trials, and our general and administrative costs through the clinical trials' projected completion and potential commercialization. Considering the substantial time and costs associated with the development of Gencaro and rNAPc2 and the risk that we may be unable to raise a significant amount of capital on acceptable terms, we are also pursuing co-development and commercialization partnering opportunities with large pharmaceutical and/or specialty pharmaceutical companies and may pursue a strategic combination or other strategic transactions. If we are unable to obtain sufficient financing or are unable to complete a strategic transaction, we may discontinue our development activities on Gencaro or rNAPc2 or discontinue our operations.

We believe our cash and cash equivalents as of December 31, 2022 will be sufficient to fund our operations through the middle of fiscal year 2024. Our review of our strategic options may impact this projection. Conducting a Phase 3 PRECISION-AF trial would likely require additional financing. However, changing circumstances may cause us to consume capital significantly faster or slower than currently anticipated. We have based these estimates on assumptions that may prove to be wrong, and we could exhaust our available financial resources sooner than we currently anticipate; therefore, we may have to raise additional capital for other clinical trials. Initiating any Phase 3 clinical trial of Gencaro will require additional financing.

In July 2020, we entered into a sales agreement with a placement agent to sell, from time to time, our common stock having an aggregate offering price of up to $54.0 million, in an 'at the market offering.' As of February 2021, we had sold an aggregate of 9,928,272 shares of our common stock pursuant to the terms of such sales agreement for aggregate gross proceeds of approximately $54.0 million. Net proceeds received in this offering were approximately $52.2 million, after deducting expenses for executing the 'at the market offering' and commissions paid to the placement agent.

In April 2021, we amended the new sales agreement and the amount available for the offering under our prospectus to our registration statement on Form S-3 (No. 333-254585). As of February 22, 2023, the amount available for the offering under the prospectus supplement is subject to the limitation of not selling a total value amount of shares exceeding more than one-third of our public float in any 12-month period, which as of February 22, 2023 would have been approximately $8.8 million.


## Research and Development Expenses

Our research and development expenses were $4.7 million for the year ended December 31, 2022 as compared to $13.8 million for 2021, a decrease of approximately $9.1 million. R&D expense in 2023 is expected to be lower than 2022.


## Licensing and Royalty Obligations


## Gencaro

Our patent portfolios relating to Gencaro, including a patent issued in 2021, are either owned by us or are subject to licenses that impose no royalty obligations or milestone payments relating to the further development, approval and commercialization of Gencaro.

We are also a party to licenses for patents relating to Gencaro that are now expired. We believe that there are no future milestone or royalty obligations that will be payable under these licenses.

---

# Page 10

# Competition


## Gencaro

Current HF treatments include three beta-blockers approved for HF in the Unites States. However, their efficacy in providing control of the arrhythmia caused by AF, or rhythm control, is only mild. It is also now acknowledged that evidence is lacking that the approved beta-blockers provide outcome benefits for patients who develop permanent AF. Furthermore, these drugs have not demonstrated efficacy for HF patients with EF ≥ 40%, which is the focus of the Gencaro development program. Current AF treatments include pharmaceutical, procedural or device intervention. There are several antiarrhythmic drugs approved by the FDA for the treatment and/or prevention of recurrent AF. However, these drugs have safety and/or administration concerns and all but one have contraindications or label warnings regarding their prescription in patients with HF.

Drugs that are currently approved or used for the treatment or prevention of AF in HF either have not demonstrated efficacy in these patients, or have notable risks due to adverse side effects or lack sufficient efficacy. Therefore, in HF, and specifically in HF patients with EF ≥ 40%, we believe there is a substantial unmet medical need for AF therapies that are more effective and have fewer side effects than those currently available. We believe that Gencaro's treatment of AF in HF patients could provide a more effective and safer pharmacotherapy than treatments currently used in these patients.

The pharmaceutical industry is highly competitive. We face significant competition from pharmaceutical companies and biotechnology companies that are researching and selling products designed to treat cardiovascular conditions. Most of these companies have significantly greater financial, product development, manufacturing, and commercial resources than we have.

If approved, some of the drugs which Gencaro would potentially compete with are generic in the United States and are used, though not approved or shown to be effective, for the treatment of AF or in HF patients with EF ≥ 40%. Gencaro could be priced at a premium compared to some of these therapies. In addition, Gencaro, if approved, would be prescribed in conjunction with a diagnostic test, adding additional procedures to the process of prescribing Gencaro, which could make it more difficult for us to compete against existing or future therapies.


## Manufacturing and Product Supply

Gencaro is a small molecule drug with an established manufacturing history. Multiple manufacturers of both the active pharmaceutical ingredients, or API, and drug product have successfully produced Gencaro for use in clinical trials over the course of its clinical development. We outsource all manufacturing and analytical testing of the Gencaro API and drug product. We have selected third party contract manufacturing organizations on the basis of their technical and regulatory expertise. Our approach with our contract manufacturing partners has been to replicate the manufacturing processes that were used to support the prior pivotal clinical trial with Gencaro, and to minimize any changes from these baseline processes, thereby reducing technical and regulatory risk. For API production, we contracted with Groupe Novasep which completed the drug substance registration batches successfully. The resulting drug substance was used to manufacture the drug product used in the clinical trial material for the Phase 2B clinical trial and is expected to be used in the proposed Phase 3 clinical trial.

For drug product production, we have contracted with Patheon, Inc. to manufacture the Gencaro tablets. Gencaro is produced in a tablet form, utilizing standard solid oral dosage processing techniques. Six separate dosage strengths have been manufactured, with the maximum recommended dose of 100mg twice daily. Registration batches were successfully completed by Patheon, Inc. and tablets from these runs were placed in cGMP storage to supply clinical trials. In addition, we contracted with a separate service provider for packaging and distribution of our clinical trial materials.


## Government Regulation

Governmental authorities in the United States at the federal, state, and local levels and foreign countries extensively regulate, among other things, the research, development, testing, manufacture, labeling, promotion, advertising, marketing, distribution, sampling, and import and export of pharmaceutical and medical device products. In the United States, the FDA regulates these activities at the federal level pursuant to the Federal Food Drug and Cosmetic Act, or the FDCA, and the regulations promulgated thereunder. In Canada, Health Canada regulates these activities. In Europe, the Competent Authorities and Ethics Committees of the respective countries regulate these activities. In South America, the Health Authorities and Ethics Committees of their respective countries regulate these activities. We anticipate that all of our product candidates will require regulatory approval by governmental agencies prior to commercialization. The process of obtaining approval and the subsequent process of maintaining compliance with appropriate federal, state, local and foreign statutes and regulations require the expenditure of substantial time and financial resources. In addition, these statutes, rules, regulations and policies may change and our products may be subject to new legislation or regulations. Both before and after approval or clearance, failure to comply with the requirements of the FDA and other state and federal statutes can lead to significant penalties or could disrupt our ability to manufacture and sell these products. In addition, the FDA could refuse to provide certificates needed to export our products if the agency determines that we are not in compliance.

---

# Page 11

# Premarket Approval of Drugs

FDA approval is required for marketing of any new drug, dosage form, indication, or strength. The steps required before new human therapeutic drug products are marketed in the United States and foreign countries include rigorous preclinical and clinical testing and other approval requirements by regulatory agencies, such as the FDA and comparable agencies in foreign countries. There is no guarantee that products will be approved in a specific timeframe or at all.

Preclinical Phase . Preclinical studies are generally conducted in the laboratory to identify potential drug candidates and to evaluate their potential efficacy and safety. These studies include laboratory evaluation of product chemistry, formulation and stability, as well as studies to evaluate short and long-term toxicity in animals. Preclinical studies are governed by numerous regulations, including but not limited to FDA's Good Laboratory Practices.

Clinical Phase . Before human clinical trials can commence, an Investigational New Drug, or IND, application, submitted to FDA must become effective. For an IND to become effective, the applicant must submit, among other things, information on design of the proposed investigation, reports necessary to assess the safety of the drug for use in clinical investigation, and information on the chemistry and manufacturing of the drug, controls available for the drug, and primary data tabulations from animal or human studies. The clinical phase of development involves the performance of human studies, including adequate and well-controlled human clinical trials to establish the safety and efficacy of the product candidate for each proposed indication. Typically, clinical evaluation involves three sequential phases, which may overlap. During Phase 1, clinical trials are conducted with a relatively small number of subjects or patients to determine the early safety profile of a product candidate, as well as dose tolerance, absorption, and the pattern of drug distribution and drug metabolism. Phase 2 trials are conducted with groups of patients afflicted by a specific target disease to determine preliminary efficacy, optimal dosages and dosage tolerance and to identify possible adverse effects and safety risks. In Phase 3, larger-scale, multi- center trials are conducted with patients afflicted with a specific target disease over a longer term to confirm Phase 2 results and provide reliable and conclusive data supporting efficacy and safety of a drug as required by regulatory agencies for drug approval. The conduct of clinical trials is subject to extensive regulation. FDA may delay or suspend clinical trials through clinical holds.

NDA Submission. In the United States, the results of preclinical and clinical testing along with chemistry, manufacturing and controls information, are submitted to the FDA in the form of an NDA. Under the current Prescription Drug User Fee Act, or PDUFA, after submission of an NDA and payment, or waiver, of the required fee, the FDA's goal is to review most standard NDAs within 10 months from the time that a sponsor's application is accepted as filed by the FDA, which can occur within a 60-day window following the initial submission of the application. At the end of the 10 months, the FDA's goal is to issue a 'complete response,' or approve the NDA. While FDA's goal is to issue a complete response within 10 months, the process may take longer than 10 months, particularly if multiple review cycles are required. Gencaro has been granted Fast Track Designation which allows for a rolling review of a marketing application. A rolling review allows FDA to consider reviewing portions of an NDA before the sponsor submits the complete application.

In responding to an NDA, the FDA may grant marketing approval or deny the application if the FDA determines that the application does not satisfy the statutory and regulatory approval criteria. A denial may include a request for additional information, including additional clinical data and/or an additional Phase 3 clinical trial. Data from clinical trials are not always conclusive and FDA may interpret data differently than we interpret data. Under the Food and Drug Modernization Act of 1997, the FDA is authorized to approve a drug based on a single adequate and well-controlled study if such study and other confirmatory data are sufficient to establish the drug's effectiveness. However, it has long been the FDA's general position that the standard of proof of a drug's effectiveness generally requires at least two well-controlled and adequate Phase 3 clinical studies demonstrating statistically significant results as compared to a placebo or active control (with p-values of less than 0.05) with respect to the primary endpoint or endpoints of the trial.

In addition, in accordance with current FDA law and regulations, the FDA may refer a drug to an advisory committee for review prior to approval. Most new compounds are referred to an FDA advisory committee, which could add additional time to the review process. There is no guarantee that the advisory committee will recommend approval of a drug candidate. In some cases, FDA may require completion, within a specified time period, of additional clinical studies after approval, referred to as Phase 4 clinical studies, to monitor the effect of a new product and may prevent or limit future marketing of the product based on the results of these postmarketing programs. Furthermore, prior to granting approval, the FDA generally conducts an inspection of the facilities, including outsourced facilities that will be involved in the manufacture, production, packaging, testing and control of the drug substance and finished drug product for compliance with current Good Manufacturing Practice, or cGMP, requirements.

---

# Page 12

If the FDA approves the NDA, the sponsor is authorized to begin commercialization of the drug in accordance with the approval. Even if the FDA approves the NDA, the FDA may decide later to suspend or withdraw product approval if compliance with regulatory standards is not maintained or if safety problems are recognized after the product reaches the market. In addition, the FDA requires surveillance programs to monitor approved products that have been commercialized, and the agency has the power to require additional clinical studies, to require changes in labeling or to prevent further marketing of a product based on the results of these post-marketing programs. The FDA also has authority to request implementation of a risk evaluation and mitigation strategy, or REMS, that could restrict distribution of Gencaro or require us to provide additional risk information to prescribers. Whether or not FDA approval has been obtained, approval of a product candidate by comparable foreign regulatory authorities is necessary prior to the commencement of marketing of a product candidate in those countries. The approval procedures vary among countries and can involve additional testing. The time required to obtain approval may differ from that required for FDA approval.

Post-approval Compliance. If regulatory approval for a drug or medical device is obtained, the product and the facilities manufacturing the product are subject to periodic inspection and continued regulation by regulatory authorities, including compliance with cGMP, as well as labeling, advertising, promotion, recordkeeping, and reporting requirements, including the reporting of adverse events. In addition, the FDA closely regulates the post-approval marketing and promotion of drugs, including standards and regulations for labeling, promotion to health care professionals, direct-to-consumer advertising, off-label promotion, industrysponsored scientific and educational activities and promotional activities involving the Internet. Drugs may be marketed only for the approved indications and in accordance with the provisions of the approved labeling. Companies are responsible for compliance with such requirements and would be responsible to ensure that all contract manufacturing organizations who perform work for them also comply with such requirements. Similarly, if a drug manufacturer hires contract sales representatives or consultants to promote its products, such organizations or individuals must comply with all of the same requirements applicable to the drug manufacturer. The FDA regularly inspects companies to determine compliance with cGMPs and other post-market requirements. Failure to comply with statutory requirements and the FDA's regulations can result in a variety of administrative or enforcement actions, including but not limited to an FDA Form 483 (which is issued by the FDA at the conclusions of an inspection when an investigator has observed any conditions that may constitute violations), a public warning letter, suspension or withdrawal of regulatory approvals, product recalls, product detentions, refusal to provide export certificates, seizure of products and criminal prosecution.

Drug Price Competition and Patent Term Restoration Act of 1984. Under the Drug Price Competition and Patent Term Restoration Act of 1984, also known as the Hatch-Waxman Act, Congress created an abbreviated FDA review process for generic versions of pioneer (brand name) drug products. The Hatch-Waxman Act also provides for patent term restoration and the award, in certain circumstances, of non-patent marketing exclusivities.

Generic Drug Approval . The Hatch-Waxman Act established an abbreviated FDA review process for drugs that are shown to be equivalent to approved pioneer drugs. Approval for a generic drug is obtained by filing an abbreviated NDA, or ANDA. Generic drug applications are 'abbreviated' because they generally do not include clinical data to demonstrate safety and effectiveness. Instead, an ANDA applicant must establish that its product is bioequivalent to an approved drug and that it is the same as the approved drug with respect to active ingredient(s), route of administration, dosage form, strength and recommended conditions of use (labeling). The FDA will approve the generic as suitable for an ANDA if it finds that the generic does not raise questions of safety and effectiveness as compared to the pioneer drug. A drug is not eligible for ANDA approval if the FDA determines that it is not equivalent to the pioneer drug or if it is intended for a different use. Any applicant who files an ANDA seeking approval of a generic version of an approved drug listed in FDA's Approved Drug Products with Therapeutic Equivalence Evaluations, or the Orange Book, must certify to the FDA that (i) no patent information on the drug has been listed in the Orange Book; (ii) that each patent listed in the Orange Book for that approved drug has expired; (iii) FDA should approve the product on the date on which a listed patent expires; or (iv) that such patent is invalid, unenforceable or will not be infringed by the manufacture, use or sale of the generic drug. If the ANDA applicant makes a certification pursuant to (iv) above, or a Paragraph IV certification, and the NDA holder files an infringement suit against the ANDA applicant within 45 days of receiving the Paragraph IV notification, the NDA owner is entitled to an automatic 30-month stay of FDA's ability to approve the ANDA. This 30-month stay will end early upon any decision by a court that the patent is invalid, unenforceable or not infringed by the generic drug.

Patent Term Extension . While the term of a U.S. patent is generally 20 years from the earliest priority date of a patent application (excluding a provisional patent application), a U.S. patent that covers subject matter requiring regulatory approval to market is eligible for an extension of that patent term. The Hatch-Waxman Act provides for the restoration of a portion of the patent term lost during product development and FDA review of an application. Patent Term Extension, or PTE, extends the term of an issued patent for generally (i) the length of the FDA approval process, i.e., the complete period of NDA review, and (ii) half of the time spent in clinical trials, i.e., the IND period. However, the maximum period of restoration cannot exceed five years, or restore the total remaining term of the patent to greater than 14 years from the date of FDA approval of the product.


Under 35 U.S.C. § 156(a), a patent covering a method of using a product is eligible for PTE if the following conditions are met:
- 1) the patent has not yet expired;
- 2) the patent was not previously extended;

---

# Page 13

- 3) the patent owner submits an application for PTE that includes all necessary supporting information within 60 days of FDA approval;
- 4) the product was subject to regulatory review before its commercial marketing or use; and
- 5) the drug application is for the first permitted commercial marketing of the product.


We believe that, if Gencaro is approved by the FDA, one of several of our U.S. patents may be eligible for PTE, which could provide approximately 5 years of additional patent life for that patent based on our current clinical trial plans.

A Supplementary Protection Certificate, or SPC, is a form of patent term extension that is available for pharmaceutical products approved for marketing in the European Union, or EU. We obtained a patent in Europe on methods for using Gencaro that is similar to one of our US Patents and this EU patent is in force in certain countries in Europe, including the United Kingdom, France, Germany, Italy and Spain. We believe that this patent may be eligible for an SPC, if Gencaro is approved for marketing in any European country in which the patent is in force, which could provide up to five years of additional patent life. We believe that our patents in other jurisdictions may also be eligible for similar term extensions.

Non-Patent Marketing Exclusivities. Separate and apart from patent protection, the Hatch-Waxman Act entitles approved drugs to various periods of non-patent statutory protection, known as marketing exclusivity. The Hatch-Waxman Act provides five years of 'new chemical entity' marketing exclusivity to the first applicant to gain approval of an NDA for a product that contains an active moiety not found in any other approved product. This exclusivity means that another manufacturer cannot submit an ANDA or 505(b)(2) NDA until the marketing exclusivity period ends. This exclusivity protects the entire new chemical entity franchise, including all products containing the active ingredient for any use and in any strength or dosage form, but will not prevent the submission or approval of stand-alone NDAs where the applicants have conducted their own clinical studies to demonstrate safety and effectiveness. There is an exception, however, for a competitor that seeks to challenge a patent with a Paragraph IV certification. Four years into the five-year exclusivity period, a manufacturer who alleges that one or more of the patents listed with the NDA is invalid, unenforceable or not infringed may submit an ANDA or 505(b)(2) NDA for a generic or modified version of the product.

The Hatch-Waxman Act also provides three years of 'new use' marketing exclusivity for the approval of NDAs, and supplements, where those applications contain the results of new clinical investigations (other than bioavailability studies) essential to the FDA's approval of the applications. Such applications may be submitted for new indications, dosage forms, strengths, or new conditions of use of approved products. So long as the studies are essential to the FDA's approval or were conducted by or for the applicant, this three-year exclusivity prohibits the final approval of ANDAs or 505(b)(2) NDAs for products with the specific changes associated with those studies. It does not prohibit the FDA from approving ANDAs or 505(b)(2) NDAs for other products containing the same active ingredient, without those changes.

Similar non-patent market exclusivity is provided for in the EU and other international jurisdictions. We believe that, if approved in the EU, Gencaro may be eligible for ten years of market exclusivity in the EU, measured from the date of approval there.


## FDA Premarket Review of Medical Devices

Unless an exemption applies, each medical device that a company wishes to market in the United States requires either approval of a premarket approval application, or PMA, or clearance of a premarket notification, commonly known as a '510(k)' from the FDA. The FDA classifies medical devices into one of three classes. Devices deemed to pose lower risks are placed in either class I or II, which may require the manufacturer to submit to the FDA a 510(k) requesting permission to commercially distribute the device. Clearance of a 510(k) usually requires between three months and one year from the time of submission of the 510(k), although the process may take longer. The FDA's 510(k) clearance procedure is less rigorous than the PMA approval procedure, but is available only to companies who can establish that their device is substantially equivalent to a legally-marketed 'predicate' device that was (i) on the market prior to the enactment of the Medical Device Amendments of 1976, (ii) reclassified from Class III to Class II, or (iii) has been cleared through the 510(k) procedure. 510(k)s must typically be supported by performance data, including preclinical data, bench testing, and in some cases, clinical data. Some low risk devices are exempted from this requirement. Devices deemed by the FDA to pose the greatest risks, or for which there is no predicate, are placed in class III, and require a PMA.

PMA Pathway . Generally, a PMA must be supported by extensive data and valid scientific evidence, including, but not limited to, technical, preclinical, clinical trials, manufacturing and labeling to demonstrate to the FDA's satisfaction a reasonable assurance of the safety and effectiveness of the device for its intended use. After a PMA is sufficiently complete, the FDA will accept the application and begin an in-depth review of the submitted information and will generally conduct a pre-approval inspection of the manufacturing facility or facilities to ensure compliance with FDA's Quality System Regulations, or QSR. By statute, the FDA has 180 days to review the 'accepted application', although, generally, review of the application can take between one and three years, and it may take significantly longer. The PMA application process can be expensive, and there is a substantial 'user fee' that must be paid to FDA in connection with the submission of a PMA application. If the FDA's evaluation of the PMA application or the manufacturing facility is not favorable, the FDA may deny approval of the PMA application or issue a 'not approvable' letter. The FDA may also require additional clinical trials, which can delay the PMA approval process by several years. In addition, if FDA discovers that an applicant has submitted false or misleading information, FDA may refuse to review submissions until certain requirements are met pursuant to its Application Integrity Policy, or AIP. If the FDA approves the PMA, it may place restrictions on the device. After the PMA is

---

# Page 14

approved, if significant changes are made to a device, its manufacturing or labeling, a PMA supplement containing additional information must be filed for prior FDA approval. PMA supplements often must be approved by the FDA before the modification to the device, the labeling, or the manufacturing process may be implemented. Delays in receipt of or failure to receive such clearances or approvals, the loss of previously received clearances or approvals, or the failure to comply with existing or future regulatory requirements could have a material adverse effect on our business, financial condition and results of operations.

Clinical Trials. Clinical trials are generally required to support a PMA application and are sometimes required for 510(k) clearance. These trials generally require an Investigational Device Exemption, or IDE, application approved in advance by the FDA for a specified number of patients, unless the proposed study is deemed a non-significant risk study, which is eligible for an exemption from the IDE requirements. The IDE application must be supported by appropriate data, such as animal and laboratory testing results. Clinical trials may begin if the IDE application is approved by the FDA and the appropriate institutional review boards, or IRBs, at the clinical trial sites. Submission of an IDE application does not give assurance that the FDA will issue the IDE. If the IDE application is approved, there can be no assurance the FDA will determine that the data derived from the trials support the safety and effectiveness of the device or warrant the continuation of clinical trials. An IDE supplement must be submitted to and approved by the FDA before a sponsor or investigator may make a change to the investigational plan in such a way that may affect its scientific soundness, study indication or the rights, safety or welfare of human subjects. The trial must also comply with the FDA's regulations, including the requirement that informed consent be obtained from each subject. Even if a trial is completed, the results of clinical testing may not adequately demonstrate the safety and efficacy of the device or may otherwise not be sufficient to obtain FDA clearance to market the product in the United States.

In Vitro Diagnostic Companion Diagnostic Devices. FDA has described IVD companion diagnostic devices as in vitro diagnostic devices that provide information that is essential for the safe and effective use of a corresponding therapeutic product. The use of an IVD companion diagnostic device with a particular therapeutic product is stipulated in the instructions for use in the labeling of both the diagnostic device and the corresponding therapeutic product, as well as in the labeling of any generic equivalents of the therapeutic product. An IVD companion diagnostic device could be used to (i) identify patients who are most likely to benefit from a particular therapeutic product; (ii) identify patients likely to be at increased risk for serious adverse reactions as a result of treatment with a particular therapeutic product; or (iii) monitor response to treatment for the purpose of adjusting treatment (e.g., schedule, dose, discontinuation) to achieve improved safety or effectiveness. Although FDA's regulation of IVD companion diagnostic devices is evolving and implemented on a case-by-case basis, FDA's stated policy for a novel therapeutic product is that an IVD companion diagnostic device should be developed and approved or cleared contemporaneously to support the therapeutic product's safe and effective use. The clinical performance and clinical significance of the IVD companion diagnostic device is to be established using data from the clinical development program of the corresponding therapeutic product. FDA recognizes, however, that there may be cases where contemporaneous development may not be possible. With respect to the Gencaro Test, there is no assurance that we will be able to develop and obtain approval or clearance contemporaneously with Gencaro. Failure to develop the Gencaro Test or obtain clearance or approval could delay approval of Gencaro, if FDA regards the Gencaro Test as an IVD companion diagnostic test that is essential to the safe and effective use of Gencaro.

Continuing Regulation. After a device is placed on the market, numerous regulatory requirements apply to the manufacturer, or holder of a PMA approval. Unless subject to an exemption, medical devices distributed in the United States must be manufactured in compliance with the FDA's Quality System Regulations, or QSRs, and current good manufacturing practices. These regulations govern the manufacturing process, including design, manufacture, testing, release, packaging, distribution, documentation and purchasing, as well as complaint handling, corrective and preventative actions and internal auditing. In complying with the QSRs, manufacturers must expend significant time, money and effort. Companies are also subject to other post-market and general requirements, including but not limited to product listing and establishment registration, post-market surveillance requirements, limitations on promotion, and requirements for recordkeeping and reporting of certain adverse events, malfunctions, corrections and removals. As discussed above, FDA regularly inspects companies to assess compliance with the QSRs and other post-market requirements. Failure to comply with these requirements can result in, among other things, adverse publicity, warning letters, and potential civil and criminal penalties. As part of such arrangement, we will seek to have the diagnostic company take responsibility for compliance with the FDA's device approval and on-going regulatory requirements.

International Marketing Approvals. International sales of medical devices are subject to foreign government regulations, which vary substantially from country to country and are subject to change. The time required to obtain approval by a foreign country may be longer or shorter than that required for FDA clearance or approval, and the requirements may differ.

Other Regulatory Requirements. We are also subject to various federal, state and local laws, regulations and recommendations relating to safe working conditions, laboratory and manufacturing practices, the experimental use of animals and the use and disposal of hazardous or potentially hazardous substances, including radioactive compounds and infectious disease agents, used in connection with our work. The extent and character of governmental regulation that might result from future legislation or administrative action cannot be accurately predicted.

---

# Page 15

# Medical Device Tax

In March 2010, the U.S. Congress adopted and President Obama signed into law comprehensive health care reform legislation. Among other initiatives, these laws impose significant new taxes on medical device makers in the form of a 2.3% excise tax on U.S. medical device sales, with certain exemptions, beginning on January 1, 2013. On January 22, 2018, legislation was enacted suspending the medical device tax in 2018 and 2019. In December 2019, a permanent repeal of the medical device tax was enacted. The Gencaro Test is likely to be subject to this tax if this tax is reinstated in the future.


## Intellectual Property

The future success of our business will partly depend on our ability to maintain market exclusivity for our product candidates, if approved, in the United States and important international markets, and for other products or product candidates that we may acquire or develop. We will rely on statutory protection, patent protection, trade secrets, know-how, and in-licensing of technology rights to maintain protection for our products.


## Gencaro

We believe that Gencaro, if approved, will have market exclusivity in the United States and in major international markets. We recently obtained a patent in the United States for the use of Gencaro for the patient population we plan to study in the Phase 3 pivotal trial. We have filed similar patent applications in international jurisdictions. If Gencaro is approved by the FDA or international regulatory agencies based on this planned clinical development, we believe that the commercialization of Gencaro will have patent protection extending into 2039.

We have an existing patent portfolio of United States and international patents covering the use of Gencaro for various cardiovascular indications in the genetic population we plan to study in Phase 3, that we believe will provide additional patent protection.

In addition to patent protection, Gencaro will qualify as a new chemical entity and if approved will have data protection in the United States and other jurisdictions in which it is approved.

We also have other patent rights in additional drug candidates having possible indications in cardiovascular disease, oncology, and other therapeutic areas; these are in both early and later stages of development. We may seek collaborators to assist us in the development of these candidates or we may seek to raise funds to advance the development of the compounds on our own.


## Information about our Executive Officers

Information relating to our executive officers is included in Item 10 of Part III of this Annual Report and such information is incorporated herein by reference.


## Human Capital Management

As of December 31, 2022, we had 6 employees, 5 of which are full-time. None of our employees are represented by any collective bargaining unit. We believe that we maintain good relations with our employees.

Information relating to compensation of our executive officers is included in Items 10 and 11 of Part III of this Annual Report and such information is incorporated herein by reference. The structure of our compensation programs balances incentive earnings for both short-term and long-term performance. We are committed to providing comprehensive benefit options and offering benefits that will allow our employees and their families to live healthier and more secure lives. Some examples are employees are eligible for health insurance, prescription drug benefits, dental insurance, vision insurance, life insurance, disability insurance, health savings accounts, flexible spending accounts, paid and unpaid leaves, a retirement plan and life and disability/accident coverage. We also offer a variety of voluntary benefits that allow employees to select the options that meet their needs, including hospital indemnity insurance, accident insurance and critical illness insurance.

We continually monitor employee turnover rates as our success depends upon retaining our highly trained personnel. We believe the combination of competitive compensation and career growth and development opportunities have helped increase employee tenure and reduce voluntary turnover. The average tenure of our employees is approximately eleven years and approximately one-half of our employees have been employed by us for more than ten years.


## Corporate Information

On January 27, 2009, we completed a business combination, or the Merger, between Nuvelo, Inc., or Nuvelo, a corporation originally incorporated in 1992, and its subsidiary, ARCA biopharma, Inc. Immediately following the Merger, we changed our name from Nuvelo, Inc. to ARCA biopharma, Inc. Our principal offices are located in Westminster, Colorado.

---

# Page 16

We file our annual reports on Form 10-K, quarterly reports on Form 10-Q and current reports on Form 8-K pursuant to Section 13(a) or 15(d) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, electronically with the U.S. Securities and Exchange Commission, or the SEC. The public may read or copy any materials that have been filed with the SEC at the SEC's Public Reference Rooms at 100 F Street, N.E., Washington, D.C. 20549 on official business days during the hours of 10:00 a.m. and 3:00 p.m. The public may obtain information on the operation of the Public Reference Room by calling the SEC at 1-800-SEC-0330. The SEC maintains an Internet site that contains reports, proxy and information statements, and other information regarding issuers that file electronically with the SEC. The address of that site is http://www.sec.gov.

You may obtain a free copy of our annual reports on Form 10-K, quarterly reports on Form 10-Q, current reports on Form 8-K and amendments to those reports on our website at http://www.arcabiopharma.com on the earliest practicable date following the filing with the SEC or by contacting the Investor Relations Department at our corporate office by calling (720) 940-2200. Information found on our website is not incorporated by reference into this report.

---

# Page 17

# Item 1A. Risk Factors

An investment in our securities involves certain risks, including those set forth below and elsewhere in this report. In addition to the risks set forth below and elsewhere in this report, other risks and uncertainties not known to us, that are beyond its control or that we deem to be immaterial may also materially adversely affect our business operations. You should carefully consider the risks described below as well as other information and data included in this report.


## Summary of Risk Factors

Below is a summary of the principal factors that make an investment in our common stock speculative or risky. This summary does not address all of the risks that we face. Additional discussion of the risks summarized in this risk factor summary, and other risks that we face, can be found below under the heading 'Risk Factors' and should be carefully considered, together with other information in this Form 10-K and our other filings with the SEC, before making an investment decision regarding our common stock.


- · there is no guarantee that even if we do engage in a strategic transaction that such strategic transaction will increase stockholder value;
- · if we engage in an acquisition, reorganization or business combination, we will incur a variety of risks potentially adversely affecting our business operations or our stockholders;
- · if we are not able to successfully develop, obtain FDA approval for, and provide for the commercialization of Gencaro or rNAPc2 in a timely manner, we may not be able to continue our business operations;
- · if we encounter difficulties enrolling patients in our future clinical trials, any potential enrollment milestones or potential regulatory approvals could be delayed or otherwise adversely affected;
- · our clinical trials for our product candidates may not yield results that will enable us to further develop our products and obtain regulatory approvals necessary to sell them;
- · we may not achieve our projected development goals in the time frames we announce and expect;
- · we expect a Phase 3 PRECISION-AF clinical trial will require substantially more capital, and we cannot guarantee when or if we will be able to secure such additional financing;
- · we will need to raise substantial additional funds through public or private equity or debt transactions and/or complete one or more strategic transactions or partnerships, to continue development of Gencaro, rNAPc2 or any of our other product candidates. If we are unable to raise such financing or complete such a transaction, we may not be able to continue operations;
- · we may need to partner rNAPc2 to continue development and commercialization or expansion into clinical trials for other disease indications. If we are unable to find a partner, we may not be able to continue operations;
- · if we are not able to maintain the requirements for listing on the Nasdaq Capital Market, we could be delisted, which could have a material adverse effect on our ability to raise additional funds as well as the price and liquidity of our common stock;
- · our business could be adversely affected by the effects of health epidemics, including the ongoing COVID-19 global pandemic, in regions where we or third parties on which we rely may have clinical trial sites or other business operations.
- · we depend or may depend on third parties to conduct clinical trials and provide diagnostic information, as well as to develop, commercialize and/or manufacture our product candidates;
- · unless we are able to generate sufficient product revenue, we will continue to incur losses from operations and will not achieve or maintain profitability. We are years away from commercializing a product and generating product revenue;
- · our product candidates are subject to extensive regulation, which can be costly and time-consuming, and unsuccessful or delayed regulatory approvals could increase our future development costs or impair our future revenue;
- · if our product candidates receive regulatory approval, we would be subject to ongoing regulatory obligations and restrictions, which may result in significant expenses and limit our ability to develop and commercialize other potential products;
- · transitioning from a clinical development stage company will require successful completion of a number of steps, many of which are outside of our control and, consequently, we can provide no assurance of our successful and timely transition

---

# Page 18

- from a clinical development stage company;
- · if approved by the FDA, Gencaro or rNAPc2 will be entering a competitive marketplace and may not succeed;
- · if we fail to identify and license or acquire other products or product candidates, then we may be unable to expand our business, and the acquisition or licensing of other products or product candidates may put a strain on our operations and will likely require us to seek additional financing;
- · the loss of any rights to market key products would significantly impair our operating results;
- · third parties may own or control patents or patent applications that we may be required to license to commercialize our product candidates or that could result in litigation that would be costly and time consuming;
- · our intellectual property rights may not preclude competitors from developing competing products and our business may suffer.



## Risks Related to Our Strategic Evaluation Process

There is no guarantee that even if we do engage in a strategic transaction that such strategic transaction will increase stockholder value.

In April 2022, the Board of Directors established a Special Committee and, in May 2022, retained Ladenburg Thalmann & Co. Inc. to evaluate strategic options, including transactions involving a merger, sale of all or part of our assets, or other alternatives with the goal of maximizing stockholder value. We believe there are multiple potential opportunities to enhance value for our shareholders. We do not have a defined timeline for the strategic review process and the review may not result in any specific action or transaction. We may never complete a strategic transaction, and in the event that we do complete a strategic transaction, implementation of such transactions may impair stockholder value or otherwise adversely affect our business. Any such transaction may require us to incur non-recurring or other charges and may pose significant integration challenges and/or management and business disruptions, any of which could harm our results of operation and business prospects and impair the value of any such strategic transaction to our stockholders.


## If we engage in an acquisition, reorganization or business combination, we will incur a variety of risks potentially adversely affecting our business operations or our stockholders.


In connection with our strategic transaction process, we are considering strategic business initiatives, which may include exploration and evaluation of strategic options such as a merger, reverse merger, other business combination, sale of assets, licensing, or other strategic transactions. If we pursue such a strategic transaction, we could, among other things:
- · issue equity securities dilutive to our current stockholders' percentage ownership;
- · incur substantial debt straining our operations;
- · spend substantial operational, financial, and management resources to integrate new businesses, technologies, and products;
- · assume substantial actual or contingent liabilities;
- · reprioritize our development programs and even cease development of our product candidates; or
- · merge with, or otherwise enter into a business combination with, another company in which our stockholders would receive cash and/or shares of the other company on terms certain of our stockholders may not deem desirable.


There is no guarantee we will be able to complete the strategic transaction process in a timely or successful manner, which could have a material adverse effect on our business.


## Risks Related to Our Business and Financial Condition

If we are not able to successfully develop, obtain FDA approval for, and provide for the commercialization of Gencaro or rNAPc2 in a timely manner, we may not be able to continue our business operations.

We currently have no products that have received regulatory approval for commercial sale. The process to develop, obtain regulatory approval for and commercialize potential product candidates is long, complex and costly.

---

# Page 19

Failure to demonstrate that a product candidate, including Gencaro or rNAPc2, is safe and effective, or significant delays in demonstrating such safety and efficacy, would adversely affect our business. Failure to obtain marketing approval of Gencaro or rNAPc2 from appropriate regulatory authorities, or significant delays in obtaining such approval, would also adversely affect our business and could, among other things, preclude us from completing a strategic transaction or obtaining additional financing necessary to continue as a going concern.

Even if approved for sale, a product candidate must be successfully commercialized to generate value. We do not currently have the capital resources or management expertise to commercialize Gencaro, rNAPc2 or any of our other product candidates and, as a result, will need to complete a strategic transaction, or, alternatively, raise substantial additional funds to enable commercialization of Gencaro, rNAPc2 or any of our other product candidates, if approved. Failure to successfully provide for the commercialization of Gencaro, rNAPc2 or any other product candidate, if approved, would damage our business.


# If we encounter difficulties enrolling patients in our future clinical trial of Gencaro, any potential enrollment milestones or potential regulatory approvals could be delayed or otherwise adversely affected.

We may encounter difficulty enrolling a sufficient number of patients in our clinical trials, due to circumstances which are outside our control, including other clinical trials that may limit the availability of study participants. As a result, we may need to delay or terminate our trial, which would have a negative impact on our business. Delays in enrolling patients in the clinical trial would also adversely affect our ability to meet projected enrollment milestones or timelines for completing the study and obtaining regulatory approval.


## Our clinical trials from our product candidates may not yield results that will enable us to further develop our products as a therapy and obtain regulatory approvals necessary to be used as a drug.

We will receive regulatory approval for our product candidates only if we can demonstrate, in carefully designed and conducted clinical trials, that the product candidate is safe and effective. We do not know whether any future clinical trials for Gencaro, rNAPc2 or any other product candidate will demonstrate sufficient safety and efficacy to obtain the requisite regulatory approvals or will result in marketable products.

The results from preclinical testing and early clinical trials may not be predictive of results from later studies. We may suffer significant setbacks in advanced clinical trials, even after seeing promising results in earlier studies. Based on results at any stage of clinical trials, we may decide to repeat or redesign a trial or discontinue development of one or more of our product candidates. If we fail to adequately demonstrate the safety and efficacy of our product candidates, we will not be able to obtain the required regulatory approvals to commercialize it and our business, results of operations and financial condition would be materially adversely affected.

In addition, administering our product candidates to humans may produce undesirable side effects. These side effects could interrupt, delay or halt clinical trials of our product candidates, and could result in the FDA or other regulatory authorities denying approval of our product candidates, for any or all targeted indications.


## We may not achieve our projected development goals in the time frames we announce and expect.

We set goals for, and make public statements regarding, the timing of certain accomplishments, such as the initiation of our clinical trials, the steps for commencing and continuing our clinical trials, the disclosure of trial results, the obtainment of regulatory approval and the sale of drug products, which we sometimes refer to as milestones. These milestones may not be achieved, and the actual timing of these events can vary dramatically due to a number of factors such as delays or failures in our clinical trials, disagreements with any collaborative partners, the uncertainties inherent in the regulatory approval process and manufacturing scale-up, delays in achieving manufacturing or marketing arrangements sufficient to commercialize our products or our inability to obtain sufficient financing in a timely manner. There can be no assurance that we will make regulatory submissions or receive regulatory approvals as planned. If we fail to achieve one or more of these milestones as planned, our business will be materially adversely affected.

---

# Page 20

# We expect a Phase 3 PRECISION-AF clinical trial will require substantially more capital, and we cannot guarantee when or if we will be able to secure such additional financing.

We will need to secure additional financing in order to initiate enrollment of our Phase 3 PRECISION-AF clinical trial. Even if we can begin enrolling patients, we expect to have to raise significant additional capital to continue enrollment. If we are not able to obtain financing in the future or on acceptable terms, we may have to terminate the clinical trial early, which could adversely affect our business.

We will need to raise substantial additional funds through public or private equity or debt transactions and/or complete one or more strategic transactions or partnerships, to continue development of Gencaro, rNAPc2 or any of our other product candidates. If we are unable to raise such financing or complete such a transaction, we may not be able to continue operations.

As a result of the expected development timeline to potentially obtain FDA approval for Gencaro or rNAPc2, if at all, the substantial additional costs associated with the development of our product candidates, including the costs associated with clinical trials related thereto, and the substantial cost of commercializing Gencaro or rNAPc2, if approved, we will need to raise substantial additional funding through public or private equity or debt transactions or a strategic combination or partnership. If we are delayed in obtaining funding or are unable to complete a strategic transaction, we may discontinue our development activities on Gencaro, rNAPc2 and our other product candidates or discontinue our operations. Even if we are able to fund continued development of Gencaro, rNAPc2 or any of our other product candidates is approved, we expect that we will need to complete a strategic transaction or raise substantial additional funding through public or private equity or debt securities or partnership to successfully commercialize Gencaro, rNAPc2 or any other product candidate.

We believe our cash and cash equivalents as of December 31, 2022 will be sufficient to fund our operations through the middle of fiscal year 2024. Our review of our strategic options may impact this projection. Conducting a Phase 3 PRECISION-AF trial or rNAPc2 clinical trial would likely require additional financing. On July 22, 2020, we entered into a new sales agreement with a placement agent to sell, from time to time, our common stock having an aggregate offering price of up to $54.0 million, in an 'at the market offering.' As of December 30, 2022, we sold an aggregate of 9,928,272 shares of our common stock pursuant to the terms of such sales agreement for aggregate gross proceeds of approximately $54.0 million. Net proceeds received in this offering were approximately $52.2 million, after deducting expenses for executing the 'at the market offering' and commissions paid to the placement agent. In April 2021, we amended the new sales agreement and have $50.0 million available for the offering under our prospectus to our registration statement on Form S-3 (No. 333-254585). As of February 22, 2023, the amount available for the offering under the prospectus supplement is subject to the limitation of not selling a total value amount of shares exceeding more than one-third of our public float in any 12-month period, which as of February 22,2023 would have been approximately $8.8 million. Sales of our common stock dilute the ownership interest of our stockholders and may cause the price per share of our common stock to decrease. Changing circumstances may cause us to consume capital significantly faster or slower than we currently anticipate. We have based these estimates on assumptions that may prove to be wrong, and we could exhaust our available financial resources sooner than we currently anticipate.

Additionally, in March 2020, the World Health Organization declared the outbreak of COVID-19 a global pandemic. This outbreak is causing major disruptions to businesses and markets worldwide as the virus spreads. The economic uncertainty surrounding the COVID-19 pandemic may dramatically reduce our ability to secure equity or debt financing necessary to support our operations. We are unable to currently estimate the financial effect of the pandemic. If the pandemic continues to be a severe worldwide crisis, economic conditions may cause capital not to be available to us, or not be available on acceptable terms, regardless of our business efforts.

---

# Page 21

Our liquidity, and our ability to raise additional capital or complete any strategic transaction, depends on a number of factors, including, but not limited to, the following:
- · the costs and timing for potential additional clinical trials in order to gain possible regulatory approval for Gencaro, rNAPc2 and our other product candidates;
- · the market price of our stock and the availability and cost of additional equity capital from existing and potential new investors;
- · our ability to retain the listing of our common stock on the Nasdaq Capital Market;
- · general economic and industry conditions affecting the availability and cost of capital, including as a result of deteriorating market conditions due to investor concerns regarding inflation and continued hostilities between Russia and Ukraine;
- · our ability to control costs associated with our operations;
- · the costs of filing, prosecuting, defending and enforcing any patent claims and other intellectual property rights; and
- · the terms and conditions of our existing collaborative and licensing agreements.


The sale of additional equity or convertible debt securities would likely result in substantial dilution to our stockholders. If we raise additional funds through the incurrence of indebtedness, the obligations related to such indebtedness would be senior to rights of holders of our capital stock and could contain covenants that would restrict our operations. We also cannot predict what consideration might be available, if any, to us or our stockholders, in connection with any strategic transaction. Should strategic alternatives or additional capital not be available to us, or not be available on acceptable terms, we may be unable to realize value from our assets and discharge our liabilities in the normal course of business which may, among other alternatives, cause us to further delay, substantially reduce or discontinue operational activities to conserve our cash resources.


## We have received an SPA agreement from the FDA relating to our planned Phase 3 program for Gencaro. This SPA agreement does not guarantee approval of Gencaro or any other particular outcome from regulatory review.

In 2019, we received an SPA agreement from the FDA for our planned Phase 3 clinical trial of Gencaro. The FDA's SPA process is designed to facilitate the FDA's review and approval of drugs by allowing the FDA to evaluate the proposed design and size of certain clinical trials that are intended to form the primary basis for determining a drug product's efficacy. Upon specific request by a clinical trial sponsor, the FDA will evaluate the protocol and respond to a sponsor's questions regarding, among other things, primary efficacy endpoints, trial conduct and data analysis, within 45 days of receipt of the request. The FDA ultimately assesses whether the protocol design and planned analysis of the trial are acceptable to support regulatory approval of the product candidate with respect to the effectiveness of the indication studied. All agreements and disagreements between the FDA and the sponsor regarding a SPA must be clearly documented in a SPA letter or the minutes of a meeting between the sponsor and the FDA.

However, an SPA agreement does not guarantee approval of a product candidate, even if the trial is conducted in accordance with the protocol. Moreover, the FDA may revoke or alter our SPA agreement in certain circumstances. In particular, a SPA agreement is not binding on the FDA if public health concerns emerge that were unrecognized at the time of the SPA agreement, other new scientific concerns regarding product safety or efficacy arise, we fail to comply with the agreed upon trial protocols, or the relevant data, assumptions or information provided by us in our request for the SPA change or are found to be false or omit relevant facts. In addition, even after an SPA agreement is finalized, the SPA agreement may be modified, and such modification will be deemed binding on the FDA review division, except under the circumstances described above, if the FDA and the sponsor agree in writing to modify the protocol and such modification is intended to improve the study. The FDA retains significant latitude and discretion in interpreting the terms of the SPA agreement and the data and results from any study that is the subject of the SPA agreement.

Even though we obtained an agreement on our SPA, we cannot assure you that our planned Phase 3 clinical trial will succeed, will be deemed binding by the FDA under our SPA agreement, or will result in any FDA approval for Gencaro. We may also alter the design of the trial to focus on endpoints that are not covered by the SPA. Moreover, if the FDA revokes or alters its agreement under our SPA, or interprets the data collected from the clinical trial differently than we do, the FDA may not deem the data sufficient to support an application for regulatory approval, which could materially adversely affect our business, financial condition and results of operations.

---

# Page 22

# If we are not able to maintain the requirements for listing on the Nasdaq Capital Market, we could be delisted, which could have a material adverse effect on our ability to raise additional funds as well as the price and liquidity of our common stock.

Our common stock is currently listed on the Nasdaq Capital Market. To maintain the listing of our common stock on the Nasdaq Capital Market we are required to meet certain listing requirements, including, among others, (i) a minimum closing bid price of $1.00 per share, (ii) a market value of publicly held shares (excluding shares held by our executive officers, directors and 10% or more stockholders) of at least $1 million and (iii) either: (x) stockholders' equity of at least $2.5 million; or (y) a total market value of listed securities of at least $35 million.

We have received three potential delisting notices from Nasdaq since 2012. In each of 2012, 2015 and 2018, we received notification from Nasdaq of potential delisting of our shares from the Nasdaq Capital Market because the closing bid price of our common stock had not met the minimum closing bid price of $1.00 per share during the preceding 30 business days. We subsequently regained compliance with Nasdaq's minimum closing bid price requirements related to the 2012, 2015 and 2018 notices, by effecting a 1-for-6 reverse split of our common stock in March 2013, a 1-for-7 reverse split of our common stock in September 2015 and a 1-for-18 reverse split of our common stock in April 2019. Despite effecting a 1-for-18 reverse split of our common stock in April 2019, there can be no assurance that the market price per share of our common stock will remain in excess of the $1.00 minimum bid price for a sustained period of time. The continuing effect of our reverse stock split on the market price of our common stock cannot be predicted with any certainty, and the history of similar stock split combinations for companies in like circumstances is varied. It is possible that the per share price of our common stock after the reverse stock split will not rise in proportion to the reduction in the number of shares of common stock outstanding resulting from the reverse stock split, effectively reducing our market capitalization, and there can be no assurance that the market price per post-reverse split share will either exceed or remain in excess of the $1.00 minimum bid price for a sustained period of time. The market price of our common stock may vary based on other factors that are unrelated to the number of shares outstanding, including our future performance.

The delisting of our common stock from a national exchange could impair the liquidity and market price of the common stock. It could also materially, adversely affect our access to the capital markets, and any limitation on market liquidity or reduction in the price of the common stock as a result of that delisting could adversely affect our ability to raise capital on terms acceptable to us, or at all.

In future periods, if we do not meet the minimum stockholders' equity, minimum closing bid price requirements, or any other listing requirements, we would be subject to delisting from the Nasdaq Capital Market.

As of February 22, 2023, the closing price of our common stock was $2.12 per share, and the total market value of our listed securities was approximately $30.5 million. As of December 31, 2022, we had stockholders' equity of $41.7 million.

Our audited financial statements for the fiscal year ended December 31, 2022 were prepared assuming that we will continue as a going concern. Our management has concluded that due to our need for additional capital, and the uncertainties surrounding our ability to raise such funding, there may be uncertainty about our ability to continue as a going concern in future years.

Our audited financial statements for the fiscal year ended December 31, 2022 were prepared assuming that we will continue as a going concern. The going concern basis of presentation assumes that we will continue in operation for the foreseeable future and will be able to realize our assets and discharge our liabilities and commitments in the normal course of business and do not include any adjustments to reflect the possible future effects on the recoverability and classification of assets or the amounts and classification of liabilities that may result from our inability to continue as a going concern. As of December 31, 2019, our management and our independent registered public accounting firm concluded that, due to our need for additional capital and the uncertainties surrounding our ability to raise such funding, substantial doubt existed as to our ability to continue as a going concern for a period from one year after our annual financial statements had been issued. We believe our cash and cash equivalents as of December 31, 2022 will be sufficient to fund our operations through the middle of fiscal year 2024. Our review of our strategic options may impact this projection. Conducting the Phase 3 PRECISION-AF trial or Phase 3 rNAPc2 clinical trial would likely require additional financing. We cannot be certain that we will be able to make any other sale of our common stock in any future offering to cover our future capital needs, or at all. Changing circumstances may cause us to consume capital significantly faster or slower than we currently anticipate. If we are delayed in completing or are unable to complete additional funding and/or a strategic transaction, we may discontinue our development activities or operations, but there are no assurances that these reductions would be sufficient to allow us to continue to operate as a going concern. Therefore, even if we resolve this uncertainty, our independent registered public accountants and/or management could conclude that uncertainty as to our ability to continue as a going concern could exist at a future date.

---

# Page 23

We have based these estimates on assumptions that may prove to be wrong, and we could exhaust our available financial resources sooner than we currently anticipate. We may be forced to reduce our operating expenses and raise additional funds to meet our working capital needs, principally through the additional sales of our securities or debt financings. However, we cannot guarantee that we will be able to obtain sufficient additional funds when needed or that such funds, if available, will be obtainable on terms satisfactory to us. If we are unable to raise sufficient additional capital or complete a strategic transaction, we may be unable to continue to fund our operations, develop Gencaro, rNAPc2 or our other product candidates, or realize value from our assets and discharge our liabilities in the normal course of business. If we cannot raise sufficient funds, we may have to liquidate our assets, and might realize significantly less than the values at which they are carried on our financial statements, and stockholders may lose all or part of their investment in our securities.


# Our business could be adversely affected by the effects of health epidemics, including the ongoing COVID-19 global pandemic, in regions where we or third parties on which we rely may have clinical trial sites or other business operations. We anticipate having clinical trial sites in countries that have been directly affected by COVID-19 and depend on third party manufacturing operations for various stages of our supply chain.

Our business could be adversely affected by health epidemics, including the ongoing COVID-19 pandemic, in regions where we may have concentrations of future clinical trial sites or other business operations.

If the recent COVID-19 outbreak continues to spread, we may need to further limit operations or implement limitations, including work-from-home policies. There is a risk that other countries or regions may be less effective at containing COVID-19, or it may be more difficult to contain if the outbreak reaches a larger population or broader geography, in which case the risks described herein could be elevated significantly.

In addition, third party manufacturing of our drug product candidates and suppliers of the materials used in the production of our drug product candidates may be impacted by significant delays or restrictions resulting from the COVID-19 outbreak which may disrupt our supply chain or limit our ability to manufacture drug product candidates for our clinical trials.

The ultimate impact of the COVID-19 outbreak or a similar future health epidemic is highly uncertain and subject to change. We do not yet know the full extent of potential delays or impacts on our business, our clinical trials, healthcare systems or the global economy as a whole. However, these effects could have a material impact on our operations, and we will continue to monitor the COVID-19 situation closely.


## If we encounter difficulties enrolling patients in any future clinical trials, our future trials could be delayed or otherwise adversely affected.

If we have difficulty enrolling a sufficient number of patients in any future clinical trial, we may need to delay or terminate our trial, which would have a negative impact on our business. Delays in enrolling patients in any future clinical trials would also adversely affect our ability to generate any product, milestone and royalty revenues under collaboration agreements, if any, and could impose significant additional costs on us or on any future collaborators.

Development beyond our control, such as the development of vaccines for the SARS-CoV-2 virus or the development of other therapies for COVID-19 disease, may impact our ability to enroll patients in any future rNAPc2 (AB201) clinical trials. Enrollment for the rNAPc2 (AB201) Phase 2b clinical trial was slower than expected.

The GENETIC-AF clinical trial required that we identify and enroll a large number of patients with the condition under investigation and the trial enrolled only those patients having a specific genotype, and certain patients who have or are willing to have a Medtronic device implanted for monitoring and recording AFB data. As a result, enrollment for GENETIC-AF was slower than expected, with our first patient enrolled in June 2014 and enrollment completed in August 2017. Because of the rigorous enrollment criteria, our clinical trial timelines were delayed from our original projections. We anticipate that any future Phase 3 clinical trial of Gencaro, including PRECISION-AF, may have similar enrollment criteria, and we cannot guarantee that we will not have similar enrollment issues in any future clinical trials.

We may also encounter difficulty enrolling a sufficient number of patients in any future clinical trial, due to circumstances which are outside our control, including as a result of deteriorating market conditions due to investor concerns regarding inflation and continued hostilities between Russia and Ukraine. See 'Our business could be adversely affected by the effects of health epidemics, including the ongoing COVID-19 global pandemic, in regions where we or third parties on which we rely have clinical trial sites or other business operations. We anticipate having clinical trial sites in countries that have been directly affected by COVID-19 and depend on third party manufacturing operations for various stages of our supply chain' for a discussion of the risks that the COVID-19 pandemic poses to, among other things, our anticipated clinical trials.

---

# Page 24

We will rely on contract research organizations to conduct substantial portions of our clinical trials, including any future clinical trial of Gencaro, rNAPc2, and as a result, we will be unable to directly control the timing, conduct and expense of all aspects of our clinical trials.

We do not currently have sufficient staff with the requisite experience to conduct our clinical trials and therefore will rely on third parties to conduct certain aspects of any future clinical trials. We previously contracted with a CRO to conduct components of our GENETIC-AF clinical trial and anticipate contracting with a CRO to conduct components of any future clinical trial for Gencaro and components of the clinical study of rNAPc2 or any future clinical trials for our other product candidates. As a result, we will have less control over many details and steps of any clinical trial, the timing and completion of any clinical trial, the required reporting of adverse events and the management of data developed through any clinical trial than would be the case if we were relying entirely upon our own staff. Communicating with outside parties can also be challenging, potentially leading to mistakes as well as difficulties in coordinating activities. Outside parties, such as CROs, may have staffing difficulties, may undergo changes in priorities or may become financially distressed, adversely affecting their willingness or ability to conduct our clinical trial. We may experience unexpected cost increases that are beyond our control. Problems with the timeliness or quality of the work of a CRO may lead us to seek to terminate the relationship and use an alternative service provider. However, making any change may be costly and may delay ongoing trials, if any, and contractual restrictions may make such a change difficult or impossible. Additionally, it may be impossible to find a replacement organization that can conduct clinical trials in an acceptable manner and at an acceptable cost.

Even though we anticipate relying on CROs in the future, we will likely have to devote substantial resources and rely on the expertise of our employees to manage the work being done by the CROs. Due to our limited experience in managing clinical trials, we cannot guarantee our employees will do so effectively.


## We expect to depend on existing and future collaborations with third parties for the development of some of our product candidates. If those collaborations are not successful, we may not be able to complete the development of these product candidates.

We collaborated with one or more clinical trial networks in our development program for rNAPc2. As a result, we lacked direct control over certain aspects of the development program and the amount and timing of resources that these collaborators devote to the project.

We had a collaboration agreement with Medtronic that supported our GENETIC-AF clinical trial. If our arrangement with Medtronic, as amended, is continued as part of our future development of Gencaro, we will have limited control over the amount and timing of resources that they dedicate to the development of Gencaro. This is also likely to be true in any future collaboration with third parties and we may seek additional third party collaborators for the development of Gencaro, rNAPc2 or any other product candidates. Our ability to benefit from these arrangements will depend on our collaborators' abilities to successfully perform the functions assigned to them in these arrangements.


Collaborations involving our product candidates pose the following risks to us:
- · collaborators have significant discretion in determining the efforts and resources that they will apply to these collaborations;
- · collaborators may not pursue development and commercialization of our product candidates or may elect not to continue or renew development or commercialization programs based on clinical trial results, changes in the collaborator's strategic focus or available funding, or external factors such as an acquisition that diverts resources or creates competing priorities;
- · collaborators may delay clinical trials, provide insufficient funding for a clinical trial program, stop a clinical trial or abandon a product candidate, repeat or conduct new clinical trials or require a new formulation of a product candidate for clinical testing;
- · collaborators could independently develop, or develop with third parties, products that compete directly or indirectly with our product candidates if the collaborators believe that competitive products are more likely to be successfully developed or can be commercialized under terms that are more economically attractive than ours;
- · collaborators may not properly maintain or defend our intellectual property rights or may use our proprietary information in such a way as to invite litigation that could jeopardize or invalidate our proprietary information or expose us to potential litigation;
- · disputes may arise between the collaborators and us that result in the delay or termination of the research, development or commercialization of our product candidates or that result in costly litigation or arbitration that diverts management attention and resources;
- · collaborations may be terminated and, if terminated, may result in a need for additional capital to pursue further development or commercialization of the applicable product candidates;

---

# Page 25

- · collaborators may elect to take over manufacturing rather than retain us as manufacturers and may encounter problems in starting up or gaining approval for their manufacturing facility and so be unable to continue development of product candidates;
- · we may be required to undertake the expenditure of substantial operational, financial and management resources in connection with any collaboration;
- · we may be required to issue equity securities to collaborators that would dilute our existing stockholders' percentage ownership;
- · we may be required to assume substantial actual or contingent liabilities;
- · collaborators may not commit adequate resources to the marketing and distribution of our product candidates, limiting our potential revenues from these products; and
- · collaborators may experience financial difficulties.


We face a number of challenges in seeking additional collaborations. Collaborations are complex and any potential discussions may not result in a definitive agreement for many reasons. For example, whether we reach a definitive agreement for a collaboration will depend, among other things, upon our assessment of the collaborator's resources and expertise, the terms and conditions of the proposed collaboration, and the proposed collaborator's evaluation of a number of factors, such as the design or results of our clinical trials, the potential market for our product candidates, the costs and complexities of manufacturing and delivering our product candidates to patients, the potential of competing products, the existence of uncertainty with respect to ownership or the coverage of our intellectual property, and industry and market conditions generally. If we were to determine that additional collaborations for our Gencaro development is necessary and were unable to enter into such collaborations on acceptable terms, we might elect to delay or scale back the development or commercialization of Gencaro in order to preserve our financial resources or to allow us adequate time to develop the required physical resources and systems and expertise ourselves .

Collaboration agreements may not lead to development or commercialization of our product candidates in the most efficient manner, or at all. In addition, there have been a significant number of recent business combinations among large pharmaceutical companies that have resulted in a reduced number of potential future collaborators. If a present or future collaborator of ours were to be involved in a business combination, the continued pursuit and emphasis on our product development or commercialization program could be delayed, diminished or terminated.


## Any future clinical trial for Gencaro will require the use of a third-party diagnostic services provider to administer a genetic test needed to identify the patient receptor genotypes of clinical trial participants, and as a result, we will be unable to directly control the timing, conduct and expense of the genetic test.

We anticipate that any future clinical trial of Gencaro, if any, will require a companion diagnostic test that identifies the patient's receptor genotype. The trial would only enroll those patients with the receptor that has the potential for enhanced efficacy, the beta-1 389 Arg receptor as detected by a beta-1 389 Arg/Arg genotype. Accordingly, we anticipate that any future clinical trial for Gencaro will require the use of a third-party diagnostic service to perform the genetic testing. There has been limited experience in our industry in prospective development of companion diagnostics required to perform the required molecular profiling. We entered into an agreement with LabCorp to provide the diagnostic services of the genetic test needed to support our GENETIC-AF clinical trial. To provide those services, LabCorp obtained from the FDA an investigational device exemption, or IDE, for the companion diagnostic test being used in our GENETIC-AF clinical trial. We would expect a similar agreement and approval would be necessary for any companion diagnostic used in any future clinical trials for Gencaro.

The FDA and similar regulatory authorities outside the United States regulate companion diagnostics. Companion diagnostics require separate or coordinated regulatory approval prior to commercialization. Changes to regulatory advice could delay our development programs or delay or prevent eventual marketing approval for our product candidates that may otherwise be approvable. In July 2011, the FDA issued draft guidance that stated that if safe and effective use of a therapeutic depends on an in vitro diagnostic, the FDA generally will not approve the therapeutic unless the FDA approves or clears this ' in vitro companion diagnostic device' at the same time that the FDA approves the therapeutic. The approval or clearance of the companion diagnostic would occur through the FDA's Center for Devices and Radiological Health. In 2014, the FDA issued guidance on in vitro companion diagnostic devices. The guidance allows for flexibility by the FDA in the case of therapeutic products to treat serious conditions for which no alternative treatment exists and the benefits of using the companion diagnostic outweigh the risk, but it is unclear how this discretion may be applied by the agency with respect to the companion diagnostic test related to any Gencaro clinical trials. The FDA's evolving position on the topic of companion diagnostics could affect our clinical development programs that utilize companion diagnostics. In particular, the FDA may limit our ability to use retrospective data, otherwise disagree with our approaches to trial design, biomarker qualification, clinical and analytical validity, and clinical utility, or make us repeat aspects of a trial or initiate new trials.

---

# Page 26

Given our limited experience in developing diagnostics, we expect to rely primarily on third parties for the design and manufacture of the companion diagnostics for our product candidates. If we, or any third parties that we engage to assist us, are unable to successfully develop companion diagnostics for our product candidates that require such diagnostics, or experience delays in doing so, the development of our product candidates may be adversely affected, our product candidates may not receive marketing approval and we may not realize the full commercial potential of any products that receive marketing approval. As a result, our business could be materially harmed.


# We will need to establish a collaborative arrangement with a third-party diagnostics services provider to obtain marketing clearance or approval of the companion genetic test for Gencaro. There is no guarantee that the FDA will grant timely clearance or approval of the genetic test, if at all, and failure to obtain such timely clearance or approval would adversely affect our ability to market Gencaro.

The drug label we intend to seek for Gencaro would identify the patient receptor genotype for which the drug is approved. Accordingly, we believe developing a genetic test that is simple to administer and widely available will be critical to the successful commercialization of Gencaro. The genetic test will be subject to regulation by the FDA and by comparable agencies in various foreign countries. The process of complying with the requirements of the FDA and comparable agencies is costly, time consuming and burdensome.

Despite the time and expense expended, regulatory clearance or approval is never guaranteed. If regulatory clearance or approval is delayed, or if one or more third-party diagnostic services providers are unable to obtain FDA approval of the genetic test at all or in parallel with the approval of Gencaro, or are unable to commercialize the test successfully and in a manner that effectively supports the commercial efforts for Gencaro, or if the information concerning the differential response to Gencaro resulting from certain genetic variation is not included in the approval label for Gencaro, the commercial launch of Gencaro may be significantly and adversely affected.

Regulatory approval is required for the genetic test to be used in our Gencaro clinical trials and to support the commercialization of the test, if approved. Delays or failures in obtaining such regulatory approval, including any required validation analyses may prevent a third-party diagnostics provider from commercializing such genetic test and will adversely affect our business, operating results and prospects.

Before a genetic test can be used commercially, including in conjunction with Gencaro, if it is approved for marketing, the third-party diagnostics provider must obtain FDA Premarket Approval, or PMA, for such test. The FDA may require additional validation of the genetic test we used in GENETIC-AF prior to any approval of Gencaro or the genetic test or prior to the use of such test in any future clinical trials for Gencaro. We anticipate the genetic test will be required as a condition to prescribing Gencaro. There is no guarantee the FDA will approve the anticipated PMA submission for the genetic test. Even if the genetic test is eventually approved, performing additional validation work necessary to support the PMA, if required, for current or future genetic test products, including one associated with Gencaro, would require additional time and expense and the outcome would be uncertain. Moreover, such delays or increased costs or failures could adversely affect our business, operating results and prospects for commercializing the genetic test.

If a third-party diagnostics provider responsible for the genetic test associated with Gencaro or certain of its third-party suppliers fails to comply with ongoing FDA or other foreign regulatory authority requirements, or if there are unanticipated problems with the genetic test, these products could be subject to restrictions or withdrawal from use in a trial or from the market.

Any diagnostic for which a third-party diagnostics provider obtains clearance or approval, and the manufacturing processes, reporting requirements, post-approval clinical data and promotional activities for such product, will be subject to continued regulatory review, oversight and periodic inspections by the FDA and other domestic and foreign regulatory bodies. With respect to the genetic test, to the extent applicable, any third-party diagnostics provider and certain of its suppliers will be required to comply with the FDA's Quality System Regulation, or QSR, and International Standards Organization, or ISO, requirements which cover the methods and documentation of the design, testing, production, control, quality assurance, labeling, packaging, storage and shipping of any product for which clearance or approval is obtained. Regulatory bodies, such as the FDA, enforce the QSR and other regulations through periodic inspections. The failure by a third-party diagnostics provider, or certain of its third-party manufacturers or suppliers, as the case may be, to comply with applicable statutes and regulations administered by the FDA and other regulatory bodies, or the failure to timely and adequately respond to any adverse inspectional observations or product safety issues, could result in, among other things, enforcement actions. If any of these actions were to occur, it could harm our reputation and cause product sales and profitability of Gencaro, if approved, to suffer and may prevent us from generating revenue or utilizing the genetic test further in any clinical trial. Even if regulatory clearance or approval is granted, such clearance or approval may be subject to limitations on the intended uses for which the product may be marketed and reduce our potential to successfully commercialize the product and generate revenue from the product.

---

# Page 27

# Future sales of Gencaro may suffer if its marketplace acceptance is negatively affected by the genetic test.

The genetic test is an important component of the commercial strategy for Gencaro in addition to being required for our clinical trials. We believe that the genetic test helps predict patient response to Gencaro, and that this aspect of the drug is important to its ability to compete effectively with current therapies. The genetic test adds an additional step in the prescribing process, an additional cost for the patient and payors, the risk that the test results may not be rapidly available and the possibility that it may not be available at all to hospitals and medical centers. Although we anticipate that Gencaro, if approved in a timely manner, would be the first geneticallytargeted cardiovascular drug, Gencaro will be one of a number of successful drugs in the beta-blocker class currently on the market. Prescribers may be more familiar with these other beta-blockers, and may be resistant to prescribing Gencaro as an AF therapy in patients with HF. For instance, the top-line results of our Phase 2B GENETIC-AF clinical trial indicated that Gencaro demonstrated a similar treatment benefit compared to the active comparator, metoprolol succinate (TOPROL-XL). If our future clinical trials in Gencaro do not show that Gencaro has a clear therapeutic benefit as compared to other drugs in the beta-blocker class currently on the market, then prescribers may be unlikely to prescribe Gencaro to patients, even if approved. Any one of these factors could affect prescriber behavior, which in turn may substantially impede market acceptance of the genetic test, which could cause significant harm to Gencaro's ability to compete, and in turn harm our business.


## Unless we are able to generate sufficient product revenue, we will continue to incur losses from operations and will not achieve or maintain profitability. We are years away from commercializing a product and generating product revenue.

Our historical losses have had and will continue to have an adverse effect on our stockholders' equity and working capital, among other things. We are years away from commercializing a product and generating any product revenue. As a result, we expect to continue to incur significant operating losses for the foreseeable future. Even if we ultimately receive regulatory approval for Gencaro, rNAPc2 or our other product candidates, sales of such products may not generate sufficient revenue for it to achieve or maintain profitability. Because of the numerous risks and uncertainties associated with developing therapeutic drugs, we may experience larger than expected future losses and may never reach profitability.


## Our product candidates are subject to extensive regulation, which can be costly and time-consuming, and unsuccessful or delayed regulatory approvals could increase our future development costs or impair our future revenue.

The preclinical and clinical development, testing, manufacture, safety, efficacy, labeling, storage, recordkeeping, and subsequent advertising, promotion, sale, marketing, and distribution, if approved, of our product candidates are subject to extensive regulation by the FDA and other regulatory authorities in the United States and elsewhere. These regulations also vary in important, meaningful ways from country to country. We are not permitted to market a potential drug in the United States until we receive approval of an NDA from the FDA for such drug. We have not received an NDA approval from the FDA for Gencaro, rNAPc2 or any of our other product candidates. There can be no guarantees with respect to our product candidates that clinical studies will adequately support an NDA, that the products will receive necessary regulatory approvals, or that they will prove to be commercially successful.

To receive regulatory approval for the commercial sale of any product candidates, we must demonstrate safety and efficacy in humans to the satisfaction of regulatory authorities through preclinical studies and adequate and well-controlled clinical trials of the product candidates. This process is expensive and can take many years, and failure can occur at any stage of the testing. Our failure to adequately demonstrate the safety and efficacy of our product candidates will prevent regulatory approval and commercialization of such products.

In 2008, we submitted and the FDA accepted our NDA filing for Gencaro for the treatment of chronic HF. In 2009, the FDA issued a Complete Response Letter, or CRL, in which the FDA stated that it could not approve the Gencaro NDA in its current form and specified actions required for approval of the NDA, including conducting an additional Phase 3 clinical trial of Gencaro in patients with HF. We completed a Phase 2B clinical study of Gencaro in HF patients to assess its efficacy in reducing or preventing AF. We enrolled 267 HF patients with AF in the Phase 2B clinical trial. We reported top-line Phase 2B data in February 2018. In the third quarter of 2018, we submitted a SPA to the FDA for a Phase 3 clinical trial. In 2019, the FDA approved our SPA request for a Phase 3 clinical trial of Gencaro. Even though the FDA approved our SPA, this product candidate will require years of additional clinical development. Even if we conduct additional studies in accordance with our SPA agreement or further FDA guidance and submit or file a new or amended NDA, the FDA may ultimately decide that the NDA does not satisfy the criteria for approval.

---

# Page 28

In the event that we or our collaborators conduct preclinical studies that do not comply with Good Laboratory Practices, or GLP, or incorrectly design or carry out human clinical trials in accordance with Good Clinical Practices, or GCP, or those clinical trials fail to demonstrate clinical significance, it is unlikely that we will be able to obtain FDA approval for product development candidates. Our inability to successfully initiate and effectively complete clinical trials for any product candidate on schedule, or at all, will severely harm our business. Significant delays in clinical development could materially increase product development costs or allow our competitors to bring products to market before we do, impairing our ability to effectively commercialize any future product candidate. We do not know whether planned clinical trials will begin on time, will need to be redesigned or will be completed on schedule, if at all. Clinical trials can be delayed for a variety of reasons, including:
- · delays or failures in obtaining regulatory authorization to commence a trial because of safety concerns of regulators relating to our product candidates or similar product candidates of our competitors or failure to follow regulatory guidelines;
- · delays or failures in obtaining clinical materials and manufacturing sufficient quantities of the product candidates for use in trials;
- · failure of clinical materials to meet pre-established specifications at product release or during ongoing stability studies;
- · delays or failures in reaching agreement on acceptable terms with prospective study sites;
- · delays or failures in obtaining approval of our clinical trial protocol from an institutional review board to conduct a clinical trial at a prospective study site;
- · delays in recruiting patients to participate in a clinical trial, which may be due to the size of the patient population, eligibility criteria, protocol design, perceived risks and benefits of the drug, availability of other approved and standard of care therapies or, availability of clinical trial sites;
- · other clinical trials seeking to enroll subjects with similar profile;
- · failure of our clinical trials and clinical investigators to be in compliance with GCP;
- · unforeseen safety issues, including negative results from ongoing preclinical studies;
- · inability to monitor patients adequately during or after treatment;
- · difficulty recruiting and monitoring multiple study sites;
- · failure of our third-party contract research organizations, clinical site organizations and other clinical trial managers, to satisfy their contractual duties, comply with regulations or meet expected deadlines; and
- · an insufficient number of patients who have, or are willing to have, a Medtronic device implanted for monitoring and recording AF burden data.


In addition, any approvals we may obtain may not cover all of the clinical indications for which we seek approval or permit us to make claims of superiority over currently marketed competitive products. Also, an approval might contain significant limitations in the form of narrow indications, warnings, precautions or contraindications with respect to conditions of use. If the FDA determines that a risk evaluation and mitigation strategy, or REMS, is necessary to ensure that the benefits of the drug outweigh the risks, we may be required to include as part of the NDA a proposed REMS that may include a package insert directed to patients, a plan for communication with healthcare providers, restrictions on a drug's distribution, or a Medication Guide, to provide better information to consumers about the drug's risks and benefits. Finally, an approval could be conditioned on our commitment to conduct further clinical trials, which we may not have the resources to conduct or which may negatively impact our financial situation.

The manufacture and analytical testing of Gencaro and rNAPc2 is performed by third party suppliers, who must also meet cGMP requirements and pass a pre-approval inspection of their facilities before we can obtain marketing approval.

---

# Page 29

All of our product candidates are prone to the risks of failure inherent in drug development. The results from preclinical animal testing and early human clinical trials may not be predictive of results obtained in later human clinical trials. Further, although a new product may show promising results in preclinical or early human clinical trials, it may subsequently prove unfeasible or impossible to generate sufficient safety and efficacy data to obtain necessary regulatory approvals. The data obtained from preclinical and clinical studies are susceptible to varying interpretations that may delay, limit or prevent regulatory approval, and the FDA and other regulatory authorities in the United States and elsewhere exercise substantial discretion in the drug approval process. The numbers, size and design of preclinical studies and clinical trials that will be required for FDA or other regulatory approval will vary depending on the product candidate, the disease or condition for which the product candidate is intended to be used and the regulations and guidance documents applicable to any particular product candidate. The FDA or other regulators can delay, limit or deny approval of any product candidate for many reasons, including, but not limited to:
- · side effects;
- · safety and efficacy;
- · defects in the design of clinical trials;
- · the fact that the FDA or other regulatory officials may not approve our or our third party manufacturer's processes or facilities; or
- · the fact that new regulations may be enacted by the FDA or other regulators may change their approval policies or adopt new regulations requiring new or different evidence of safety and efficacy for the intended use of a product candidate.


In light of widely publicized events concerning the safety of certain drug products, regulatory authorities, members of Congress, the Government Accountability Office, medical professionals and the general public have raised concerns about potential drug safety issues. These events have resulted in the withdrawal of certain drug products, revisions to certain drug labeling that further limit use of the drug products and establishment of risk management programs that may, for instance, restrict distribution of drug products. The increased attention to drug safety issues may result in a more cautious approach by the FDA to clinical trials and approval. Data from clinical trials may receive greater scrutiny with respect to safety and the product's risk/benefit profile, which may make the FDA or other regulatory authorities more likely to terminate clinical trials before completion, or require longer or additional clinical trials that may result in substantial additional expense, and a delay or failure in obtaining approval or approval for a more limited indication than originally sought. Aside from issues concerning the quality and sufficiency of submitted preclinical and clinical data, the FDA may be constrained by limited resources from reviewing and determining the approvability of the Gencaro NDA in a timely manner.

In pursuing clinical development of Gencaro for an AF indication, we will be required to amend the Gencaro HF NDA or prepare a new NDA. The FDA could approve Gencaro, but without including some or all of the prescribing information that we have requested. For instance, the FDA could approve Gencaro for AF in a more limited patient population or include additional warnings in the drug's label. This, in turn, could substantially and detrimentally impact our ability to successfully commercialize Gencaro and effectively protect our intellectual property rights in Gencaro.


## If our product candidates receive regulatory approval, we would be subject to ongoing regulatory obligations and restrictions, which may result in significant expenses and limit our ability to develop and commercialize other potential products.

If a product candidate of ours is approved by the FDA or by another regulatory authority, we would be held to extensive regulatory requirements over product manufacturing, testing, distribution, labeling, packaging, adverse event reporting and other reporting to regulatory authorities, storage, advertising, marketing, promotion, distribution, and record keeping. Regulatory approvals may also be subject to significant limitations on the indicated uses or marketing of the product candidates. Potentially costly follow-up or postmarketing clinical studies may be required as a condition of approval to further substantiate safety or efficacy, or to investigate specific issues of interest to the regulatory authority. Previously unknown problems with the product candidate, including adverse events of unanticipated severity or frequency, may result in additional regulatory controls or restrictions on the marketing or use of the product or the need for post marketing studies, and could include suspension or withdrawal of the products from the market.

Furthermore, our third-party manufacturers and the manufacturing facilities that they use to make our product candidates are regulated by the FDA. Quality control and manufacturing procedures must continue to conform to cGMP after approval. Drug manufacturers and their subcontractors are required to register their facilities and products manufactured annually with the FDA and certain state agencies and are subject to periodic unannounced inspections by the FDA, state and/or other foreign authorities. Any subsequent discovery of problems with a product, or a manufacturing or laboratory facility used by us or our collaborators, may result in restrictions on the product, or on the manufacturing or laboratory facility, including a withdrawal of the drug from the market or suspension of manufacturing. Any changes to an approved product, including the way it is manufactured or promoted, often require FDA approval before the product, as modified, can be marketed. We and our third-party manufacturers will also be subject to ongoing FDA requirements for submission of safety and other post-market information.

---

# Page 30

The marketing and advertising of our drug products by our collaborators or us will be regulated by the FDA, certain state agencies or foreign regulatory authorities. Violations of these laws and regulations, including promotion of our products for unapproved uses or failing to disclose risk information, are punishable by criminal and civil sanctions and may result in the issuance of enforcement letters or other enforcement action by the FDA, U.S. Department of Justice, state agencies, or foreign regulatory authorities that could jeopardize our ability to market the product.

In addition to the FDA, state or foreign regulations, the marketing of our drug products by us or our collaborators will be regulated by federal, state or foreign laws pertaining to health care 'fraud and abuse,' such as the federal anti-kickback law prohibiting bribes, kickbacks or other remuneration for the order or recommendation of items or services reimbursed by federal health care programs. Many states have similar laws applicable to items or services reimbursed by commercial insurers. Violations of these laws are punishable by criminal and civil sanctions, including, in some instances, imprisonment and exclusion from participation in federal and state health care programs, including the Medicare, Medicaid and Veterans Affairs healthcare programs. Because of the far-reaching nature of these laws, we may be required to discontinue one or more of our practices to be in compliance with these laws. Healthcare fraud and abuse regulations are complex, and even minor irregularities can potentially give rise to claims that a statute or prohibition has been violated. Any violations of these laws, or any action against us for violations of these laws, even if we successfully defend against it, could have a material adverse effect on our business, financial condition and results of operations.

We could also become subject to false claims litigation under federal statutes, which can lead to civil money penalties, restitution, criminal fines and imprisonment, and exclusion from participation in Medicare, Medicaid and other federal and state health care programs. These false claims statutes include the False Claims Act, which allows any person to bring a suit on behalf of the federal government alleging submission of false or fraudulent claims, or causing to present such false or fraudulent claims, under federal programs or contracts claims or other violations of the statute and to share in any amounts paid by the entity to the government in fines or settlement. These suits against pharmaceutical companies have increased significantly in volume and breadth in recent years. Some of these suits have been brought on the basis of certain sales practices promoting drug products for unapproved uses. This new growth in litigation has increased the risk that a pharmaceutical company will have to defend a false claim action, pay fines or restitution, or be excluded from the Medicare, Medicaid, Veterans Affairs and other federal and state healthcare programs as a result of an investigation arising out of such action. We may become subject to such litigation and, if we are not successful in defending against such actions, those actions may have a material adverse effect on our business, financial condition and results of operations. We could also become subject to false claims litigation and consumer protection claims under state statutes, which also could lead to civil monetary penalties, restitution, criminal fines and imprisonment, and exclusion from participation in state health care programs. Of note, over the past few years there has been an increased focus on the sales and marketing practices of the pharmaceutical industry at both the federal and state level. Additionally, the law or regulatory policies governing pharmaceuticals may change. New statutory requirements may be enacted or additional regulations may be adopted that could prevent or delay regulatory approval of our product candidates or limit our ability to commercialize our products. We cannot predict the likelihood, nature or extent of adverse government regulation that may arise from future legislation or administrative action, either in the United States or elsewhere.


If we, our collaborators or our third-party manufacturers fail to comply with applicable continuing regulatory requirements, our business could be seriously harmed because a regulatory agency may:
- · issue untitled or warning letters;
- · suspend or withdraw our regulatory approval for approved products;
- · seize or detain products or recommend a product recall of a drug or medical device, or issue a mandatory recall of a medical device;
- · refuse to approve pending applications or supplements to approved applications filed by us;
- · suspend our ongoing clinical trials;
- · restrict our operations, including costly new manufacturing requirements, or restrict the sale, marketing and/or distribution of our products;
- · seek an injunction;
- · pursue criminal prosecutions;
- · close the facilities of our contract manufacturers; or
- · impose civil or criminal penalties.

---

# Page 31

# Reliance on third parties to commercialize Gencaro, rNAPc2 or our other product candidates could negatively impact our business. If we are required to establish a direct sales force in the United States and are unable to do so, our business may be harmed.

Commercialization of Gencaro, rNAPc2 or any other product candidate, if approved, particularly the establishment of a sales organization, will require substantial additional capital resources. We currently intend to pursue a strategic partnership alternative for the commercialization of Gencaro or rNAPc2, if it is approved, and we have suspended our efforts to build internal sales, marketing and distribution capabilities. If we elect to rely on third parties to sell Gencaro, rNAPc2 and any other products, then we may receive less revenue than if we sold such products directly. In addition, we may have little or no control over the sales efforts of those third parties. If we are unable to complete a strategic transaction, we would be unable to commercialize Gencaro, rNAPc2 or any other product candidate without substantial additional capital. Even if such capital were secured, we would be required to build internal sales, marketing and distribution capabilities to market Gencaro or rNAPc2 in the United States. None of our current employees have experience in establishing and managing a sales force.

In the event we are unable to sell Gencaro, rNAPc2 and other selected product candidates, either directly or through third parties via a strategic transaction, the commercialization of Gencaro or rNAPc2, if approved, may be delayed indefinitely.


## We are dependent on our key personnel.

The success of our business is highly dependent on the principal members of our board of directors and executive management, including our President and Chief Executive Officer, Michael R. Bristow. The loss of the services of any such individual might seriously harm our product development, partnering and financing efforts. Recruiting and training personnel with the requisite skills is challenging and we compete for talent with companies that are larger and have more financial resources.


## We have no manufacturing capacity which puts us at risk of lengthy and costly delays of bringing our products to market.


We do not currently operate manufacturing facilities for clinical or commercial production of our product candidates, including their drug substance or active pharmaceutical ingredients, or API. We have no experience in drug formulation or manufacturing, and we lack the resources and the capabilities to manufacture any of our product candidates on a clinical or commercial scale. We do not intend to develop facilities for the manufacture of product candidates for clinical trials or commercial purposes in the foreseeable future. We have contracted with several third-party manufacturing organizations for production and analytical testing of our product candidates. These contract manufacturers may not perform as agreed or may not remain in the contract manufacturing business for the time required to successfully produce, store and distribute our products. In addition, these manufacturers may have staffing difficulties, may experience delays due to key material or component availability, may not be able to manufacture our products on a timely basis or may become financially distressed. In the event of errors in forecasting production quantities required to meet demand, natural disaster, equipment malfunctions or failures, technology malfunctions, strikes, lock-outs or work stoppages, regional power outages, product tampering, war or terrorist activities, actions of regulatory authorities, business failure, strike or other difficulty, we may be unable to find an alternative third-party manufacturer in a timely manner and the production of our product candidates would be interrupted, resulting in delays and additional costs, which could impact our ability to commercialize and sell our product candidates. We or our contract manufacturers may also fail to achieve and maintain required manufacturing standards, which could result in patient injury or death, product recalls or withdrawals, an order by governmental authorities to halt production, delays or failures in product testing or delivery, stability testing failures, cost overruns or other problems that could seriously hurt our business. Contract manufacturers also often encounter difficulties involving production yields, quality control and quality assurance, as well as shortages of qualified personnel. In addition, our contract manufacturers are subject to ongoing inspections and regulation by the FDA, the U.S. Drug Enforcement Agency and corresponding foreign and state agencies and they may fail to meet these agencies' acceptable standards of compliance. If our contract manufacturers fail to comply with applicable governmental regulations, such as quality control, quality assurance and the maintenance of records and documentation, we may not be able to continue production of the API or finished product. If the safety of any API or product supplied is compromised due to failure to adhere to applicable laws or for other reasons, this may jeopardize our regulatory approval for Gencaro, rNAPc2 and other product candidates, and we may be held liable for any injuries sustained as a result. Upon the occurrence of one of the aforementioned events, the ability to switch manufacturers may be difficult for a number of reasons, including:
- · the number of potential manufacturers is limited and we may not be able to negotiate agreements with alternative manufacturers on commercially reasonable terms, if at all;
- · long lead times are often needed to manufacture drugs;
- · the manufacturing process is complex and may require a significant learning curve; and
- · the FDA must approve any replacement prior to manufacturing, which requires new testing and compliance inspections.

---

# Page 32

Transitioning from a clinical development stage company will require successful completion of a number of steps, many of which are outside of our control and, consequently, we can provide no assurance of our successful and timely transition from a clinical development stage company.


We are a clinical development stage biopharmaceutical company with a limited operating history. To date we have not generated any product revenue and have historically funded our operations through investment capital. Our future growth depends on our ability to emerge from the clinical development stage and successfully commercialize or provide for the commercialization of Gencaro, rNAPc2 and our other product candidates which in turn, will depend, among other things, on our ability to:
- · conduct additional clinical trials and develop and obtain regulatory approval for Gencaro, rNAPc2 or other product candidates;
- · successfully partner a companion genetic test with the commercial launch of Gencaro or rNAPc2;
- · enter into a strategic transaction enabling the continued development and commercialization of Gencaro or rNAPc2, or alternatively, raise significant additional capital to enable these activities;
- · pursue additional indications for Gencaro or rNAPc2 and develop other product candidates, including other cardiovascular therapies; and
- · obtain commercial quantities of Gencaro, rNAPc2 or other product candidates at acceptable cost levels.


Any one of these factors or other factors discussed in this report could affect our ability to successfully commercialize Gencaro and other product candidates, which could impact our ability to earn sufficient revenues to transition from a clinical development stage company and continue our business.


## If approved by the FDA, Gencaro or rNAPc2 will be entering a competitive marketplace and may not succeed.

Gencaro is a new type of beta-blocker and vasodilator being developed for AF. While we anticipate that this drug, if approved, would be the first genetically-targeted cardiovascular drug, and potentially the only beta-blocker approved for AF, Gencaro will be one of a number of accepted treatments for AF. In addition, our proposed prescribing information for Gencaro is expected to include a requirement for genetic testing of the patient to ascertain if they have the genotype that we believe responds best to Gencaro. This additional step will add incremental cost and procedures to prescribing Gencaro, which could make it more difficult to compete against existing therapies.

We do not yet know what the commercial opportunity will be, if any, for rNAPc2 if it is approved for treating COVID-19 disease. We do not know how and to whom rNAPc2 would be marketed and what the commercial arrangements would be for its sales and reimbursement. While we anticipate that rNAPc2, if approved, could potentially be used in combination with antiviral drugs and other therapies, there are other vaccines and therapies under development.

Our commercial opportunity may be reduced or eliminated if competitors develop and commercialize products that are safer, more effective, have fewer side effects, are more convenient or are less expensive than Gencaro. If products with any of these properties are developed, or any of the existing products are better marketed, then prescriptions of Gencaro by physicians and patient use of Gencaro could be significantly reduced or rendered obsolete and noncompetitive. Further, public announcements regarding the development of any such competing drugs could adversely affect the market price of our common stock and the value of our assets.


## Future sales of our products may suffer if they are not accepted in the marketplace by physicians, patients and the medical community.

Gencaro, rNAPc2 or our other product candidates may not gain market acceptance among physicians, patients and the medical community. The degree of market acceptance of Gencaro, rNAPc2 or our other product candidates will depend on a number of factors, such as its effectiveness and tolerability, as compared with competitive drugs. For instance, if rNAPc2 is approved, by that time there may be superior alternatives in terms of vaccines and/or therapeutics that may significantly impact the relative medical benefits offered by rNAPc2. If our future clinical trials for rNAPc2 do not show that rNAPc2 has a clear therapeutic benefit as compared to other therapies or vaccines that are approved in the interim, then there may be a limited or no commercial market for rNAPc2. Also, prevalence and severity of side-effects could negatively affect market acceptance of rNAPc2. Failure to achieve market acceptance of  Gencaro or rNAPc2 would significantly harm our business.

If we are unable to obtain acceptable prices or adequate reimbursement from third-party payors for Gencaro, rNAPc2, or any other product candidates that we may seek to commercialize, then our revenues and prospects for profitability will suffer.

---

# Page 33

Our or any strategic partner's ability to commercialize Gencaro, rNAPc2, or any other product candidates that we may seek to commercialize, is highly dependent on the extent to which coverage and reimbursement for these product candidates will be available from:
- · governmental payors, such as Medicare and Medicaid;
- · private health insurers, including managed-care organizations; and
- · other third-party payors.


Many patients will not be capable of paying for our potential products themselves and will rely on third-party payors to pay for their medical needs. A primary current trend in the U.S. health care industry is toward cost containment. Large private payors, managedcare organizations, group purchasing organizations and similar organizations are exerting increasing influence on decisions regarding the use of, and reimbursement levels for, particular treatments. Such third-party payors, including Medicare, are challenging the prices charged for medical products and services, and many third-party payors limit reimbursement for newly approved health care products.

Cost-control initiatives could decrease the price we might establish for products, which could result in product revenues lower than anticipated. If the prices for our product candidates decrease, or if governmental and other third-party payors do not provide adequate coverage and reimbursement levels, then our revenue and prospects for profitability will suffer.


## Health care reform measures could materially and adversely affect our business.

The business and financial condition of pharmaceutical and biotechnology companies are affected by the efforts of governmental and third-party payors to contain or reduce the costs of health care. The U.S. Congress has enacted legislation to reform the health care system. While we anticipate that this legislation may, over time, increase the number of patients who have insurance coverage for pharmaceutical products, it also imposes cost containment measures that may adversely affect the amount of reimbursement for pharmaceutical products. These measures include increasing the minimum rebates for products covered by Medicaid programs and extending such rebates to drugs dispensed to Medicaid beneficiaries enrolled in Medicaid managed care organizations as well as expansion of the 340(B) Public Health Services drug discount program. In addition, such legislation contains a number of provisions designed to generate the revenues necessary to fund the coverage expansion, including new fees or taxes on certain health-related industries, including medical device manufacturers. Each medical device manufacturer has to pay an excise tax (or sales tax) in an amount equal to 2.3% of the price for which such manufacturer sells its medical devices. Such excise taxes may impact any potential sales of the genetic test if it is approved for marketing. On January 22, 2018, legislation was enacted suspending the medical device tax in 2018 and 2019. In December 2019, a permanent repeal of the medical device tax was enacted. The Gencaro Test is likely to be subject to this tax if this tax is reinstated in the future. In foreign jurisdictions there have been, and we expect that there will continue to be, a number of legislative and regulatory proposals aimed at changing the health care system. For example, in some countries other than the United States, pricing of prescription drugs is subject to government control and we expect to see continued efforts to reduce healthcare costs in international markets.

Some states are also considering legislation that would control the prices of drugs, and state Medicaid programs are increasingly requesting manufacturers to pay supplemental rebates and requiring prior authorization by the state program for use of any drug for which supplemental rebates are not being paid. Managed care organizations continue to seek price discounts and, in some cases, to impose restrictions on the coverage of particular drugs. Government efforts to reduce Medicaid expenses may lead to increased use of managed care organizations by Medicaid programs. This may result in managed care organizations influencing prescription decisions for a larger segment of the population and a corresponding constraint on prices and reimbursement for drugs. It is likely that federal and state legislatures and health agencies will continue to focus on additional health care reform in the future although we are unable to predict what additional legislation or regulation, if any, relating to the health care industry or third-party coverage and reimbursement may be enacted in the future or what effect such legislation or regulation would have on our business. We or any strategic partner's ability to commercialize Gencaro, rNAPc2, or any other product candidates that we may seek to commercialize, is highly dependent on the extent to which coverage and reimbursement for these product candidates will be available from government payors, such as Medicare and Medicaid, private health insurers, including managed care organizations, and other third-party payors, and any change in reimbursement levels could materially and adversely affect our business. Further, the pendency or approval of future proposals or reforms could result in a decrease in our stock price or limit our ability to raise capital or to obtain strategic partnerships or licenses.

---

# Page 34

# Our competitors may be better positioned in the marketplace and thereby may be more successful than us at developing, manufacturing and marketing approved products.


Many of our competitors currently have significantly greater financial resources and expertise in conducting clinical trials, obtaining regulatory approvals, managing manufacturing and marketing approved products than us. Other early-stage companies may also prove to be significant competitors, particularly through collaborative arrangements with large and established companies. In addition, these third parties compete with us in recruiting and retaining qualified scientific and management personnel, establishing clinical trial sites and patient registration for clinical trials, as well as in acquiring therapies and therapy licenses complementary to our programs or advantageous to our business. We expect that our ability to compete effectively will depend upon our ability to:
- · successfully and rapidly complete clinical trials for any product candidates and obtain all requisite regulatory approvals in a cost-effective manner;
- · build an adequate sales and marketing infrastructure, raise additional funding, or enter into strategic transactions enabling the commercialization of our products;
- · develop competitive formulations of our product candidates;
- · attract and retain key personnel; and
- · identify and obtain other product candidates on commercially reasonable terms.



## If we fail to identify and license or acquire other products or product candidates, then we may be unable to expand our business, and the acquisition or licensing of other products or product candidates may put a strain on our operations and will likely require us to seek additional financing.

One of our strategies is to license or acquire clinical-stage products or product candidates and further develop them for commercialization. The market for licensing and acquiring products and product candidates is intensely competitive and many of our competitors may have greater resources than we do. If we undertake any additional acquisitions, whether of product candidates or other biopharmaceutical companies, the process of integrating an acquired product candidate or complementary company into our business may put a strain on our operations, divert personnel, financial resources and management's attention. In 2020, our research and development activities were dedicated to initiating the clinical trial of rNAPc2. If we are not able to substantially expand our research and development efforts, or identify, or license or acquire other products or product candidates or complete future acquisitions, then we will likely be unable expand our pipeline of product candidates. In addition, any future acquisition would give rise to additional operating costs and will likely require us to seek additional financing. Future acquisitions could result in additional issuances of equity securities that would dilute the ownership of existing stockholders. Future acquisitions could also result in the incurrence of debt, contingent liabilities or the amortization of expenses related to other intangible assets, any of which could adversely affect our operating results.


## We would be subject to applicable regulatory approval requirements of the foreign countries in which we market our products, which are costly and may prevent or delay us from marketing our products in those countries.

In addition to regulatory requirements in the United States, we would be subject to the regulatory approval requirements in each foreign country where we market our products. In addition, we might be required to identify one or more collaborators in these foreign countries to develop, seek approval for and manufacture our products and any companion genetic test for Gencaro. If we decide to pursue regulatory approvals and commercialization of our product candidates internationally, we may not be able to obtain the required foreign regulatory approvals on a timely basis, if at all, and any failure to do so may cause us to incur additional costs or prevent us from marketing our products in foreign countries, which may have a material adverse effect on our business, financial condition and results of operations.


## If our internal control over financial reporting is not considered effective, our business and stock price could be adversely affected.

Section 404 of the Sarbanes-Oxley Act of 2002 requires us to evaluate the effectiveness of our internal control over financial reporting as of the end of each fiscal year, and to include a management report assessing the effectiveness of our internal control over financial reporting in our annual report on Form 10-K for that fiscal year. Our management, including our principal executive officer and principal financial officer, does not expect that our internal control over financial reporting will prevent all error and all fraud. We continue to operate with a small staff for financial reporting. Though the process and design of our internal controls over financial reporting have not been altered, the small number of staff involved in financial reporting may limit our ability to properly segregate internal control procedures which could result in deficiencies or material weaknesses in our internal controls in the future. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system's objectives will be met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud involving a company have been, or will be, detected. The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and we cannot assure you that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls

---

# Page 35

may become ineffective because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected. We cannot assure you that we or our independent registered public accounting firm will not identify a material weakness in our internal control over financial reporting in the future. A material weakness in our internal control over financial reporting would require management to consider our internal control over financial reporting as ineffective. If our internal control over financial reporting is not considered effective, we may experience a loss of public confidence, which could have an adverse effect on our business and on the market price of our common stock.


# Changes in tax laws or regulations that are applied adversely to us or our customers may have a material adverse effect on our business, cash flow, financial condition or results of operations.

New income, sales, use or other tax laws, statutes, rules, regulations or ordinances could be enacted at any time, which could affect the tax treatment of our domestic and foreign earnings. Any new taxes could adversely affect our domestic and international business operations, and our business and financial performance. Further, existing tax laws, statutes, rules, regulations or ordinances could be interpreted, changed, modified or applied adversely to us. For example, legislation enacted in 2017, informally titled the Tax Cuts and Jobs Act, significantly revised the Internal Revenue Code of 1986, as amended, or the Code. Future guidance from the Internal Revenue Service and other tax authorities with respect to the Tax Cuts and Jobs Act may affect us, and certain aspects of the Tax Cuts and Jobs Act could be repealed or modified in future legislation. In addition, it is uncertain if and to what extent various states will conform to the Tax Cuts and Jobs Act or any newly enacted federal tax legislation. Changes in corporate tax rates, the realization of net deferred tax assets relating to our operations, the taxation of foreign earnings, and the deductibility of expenses under the Tax Cuts and Jobs Act or future reform legislation could have a material impact on the value of our deferred tax assets, could result in significant one-time charges, and could increase our future U.S. tax expense.


## Our ability to use our net operating losses to offset future taxable income may be subject to certain limitations.

As of December 31, 2022, we had net operating loss, or NOL, carryforwards of approximately $203.3 million, and approximately $2.4 million of research and development credits that may be used to offset future taxable income. Our net operating loss carryforwards generated prior to 2018 will expire beginning in 2025 if not utilized. Under the Tax Cuts and Jobs Act, U.S. federal NOLs incurred in tax years ending after December 31, 2017, may be carried forward indefinitely, but the deductibility of federal NOLs generated in tax years beginning after December 31, 2017, may be limited. In general, under Section 382 of the Code, a corporation that undergoes an 'ownership change' (as defined under Section 382 of the Code and applicable Treasury Regulations) is subject to limitations on its ability to utilize its pre-change NOLs to offset future taxable income. We have not determined whether we have experienced an ownership change in the past, and we may experience ownership changes in the future as a result of subsequent shifts in our stock ownership, some of which may be outside of our control. There is also a risk that due to regulatory changes, such as suspensions on the use of NOLs or other unforeseen reasons, our existing NOLs could expire or otherwise be unavailable to reduce future income tax liabilities, including for state tax purposes. For these reasons, we may not be able to utilize a material portion of the NOLs reflected on our balance sheet, even if we attain profitability, which could potentially result in increased future tax liability to us and could adversely affect our operating results and financial condition.


## Security breaches, cyber-attacks, or other disruptions or incidents could expose us to liability and affect our business and reputation.

We are increasingly dependent on our information technology systems and infrastructure for our business. We, our collaborators and our service providers collect, store, and transmit sensitive information including intellectual property, proprietary business information, clinical trial data and personal information in connection with our business operations. The secure maintenance of this information is critical to our operations and business strategy. Some of this information could be an attractive target of criminal attack by third parties with a wide range of motives and expertise, including organized criminal groups, 'hacktivists,' patient groups, disgruntled current or former employees, nation-state and nation-state supported actors, and others. Cyber-attacks are of everincreasing levels of sophistication, and despite our security measures, our information technology and infrastructure may be vulnerable to such attacks or may be breached, including due to employee error or malfeasance.

We have implemented information security measures to protect our systems, proprietary information and sensitive data against the risk of inappropriate and unauthorized external use and disclosure and other types of compromise. However, despite these measures, and due to the ever changing information cyber-threat landscape, we cannot guarantee that these measures will be adequate to detect, prevent or mitigate security breaches and other incidents and we may be subject to data breaches through cyber-attacks, malicious code (such as viruses and worms), phishing attacks, social engineering schemes, and insider theft or misuse. Any such breach could compromise our networks and the information stored there could be accessed, modified, destroyed, publicly disclosed, lost or stolen. If our systems become compromised, we may not promptly discover the intrusion.

Any security breach of other incident, whether real or perceived, could cause us to suffer reputational damage. Such incidents could result in costs to respond to, investigate and remedy such incidents, notification obligations to affected individuals, government agencies, credit reporting agencies and other third parties, legal claims or proceedings, and liability under our contracts with other parties and federal and state laws that protect the privacy and security of personal information. Any one of these events could cause our business to be materially harmed and our results of operations would be adversely impacted.

---

# Page 36

# Failure to comply with data protection laws and regulations could lead to government enforcement actions (which could include civil or criminal penalties), private litigation, and/or adverse publicity and could negatively affect our operating results and business.

We and our partners may be subject to federal, state, and foreign data protection laws and regulations (i.e., laws and regulations that address privacy and data security). In the United States, numerous federal and state laws and regulations, including state data breach notification laws, state health information privacy laws, and federal and state consumer protection laws and regulations (e.g., Section 5 of the FTC Act), that govern the collection, use, disclosure, and protection of health-related and other personal information could apply to our operations or the operations of our partners. In addition, we may obtain health information from third parties (including research institutions from which we obtain clinical trial data) that are subject to privacy and security requirements under the Health Insurance Portability and Accountability Act of 1996, as amended, or HIPAA. Depending on the facts and circumstances, we could be subject to criminal penalties if we knowingly obtain, use, or disclose individually identifiable health information maintained by a HIPAA-covered entity in a manner that is not authorized or permitted by HIPAA.

In addition, the California Consumer Privacy Act, or the CCPA, became effective on January 1, 2020. The CCPA gives California residents expanded rights to access and delete their personal information, opt out of certain personal information sharing and receive detailed information about how their personal information is used by requiring covered companies to provide new disclosures to California consumers (as that term is broadly defined) and provide such consumers new ways to opt-out of certain sales of personal information. The CCPA provides for civil penalties for violations, as well as a private right of action for data breaches that is expected to increase data breach litigation. Although there are limited exemptions for clinical trial data and the CCPA's implementation standards and enforcement practices are likely to remain uncertain for the foreseeable future, the CCPA may increase our compliance costs and potential liability. Many similar privacy laws have been proposed at the federal level and in other states.

Foreign data protection laws, including, without limitation, the European Union Directive 95/46/EC, or the Directive, and the European Union's General Data Protection Regulation, or the GDPR, that became effective in May 2018, and member state data protection legislation, may also apply to health-related and other personal information obtained outside of the United States. These laws impose strict obligations on the ability to process health-related and other personal information of data subjects in the European Union and the United Kingdom, including in relation to use, collection, analysis, and transfer (including cross-border transfer) of such personal information. These laws include several requirements relating to the consent of the individuals to whom the personal data relates, limitations on data processing, establishing a legal basis for processing, notification of data processing obligations or security incidents to appropriate data protection authorities or data subjects, the security and confidentiality of the personal data and various rights that data subjects may exercise.

The Directive and the GDPR prohibit, without an appropriate legal basis, the transfer of personal data to countries outside of the European Economic Area, or EEA, such as the United States, which are not considered by the European Commission to provide an adequate level of data protection. Switzerland has adopted similar restrictions. Although there are legal mechanisms to allow for the transfer of personal data from the EEA and Switzerland to the United States, uncertainty about compliance with European Union data protection laws remains. For example, ongoing legal challenges in Europe to the mechanisms allowing companies to transfer personal data from the EEA to the United States could result in further limitations on the ability to transfer personal data across borders, particularly if governments are unable or unwilling to reach new or maintain existing agreements that support cross-border data transfers, such as the European Union-U.S. and Swiss-U.S. Privacy Shield framework. Additionally, other countries have passed or are considering passing laws requiring local data residency.

Under the GDPR, regulators may impose substantial fines and penalties for non-compliance. Companies that violate the GDPR can face fines of up to the greater of 20 million Euros or 4% of their worldwide annual turnover (revenue). The GDPR increases our responsibility and potential liability in relation to personal data that we process, and we may be required to put in place additional mechanisms to ensure compliance with the GDPR and other EU and international data protection rules.

Compliance with U.S. and foreign privacy and security laws, rules and regulations could require us to take on more onerous obligations in our contracts, require us to engage in costly compliance exercises, restrict our ability to collect, use and disclose data, or in some cases, impact our or our partners' or suppliers' ability to operate in certain jurisdictions. Each of these constantly evolving laws can be subject to varying interpretations. Failure to comply with U.S. and foreign data protection laws and regulations could result in government investigations and enforcement actions (which could include civil or criminal penalties), fines, private litigation, and/or adverse publicity and could negatively affect our operating results and business. Moreover, patients about whom we or our partners obtain information, as well as the providers who share this information with us, may contractually limit our ability to use and disclose the information. Claims that we have violated individuals' privacy rights, failed to comply with data protection laws, or breached our contractual obligations, even if we are not found liable, could be expensive and time-consuming to defend and could result in adverse publicity that could harm our business.

---

# Page 37

# Risks Related to Intellectual Property and Other Legal Matters


## If product liability lawsuits are successfully brought against us, then we will incur substantial liabilities and may be required to limit commercialization of Gencaro, rNAPc2 or other product candidates.

We face product liability exposure related to the testing of our product candidates in human clinical trials, and may face exposure to claims by an even greater number of persons once we begin marketing and distributing our products commercially. If we cannot successfully defend against product liability claims, then we will incur substantial liabilities.


Regardless of merit or eventual outcome, liability claims may result in:
- · decreased demand for our products and product candidates;
- · injury to our reputation;
- · withdrawal of clinical trial participants;
- · costs of related litigation;
- · substantial monetary awards to patients and others;
- · loss of revenues; and
- · the inability to commercialize our products and product candidates.


We have obtained limited product liability insurance coverage. Such coverage, however, may not be adequate or may not continue to be available to us in sufficient amounts or at an acceptable cost, or at all. We may not be able to obtain commercially reasonable product liability insurance for any product candidate.


## Defending against claims relating to improper handling, storage or disposal of hazardous chemicals, radioactive or biological materials could be time consuming and expensive.

Our research and development of product candidates may involve the controlled use of hazardous materials, including chemicals, radioactive and biological materials. We cannot eliminate the risk of accidental contamination or discharge and any resultant injury from the materials. Various laws and regulations govern the use, manufacture, storage, handling and disposal of hazardous materials. We may be sued or be required to pay fines for any injury or contamination that results from our use or the use by third parties of these materials. Compliance with environmental laws and regulations may be expensive, and current or future environmental regulations may impair our research, development and production efforts.


## The loss of any rights to market key products would significantly impair our operating results.

Our patent portfolios relating to Gencaro, including a patent that issued in 2021, are either owned by us or are subject to licenses that impose no royalty obligations or milestone payments relating to the further development, approval and commercialization of Gencaro.

Termination of our license agreements could result in the loss of our further rights to develop and commercialize Gencaro for any indication. The termination of any such license, or of any other agreement which enables us to market a key product or product candidate, could significantly and adversely affect our business.

Certain intellectual property licensed by us is the subject of additional licensing arrangements to which the party that has licensed rights to us is subject. If such parties were to breach the terms of such licenses or such licenses were otherwise to terminate, our and our partners' rights to use such technology and develop and commercialize their products such as the genetic test may terminate and our business would be materially harmed.


## Third parties may own or control patents or patent applications that we may be required to license to commercialize our product candidates or that could result in litigation that would be costly and time consuming.

Our or any strategic partner's ability to commercialize Gencaro, rNAPc2 and other product candidates depends upon our ability to develop, manufacture, market and sell these drugs without infringing the proprietary rights of third parties. A number of pharmaceutical and biotechnology companies, universities and research institutions have or may be granted patents that cover technologies similar to the technologies owned by or licensed to us. We may choose to seek, or be required to seek, licenses under third party patents, which would likely require the payment of license fees or royalties or both. We may also be unaware of existing patents that may be infringed by Gencaro or rNAPc2, the genetic testing we intend to use in connection with Gencaro or our other product candidates. Because patent applications can take many years to issue, there may be other currently pending applications that may later result in issued patents that are infringed by Gencaro, rNAPc2 or our other product candidates. Moreover, a license may not be available to us on commercially reasonable terms, or at all.

---

# Page 38

There is a substantial amount of litigation involving patent and other intellectual property rights in the biotechnology and biopharmaceutical industries generally. If a third party claims that we are infringing on its technology, then our business and results of operations could be harmed by a number of factors, including:
- · infringement and other intellectual property claims, even if without merit, are expensive and time-consuming to litigate and can divert management's attention from our core business;
- · monetary damage awards for past infringement can be substantial;
- · a court may prohibit us from selling or licensing product candidates unless the patent holder chooses to license the patent to us; and
- · if a license is available from a patent holder, we may have to pay substantial royalties.


We may also be forced to bring an infringement action if we believe that a competitor is infringing our protected intellectual property. Any such litigation will be costly, time-consuming and divert management's attention, and the outcome of any such litigation may not be favorable to us.


## Our intellectual property rights may not preclude competitors from developing competing products and our business may suffer.

Our competitive success will depend, in part, on our ability to obtain and maintain patent protection for our inventions, technologies and discoveries, including intellectual property that we license. The patent positions of biotechnology companies involve complex legal and factual questions, and we cannot be certain that our patents and licenses will successfully preclude others from using our technology. Consequently, we cannot be certain that any of our patents will provide significant market protection or will not be circumvented or challenged and found to be unenforceable or invalid. In some cases, patent applications in the United States and certain other jurisdictions are maintained in secrecy until patents issue, and since publication of discoveries in the scientific or patent literature often lags behind actual discoveries, we cannot be certain of the priority of inventions covered by pending patent applications. Moreover, we may have to participate in interference proceedings declared by the U.S. Patent and Trademark Office to determine priority of invention, in opposition proceedings in a foreign patent office, or in a post-grant challenge proceeding such as an ex parte reexamination or inter partes review at the U.S. Patent and Trademark Office, any of which could result in substantial cost to us, even if the eventual outcome is favorable. There can be no assurance that a court of competent jurisdiction would hold any claims in any issued patent to be valid. An adverse outcome could subject us to significant liabilities to third parties, require disputed rights to be licensed from third parties or require us to cease using such technology.

We own the clinical development program of rNAPc2, including Phase 2b clinical trials. If rNAPc2 is successfully developed, we believe it will have intellectual property protection, including 12 years of market exclusivity as an innovative biologic product under FDA law in the United States, 10 years data protection exclusivity in the EU, and potentially patent protection in addition to this. However, another competitor could develop a compound with similar biological properties to rNAPc2 that may not be barred by our exclusivity. We have also filed a provisional patent application for rNAPc2 and its use for COVID-19 disease, but there is no assurance that this provisional application will ultimately result in an issued patent.

Regardless of merit, the listing of patents in the FDA Orange Book for Gencaro may be challenged as being improperly listed. We may have to defend against such claims and possible associated antitrust issues. We could also incur substantial costs in seeking to enforce our proprietary rights against infringement.

While the composition of matter patents on the compound that comprises Gencaro have expired, we hold the intellectual property concerning the interaction of Gencaro with the polymorphisms of the beta-1 and alpha-2C receptors. We have obtained patents that claim methods involving Gencaro after a patient's receptor genotype has been determined. We anticipate that any NDA for Gencaro will request a label including a claim that efficacy varies based on receptor genotype and a recommendation in the prescribing information that prospective patients be tested for their receptor genotype. We believe that under applicable law, a generic bucindolol label would likely be required to include this recommendation as it pertains directly to the safe or efficacious use of the drug. Such a label may be considered as inducing infringement, carrying the same liability as direct infringement. If the label with the genotype information for Gencaro is not approved, or if generic labels are not required to copy the approved label, competitors could have an easier path to introduce competing products and our business may suffer. The approved label may not contain language covered by the patents, or we may be unsuccessful in enforcing them.

We may not be able to effectively protect our intellectual property rights in some foreign countries, as our patents are limited by jurisdiction and many countries do not offer the same level of legal protection for intellectual property as the United States.

We require our employees, consultants, business partners and members of our scientific advisory board to execute confidentiality agreements upon the commencement of employment, consulting or business relationships with us. These agreements provide that all confidential information developed or made known during the course of the relationship with us be kept confidential and not disclosed to third parties except in specific circumstances. In the case of employees, the agreements provide that all inventions resulting from work performed for us, utilizing the property or relating to our business and conceived or completed by the individual during employment shall be our exclusive property to the extent permitted by applicable law.

---

# Page 39

Third parties may breach these and other agreements with us regarding our intellectual property and we may not have adequate remedies for the breach. Third parties could also fail to take necessary steps to protect our licensed intellectual property, which could seriously harm our intellectual property position.

If we are not able to protect our proprietary technology, trade secrets and know-how, then our competitors may develop competing products. Any issued patent may not be sufficient to prevent others from competing with us. Further, we have trade secrets relating to rNAPc2 and Gencaro, and such trade secrets may become known or independently discovered. Our issued patents and those that may issue in the future, or those licensed to us, may be challenged, opposed, invalidated or circumvented, which could allow competitors to market similar products or limit the patent protection term of our product candidates. All of these factors may affect our competitive position.


# If the manufacture, use or sale of our products infringe on the intellectual property rights of others, we could face costly litigation, which could cause us to pay substantial damages or licensing fees and limit our ability to sell some or all of our products.

Extensive litigation regarding patents and other intellectual property rights has been common in the biopharmaceutical industry. Litigation may be necessary to assert infringement claims, enforce patent rights, protect trade secrets or know-how and determine the enforceability, scope and validity of certain proprietary rights. Litigation may even be necessary to defend disputes of inventorship or ownership of proprietary rights. The defense and prosecution of intellectual property lawsuits, U.S. Patent and Trademark Office interference proceedings, and related legal and administrative proceedings (e.g., a reexamination, inter partes review, or post-grant review) in the United States and internationally involve complex legal and factual questions. As a result, such proceedings are costly and time-consuming to pursue, and their outcome is uncertain.

Regardless of merit or outcome, our involvement in any litigation, interference or other administrative proceedings could cause us to incur substantial expense and could significantly divert the efforts of our technical and management personnel. Any public announcements related to litigation or interference proceedings initiated or threatened against us could cause our stock price to decline. Adverse outcomes in patent litigation may potentially subject us to antitrust litigation which, regardless of the outcome, would adversely affect our business. An adverse determination may subject us to the loss of our proprietary position or to significant liabilities, or require us to seek licenses that may include substantial cost and ongoing royalties. Licenses may not be available from third parties, or may not be obtainable on satisfactory terms. An adverse determination or a failure to obtain necessary licenses may restrict or prevent us from manufacturing and selling our products, if any. These outcomes could materially harm our business, financial condition and results of operations.


## Risks Related to Ownership of our Common Stock and Stock Price Volatility


## Our stock price has been and is expected to be volatile.


Our common stock has in the past been and in the future could be subject to significant fluctuations. Market prices for securities of early-stage pharmaceutical, biotechnology and other life sciences companies have historically been particularly volatile. Some of the factors that may cause the market price of our common stock to fluctuate include:
- · the regulatory status of Gencaro, rNAPc2 and the genetic test, and whether and when they are approved for sale, if at all, and the labeling or other conditions of use imposed by the FDA;
- · our ability to secure additional funding or complete a strategic transaction or to complete development of and commercialize Gencaro or rNAPc2;
- · progress of any future clinical trials for Gencaro, rNAPc2 or our other product candidate, including enrollment and any data that may become available;
- · the results of our future clinical trials and any future NDAs of our current and future product candidates;
- · the entry into, or termination of, key agreements, including key strategic alliance agreements;
- · the results and timing of regulatory reviews relating to our product candidates;
- · failure of any of our product candidates, if approved, to achieve commercial success;
- · general and industry-specific economic conditions that may affect our research and development expenditures;
- · the results of clinical trials conducted by others on drugs that would compete with our product candidates;
- · issues in manufacturing or testing our product candidates or any approved products;
- · the initiation of or material developments in or the conclusion of litigation to enforce or defend any of our intellectual property rights;
- · the loss of key employees;

---

# Page 40

- · the introduction of technological innovations or new commercial products by our competitors;
- · changes in estimates or recommendations by securities analysts, if any, who cover our common stock;
- · future sales of our common stock;
- · changes in the structure of health care payment systems;
- · period-to-period fluctuations in our financial results; and
- · our ability to retain the listing of our common stock on the Nasdaq Capital Market.


Moreover, the stock markets in general have experienced substantial volatility that has often been unrelated to the operating performance of individual companies, including as a result of deteriorating market conditions due to investor concerns regarding inflation and continued hostilities between Russia and Ukraine. These broad market fluctuations may also adversely affect the trading price of our common stock. In the past, following periods of volatility in the market price of a company's securities, stockholders have often instituted class action securities litigation against those companies. Such litigation, if instituted, could result in substantial costs and diversion of management attention and resources, which could significantly harm our profitability and reputation.


## Future sales or the possibility of future sales of our common stock may depress the market price of our common stock.

Sales in the public market of substantial amounts of our common stock could depress prevailing market prices of our common stock. As of December 31, 2022, approximately 14.4 million shares of common stock were outstanding, and all of these shares are freely transferable without restriction or further registration under the Securities Act of 1933, as amended, or the Securities Act, except for shares held by our directors, officers and other affiliates and unregistered shares held by non-affiliates. The sale of these additional shares, or the perception that such sales may occur, could depress the market price of our common stock.

As of December 31, 2022, there were approximately 796,000 shares of our common stock which may be issued upon the exercise of outstanding stock options and the vesting of restricted stock units, and we anticipate that we will continue to issue stock option and restricted stock unit awards to our employees and consultants in the fiscal year ended December 31, 2023 and thereafter. If and when these options are exercised and these restricted stock units are vested, such shares will be available for sale in the open market without further registration under the Securities Act. The existence of these outstanding options and restricted stock units may negatively affect our ability to complete future equity financings at acceptable prices and on acceptable terms. The exercise of those options and vesting of the restricted stock units, and the prompt resale of shares of our common stock received, may also result in downward pressure on the price of our common stock.

In the absence of a significant strategic transaction, we will need to raise significant additional capital to finance the research, development and commercialization of Gencaro, rNAPc2 and our other product candidate. If future securities offerings occur, they would dilute our current stockholders' equity interests and could reduce the market price of our common stock.


## We do not expect to pay cash dividends, and accordingly, stockholders must rely on stock appreciation for any return on their investment.

We anticipate that we will retain our earnings, if any, for future growth and therefore do not anticipate paying cash dividends in the future. As a result, only appreciation of the price of our common stock will provide a return to stockholders. Investors seeking cash dividends should not invest in our common stock.


## Our business could be negatively affected as a result of actions of activist shareholders.

Responding to actions by activist shareholders could be costly and time-consuming, disrupt our operations and divert the attention of management and our employees. For example, in connection with the negotiation and entry into a cooperation agreement in June 2022 with Cable Car Capital LLC, The Funicular Fund, LP, Funicular Funds, LP and Jacob Ma-Weaver, collectively, Cable Car, one of our stockholders, we appointed two new directors in 2022. Activist shareholders may advocate for certain governance and strategic changes at our company. In the event of stockholder activism, particularly with respect to matters which our board of directors, in exercising their fiduciary duties, disagree with or have determined not to pursue, our business could be adversely affected because responding to actions by activist stockholders can be costly and time-consuming, disrupting our operations and diverting the attention of management, and perceived uncertainties as to our future direction may result in the loss of potential business opportunities and may make it more difficult to attract and retain qualified personnel, business partners, and customers.

Additionally, if faced with a consent solicitation or proxy contest, we may not be able to respond successfully to the contest or dispute, which would be disruptive to our business. If individuals are elected to our board of directors with a differing agenda, our ability to effectively and timely implement our strategic plan and create additional value for our stockholders may be adversely affected. In addition, our share price could experience periods of increased volatility as a result of shareholder activism.

---

# Page 41

# We have implemented anti-takeover provisions that could discourage, prevent or delay a takeover, even if the acquisition would be beneficial to our stockholders.


Provisions of our certificate of incorporation and bylaws, as well as provisions of Delaware law, could make it more difficult for a third party to acquire us, even if doing so would benefit our stockholders. These provisions:
- · establish a classified board of directors so that not all members of our board may be elected at one time;
- · authorize the issuance of up to approximately 5 million additional shares of preferred stock that could be issued by our board of directors to increase the number of outstanding shares and hinder a takeover attempt;
- · limit who may call a special meeting of stockholders;
- · prohibit stockholder action by written consent, thereby requiring all stockholder actions to be taken at a meeting of our stockholders; and
- · establish advance notice requirements for nominations for election to our board of directors or for proposing matters that can be acted upon at a stockholder meeting.


Specifically, our certificate of incorporation provides that all stockholder action must be effected at a duly called meeting and not by a written consent. The bylaws provide, however, that our stockholders may call a special meeting of stockholders only upon a request of stockholders owning at least 50% of our outstanding common stock. These provisions of our certificate of incorporation and bylaws could discourage potential acquisition proposals and could delay or prevent a change in control. We designed these provisions to reduce our vulnerability to unsolicited acquisition proposals and to discourage certain tactics that may be used in proxy fights. These provisions, however, could also have the effect of discouraging others from making tender offers for our shares. As a consequence, they also may inhibit fluctuations in the market price of our shares that could result from actual or rumored takeover attempts. Such provisions also may have the effect of preventing changes in our management.

We are permitted to issue shares of our preferred stock without stockholder approval upon such terms as our board of directors determines. Therefore, the rights of the holders of our common stock are subject to, and may be adversely affected by, the rights of the holders of our preferred stock that may be issued in the future. In addition, the issuance of preferred stock could have a dilutive effect on the holdings of our current stockholders.


We are subject to the Delaware anti-takeover laws regulating corporate takeovers. These anti-takeover laws prevent a Delaware corporation from engaging in a merger or sale of more than 10% of its assets with any stockholder, including all affiliates and associates of the stockholder, who owns 15% or more of the corporation's outstanding voting stock, for three years following the date that the stockholder acquired 15% or more of the corporation's stock unless:
- · the board of directors approved the transaction where the stockholder acquired 15% or more of the corporation's stock;
- · after the transaction in which the stockholder acquired 15% or more of the corporation's stock, the stockholder owned at least 85% of the corporation's outstanding voting stock, excluding shares owned by directors, officers and employee stock plans in which employee participants do not have the right to determine confidentially whether shares held under the plan will be tendered in a tender or exchange offer; or
- · on or after this date, the merger or sale is approved by the board of directors and the holders of at least two-thirds of the outstanding voting stock that is not owned by the stockholder.



The provisions of our governing documents and current Delaware law may, collectively:
- · lengthen the time required for a person or entity to acquire control of us through a proxy contest for the election of a majority of our board of directors;
- · discourage bids for our common stock at a premium over market price; and
- · generally deter efforts to obtain control of us.



## Item 1B. Unresolved Staff Comments

Not applicable.

---

# Page 42

# Item 2. Properties

Our headquarters facility consists of approximately 8,200 square feet of office space in Westminster, Colorado, of which approximately 5,200 square feet is leased until March 2024 and includes an option to renew for an additional 36 month term and approximately 3,000 square feet is subleased until October 2023, with no renewal option. We believe that this facility is adequate to meet our current needs.


## Item 3. Legal Proceedings

Not applicable.


## Item 4. Mine Safety Disclosures

Not applicable.

---

# Page 43

# PART II


## Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities

As of March 7, 2011, our common stock began trading on The Nasdaq Capital Market under the symbol 'ABIO', and was previously traded under the same symbol on The Nasdaq Global Market. Prior to completion of the merger with Nuvelo, Nuvelo's common stock traded under the symbol 'NUVO' on The Nasdaq Global Market from January 31, 2003 to January 27, 2009 (except for the period between June 19, 2003 and March 19, 2004, where it temporarily traded under the symbol 'NUVOD').


## Stockholders

As of February 22, 2023, we had approximately 18 stockholders of record of our common stock, and the last sale price reported on The Nasdaq Capital Market for our common stock as of such date was $2.12 per share.


## Dividend Policy

The holders of our common stock are entitled to dividends in such amounts and at such times, if any, as may be declared by our Board of Directors out of legally available funds. We have not paid any dividends on our common stock and do not anticipate paying any cash dividends in the foreseeable future.


## Securities Authorized for Issuance Under Equity Compensation Plans

Information relating to our equity compensation plans as of December 31, 2022, under which our equity securities were authorized for issuance, is included in Item 12 of Part III of this Annual Report and such information is incorporated herein by reference.


## Unregistered Sales of Equity Securities and Use of Proceeds

None.


## Issuer Purchases of Equity Securities

None.


## Item 6. Reserved

---

# Page 44

# Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations

We have included or incorporated by reference into this Management's Discussion and Analysis of Financial Condition and Results of Operations and elsewhere in this Annual Report on Form 10-K, and from time to time our management may make, statements that constitute 'forward-looking statements' within the meaning of Section 27A of the Securities Act and Section 21E of the Exchange Act. Forward-looking statements may be identified by words including 'anticipate,' 'plan,' 'believe,' 'intend,' 'estimate,' 'expect,' 'should,' 'may,' 'potential' and similar expressions. These statements involve known and unknown risks, uncertainties and other factors that may cause our actual results, levels of activity, performance or achievements to be materially different from the information expressed or implied by these forward-looking statements. While we believe that we have a reasonable basis for each forward-looking statement contained in this Annual Report, we caution you that these statements are based on a combination of facts and factors currently known by us and our projections of the future, about which we cannot be certain. We undertake no obligation to publicly update any forward-looking statements, whether as a result of new information, future events or otherwise. You are advised, however, to consult any further disclosures we make on related subjects in our Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and our website.


## Overview

We are a clinical-stage biopharmaceutical company applying a precision medicine approach to the development and commercialization of targeted therapies for cardiovascular diseases. Precision medicine refers to the tailoring of medical treatment to the individual characteristics of patients, using genomic, non-genomic biomarker and other information that extends beyond routine diagnostic categorization. We believe that when implemented correctly precision medicine can enhance therapeutic response, improve patient outcomes, and reduce healthcare costs.

In April 2022, the Board of Directors established a Special Committee and, in May 2022, retained Ladenburg Thalmann & Co. Inc. to evaluate strategic options, including transactions involving a merger, sale of all or part of our assets, or other alternatives with the goal of maximizing stockholder value. We believe there are multiple potential opportunities to enhance value for our shareholders. We do not have a defined timeline for the strategic review process and the review may not result in any specific action or transaction.

Our lead product candidate is Gencaro™ (bucindolol hydrochloride) for the treatment of atrial fibrillation, or AF, in patients with chronic heart failure, or HF. Gencaro is being developed for patients who have a genotype that identifies a drug target associated with heightened efficacy.


## Gencaro™ (bucindolol hydrochloride) for Atrial Fibrillation

Gencaro™ (bucindolol hydrochloride) is a pharmacogenetically-targeted beta-adrenergic receptor antagonist with mild vasodilator properties that we are developing for the treatment of atrial fibrillation in patients with heart failure. We believe the pharmacology of Gencaro is unique and its efficacy can be enhanced by prescribing it to patients with a common genotypic variant that is present in approximately 50% of the North American and European general populations. This gene can be detected with a simple genetic test.

We are developing Gencaro to treat atrial fibrillation, or AF, in patients with chronic heart failure, or HF. AF is the most common form of cardiac arrhythmia, a disruption of the heart's normal rhythm or rate. HF is a chronic condition in which the heart is unable to pump enough blood to meet the body's needs. AF and HF commonly occur together. In HF patients, the development of AF leads to worsening symptoms, and increased risk of hospitalization and death. Current treatment options for AF in HF patients are limited, and can be invasive, costly and dangerous.

Our development plan for Gencaro focuses on the treatment of AF in patients with higher ejection fraction HF, those who have an ejection fraction, or EF, of 40% and higher who also have the genotype we believe is optimal for Gencaro efficacy. This population of HF encompasses more than half of all HF patients in the United States and Europe. There are currently few approved or effective drug therapies to treat AF or HF in this patient population.

Our development plan for Gencaro is based on our recently published analysis of the Phase 2b clinical trial of Gencaro for the prevention of AF in HF patients, known as GENETIC-AF. This analysis showed novel results for Gencaro in patients in the clinical trial with EF's of 40% and higher. We currently have an agreement with the FDA, known as a Special Protocol Assessment, or SPA, for the requirements of a Gencaro Phase 3 clinical trial that would support approval of Gencaro if successful. The Phase 3 pivotal clinical trial of Gencaro conducted under an SPA will include secondary endpoints that are intended to capture some of this new information, such as a reduction in the need to deploy rhythm control interventions including electrical cardioversion, catheter ablation and use of anti-arrhythmic drugs and avoidance of drug-related complications such as bradycardia. Based on these analyses, we were issued a United States patent in February 2021 for the use of Gencaro in this patient population. We believe this patent will substantially extend the patent protection for our planned development of Gencaro into 2039. We are seeking similar patent protection in other countries.

---

# Page 45

We believe that patients with HF and AF represent a major unmet medical need, and this need is most pronounced in patients with EF values of 40% and above. This EF range constitutes more than half of all chronic HF in the United States and Europe, as well as in Japan and China, and there are currently few approved, effective or guideline-recommended therapies for these patients to treat either their AF or HF. AF is a very common complication in these patients, with estimates of AF incidence ranging from 40% to 60%. Betablockers approved for HF are commonly used off-label to control heart rate in these patients, but they are not considered effective in preventing AF and none are approved for patients with EF ≥ 40%. Other anti-arrhythmic drugs approved for the treatment of AF have adverse side effects and in HF patients are either contraindicated or have label warnings for use due to an increased risk of mortality. Interventional procedures for AF, such as catheter ablation and electrical cardioversion, are invasive, expensive, and often temporary; these interventions also typically require the continued use of beta blockers and other anti-arrhythmic drugs post-intervention.


We believe that Gencaro, if approved, may be a safe and more effective therapy for the treatment of higher ejection fraction HF patients with AF. We believe there are several potentially important attributes that would differentiate Gencaro from existing therapies, including:
- · More effective rhythm control compared to the current standard of care;
- · Reduction in the need for catheter ablation, electrical cardioversion, or toxic anti-arrhythmic drugs;
- · Maintenance of rhythm control after a successful AF catheter ablation;
- · Effective rate control with lower risk of treatment-limiting, adverse event producing bradycardia;
- · Reduction in symptoms and improvement in quality of life;
- · Reduced health care burden;
- · Foundational beta-blocker benefits for HF and unique evidence of efficacy in HF patients with AF;
- · One of the only drug therapies approved and shown effective for AF in HF patients with EF ≥ 40%, and the only one in its drug class.


We have an international patent portfolio for Gencaro in the United States, the EU, and other major markets, as well as new chemical entity status, including a new patent that we believe will give us a strong intellectual property position to at least approximately 2039 in the United States; we have filed applications similar to this new patent in international territories. We have developed a laboratory platform for the diagnostic test that would be used to prescribe Gencaro; this platform was approved by FDA for use in the Phase 2B clinical trial. We retain all rights to this test platform; we expect to use it in future clinical trials, and we believe it could be one of multiple diagnostic platforms used for commercialization.


## rNAPc2 (AB201) for treatment of COVID-19

Recombinant Nematode Anticoagulant Protein c2, or rNAPc2 (AB201), is a protein therapeutic in clinical development as a potential treatment for patients with COVID-19. Based on its unique mechanism of action, development history and the clinical evidence from the SARS-CoV-2 pandemic, we believe rNAPc2 has potential to be a beneficial therapy for patients with this serious viral disease. We initiated a Phase 2b clinical trial of rNAPc2 as a potential treatment for patients hospitalized with COVID-19 in the fourth quarter of 2020 and completed patient enrollment in the fourth quarter 2021. In the clinical trial, both doses of rNAPc2 demonstrated a treatment benefit for patients, however, neither dose achieved statistical significance for the primary efficacy endpoint of change in D-dimer level from Baseline to Day 8 compared to standard of care heparin.

On the secondary endpoints measuring thrombotic events and time-to-recovery, there was a numerical imbalance in favor of rNAPc2 that was non-significant. rNAPc2 was well-tolerated at both doses. There were no serious treatment-related adverse events and no dose dependent increase in adverse events was observed. There was no difference between rNAPc2 and standard-of-care heparin in major or non-major clinically relevant bleeding.

To support the continued development of Gencaro and rNAPc2, we will need additional financing to fully fund any clinical trials, and our general and administrative costs through the clinical trials' projected completion and potential commercialization. Considering the substantial time and costs associated with the development of Gencaro and rNAPc2 and the risk that we may be unable to raise a significant amount of capital on acceptable terms, we are also pursuing co-development and commercialization partnering opportunities with large pharmaceutical and/or specialty pharmaceutical companies and may pursue a strategic combination or other strategic transactions. If we are unable to obtain sufficient financing or are unable to complete a strategic transaction, we may discontinue our development activities on Gencaro or rNAPc2 or discontinue our operations.

---

# Page 46

We believe our cash and cash equivalents as of December 31, 2022 will be sufficient to fund our operations through the middle of fiscal year 2024. Our review of our strategic options may impact this projection. Conducting a Phase 3 PRECISION-AF trial would likely require additional financing. However, changing circumstances may cause us to consume capital significantly faster or slower than currently anticipated. We have based these estimates on assumptions that may prove to be wrong, and we could exhaust our available financial resources sooner than we currently anticipate; therefore, we may have to raise additional capital for other clinical trials. Initiating any Phase 3 clinical trial of Gencaro will require additional financing.

In April 2022, the Board of Directors established a Special Committee and, in May 2022, retained Ladenburg Thalmann & Co. Inc. to evaluate strategic options, including transactions involving a merger, sale of all or part of our assets, or other alternatives with the goal of maximizing stockholder value. We believe there are multiple potential opportunities to enhance value for our shareholders. We do not have a defined timeline for the strategic review process and the review may not result in any specific action or transaction.

In July 2020, we entered into a new sales agreement with a placement agent to sell, from time to time, our common stock having an aggregate offering price of up to $54.0 million, in an 'at the market offering.' As of February 2021, we had sold an aggregate of 9,928,272 shares of our common stock pursuant to the terms of such sales agreement for aggregate gross proceeds of approximately $54.0 million. Net proceeds received in this offering were approximately $52.2 million, after deducting expenses for executing the 'at the market offering' and commissions paid to the placement agent.

In April 2021, we amended the new sales agreement and the amount available for the offering under our prospectus to our registration statement on Form S-3 (No. 333-254585). As of February 22, 2023, the amount available for the offering under the prospectus supplement is subject to the limitation of not selling a total value amount of shares exceeding more than one-third of our public float in any 12-month period, which as of February 22, 2023 would have been approximately $8.8 million.

In March 2020, the World Health Organization declared the outbreak of COVID-19, a novel strain of Coronavirus, a global pandemic. This outbreak is causing major disruptions to businesses and markets worldwide as the virus spreads. We do not expect a material financial effect as a result of the pandemic. However, if the pandemic continues to be a severe worldwide crisis, it could have a material adverse effect on our business, results of operations, financial condition and cash flows.


## Results of Operations


## Research and Development Expenses

Research and development, or R&D, expense is comprised primarily of personnel costs, clinical development, manufacturing process development, and regulatory activities and costs.

Our research and development expenses were $4.7 million for the year ended December 31, 2022 as compared to $13.8 million for 2021. The $9.1 million decrease in research and development expenses in 2022 as compared to 2021 was primarily related to the completion of enrollment in our rNAPc2 (AB201) international Phase 2b clinical trial in the fourth quarter of 2021.

Clinical expense decreased approximately $5.7 million for the year ended December 31, 2022. The decrease was related to the completion of enrollment in our rNAPc2 (AB201) international Phase 2b clinical trial in the fourth quarter of 2021.

Manufacturing process development costs decreased approximately $2.5 million year ended December 31, 2022 compared to 2021. The decrease was related to the completion of enrollment in our rNAPc2 (AB201) international Phase 2b clinical trial in the fourth quarter of 2021.

R&D personnel costs decreased approximately $0.7 million for the year ended December 31, 2022, as compared to 2021. In July 2022, we implemented a strategic reduction of our workforce by approximately 67%, or 12 employees. Personnel reductions were primarily focused in research and development and general and administrative functions. The restructuring was a result of our decision to manage our operating costs and expenses. During the year ended December 31, 2022, we recorded total restructuring charges of approximately $755,000, of which $470,000 and $285,000 were recognized in research and development and general and administrative expenses, respectively, in connection with the restructuring, all in the form of one-time termination benefits.

R&D expense in 2023 is expected to be lower than 2022, as we completed our rNAPc2 (AB201) international Phase 2b clinical trial in the fourth quarter of 2021.


## General and Administrative Expenses

General and administrative, or G&A, expenses primarily consist of personnel costs, consulting and professional fees, insurance, facilities and depreciation expenses, and various other administrative costs.

---

# Page 47

G&A expenses were $5.8 million for the year ended December 31, 2022, compared to $5.5 million for 2021, an increase of approximately $0.3 million. The increase in expenses during 2022 was primarily a result of increases in professional fees and consulting costs and one-time termination benefits discussed above in 2022.

G&A expenses in 2023 are expected to be consistent with those in 2022 as we maintain administrative activities to support our ongoing operations.


# Interest and Other Income

Interest and other income was $675,000 of interest income for the year ended December 31, 2022 as compared to $13,000 for 2021, resulting in an increase of $662,000. We expect interest income in 2023 to be consistent with 2022, as we continue to use our cash and cash equivalents to fund our operations, offset by higher interest rates.


## Other Expense

Other expense was $5,000 for the year ended December 31, 2022. There was no other expense for the year eneded December 31, 2021. The amounts were nominal to our overall operations. Based on our current capital structure, other expense is expected to be negligible in 2023.


## Liquidity and Capital Resources


## Cash and Cash Equivalents


| December 31,                                                       | December 31,   |
|--------------------------------------------------------------------|----------------|
| 2022                                                               | 2021           |
| (in thousands)                                                     | (in thousands) |
| Cash and cash equivalents.................................$ 42,445 | $ 53,359       |


As of December 31, 2022, we had total cash and cash equivalents of approximately $42.4 million, as compared to $53.4 million as of December 31, 2021. The net decrease of $10.9 million during the year primarily reflects cash used in operating activities during the year ended December 31, 2022.


## Cash Flows from Operating, Investing and Financing Activities


|                                                                             | Years Ended December 31,   | Years Ended December 31,   |
|-----------------------------------------------------------------------------|----------------------------|----------------------------|
|                                                                             | 2022                       | 2021                       |
|                                                                             | (in thousands)             | (in thousands)             |
| Net cash provided by (used in):                                             |                            |                            |
| Operating activities .....................................................$ | (10,912)                   | $ (18,762)                 |
| Investing activities ...................................................... | (2)                        | (43)                       |
| Financing activities .....................................................  | -                          | 23,093                     |
| Net increase in cash and cash equivalents ........................$         | (10,914)                   | $ 4,288                    |


Net cash used in operating activities for the year ended December 31, 2022 decreased approximately $7.8 million compared with 2021. This was primarily due to lower outflows related to changes in operating assets and liabilities and a lower net loss in 2022, as discussed in Results of Operations above.

Net cash used in investing activities for the years ended December 31, 2022 and 2021 was $2,000 and $43,000, respectively, for the purchase of property and equipment.

There were no financing activities in the year ended December 31, 2022. Net cash provided by financing activities was $23.1 million for the year ended December 31, 2021 related to net proceeds from sales of our common stock in our 'at the market' equity offering.


## Sources and Uses of Capital

Our primary sources of liquidity to date have been capital raised from issuances of shares of our preferred and common stock. The primary uses of our capital resources to date have been to fund operating activities, including research, clinical development and drug manufacturing expenses, license payments, and spending on capital items.

---

# Page 48

In July 2020, we entered into a sales agreement with a placement agent to sell, from time to time, our common stock having an aggregate offering price of up to $54.0 million, in an 'at the market offering.' As of February 2021, we had sold an aggregate of 9,928,272 shares of our common stock pursuant to the terms of such sales agreement for aggregate gross proceeds of approximately $54.0 million. Net proceeds received in this offering were approximately $52.2 million, after deducting expenses for executing the 'at the market offering' and commissions paid to the placement agent.

In April 2021, we amended the new sales agreement and the amount available for the offering under our prospectus to our registration statement on Form S-3 (No. 333-254585). As of February 22, 2023, the amount available for the offering under the prospectus supplement is subject to the limitation of not selling a total value amount of shares exceeding more than one-third of our public float in any 12-month period, which as of February 22, 2023 would have been approximately $8.8 million.


Our ability to execute our development programs in accordance with our projected time line depends on a number of factors, including, but not limited to, the following:
- · the costs and timing for the potential additional clinical trials in order to gain possible regulatory approval for Gencaro, rNAPc2 or any other product candidate;
- · the market price of our stock and the availability and cost of additional equity capital from existing and potential new investors;
- · our ability to retain the listing of our common stock on the Nasdaq Capital Market;
- · our ability to control costs associated with our operations;
- · general economic and industry conditions affecting the availability and cost of capital, including as a result of deteriorating market conditions due to investor concerns regarding inflation and continued hostilities between Russia and Ukraine;
- · the costs of filing, prosecuting, defending and enforcing any patent claims and other intellectual property rights; and
- · the terms and conditions of our existing collaborative and licensing agreements.


We believe our cash and cash equivalents as of December 31, 2022 will be sufficient to fund our operations through the middle of fiscal year 2024. Our review of our strategic options may impact this projection. Conducting a Phase 3 PRECISION-AF trial would likely require additional financing. However, changing circumstances may cause us to consume capital significantly faster or slower than currently anticipated. We have based these estimates on assumptions that may prove to be wrong, and we could exhaust our available financial resources sooner than we currently anticipate; therefore, we may have to raise additional capital for other clinical trials. Initiating any Phase 3 clinical trial of Gencaro will require additional financing. We may not be able to raise sufficient capital on acceptable terms, or at all, to continue development and potential commercialization Gencaro or to otherwise continue operations and may not be able to execute any strategic transaction.

In April 2022, the Board of Directors established a Special Committee and, in May 2022, retained Ladenburg Thalmann & Co. Inc. to evaluate strategic options, including transactions involving a merger, sale of all or part of our assets, or other alternatives with the goal of maximizing stockholder value. We believe there are multiple potential opportunities to enhance value for our shareholders. We do not have a defined timeline for the strategic review process and the review may not result in any specific action or transaction.


## Contractual Obligation and Commitments

In December 2022, the Board of Directors approved retention bonuses for certain employees, subject to continued employment with us through the earlier of a change in control of our company or certain clinical development decisions totaling $265,000, none of which was accrued as of December 31, 2022.

On August 29, 2020 the Company entered into a lease agreement for approximately 5,200 square feet of office facilities in Westminster, Colorado which serves as the Company's primary business office effective October 1, 2020 (October 2020 Lease). The lease term is 42 months beginning October 1, 2020 and includes an option to renew for an additional 36 month term at the then prevailing rental rate. The exercise of the lease renewal option is at the Company's sole discretion. The amounts recorded assume the Company will exercise its renewal option. In June 2021, the Company entered into a sublease agreement for approximately 3,000 square feet of additional office facilities in the Company's primary business office (2021 Lease). The sublease term is 29 months beginning June 2021, with no renewal option.  The leases include real estate taxes and insurance, which is not a lease component and is not included in the lease obligation. In addition, common area maintenance charges are based on actual costs incurred and are a nonlease component that is not included in the lease obligation. Rent expense, which is included in general and administrative expense, under these leases for the years ended December 31, 2022 and 2021 was $125,000 and $109,000, respectively.

We have licensed worldwide rights to all preclinical and clinical data through the BEST trial for development of bucindolol.  The patents that were the subject of this license are expired. If the license agreement is deemed enforceable, we would incur milestone and

---

# Page 49

royalty obligations upon the occurrence of certain events, including if the FDA grants marketing approval for Gencaro, upon regulatory marketing approval in Europe and Japan and based on achievement of specified product sales levels.


# Critical Accounting Policies and Estimates

A critical accounting policy is one that is both important to the portrayal of our financial condition and results of operation and requires management's most difficult, subjective or complex judgments, often as a result of the need to make estimates about the effect of matters that are inherently uncertain. While our significant accounting policies are described in Note 1 of 'Notes to Financial Statements' included within Item 8 in this report, we believe the following critical accounting policy affected our most significant judgments, assumptions, and estimates used in the preparation of our financial statements and, therefore, is important in understanding our financial condition and results of operations.


## Accrued Outsourcing Expenses

As part of the process of preparing our financial statements, we are required to estimate accrued outsourcing expenses. This process involves identifying services that third parties have performed on our behalf and estimating the level of service performed and the associated cost incurred for these services as of the balance sheet date. Examples of estimated accrued outsourcing expenses include contract service fees, such as fees payable to contract manufacturers in connection with the production of materials related to our drug product, and service fees from clinical research organizations. We develop estimates of liabilities using our judgment based upon the facts and circumstances known at the time.


## Indemnifications

In the ordinary course of business, we enter into contractual arrangements under which we may agree to indemnify certain parties from any losses incurred relating to the services they perform on our behalf or for losses arising from certain events as defined within the particular contract. Such indemnification obligations may not be subject to maximum loss clauses. We have entered into indemnity agreements with each of our directors, officers and certain employees. Such indemnity agreements contain provisions, which are in some respects broader than the specific indemnification provisions contained in Delaware law. We also maintain an insurance policy for our directors and executive officers insuring against certain liabilities arising in their capacities as such.


## Item 7A. Quantitative and Qualitative Disclosures About Market Risk

Not applicable.

---

# Page 50

# Item 8. Financial Statements and Supplementary Data


|                                                                                                                                                                                           |   Page |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------|
| Report of Independent Registered Public Accounting Firm, KPMG LLP ...........................................................................................                             |     49 |
| Balance Sheets as of December 31, 2022 and 2021............................................................................................................................               |     50 |
| Statements of Operations for the years ended December 31, 2022 and 2021.......................................................................................                            |     51 |
| Statements of Stockholders' Equity for the years ended December 31, 2022 and 2021  ......................................................................                                 |     52 |
| Statements of Cash Flows for the years ended December 31, 2022 and 2021......................................................................................                             |     53 |
| Notes to Financial Statements............................................................................................................................................................ |     54 |

---

# Page 51

# Report of Independent Registered Public Accounting Firm


## To the Stockholders and Board of Directors

ARCA biopharma, Inc.:


## Opinion on the Financial Statements

We have audited the accompanying balance sheets of ARCA biopharma, Inc. (the Company) as of December 31, 2022 and 2021, the related statements of operations, stockholders' equity, and cash flows for the years then ended, and the related notes (collectively, the financial statements). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of December 31, 2022 and 2021, and the results of its operations and its cash flows for the years then ended, in conformity with U.S. generally accepted accounting principles.


## Basis for Opinion

These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on these financial statements based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. The Company is not required to have, nor were we engaged to perform, an audit of its internal control over financial reporting. As part of our audits, we are required to obtain an understanding of internal control over financial reporting but not for the purpose of expressing an opinion on the effectiveness of the Company's internal control over financial reporting. Accordingly, we express no such opinion.

Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.


## Critical Audit Matter

Critical audit matters are matters arising from the current period audit of the financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. We determined that there are no critical audit matters.

/s/ KPMG LLP

We have served as the Company's auditor since 2006.

Boulder, Colorado February 24, 2023

---

# Page 52

# ARCA BIOPHARMA, INC.


## BALANCE SHEETS


|                                                                                                                                                                                                                        | As of December 31,                                 | As of December 31,                                 |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------|----------------------------------------------------|
|                                                                                                                                                                                                                        | 2022                                               | 2021                                               |
|                                                                                                                                                                                                                        | (in thousands, except share and per share amounts) | (in thousands, except share and per share amounts) |
| ASSETS                                                                                                                                                                                                                 |                                                    |                                                    |
| Current assets:                                                                                                                                                                                                        |                                                    |                                                    |
| Cash and cash equivalents ..............................................................................................$                                                                                              | 42,445                                             | $ 53,359                                           |
| Other current assets.........................................................................................................                                                                                          | 254                                                | 1,062                                              |
| Total current assets .....................................................................................................                                                                                             | 42,699                                             | 54,421                                             |
| Right-of-use asset - operating.............................................................................................                                                                                            | 343                                                | 437                                                |
| Property and equipment, net...............................................................................................                                                                                             | 25                                                 | 48                                                 |
| Other assets.........................................................................................................................                                                                                  | 18                                                 | 18                                                 |
| Total assets ................................................................................................................$                                                                                         | 43,085                                             | $ 54,924                                           |
| LIABILITIES AND STOCKHOLDERS' EQUITY                                                                                                                                                                                   |                                                    |                                                    |
| Current liabilities:                                                                                                                                                                                                   |                                                    |                                                    |
| Accounts payable............................................................................................................$                                                                                          | 334                                                | $ 1,117                                            |
| Accrued compensation and employee benefits...............................................................                                                                                                              | 173                                                | 925                                                |
| Accrued expenses and other liabilities ...........................................................................                                                                                                     | 625                                                | 1,456                                              |
| Total current liabilities................................................................................................                                                                                              | 1,132                                              | 3,498                                              |
| Operating lease liability, net of current portion..................................................................                                                                                                    | 280                                                | 383                                                |
| Total liabilities ...........................................................................................................                                                                                          | 1,412                                              | 3,881                                              |
| Commitments and contingencies                                                                                                                                                                                          |                                                    |                                                    |
| Stockholders' equity:                                                                                                                                                                                                  |                                                    |                                                    |
| Preferred stock, $0.001 par value; 5 million shares authorized;    no shares issued or outstanding at December 31, 2022 and 2021 ...............................                                                       | -                                                  | -                                                  |
| Common stock, $0.001 par value; 100 million shares authorized    at December 31, 2022 and 2021; 14,410,143 shares    issued and outstanding at December 31, 2022 and 2021............................................. | 14                                                 | 14                                                 |
| Additional paid-in capital ...............................................................................................                                                                                             | 225,061                                            | 224,505                                            |
| Accumulated deficit........................................................................................................                                                                                            | (183,402)                                          | (173,476)                                          |
| Total stockholders' equity ........................................................................................                                                                                                    | 41,673                                             | 51,043                                             |
| Total liabilities and stockholders' equity ................................................................$                                                                                                           | 43,085                                             | $ 54,924                                           |

---

# Page 53

# ARCA BIOPHARMA, INC.


## STATEMENTS OF OPERATIONS


|                                                                                                                                      | Years Ended December 31,                           | Years Ended December 31,                           |
|--------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------|----------------------------------------------------|
|                                                                                                                                      | 2022                                               | 2021                                               |
|                                                                                                                                      | (in thousands, except share and per share amounts) | (in thousands, except share and per share amounts) |
| Costs and expenses:                                                                                                                  |                                                    |                                                    |
| Research and development ..........................................................................................$                 | 4,749                                              | $ 13,832                                           |
| General and administrative ..........................................................................................                | 5,847                                              | 5,503                                              |
| Total costs and expenses......................................................................................                       | 10,596                                             | 19,335                                             |
| Loss from operations ...........................................................................................                     | (10,596)                                           | (19,335)                                           |
| Interest and other income.................................................................................................           | 675                                                | 13                                                 |
| Other loss ......................................................................................................................... | (5)                                                | -                                                  |
| Net loss ................................................................................................................$           | (9,926)                                            | $ (19,322)                                         |
| Net loss per share:                                                                                                                  |                                                    |                                                    |
| Basic and diluted......................................................................................................$             | (0.69)                                             | $ (1.39)                                           |
| Weighted average shares outstanding:                                                                                                 |                                                    |                                                    |
| Basic and diluted......................................................................................................              | 14,410,143                                         | 13,903,871                                         |


See accompanying Notes to Financial Statements

---

# Page 54

# ARCA BIOPHARMA, INC.


## STATEMENTS OF STOCKHOLDERS' EQUITY


|                                                                                            | Stockholders' Equity                               | Stockholders' Equity                               | Stockholders' Equity                               | Stockholders' Equity                               | Stockholders' Equity                               |
|--------------------------------------------------------------------------------------------|----------------------------------------------------|----------------------------------------------------|----------------------------------------------------|----------------------------------------------------|----------------------------------------------------|
|                                                                                            | Common stock                                       | Common stock                                       | Additional Paid-In                                 | Accumulated                                        |                                                    |
|                                                                                            | Shares                                             | Amount                                             | Capital                                            | Deficit                                            | Total                                              |
|                                                                                            | (in thousands, except share and per share amounts) | (in thousands, except share and per share amounts) | (in thousands, except share and per share amounts) | (in thousands, except share and per share amounts) | (in thousands, except share and per share amounts) |
| Balance, December 31, 2020 .................                                               | 9,548,150                                          | $ 10                                               | $ 200,665                                          | $ (154,154)                                        | $ 46,521                                           |
| Issuance of common stock for cash,    net of offering costs .............................. | 4,861,993                                          | 4                                                  | 23,343                                             | -                                                  | 23,347                                             |
| Share-based compensation ......................                                            | -                                                  | -                                                  | 497                                                | -                                                  | 497                                                |
| Net loss ....................................................                              | -                                                  | -                                                  | -                                                  | (19,322)                                           | (19,322)                                           |
| Balance, December 31, 2021 .................                                               | 14,410,143                                         | 14                                                 | 224,505                                            | (173,476)                                          | 51,043                                             |
| Share-based compensation ......................                                            | -                                                  | -                                                  | 556                                                | -                                                  | 556                                                |
| Net loss ....................................................                              | -                                                  | -                                                  | -                                                  | (9,926)                                            | (9,926)                                            |
| Balance, December 31, 2022 .................                                               | 14,410,143                                         | $ 14                                               | $ 225,061                                          | $ (183,402)                                        | $ 41,673                                           |


See accompanying Notes to Financial Statements

---

# Page 55

# ARCA BIOPHARMA, INC.


## STATEMENTS OF CASH FLOWS


|                                                                                                                                     | Years Ended December 31,   | Years Ended December 31,   |
|-------------------------------------------------------------------------------------------------------------------------------------|----------------------------|----------------------------|
|                                                                                                                                     | 2022                       | 2021                       |
|                                                                                                                                     | (in thousands)             | (in thousands)             |
| Cash flows from operating activities:                                                                                               |                            |                            |
| Net loss .........................................................................................................................$ | (9,926)                    | $ (19,322)                 |
| Adjustments to reconcile net loss to net cash used    in operating activities:                                                      |                            |                            |
| Depreciation..............................................................................................................          | 20                         | 16                         |
| Amortization of right-of-use asset - operating..........................................................                            | 94                         | 75                         |
| Share-based compensation........................................................................................                    | 556                        | 497                        |
| Loss from disposal of property and equipment ........................................................                               | 5                          | -                          |
| Change in operating assets and liabilities:                                                                                         |                            |                            |
| Other current assets...............................................................................................                 | 808                        | (156)                      |
| Other assets ...........................................................................................................            | -                          | (6)                        |
| Accounts payable..................................................................................................                  | (783)                      | (411)                      |
| Accrued compensation and employee benefits.....................................................                                     | (752)                      | 110                        |
| Accrued expenses and other liabilities..................................................................                            | (934)                      | 435                        |
| Net cash used in operating activities .....................................................................                         | (10,912)                   | (18,762)                   |
| Cash flows from investing activities:                                                                                               |                            |                            |
| Purchase of property and equipment ............................................................................                     | (2)                        | (43)                       |
| Net cash used in investing activities ......................................................................                        | (2)                        | (43)                       |
| Cash flows from financing activities:                                                                                               |                            |                            |
| Proceeds from the issuance of common stock..............................................................                            | -                          | 24,070                     |
| Common stock offering costs .......................................................................................                 | -                          | (977)                      |
| Net cash provided by financing activities .............................................................                             | -                          | 23,093                     |
| Net (decrease) increase in cash and cash equivalents ..................................................                             | (10,914)                   | 4,288                      |
| Cash and cash equivalents, beginning of year ..................................................................                     | 53,359                     | 49,071                     |
| Cash and cash equivalents, end of year ........................................................................$                    | 42,445                     | $ 53,359                   |
| Supplemental cash flow information:                                                                                                 |                            |                            |
| Interest paid...............................................................................................................$       | -                          | $ -                        |
| Income tax refund received.......................................................................................$                  | -                          | $ -                        |
| Supplemental disclosure of noncash investing and financing                                                                          |                            |                            |
| transactions:                                                                                                                       |                            |                            |
| Leased assets obtained in exchange for operating lease liabilities ...........................$                                     | -                          | $ 84                       |

---

# Page 56

# ARCA BIOPHARMA, INC.


## NOTES TO FINANCIAL STATEMENTS


## (1) The Company and Summary of Significant Accounting Policies


## Description of Business

ARCA biopharma, Inc. (the Company or ARCA), a Delaware corporation, is headquartered in Westminster, Colorado. The Company is a clinical-stage biopharmaceutical company applying a precision medicine approach to the development and commercialization of genetically targeted therapies for cardiovascular diseases. The Company's lead product candidate is Gencaro™ (bucindolol hydrochloride) for the treatment of atrial fibrillation (AF) in patients with chronic heart failure (HF).

In April 2022, the Board of Directors established a Special Committee and, in May 2022, retained Ladenburg Thalmann & Co. Inc. to evaluate strategic options, including transactions involving a merger, sale of all or part of the Company's assets, or other alternatives with the goal of maximizing stockholder value. The Company does not have a defined timeline for the strategic review process and the review may not result in any specific action or transaction.


## Liquidity and Going Concern

The Company devotes substantially all of its efforts towards obtaining regulatory approval and raising capital necessary to fund its operations and it is subject to a number of risks associated with clinical research and development, including dependence on key individuals, the development of and regulatory approval of commercially viable products, the need to raise adequate additional financing necessary to fund the development and commercialization of its products, and competition from larger companies. The Company has not generated revenue to date and has incurred substantial losses and negative cash flows from operations since its inception. The Company has historically funded its operations through issuances of common and preferred stock.

The Company believes that its current cash and cash equivalents as of December 31, 2022 will be sufficient to fund its operations through the middle of fiscal year 2024. The Company's review of its strategic options may impact this projection. Changing circumstances may cause us to consume capital significantly faster or slower than currently anticipated. The Company has based these estimates on assumptions that may prove to be wrong, and the Company could exhaust its available financial resources sooner than the Company currently anticipates. Therefore, the Company will have to raise additional capital for clinical trials of Gencaro. The Company may not be able to raise sufficient capital on acceptable terms, or at all, to continue development of Gencaro or rNAPc2 or to otherwise continue operations and may not be able to execute any strategic transaction.


The Company's liquidity, and its ability to raise additional capital or complete any strategic transaction, depends on a number of factors, including, but not limited to, the following:
- · the costs and timing for the potential additional clinical trials in order to gain possible regulatory approval for Gencaro, rNAPc2, or any other product candidate;
- · the market price of the Company's stock and the availability and cost of additional equity capital from existing and potential new investors;
- · the Company's ability to retain the listing of its common stock on the Nasdaq Capital Market;
- · general economic and industry conditions affecting the availability and cost of capital, including as a result of deteriorating market conditions due to investor concerns regarding inflation and continued hostilities between Russia and Ukraine;
- · the Company's ability to control costs associated with its operations;
- · the costs of filing, prosecuting, defending and enforcing any patent claims and other intellectual property rights; and
- · the terms and conditions of the Company's existing collaborative and licensing agreements.


The sale of additional equity or convertible debt securities would likely result in substantial additional dilution to the Company's stockholders. If the Company raises additional funds through the incurrence of indebtedness, the obligations related to such indebtedness would be senior to rights of holders of the Company's capital stock and could contain covenants that would restrict the Company's operations. The Company also cannot predict what consideration might be available, if any, to the Company or its stockholders, in connection with any strategic transaction. Should strategic alternatives or additional capital not be available to the Company, or not be available on acceptable terms, the Company may be unable to realize value from its assets and discharge its liabilities in the normal course of business which may, among other alternatives, cause the Company to further delay, substantially reduce or discontinue operational activities to conserve its cash resources.

---

# Page 57

# Basis of Presentation

The accompanying financial statements have been prepared in accordance with U.S. generally accepted accounting principles (U.S. GAAP) and include all adjustments necessary for the fair presentation of our financial position, results of operations and cash flows for the periods presented. Management has performed an evaluation of the Company's activities through the date of filing of this Annual Report on Form 10-K.


## Recent Accounting Pronouncements

The Company reviewed all other recently issued accounting pronouncements and concluded that they were either not applicable or not expected to have a significant impact to the financial statements.


## Accounting Estimates in the Preparation of Financial Statements

The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of expenses during the reporting period. The Company bases estimates on various assumptions that are believed to be reasonable under the circumstances. The Company believes significant judgment was involved in estimating the outsourcing expenses, and in estimating other accrued liabilities and income taxes. Management is continually evaluating and updating these estimates, and it is possible that these estimates will change in the future or that actual results may differ from these estimates.


## Cash Equivalents

Cash equivalents generally consist of money market funds and debt securities with maturities of 90 days or less at the time of purchase. The Company invests its excess cash in securities with strong ratings and has established guidelines relative to diversification and maturity with the objective of maintaining safety of principal and liquidity.


## Concentrations of Credit Risk

Financial instruments that potentially subject the Company to significant concentrations of credit risk consist primarily of cash and cash equivalents. The Company has no off-balance-sheet concentrations of credit risk, such as foreign exchange contracts, option contracts, or foreign currency hedging arrangements. The Company maintains cash and cash equivalent balances in the form of bank demand deposits and money market fund accounts with financial institutions that management believes are creditworthy. Such balances may at times exceed the insured amount.


## Property and Equipment

Property and equipment are stated at cost less accumulated depreciation and amortization. Cost includes expenditures for equipment, leasehold improvements, replacements, and renewals. Maintenance and repairs are charged to expense as incurred. When assets are sold, retired, or otherwise disposed of, the cost and accumulated depreciation are removed from the accounts and any resulting gain or loss is reflected in operations. The cost of property and equipment is depreciated using the straight-line method over the estimated useful lives of the related assets. Leasehold improvements are amortized over the shorter of the life of the lease or the estimated useful life of the assets.

---

# Page 58

# Comprehensive Loss

Comprehensive loss is defined as the change in equity during a period from transactions and other events and/or circumstances from non-owner sources. If the Company had comprehensive gains (losses), they would be reflected in the statement of operations and comprehensive loss and as a separate component in the statement of stockholders' equity. There were no elements of comprehensive loss during the years ended December 31, 2022 and 2021.


## Leases

The Company determines if an arrangement is a lease at inception. Operating leases are included in right-of-use (ROU) asset operating and lease obligations are included in accrued expenses and other liabilities and operating lease liability on the Company's December 31, 2022 and 2021 balance sheets.

ROU lease assets represent the Company's right to use an underlying asset for the lease term and lease obligations represent the Company's obligation to make lease payments arising from the lease. Operating ROU lease assets are recognized at the commencement date based on the present value of lease payments over the lease term. As the Company's lease does not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date in determining the present value of lease payments. The Company's lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for lease payments is recognized on a straightline basis over the lease term.


## Accrued Outsourcing Expenses

As part of the process of preparing its financial statements, the Company is required to estimate accrued outsourcing expenses. This process involves identifying services that third parties have performed on the Company's behalf and estimating the level of service performed and the associated cost incurred for these services as of the balance sheet date. Examples of estimated accrued outsourcing expenses include contract service fees, such as fees payable to contract manufacturers in connection with the production of materials related to the Company's drug product, and service fees and pass through costs from clinical research organizations. The Company develops estimates of liabilities using its judgment based upon the facts and circumstances known at the time.


## Segments

The Company operates in one segment. Management uses one measure of profitability and does not segment its business for internal reporting.


## Research and Development

Research and development costs are expensed as incurred. These consist primarily of salaries, contract services, and supplies.

Costs related to clinical trial and drug manufacturing activities are based upon estimates of the services received and related expenses incurred by contract research organizations (CROs), clinical study sites, drug manufacturers, collaboration partners, laboratories, consultants, or otherwise. Related contracts vary significantly in length, and could be for a fixed amount, a variable amount based on actual costs incurred, capped at a certain limit, or for a combination of these elements. Activity levels are monitored through communications with the vendors, including detailed invoices and task completion review, analysis of expenses against budgeted amounts, and pre-approval of any changes in scope of the services to be performed. Certain significant vendors may also provide an estimate of costs incurred but not invoiced on a periodic basis. Expenses related to the CROs and clinical studies, as well as contract drug manufacturers, are primarily based on progress made against specified milestones or targets in each period.

In accordance with certain research and development agreements, the Company is obligated to make certain upfront payments upon execution of the agreement. The Company records these upfront payments as prepaid research and development expenses, which are included in Other current assets or Other assets in the accompanying Balance Sheets. Such payments are recorded to research and development expense as services are performed. The Company evaluates on a quarterly basis whether events and circumstances have occurred that may indicate impairment of remaining prepaid research and development expenses.


## Stock-Based Compensation

The Company's stock-based compensation cost recognized is based on the estimated grant date fair value. The Company recognizes compensation costs for its stock-based awards on a straight-line basis over the requisite service period for the entire award, as adjusted for expected forfeitures.

---

# Page 59

# Income Taxes

The current benefit for income taxes represents actual or estimated amounts payable or refundable on tax returns filed or to be filed each year. Deferred tax assets and liabilities are recognized for the estimated future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carryforwards. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in the period that includes the enactment date. The overall change in deferred tax assets and liabilities for the period measures the deferred tax expense or benefit for the period. The measurement of deferred tax assets may be reduced by a valuation allowance based on judgmental assessment of available evidence if deemed more likely than not that some or all of the deferred tax assets will not be realized.


## (2) Net Loss Per Share

The Company calculates basic loss per share by dividing net loss by the weighted average common shares outstanding during the period. Diluted loss per share is computed by dividing net loss by the weighted average number of common shares outstanding during the period increased to include, if dilutive, the number of additional common shares that would have been outstanding if the potential common shares had been issued. The Company's potentially dilutive shares include stock options, restricted stock units and warrants for common stock.


Because the Company reported a net loss for the years ended December 31, 2022 and 2021, all potentially dilutive shares of common stock have been excluded from the computation of the dilutive net loss per share for all periods presented. Such potentially dilutive shares of common stock consist of the following:
|                                                                         | Years Ended December 31,   | Years Ended December 31,   |
|-------------------------------------------------------------------------|----------------------------|----------------------------|
|                                                                         | 2022                       | 2021                       |
| Potentially dilutive securities, excluded:                              |                            |                            |
| Outstanding stock options ............................................. | 704,960                    | 904,123                    |
| Unvested restricted stock units......................................   | 91,000                     | -                          |
| Warrants to purchase common stock.............................          | -                          | 133,401                    |
|                                                                         | 795,960                    | 1,037,524                  |



## (3) Fair Value Disclosures


Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (exit price). Inputs used to measure fair value are classified into the following hierarchy:
- · Level 1-Unadjusted quoted prices in active markets for identical assets or liabilities. The Company's Level 1 assets consist of money market investments. The Company does not have any Level 1 liabilities.
- · Level 2-Unadjusted quoted prices in active markets for similar assets or liabilities; unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active; or inputs other than quoted prices that are observable for the asset or liability. The Company's Level 2 assets consist of corporate bonds and commercial paper securities. The Company does not have any Level 2 liabilities.
- · Level 3-Unobservable inputs for the asset or liability. The Company does not have any Level 3 assets or liabilities.


As of December 31, 2022 and 2021, the Company had $42.4 million and $53.3 million, respectively, of cash equivalents consisting of money market funds with original maturities of 90 days or less. The Company has the ability to liquidate these investments without restriction. The Company determines fair value for these money market funds with Level 1 inputs through quoted market prices. There were no transfers between any fair value hierarchy levels in 2022 or 2021.


## Fair Value of Other Financial Instruments

The carrying amount of other financial instruments, including accounts payable, approximated fair value due to their short maturities. As of December 31, 2022 and 2021, the Company did not have any debt outstanding.

---

# Page 60

# (4) Property and Equipment


Property and equipment consist of the following (in thousands):
|                                                                    | Estimated Life   | December 31, 2022   | December 31, 2021   |
|--------------------------------------------------------------------|------------------|---------------------|---------------------|
| Computer equipment...........................................      | 3 years          | $ 39                | $ 50                |
| Lab equipment..................................................... | 5 years          | 130                 | 133                 |
| Furniture and fixtures..........................................   | 5 years          | 44                  | 44                  |
| Computer software..............................................    | 3 years          | 16                  | 16                  |
|                                                                    |                  | 229                 | 243                 |
| Accumulated depreciation and amortization.......                   |                  | (204)               | (195)               |
| Property and equipment, net ...............................        |                  | $ 25                | $ 48                |


For the years ended December 31, 2022 and 2021, depreciation and amortization expense was $20,000 and $16,000, respectively.


## (5) Related Party Arrangements

Transactions with the Company's President and Chief Executive Officer

The Company has entered into unrestricted research grants with its President and Chief Executive Officer's academic research laboratory at the University of Colorado. Funding of any unrestricted research grants is contingent upon the Company's financial condition, and can be deferred or terminated at the Company's discretion. Total expense under these arrangements for the years ended December 31, 2022 and 2021 was $432,000 and $439,000, respectively, of which $216,000 was unpaid and included in accrued expenses and other liabilities as of December 31, 2022.


## (6) Commitments and Contingencies

The Company has or is subject to the following commitments and contingencies:


## Employment Agreements and Reduction of Workforce

The Company maintains employment agreements with several key executive employees. The agreements may be terminated at any time by the Company with or without cause upon written notice to the employee, and entitle the employee to wages in lieu of notice for periods not exceeding one calendar year from date of termination without cause or by the employee for good reason. Certain of these agreements also provide for payments to be made under certain conditions related to a change in control of the Company.

In December 2022, the Company's Board of Directors approved retention bonuses for certain employees, subject to continued employment with the Company through the earlier of a change in control of the Company or certain clinical development decisions totaling $265,000, none of which was accrued as of December 31, 2022, since there had not been a change in control or clinical development decision.

In 2022, the Company implemented a strategic reduction of the workforce by approximately 67%, or 12 employees. Personnel reductions were primarily focused in research and development and general and administrative functions. The restructuring was a result of the Company's decision to manage operating costs and expenses. During the year ended December 31, 2022, the Company recorded total restructuring charges of approximately $755,000, of which $470,000 and $285,000 were recognized in research and development and general and administrative expenses, respectively, in connection with the restructuring, all in the form of one-time termination benefits. As of December 31, 2022, approximately $57,000 of the total restructuring charges remains unpaid and was included in accrued compensation and employee benefits.

---

# Page 61

# Operating Lease

On August 29, 2020 the Company entered into a lease agreement for approximately 5,200 square feet of office facilities in Westminster, Colorado which serves as the Company's primary business office effective October 1, 2020 (October 2020 Lease). The lease term is 42 months beginning October 1, 2020 and includes an option to renew for an additional 36 month term at the then prevailing rental rate. The exercise of the lease renewal option is at the Company's sole discretion. The amounts recorded assume the Company will exercise its renewal option. In June 2021, the Company entered into a sublease agreement for approximately 3,000 square feet of additional office facilities in the Company's primary business office (2021 Lease). The sublease term is 29 months beginning June 2021, with no renewal option. The leases include real estate taxes and insurance, which is not a lease component and is not included in the lease obligation. In addition, common area maintenance charges are based on actual costs incurred and are a nonlease component that is not included in the lease obligation.


Future minimum commitments due under the October 2020 Lease and 2021 Lease agreements as of December 31, 2022 are as follows (in thousands):
| 2023..............................................................................$   | 127   |
|---------------------------------------------------------------------------------------|-------|
| 2024..............................................................................    | 93    |
| 2025..............................................................................    | 96    |
| 2026..............................................................................    | 100   |
| 2027..............................................................................    | 25    |
| Total remaining lease payments ...................................                    | 441   |
| Less: imputed lease interest........................................                  | (58)  |
| Less: Current portion..................................................               | (103) |
| Operating lease liability, net of current portion............$                        | 280   |


Rent expense, which is included in general and administrative expense, under these leases for the years ended December 31, 2022 and 2021 was $125,000 and $109,000, respectively.

As of December 31, 2022, the lease liability was $383,000 and the current portion is included in accrued expenses and other liabilities and the non-current portion is in operating lease liability, net of current portion in the accompanying balance sheet. Cash paid for amounts included in the measurement of lease liabilities and the operating cash flows from operating leases for the years ended December 31, 2022 and 2021 were $131,000 and $84,000, respectively. The weighted-average remaining lease term for the operating lease as of December 31, 2022 is 3.9 years. The weighted-average discount rate for the operating lease is 7%.


## Patent Agreement

In July 2021, the Company entered into a patent assignment agreement (the Agreement) with the University Medical Center of Johannes Gutenberg University Mainz, Germany.

Under the terms of the Agreement, the Company received exclusive world-wide patent rights relating to the use of rNAPc2 as a potential treatment for COVID-19, and other indications, based on the research and discoveries from Univ.-Prof. Dr. Wolfram Ruf, the Scientific Director and Alexander von Humboldt Professor at the Center for Thrombosis and Hemostasis (CTH) of the University Medical Center Mainz, and his collaborators. The Company has upfront and potential milestone obligations to the University Medical Center Mainz that could total approximately €1.6 million and royalty obligations in the low single digit range, if rNAPc2 receives regulatory approval and is commercialized. The term of the Agreement extends to the date of expiration of the last to expire of any of the assigned patents.


## Gencaro License

ARCA has licensed worldwide rights to all preclinical and clinical data through the BEST trial for development of bucindolol. The patents that were the subject of this license are expired. If the license agreement is deemed enforceable, the Company would incur milestone and royalty obligations upon the occurrence of certain events, including if the FDA grants marketing approval for Gencaro, upon regulatory marketing approval in Europe and Japan and based on achievement of specified product sales levels.

---

# Page 62

# (7) Equity Financings


## At the Market Equity Financing

On July 22, 2020, the Company entered into a Capital on Demand  TM  Sales Agreement (the Sales Agreement) with JonesTrading Institutional Services LLC, as agent (JonesTrading), pursuant to which the Company may offer and sell, from time to time through JonesTrading, shares of the Company's common stock, par value $0.001 per share (the Common Stock), having an aggregate offering price of up to $54.0 million (the Shares).

Under the Sales Agreement, JonesTrading may sell the Shares by any method permitted by law and deemed to be an 'at the market offering' as defined in Rule 415 promulgated under the Securities Act of 1933, as amended, including sales made directly on or through the Nasdaq Capital Market, on any other existing trading market for the Common Stock or to or through a market maker. In addition, under the amended Sales Agreement, JonesTrading may sell the Shares by any other method permitted by law, including in negotiated transactions. The Company may instruct JonesTrading not to sell Shares if the sales cannot be effected at or above the price designated by the Company from time to time.

The Company is not obligated to make any sales of the Shares under the Sales Agreement. The offering of Shares pursuant to the Sales Agreement will terminate upon the earlier of (a) the sale of all of the Shares subject to the Sales Agreement or (b) the termination of the Sales Agreement by JonesTrading or the Company, as permitted therein.

The Company paid JonesTrading a commission rate equal to 3.0% of the aggregate gross proceeds from each sale of Shares and agreed to provide JonesTrading with customary indemnification and contribution rights. The Company will also reimburse JonesTrading for certain specified expenses in connection with entering into the Sales Agreement.

No sales were made in 2022. During the year ended December 31, 2021, the Company had sold an aggregate of 4,861,993 shares of its Common Stock pursuant to the terms of the Sales Agreement for net proceeds of approximately $23.3 million, after deducting expenses for executing the 'at the market offering' and commissions paid to the placement agent.

In April 2021, the Company amended the 2020 Sales Agreement and the amount available for the offering under its prospectus to the Company's registration statement on Form S-3 (No. 333-254585). The amount available for the offering under the prospectus supplement is subject to the limitation of not selling a total value amount of shares exceeding more than one-third of the Company's public float in any 12-month period.


## (8) Share-based Compensation


## Stock Plans

The Company's equity incentive plan, the 2020 Equity Incentive Plan (the Equity Plan), was approved by stockholders on December 10, 2020. The maximum number of shares issuable under this plan is 1,167,425 shares.

The Equity Plan provides for the granting of stock options (including indexed options), restricted stock units, stock appreciation rights, restricted stock purchase rights, restricted stock bonuses, performance shares, performance units and deferred stock units. Under the Equity Plan, awards may be granted to employees, directors and consultants of ARCA, except for incentive stock options, which may be granted only to employees. As of December 31, 2022, options to purchase 684,400 shares with a weighted average exercise price of $3.47 per share were outstanding under the Equity Plan, and 371,487 shares were reserved for future awards.

In general, the Equity Plan authorizes the grant of stock options that vest at rates set by the Board of Directors or the Compensation Committee thereof. Generally, stock options granted by ARCA under the equity incentive plans become exercisable ratably for a period of three to four years from the date of grant and have a maximum term of ten years. The exercise prices of stock options under the equity incentive plan generally meet the following criteria: the exercise price of incentive stock options must be at least 100% of the fair market value on the grant date and exercise price of options granted to 10% (or greater) stockholders must be at least 110% of the fair market value on the grant date.

In conjunction with the adoption of the Equity Plan, the Company discontinued grants under the 2013 Plan, effective December 10, 2020. In conjunction with the adoption of the 2013 Plan, the Company discontinued grants under its previous plan the Amended and Restated ARCA biopharma, Inc. 2004 Equity Incentive Plan (the 2004 Plan), effective September 17, 2013. As of December 31, 2022, options to purchase 20,538 shares with a weighted average exercise price of $77.12 per share were outstanding under the 2013 plan. The 2004 Plan expired in 2014; however, options outstanding under the 2004 plan will continue to vest according to the original terms of each grant. As of December 31, 2022, options to purchase 22 shares with a weighted average exercise price of $172.79 per share were outstanding under the 2004 plan.

---

# Page 63

The Company granted options to purchase an aggregate of 60,000 and 433,700 shares of common stock in the years ended December 31, 2022 and 2021, respectively. The fair values of employee stock options granted in the years ended December 31, 2022 and 2021 were estimated at the date of grant using the Black-Scholes model with the following assumptions and had the following estimated weighted average grant date fair value per share:
|                                                                            | Year Ended December 31,   | Year Ended December 31,   |
|----------------------------------------------------------------------------|---------------------------|---------------------------|
|                                                                            | 2022                      | 2021                      |
| Expected term............................................................. | 5.5 years                 | 5.9 years                 |
| Expected volatility......................................................  | 107%                      | 94%                       |
| Risk-free interest rate .................................................  | 3.56%                     | 1.08%                     |
| Expected dividend yield .............................................      | 0%                        | 0%                        |
| Weighted-average grant date fair value per share ......                    | $ 1.87                    | $ 2.09                    |



A summary of ARCA's stock option activities for the years ended December 31, 2022 and 2021, and related information as of December 31, 2022, is as follows:
|                                                             | Options Outstanding   | Options Outstanding                | Options Outstanding                                         | Options Outstanding                       |
|-------------------------------------------------------------|-----------------------|------------------------------------|-------------------------------------------------------------|-------------------------------------------|
|                                                             | Number of Options     | Weighted  Average  Exercise  Price | Weighted  Average  Remaining  Contractual  Term  (in years) | Aggregate  Intrinsic Value (in thousands) |
| Options outstanding - December 31,                          |                       |                                    |                                                             |                                           |
| 2020 ...................................................... | 531,238               | $ 8.71                             |                                                             |                                           |
| Granted .................................................   | 433,700               | 2.77                               |                                                             |                                           |
| Exercised...............................................    | -                     | -                                  |                                                             |                                           |
| Forfeited and cancelled.........................            | (60,815)              | 12.71                              |                                                             |                                           |
| Options outstanding - December 31,                          |                       |                                    |                                                             |                                           |
| 2021 ...................................................... | 904,123               | $ 5.59                             | 9.18                                                        | $ -                                       |
| Granted .................................................   | 60,000                | 2.31                               |                                                             |                                           |
| Exercised...............................................    | -                     | -                                  |                                                             |                                           |
| Forfeited and cancelled.........................            | (259,163)             | 4.74                               |                                                             |                                           |
| Options outstanding - December 31,                          |                       |                                    |                                                             |                                           |
| 2022 ...................................................... | 704,960               | $ 5.62                             | 8.29                                                        | $ 18                                      |
| Options exercisable - December 31,                          |                       |                                    |                                                             |                                           |
| 2022 ...................................................... | 308,237               | $ 8.69                             | 7.90                                                        | $ 5                                       |
| Options vested and expected to vest -                       |                       |                                    |                                                             |                                           |
| December 31, 2022........................                   | 704,803               | $ 5.62                             | 8.29                                                        | $ 18                                      |


The aggregate intrinsic value in the table above represents the total intrinsic value, based on our closing price as of December 31 of the respective year, which would have been received by the option holders had all the option holders with in-the-money options exercised as of that date. As of December 31, 2022, the unrecognized compensation expense related to unvested options, excluding estimated forfeitures, was $971,000 which is expected to be recognized over a weighted average period of 1.9 years. The Company recognizes compensation costs for its share-based awards on a straight-line basis over the requisite service period for the entire award, as adjusted for expected forfeitures.

---

# Page 64

# Restricted Stock Units

The Company granted restricted stock units (RSUs) under the Equity Plan to employees during 2022.The fair value of RSU awards is the closing price of the Company's common stock on the date of the grant and is recognized as compensation expense on a straightline basis over the respective vesting period. The stock awards granted have a requisite service period of one year.


A summary of RSU activity for the year ended December 31, 2022 is presented below:
|                                                                   | Restricted Stock Units Outstanding Weighted Average   | Restricted Stock Units Outstanding Weighted Average   |
|-------------------------------------------------------------------|-------------------------------------------------------|-------------------------------------------------------|
|                                                                   | Number of Shares                                      | Grant Date Fair Value                                 |
| RSUs outstanding - December 31, 2021.......                       | -                                                     | $ -                                                   |
| Granted.......................................................... | 91,000                                                | 2.21                                                  |
| Vested and released.......................................        | -                                                     | -                                                     |
| Forfeited and cancelled .................................         | -                                                     | -                                                     |
| RSUs outstanding - December 31, 2022.......                       | 91,000                                                | $ 2.21                                                |


As of December 31, 2022, the total unrecognized compensation cost related to unvested stock awards was approximately $188,000. This cost will be recognized on a straight-line basis over the next 0.9 years and will be adjusted for estimated forfeitures.


## Non-cash Stock-based Compensation


For the years ended December 31, 2022 and 2021, the Company recognized the following non-cash, share-based compensation expense (in thousands):
| Years Ended December 31,                                      | Years Ended December 31,   |
|---------------------------------------------------------------|----------------------------|
| 2022                                                          | 2021                       |
| Research and development................$ 133                 | $ 160                      |
| General and administrative ............... 423                | 337                        |
| Total ..................................................$ 556 | $ 497                      |


ARCA did not recognize any tax benefit related to employee stock-based compensation cost as a result of the full valuation allowance on its net deferred tax assets.


## (9) Employee Benefit Plans

The Company has a 401(k) plan and makes a matching contribution equal to 100% of the employee's first 3% of the employee's contributions and 50% of the employee's next 2% of contributions. The Company adopted the plan in 2006 and contributed $96,000 and $118,000 for the years ended December 31, 2022 and 2021, respectively.


## ( 10) Income Taxes

Effective June 1, 2005, the Company changed from an S-Corporation to a C-Corporation. As an S-Corporation, the net operating loss carryforwards were distributed to the Company's stockholders; such amounts were not significant. As of December 31, 2022, the Company has net operating loss carryforwards of approximately $203.3 million, and approximately $2.4 million of research and development credits that may be used to offset future taxable income. The Company's net operating loss carryforwards through December 31, 2017 will expire beginning 2025 through 2037. The net operating loss carryforwards beginning in 2018, have no expiration. Utilization of net operating losses and tax credits, including those acquired as a result of the Merger, will be subject to an annual limitation due to ownership change limitations provided by Internal Revenue Code Section 382. The Company believes that an ownership change limitation as defined under Section 382 of the U.S. Internal Revenue Code occurred as a result of its various historical financing transactions. Future utilization of the federal net operating losses and tax credit carryforwards accumulated from June 2005 to the change in ownership date will be subject to annual limitations to offset future taxable income. The annual limitation may result in the expiration of the net operating losses and credits before utilization. As such, a portion of the Company's net operating loss carryforwards may be limited.

---

# Page 65

In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the period in which those temporary differences become deductible. Management considers the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment. Due primarily to the Company's history of operating losses, management is unable to conclude that it is more likely than not that the Company will realize the benefits of these deductible differences, and accordingly has provided a valuation allowance against the entire net deferred tax assets and liabilities of approximately $54.4 million at December 31, 2022, reflecting an increase of approximately $2.3 million from December 31, 2021. The deferred tax assets are primarily comprised of net operating loss carryforwards and research and experimentation credit carryforwards. As of December 31, 2022, the Company has not performed an Internal Revenue Code Section 382 limitation study. Depending on the outcome of such a study, the gross amount of net operating losses recognizable in future tax periods could be limited. A limitation in the carryforwards would decrease the carrying amount of the gross amount of the net operating loss carryforwards, with a corresponding decrease in the valuation allowance recorded against these gross deferred tax assets.


Income tax benefit attributable to the Company's loss from operations before income taxes differs from the amounts computed by applying the U.S. federal statutory income tax rate of 21% for 2022 and 2021, as a result of the following (in thousands):
|                                                                                                         | Years ended December 31,   | Years ended December 31,   |
|---------------------------------------------------------------------------------------------------------|----------------------------|----------------------------|
|                                                                                                         | 2022                       | 2021                       |
| U.S. federal income tax benefit at statutory rates .............................$                       | (2,085)                    | $ (4,058)                  |
| State income tax benefit, net of federal benefit.................................                       | (357)                      | (695)                      |
| Research and experimentation credits...............................................                     | -                          | (560)                      |
| Deferred tax asset adjustment ...........................................................               | 2                          | -                          |
| Other.................................................................................................. | 186                        | 185                        |
| Change in valuation allowance .........................................................                 | 2,254                      | 5,128                      |
| Income tax benefit.............................................................................$        | -                          | $ -                        |



Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting and the amounts used for income tax purposes, as well as operating loss and tax credit carryforwards. The income tax effects of temporary differences and carryforwards that give rise to significant portions of the Company's net deferred tax assets and liabilities consisted of the following (in thousands):
|                                                                                              | As of December 31,   | As of December 31,   |
|----------------------------------------------------------------------------------------------|----------------------|----------------------|
|                                                                                              | 2022                 | 2021                 |
| Deferred tax assets:                                                                         |                      |                      |
| Net operating loss carryforwards ...............................................$            | 50,008               | $ 48,520             |
| Charitable contribution carryforwards.......................................                 | 393                  | 443                  |
| Research and experimentation credits........................................                 | 2,420                | 2,420                |
| Capitalized research and development costs..............................                     | 979                  | -                    |
| Capitalized intangibles...............................................................       | 356                  | 387                  |
| Stock-based compensation.........................................................            | 205                  | 152                  |
| Accrued compensation...............................................................          | 6                    | 196                  |
| Lease liabilities .......................................................................... | 94                   | 119                  |
| Total deferred tax assets...............................................................     | 54,461               | 52,237               |
| Valuation allowance.....................................................................     | (54,372)             | (52,118)             |
| Deferred tax assets, net of valuation allowance...........................                   | 89                   | 119                  |
| Deferred tax liabilities:                                                                    |                      |                      |
| Right-of-use asset.......................................................................    | (84)                 | (107)                |
| Depreciation and amortization...................................................             | (5)                  | (12)                 |
| Net deferred tax liability ..............................................................$   | -                    | $ -                  |


Since the Company is in a loss carryforward position, the Company is generally subject to U.S. federal and state income tax examinations by tax authorities for all years for which a loss carryforward is available. Thus, the Company's open tax years extend back to 2009. The Company believes that its tax filing positions and deductions related to tax periods subject to examination will be sustained upon audit and does not anticipate any adjustment will result in a material adverse effect on the Company's financial condition, result of operations, or cash flow. For the years ended December 31, 2022 and 2021, the Company has no reserve for

---

# Page 66

uncertain tax positions. The Company does not expect that the total amounts of unrecognized tax benefits will significantly increase or decrease within the subsequent twelve months. In the event the Company concludes it is subject to interest or penalties arising from uncertain tax positions, the Company will record interest and penalties as a component of other income and expense. No interest or penalties were recognized in the financial statements for the years ended December 31, 2022 and 2021.


# ( 11) Subsequent Event

The Company and Christopher D. Ozeroff, the Secretary, Senior Vice President and General Counsel of ARCA have mutually agreed to conclude Mr. Ozeroff's employment effective March 31, 2023. Pursuant to Mr. Ozeroff's existing employment agreement, as previously amended, ARCA will provide Mr. Ozeroff severance benefits pursuant to the terms of his existing employment agreement with the Company, as previously amended. The severance benefits include severance payments and reimbursement to cover out-ofpocket costs to continue group health insurance benefits under COBRA, whether he elects or is eligible to receive COBRA (provided, that even if he does not elect or is not eligible to receive COBRA, he will receive the equivalent of such out-of-pocket expenses paid by him not to exceed the costs that the benefits would equal under COBRA if he were so eligible) and will be recorded in the first quarter of 2023. The severance benefits are conditioned on the execution by Mr. Ozeroff of a legal release of claims.

---

# Page 67

# Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure

Not applicable.


## Item 9A. Controls and Procedures


## Evaluation of Disclosure Controls and Procedures

Under the supervision and with the participation of management, including our Principal Executive Officer and our Principal Financial Officer, we have evaluated the effectiveness of the design and operation of our disclosure controls and procedures (as defined in Exchange Act Rule 13a-15(e) and 15d-15(e)). Based on this evaluation, our Principal Executive Officer and Principal Financial Officer have concluded that our disclosure controls and procedures were effective as of the end of the period covered by this annual report.


## Management's Report on Internal Control over Financial Reporting

Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rules 13a-15(f) and 15(d)-15(f) under the Exchange Act). Our internal control system is designed to provide reasonable assurance to management and our board of directors regarding the preparation and fair presentation of published financial statements.

Because of its inherent limitations, internal control over financial reporting may not prevent or detect all misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

Under the supervision and with the participation of management, including our Principal Executive Officer and Principal Financial Officer, we have assessed the effectiveness of our internal control over financial reporting as of December 31, 2022. In making our assessment of internal control over financial reporting, we used the criteria issued in the report Internal Control-Integrated Framework (2013) by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). We have concluded that our internal control over financial reporting was effective as of December 31, 2022 based on these criteria.

This annual report does not include an attestation report of our independent registered public accounting firm regarding internal control over financial reporting. Management's report was not subject to attestation by our independent registered public accounting firm pursuant to the exemption from Section 404(b) of the Sarbanes-Oxley Act for non-accelerated filers provided by the Dodd-Frank Wall Street Reform and Consumer Protection Act.


## Changes in Internal Control over Financial Reporting

During the fourth quarter of 2022, there were no changes in our internal control over financial reporting that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.


## Limitations on the Effectiveness of Controls

Our management, including our Principal Executive Officer and Principal Financial Officer, does not expect that our disclosure controls and procedures or our internal control over financial reporting will prevent all errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within our company have been detected.


## Item 9B. Other Information

None


## Item 9C. Disclosure Regarding Foreign Jurisdictions that Prevent Inspections

Not applicable

---

# Page 68

# PART III


## Item 10. Directors, Executive Officers and Corporate Governance


Our directors, executive officers and key employees as of February 15, 2023 are as follows:
| Name                              |   Age | Position                                                         |
|-----------------------------------|-------|------------------------------------------------------------------|
| Dr. Michael R. Bristow            |    78 | President and Chief Executive Officer and Class II  Director (5) |
| Thomas A. Keuer                   |    64 | Chief Operating Officer                                          |
| Christopher D. Ozeroff †          |    64 | Secretary, Senior Vice President and General Counsel             |
| C. Jeffrey Dekker                 |    58 | Chief Financial Officer                                          |
| Dr. Linda Grais (1) (2)* (4)      |    66 | Class I Director (5)                                             |
| Dr. Raymond L. Woosley (2) (3)*   |    80 | Class III Director (5)                                           |
| Mr. Robert E. Conway (1)* (2) (4) |    69 | Class II Director (5)                                            |
| Mr. Dan J. Mitchell (1) (3)       |    65 | Class III Director (5)                                           |
| Dr. Anders Hove (3) (4)           |    57 | Class I Director (5)                                             |
| Mr. Jacob Ma-Weaver (4)           |    35 | Class III Director (5)                                           |
| Mr. James Flynn                   |    42 | Class I Director (5)                                             |
† Mr. Ozeroff and the Company have mutually agreed to conclude Mr. Ozeroff's employment effective March 31, 2023.
* Committee Chairperson
(1) Member of the Audit Committee of the Board of Directors
(2) Member of the Compensation Committee of the Board of Directors
(3) Member of the Nominating and Corporate Governance Committee of the Board of Directors
(4) Member of the Special Committee of the Board of Directors
(5) See 'Election of Board of Directors' below for discussion of Class I - III Director service terms.


Michael R. Bristow, M.D., Ph.D. Dr. Bristow was one of the founders of ARCA in September 2004, and has served as a Director since that time. Dr. Bristow has also served as the Company's President and Chief Executive Officer since July 2009. Previously, Dr. Bristow served as the President and Chief Executive Officer of the Company from September 2004 to November 2006, and as the Company's Chief Science and Medical Officer from November 2006 to July 2009. Dr. Bristow is a Professor of Medicine and the former Head of Cardiology at the University of Colorado Health Sciences Center, where he has been since October 1991. Dr. Bristow was one of the founders of Myogen, Inc. and served as Myogen's Chief Science and Medical Officer from October 1996 to February 2006 and as a Scientific Advisor to Myogen from February 2006 until the acquisition of Myogen by Gilead Sciences, Inc. in November 2006. We believe Dr. Bristow is an appropriate member of the Company's Board of Directors given his extensive experience and expertise as a cardiologist, medical researcher and drug developer in the field of cardiovascular medicine, and heart failure specifically, and his experience as a founder and manager of a cardiovascular-focused, public pharmaceutical company. Dr. Bristow also has extensive experience with, and knowledge of, ARCA's business, as the founder and former Chief Science and Medical Officer of the Company, and the current President and Chief Executive Officer of ARCA, and as a member of the Board of Directors of ARCA since the founding of the Company. Dr. Bristow holds a M.D. and Ph.D. from the University of Illinois.

Thomas A. Keuer . Mr. Keuer has served as the Company's Chief Operating Officer since December 2014. Mr. Keuer served as the Company's Executive Vice President, Pharmaceutical Operations from 2006 to 2014. Prior to joining the Company, Mr. Keuer served as the SVP of Operations for Insmed, Inc. from 2004 to 2006. Prior to Insmed, Mr. Keuer served as the VP of Engineering for Baxter Healthcare from 1998 to 2004. Prior to Baxter, Mr. Keuer served as the VP of Operations for Somatogen, Inc. Mr. Keuer received his M.S. in Biochemical Engineering from Rice University and received his B.S. in Chemical Engineering from the University of Texas, Austin.

Christopher D. Ozeroff . Mr. Ozeroff is a co-founder of ARCA. Mr. Ozeroff has served as the Company's Senior Vice President, General Counsel and Secretary since 2009, has served as the Company's General Counsel and Secretary since the Company's founding, and has also served as Executive Vice President, Business Development from 2004 to 2009. Prior to joining the Company, Mr. Ozeroff was a partner with the law firm of Hogan & Hartson L.L.P., where he practiced in such areas as finance, acquisitions, public offerings, and licensing. Mr. Ozeroff completed his undergraduate degree at Stanford University and his law degree at the University of Chicago Law School. The Company and Mr. Ozeroff have mutually agreed to conclude Mr. Ozeroff's employment effective March 31, 2023. Mr. Ozeroff's departure is not the result of any disagreement with the Company on any matter relating to its operations, policies or practices, or regarding the general direction of the company.

C. Jeffrey Dekker . Mr. Dekker has served as the Company's Chief Financial Officer since May 2021. Prior to joining the Company, Mr. Dekker served in multiple roles of increasing responsibility at GlobeImmune, Inc. from 2006 to 2021, including

---

# Page 69

President, Vice President of Finance, and Senior Director, Finance and Controller. Before joining GlobeImmune, Mr. Dekker held leadership positions in finance and accounting at private software companies since 1993, including posts ranging from Corporate Controller to Vice President at Webroot Software Inc., Requisite Technology Inc. and NxTrend Technology Inc. Earlier in his career, Mr. Dekker worked at ITT Rayonier Port Angeles Pulp Division and at KPMG in Los Angeles. He earned a B.S. in accounting from Utah State University and is a certified public accountant.

Linda Grais, M.D. Dr. Grais has served as a member of the Board of Directors since May 2007. Dr. Grais has been a director of Ocera Therapeutics, Inc., a public biopharmaceutical company, since January 2008 and became President and Chief Executive Officer of Ocera in June 2012, and served in that role until Ocera's acquisition by Mallinckrodt Pharmaceuticals in December 2017. Dr. Grais served as a Managing Member at InterWest Partners, a venture capital firm from May 2005 until February 2011. From July 1998 to July 2003, Dr. Grais was a founder and executive vice president of SGX Pharmaceuticals Inc., a drug discovery company. Prior to that, she was a corporate attorney at Wilson Sonsini Goodrich & Rosati, where she practiced in such areas as venture financings, public offerings and strategic partnerships. Before practicing law, Dr. Grais worked as an assistant clinical professor of Internal Medicine and Critical Care at the University of California, San Francisco. Dr. Grais received a B.A. from Yale University, magna cum laude, and Phi Beta Kappa, an M.D. from Yale Medical School and a J.D. from Stanford Law School. Since September 2015, Dr. Grais served on the board of PRA Health Sciences, which was acquired by ICON plc in 2021, a public contract research organization, and currently serves on the board of ICON plc. Dr. Grais also joined the board of Corvus Pharmaceuticals., a publicly traded pharmaceutical company, in January 2019. We believe Dr. Grais is an appropriate member of the Board of Directors because of her diverse training and experience as both a medical doctor and a lawyer, her experience as a founder and senior executive of a pharmaceutical company, and her experience as an investor in new life sciences companies. She also has extensive experience with and knowledge of the Company's business from her service on the Board of Directors of the Company since 2007.

Raymond L. Woosley, M.D., Ph.D. Dr. Woosley was appointed to the Board of Directors in July 2013. Since 2012, Dr. Woosley has been the Director of the Arizona Center for Education and Research on Therapeutics, an independent, nonprofit research and education organization. Dr. Woosley is currently the President Emeritus of the Critical Path Institute, a non-profit, public-private partnership with the Federal Food and Drug Administration, of which he was a founder in November 2004, and where he served as President, Chief Executive Officer and Chairman of the board of directors from 2005 to 2011. Since 2001, Dr. Woosley has also been a Professor of Medicine and Pharmacology at The University of Arizona Health Sciences Center, and, since 2012, Professor Emeritus, where he was also Vice President for Health Sciences from 2001 to 2005, and Dean of the College of Medicine from 2001 to 2002. Since 2015, he has been Professor of Medicine in the University of Arizona, College of Medicine-Phoenix. From 1988 to 2001, Dr. Woosley was a professor of medicine at the Georgetown University School of Medicine, where he was also Director of the Institute of Cardiovascular Sciences from 1994 to 2000, and Division Chief, Clinical Pharmacology, in the Department of Medicine from 1988 to 1994. Dr. Woosley earned his Ph.D. in Pharmacology from the University of Louisville and his M.D. from the University of Miami. We believe Dr. Woosley is an appropriate member of the Board of Directors, given his expertise and experience in cardiovascular clinical pharmacology, anti-arrhythmic therapeutics, pharmacogenetic drug development and therapeutic regulatory approval.

Robert E. Conway Mr. Conway was appointed to the Board of Directors in September 2013, and has served as the Chairman of our Board of Directors since 2014. Mr. Conway served as the Chief Executive Officer and member of the board of directors of Array Biopharma, a publicly traded biopharmaceutical company, from 1999 to 2012. Prior to joining Array, Mr. Conway was the Chief Operating Officer and Executive Vice President of Hill Top Research, Inc., from 1996 to 1999. From 1979 until 1996, Mr. Conway held various executive positions for Corning Inc. including Corporate Vice President and General Manager of Corning Hazleton, Inc., a contract research organization. From 2004 to 2013, he served on the board of directors of PRA International, Inc., which was a public company for a portion of his tenure there, from 2012 to the present, he has served on the board of directors of eResearch Technology, Inc., a private company, and from 2015 to July 2017, Advarra, Inc. from 2019 to August 2022, and he has served on the board of directors of Nivalis Therapeutics, Inc. a public, clinical stage pharmaceutical company. In July 2017, Nivalis Therapeutics, Inc. combined with Alpine Immune Sciences, Inc., a public, clinical stage pharmaceutical company, and Mr. Conway continues to serve on the board of directors following such combination. In addition, Mr. Conway is a member of the Strategic Advisory Committee of Genstar Capital, LLC and is a member of the board of directors of Signant Health. Mr. Conway received a B.S. in accounting from Marquette University in 1976. We believe Mr. Conway is an appropriate member of the Board of Directors given his experience and expertise in the pharmaceutical industry, in pharmaceutical development and clinical trials, and in corporate finance, governance, accounting and public company compliance.

Dan J. Mitchell Mr. Mitchell was appointed to the Board of Directors in February 2014. He founded, and was a manager of Sequel Venture Partners, L.L.C., a venture capital firm formed in January 1997. Prior to founding Sequel Venture Partners, Mr. Mitchell was a founder of Capital Health Venture Partners, a health care focused venture capital firm, where he was a General Partner from October 1986 until 2006, and he was in the Venture Capital Division of the Trust Department of the First National Bank of Chicago from 1983 to 1985. He currently serves on the board of directors of several private companies. Mr. Mitchell holds a B.S. from the University of Illinois and an M.B.A. from the University of California at Berkeley. We believe Mr. Mitchell is an appropriate member of the Board of Directors given his expertise and experience in the pharmaceutical industry, pharmaceutical development, and in corporate finance and governance.

---

# Page 70

Anders Hove, M.D. Dr. Hove has served as a member of the Board of Directors since February 2017. Dr. Hove is the manager of Acorn Bioventures, a partnership focusing on long-term investments in biotech, specialty pharma and medical device companies. Dr. Hove was recently a general partner of Venrock Associates, a venture capital firm, which he joined in 2004 and remained at through 2016. In 2008, Dr. Hove was a founder of Venrock Healthcare Capital Partners, Venrock's public funds focused on small capitalization biotech companies and late-stage private companies. From 1996 to 2004, Dr. Hove was a fund manager at BB Biotech Fund, an investment firm, and from 2002 to 2003 he also served as Chief Executive Officer of Bellevue Asset Management, an investment company. Dr. Hove previously held senior level positions in the medical, clinical and business operations of the pharmaceuticals division of Ciba-Geigy and Novartis. Mr. Hove was a member of the boards of directors of Anacor Pharmaceuticals, a publicly traded pharmaceutical company, from 2005 until its acquisition by Pfizer in June 2016, and Edge Therapeutics, a publicly traded biotechnology company, from 2015 to 2016. In addition, Dr. Hove is a member of the board of directors of MC2 Therapeutics. He received a M.Sc. in Biotechnology Engineering from the Technical University of Denmark, an M.D. from the University of Copenhagen and an M.B.A. from the Institut Européen d'Administration des Affaires. We believe Dr. Hove is an appropriate member of the Company's Board of Directors, given his extensive training and experience as a medical doctor and masters of business administration, an executive in the pharmaceutical industry, and as an investor in biotechnology companies.

Jacob Ma-Weaver Mr. Ma-Weaver was appointed to the Board of Directors in June 2022. He is the Managing Member of Cable Car Capital LLC, an investment adviser he founded in 2013. Cable Car Capital LLC is the General Partner of Funicular Funds, LP, a hedge fund. From 2012 to 2013, Mr. Ma-Weaver was employed as an investment analyst at Amici Capital LLC, where he focused on healthcare. He was previously employed as an equity research associate at Dodge & Cox and a corporate finance business analyst at McKinsey & Company. Mr. Ma-Weaver received a Bachelor of Arts in Comparative Literature & Society and Economics and a Master of Arts in Statistics from Columbia University. He is a Chartered Financial Analyst (CFA) charterholder. We believe Mr. Ma-Weaver is an appropriate member of the Board of Directors because of his experience as an investor in life sciences companies, an analyst for investment firms and his academic background.

James Flynn Mr. Flynn was appointed to the Board of Directors in December 2022. Mr. Flynn is currently a Managing Member and Portfolio Manager of Nerium Capital LLC, an investment adviser he founded in 2021. Nerium Capital LLC is the General Partner of Nerium Partners LP, a healthcare focused investment partnership. Mr. Flynn also currently serves as a Board Member for Axiom Health, a provider of software and big-data solutions to the healthcare industry, since 2022, and has been an advisor to the company since 2020. From 2017 to 2018, Mr. Flynn worked as a therapeutics analyst at Aptigon Capital (a Citadel Company), an investment firm. Prior to that, from 2003 to 2017, Mr. Flynn served in various roles at Amici Capital, LLC, an investment firm, including healthcare portfolio manager (2008 to 2017). From 2002 to 2003, Mr. Flynn worked in the credit research/high yield group at Putnam Investments, an investment firm. Mr. Flynn earned a S.B. degree in Management Science with a concentration in Finance and a minor in Economic Science from the Massachusetts Institute of Technology (MIT). Mr. Flynn is a Chartered Financial Analyst (CFA) charterholder. We believe Mr. Flynn is an appropriate member of the Board of Directors because of his experience as an investor in life sciences companies, an analyst for investment firms and his academic background.


## ADDITIONAL INFORMATION REGARDING THE BOARD OF DIRECTORS AND CORPORATE GOVERNANCE


## Election of Board of Directors

Directors are elected by a plurality of the votes of the holders of shares present in person or represented by proxy and entitled to vote on the election of directors at our annual stockholders' meetings. The Company's Amended and Restated Certificate of Incorporation, as amended, provides that the Board of Directors is divided into three classes to provide for staggered terms and that each director will serve for a term of three years or less, depending on the class to which the Board of Directors has assigned a director not previously elected by the stockholders. There are currently two Class II directors whose terms expire at the annual meeting in 2023, three Class III directors whose terms expire at the annual stockholders' meeting in 2024 and three Class I directors whose terms expire at the annual stockholders' meeting in 2025. The two Class II directors, Dr. Michael Bristow and Robert Conway, are currently scheduled for re-election to the Board of Directors at the 2023 annual stockholders' meeting, for a three-year term ending on the date of the annual meeting in 2026 or until their successors are duly elected and qualified or appointed.

Our executive officers are appointed by and serve at the discretion of our Board of Directors. There are no family relationships between our directors and executive officers.

---

# Page 71

# Code of Ethics

The Company has adopted the ARCA biopharma, Inc. Code of Business Conduct and Ethics that applies to all officers, directors and employees. The Code of Business Conduct and Ethics is available on the Company's website at www.arcabiopharma.com. If the Company makes any substantive amendments to the Code of Business Conduct and Ethics or grants any waiver from a provision of the Code of Business Conduct and Ethics to any executive officer or director, the Company will promptly disclose the nature of the amendment or waiver on its website and file any current report on Form 8-K required by applicable law or Nasdaq listing standards.


## Audit Committee

The Audit Committee of the Board of Directors, or the Audit Committee, was established by the Board of Directors in accordance with Section 3(a)(58)(A) of the Exchange Act, to oversee the Company's corporate accounting and financial reporting processes and audits of its financial statements. For this purpose, the Audit Committee performs several functions. The Audit Committee evaluates the performance of and assesses the qualifications of the independent registered public accounting firm; determines and approves the engagement of the independent registered public accounting firm; determines whether to retain or terminate the existing independent registered public accounting firm or to appoint and engage a new independent registered public accounting firm; reviews and approves the retention of the independent registered public accounting firm to perform any proposed permissible non-audit services; monitors the rotation of partners of the independent registered public accounting firm on the Company's audit engagement team as required by law; reviews and approves or rejects transactions between the company and any related persons; confers with management and the independent registered public accounting firm regarding the effectiveness of internal controls over financial reporting; establishes procedures, as required under applicable law, for the receipt, retention and treatment of complaints received by the Company regarding accounting, internal accounting controls or auditing matters and the confidential and anonymous submission by employees of concerns regarding questionable accounting or auditing matters; and meets to review the Company's annual audited financial statements and quarterly financial statements with management and the independent registered public accounting firm, including a review of the Company's disclosures under the 'Management's Discussion and Analysis of Financial Condition and Results of Operations' discussion in its Annual Reports on Form 10-K and Quarterly Reports on Form 10-Q. As of December 31, 2022, the Audit Committee was composed of three directors: Mr. Conway (chair), Mr. Mitchell and Dr. Grais. The Audit Committee met four times during the fiscal year. The Board of Directors has adopted a written charter of the Audit Committee that is available to stockholders on the Company's website at www.arcabio.com.

The Board of Directors reviews the Nasdaq listing standards definition of independence for audit committee members on an annual basis and has determined that all members of the Audit Committee are independent (as independence is currently defined in Rule 5605(c)(2)(A)(i) and (ii) of the Nasdaq listing standards).   The Board of Directors has also determined that Mr. Conway qualifies as an 'audit committee financial expert,' as defined in applicable SEC rules. The Board of Directors made a qualitative assessment of Mr. Conway's level of knowledge and experience based on several factors, including his prior experience, business acumen and independence.


## Report of the Audit Committee of the Board of Directors 1

The Audit Committee has reviewed and discussed the audited financial statements for the fiscal year ended December 31, 2022, with management of the Company. The Audit Committee has discussed with the independent registered public accounting firm the matters required to be discussed by Public Company Accounting Oversight Board, or PCAOB, Auditing Standard No. 1301, Communications with Audit Committees. The Audit Committee has also received the written disclosures and the letter from the independent registered public accounting firm required by applicable requirements of the PCAOB regarding the independent registered public accounting firm's communications with the Audit Committee concerning independence, and has discussed with the independent registered public accounting firm the accounting firm's independence. Based on the foregoing, the Audit Committee has recommended to the Board of Directors that the audited financial statements be included in the Company's Annual Report on Form 10-K for the fiscal year ended December 31, 2022.

Mr. Robert Conway

Mr. Dan Mitchell

Dr. Linda Grais


## Compensation Committee

The Compensation Committee of the Board of Directors, or the Compensation Committee, is currently composed of three directors: Mr. Conway, Dr. Grais (chair) and Dr. Woosley. All members of the Compensation Committee are independent, as independence is currently defined in Rule 5605(a)(2) of the Nasdaq listing standards. The Compensation Committee met two times during the fiscal year. The Compensation Committee has adopted a written charter that is available to stockholders on the Company's website at www.arcabio.com.

---

# Page 72

The Compensation Committee of the Board of Directors acts on behalf of the Board of Directors to review, adopt and oversee the Company's compensation strategy, policies, plans and programs, including:
- · overseeing succession planning for senior management of the Company, including a review of the performance and advancement potential of current and future senior management and succession plans for each and recommending, as appropriate, the retention of potential succession candidates;
- · assessing the overall compensation structure of the Company and evaluating and recommending changes to the Company's compensation philosophies and strategies;
- · reviewing and approving performance-based compensation plans or programs, including establishing goals and targets, applicable to the Chief Executive Officer and other members of the management team;
- · administering, reviewing, and approving all executive compensation programs or plans, and all of the Company's incentive compensation and stock plans and awards thereunder of the Company, including amendments to the programs, plans or awards made thereunder; and
- · preparing and approving the Report of the Compensation Committee to be included as part of the Company's annual meeting proxy statement, to the extent required.
1 The material in this report is not 'soliciting material,' is not deemed 'filed' with the Commission and is not to be incorporated by reference in any filing of the Company under the Securities Act of 1933, as amended, or the Exchange Act, whether made before or after the date hereof and irrespective of any general incorporation language in any such filing.



## Compensation Committee Processes and Procedures

Typically, the Compensation Committee meets, as it deems appropriate. The agenda for each meeting is usually developed by the Chair of the Compensation Committee. However, from time to time, various members of management and other employees as well as outside advisors or consultants may be invited by the Compensation Committee to make presentations, to provide financial or other background information or advice or to otherwise participate in Compensation Committee meetings. The Chief Executive Officer may not participate in, or be present during, any deliberations or determinations of the Compensation Committee regarding his compensation or individual performance objectives. The Compensation Committee has the sole authority to retain compensation consultants to assist in its evaluation of executive and director compensation, including the authority to approve the consultant's reasonable fees and other retention terms. In general, the Compensation Committee has set executive compensation to be in line with peer companies identified by the Compensation Committee and to incentivize the Company's executive officers in achieving the Company's short- and long-term corporate goals.

In 2020, the Compensation and Nominating and Corporate Governance Committees of the Company reviewed the Company's current employee and director compensation, including the Company's 2013 Equity Incentive Plan. As part of this review, the Committees considered certain changes to the ARCA 2013 Equity Incentive Plan that were included in the 2020 ARCA Equity Incentive Plan. Both Committees recommended approval of the 2020 ARCA Equity Incentive Plan, and the Plan was subsequently approved by the Board of Directors and the Company's stockholders on December 10, 2020.


The current compensation for the Named Executive Officers was set by the Compensation Committee and the Board in 2020. On December 21, 2020, the Compensation Committee approved the following base salary compensation and target bonus percentages for the named executive officers and principal financial officer for the 2021 fiscal year:
- · Michael R. Bristow, President and Chief Executive Officer, $345,000 base salary and target bonus of 50% of base salary;
- · Thomas A. Keuer, Chief Operating Officer, $340,000 base salary and target bonus of 40% of base salary; and
- · Christopher D. Ozeroff, Secretary, Senior Vice President and General Counsel, $304,000 base salary and target bonus of 35% of base salary.

---

# Page 73

On May 3, 2021, the Compensation Committee approved a $270,000 base salary and target bonus of 35% of base salary for C. Jeffrey Dekker, Chief Financial Officer, the Company's principal financial officer hired in May 2021.

Historically, the Compensation Committee has made most of the significant adjustments to annual compensation, determined bonus and equity awards and established new performance objectives at one or more meetings held during the first quarter of the year. However, the Compensation Committee also considers matters related to individual compensation, such as compensation for new executive hires, as well as high-level strategic issues, such as the efficacy of the Company's compensation strategy, potential modifications to that strategy and new trends, plans or approaches to compensation, at various meetings throughout the year. Generally, the Compensation Committee's process comprises two related elements: the determination of compensation levels and the establishment of performance objectives for the current year.

The Compensation Committee reviews and approves the compensation of the Chief Executive Officer and the other executive officers of the Company, including annual base salaries, annual and long-term incentive or bonus awards, employment agreements, and severance and change in control agreements/provisions, in each case as, when and if appropriate, and any special or supplemental benefits. For executives other than the Chief Executive Officer, the Compensation Committee solicits and considers evaluations and recommendations submitted to the Compensation Committee by the Chief Executive Officer. The Compensation Committee evaluates the performance of the Chief Executive Officer in light of Company and individual goals and objectives, and makes appropriate recommendations for improving performance. In performing the evaluation, the Chair of the Compensation Committee may solicit comments from the other non-employee members of the Board of Directors and lead the Board of Directors in an overall review of the Chief Executive Officer's performance in an executive session of non-employee members of the Board of Directors. If the compensation for the Chief Executive Officer or any other executive officer is governed by an employment agreement, the Compensation Committee approves such employment agreement and any amendments thereto.

For all executives as part of its deliberations, the Compensation Committee may review and consider, as appropriate, materials such as financial reports and projections, operational data, tax and accounting information, tally sheets that set forth the total compensation that may become payable to executives in various hypothetical scenarios, executive and director stock ownership information, company stock performance data, analyses of historical executive compensation levels and current Company-wide compensation levels.

The Compensation Committee also considers the results of any 'say-on-pay' vote of the Company's stockholders with regard to the compensation of the Company's executive officers when making compensation decisions. At the 2022 annual meeting of stockholders, the Company's stockholders approved, on an advisory basis, the compensation of the Company's named executive officers as described in the proxy statement for such annual meeting, with over 91% of stockholder votes cast in favor of our 'say-on-pay' resolution. The Compensation Committee believes that this advisory vote supports that the Company's current compensation practices are aligned with the best interests of stockholders and anticipates taking into account the results of the advisory vote, and any future advisory votes, when making compensation decisions in the future.


## Nominating and Corporate Governance Committee

The Nominating and Corporate Governance Committee of the Board of Directors, or the Nominating and Corporate Governance Committee, is responsible for identifying, reviewing and evaluating candidates to serve as directors of the Company (consistent with criteria approved by the Board of Directors), reviewing and evaluating incumbent directors, recommending to the Board of Directors candidates for election to the Board of Directors, making recommendations to the Board of Directors regarding compensation for service on the Board of Directors and the committees thereof, making recommendations to the Board of Directors regarding the membership of the committees of the Board of Directors, assessing the performance of the Board of Directors and developing a set of corporate governance principles for the Company. The Nominating and Corporate Governance Committee is composed of three directors: Dr. Hove, Mr. Mitchell and Dr. Woosley (chair). All members of the Nominating and Corporate Governance Committee in 2022 were independent (as independence is currently defined in Rule 5605(a)(2) of the Nasdaq listing standards). The Nominating and Corporate Governance Committee met once during the 2022 fiscal year. The Nominating and Corporate Governance Committee has adopted a written charter that is available to stockholders on the Company's website at www.arcabio.com.

The Nominating and Corporate Governance Committee periodically reviews the compensation of non-employee Directors for service on the Board of Directors and committees thereof. In 2015, the Nominating and Corporate Governance Committee began a review of its Director compensation levels considering general market conditions in the life science industry, and in comparison to other clinical stage biopharmaceutical companies, and in early 2016, the Committee recommended, and the Board of Directors approved, revised compensation for non-employee Directors, discussed in 'Director Compensation' below. Since adoption of this policy, the Nominating and Corporate Governance Committee has reviewed Director compensation on an annual basis.

In 2020, the Nominating and Corporate Governance Committee (together with the Compensation Committee) engaged a consultant to evaluate the current compensation of the Company's non-employee directors and make recommendations to the Nominating and Corporate Governance Committee. The changes made as a result of this evaluation are discussed in 'Director Compensation' below.

---

# Page 74

The Board of Directors has adopted a process for identifying and evaluating director nominees, including stockholder nominees. Before recommending an individual to the Board of Directors for membership on the Board of Directors, the Nominating and Corporate Governance Committee canvasses its members and the Company's management team for potential candidates for the Board of Directors. The Nominating and Corporate Governance Committee also uses its network of contacts to identify potential candidates and, if it deems appropriate, may also engage a professional search firm. The Nominating and Corporate Governance Committee will consider stockholders' recommendations for nominees to serve as director if notice is timely received by the Secretary of the Company. Candidates nominated by stockholders will be evaluated in the same manner as other candidates. The Nominating and Corporate Governance Committee keeps the Board of Directors apprised of its discussions with potential nominees, and the names of potential nominees received from its current directors, management, and stockholders, if the stockholder notice of nomination is timely made.

Although the Board of Directors has not adopted a fixed set of minimum qualifications for candidates for membership on the Board of Directors, the Nominating and Corporate Governance Committee generally considers several factors in its evaluation of a potential member, such as the candidate's education, professional background and field of expertise including industry or academic experience in the pharmaceutical and biotechnology fields, experience in corporate governance and management, the reasonable availability of the potential member to devote time to the affairs of the Company, as well as any other criteria deemed relevant by the Board of Directors or the Nominating and Corporate Governance Committee. However, the Nominating and Corporate Governance Committee retains the right to modify these qualifications from time to time. Candidates for director nominees are reviewed in the context of the current composition of the Board of Directors, the operating requirements of the Company and the long-term interests of stockholders. In conducting this assessment, the Nominating and Corporate Governance Committee typically considers diversity, age, skills and such other factors as it deems appropriate given the current needs of the Board of Directors and the Company, to maintain a balance of knowledge, experience and capability. The Nominating and Corporate Governance Committee believes it is essential that Board of Directors members come from a variety of backgrounds and experiences.

In the case of incumbent directors whose terms of office are set to expire, the Nominating and Corporate Governance Committee reviews these directors' overall contributions to the Company and the Board of Directors during their terms, including level of attendance, level of participation, quality of performance and contribution to the Board of Directors' responsibilities and actions, and any relationships and transactions that might impair the directors' independence. In the case of new director candidates, the Nominating and Corporate Governance Committee also determines whether the nominee is independent for Nasdaq and SEC purposes, which determination is based upon applicable Nasdaq listing standards, applicable SEC rules and regulations and the advice of counsel, if necessary. The Nominating and Corporate Governance Committee conducts any appropriate and necessary inquiries into the backgrounds and qualifications of possible candidates after considering the function and needs of the Board of Directors. The Nominating and Corporate Governance Committee meets to discuss and consider the candidates' qualifications and then determines whether to recommend a nominee to the Board of Directors by majority vote.

Stockholders who wish to recommend individuals for consideration by the Nominating and Corporate Governance Committee to become nominees for election to the Board of Directors may do so by delivering a written recommendation to the Nominating and Corporate Governance Committee addressed to the Corporate Secretary, between 60 and 90 days before the one year anniversary date of ARCA's last annual meeting of stockholders. Recommendations must include the full name of the proposed nominee, a description of the proposed nominee's business experience for at least the previous five years, complete biographical information, a description of the proposed nominee's qualifications as a director, and a representation that the recommending stockholder is a beneficial or record owner of ARCA's stock. Any such submission must be accompanied by the written consent of the proposed nominee to be named as a nominee and to serve as a director if elected. To date, the Nominating and Corporate Governance Committee has not rejected a timely director nominee from a stockholder.

In 2022, the Nominating and Corporate Governance Committee did not pay any fees to assist in the process of identifying or evaluating director candidates.


## Stockholder Communications with the Board of Directors

Stockholders who wish to communicate with the Board of Directors may do so by e-mail by using the following email address: directors@arcabio.com; or by mail by following the directions as set forth on ARCA's website at www.arcabio.com, under the section titled 'Corporate Governance' and the subsection titled 'Governance Documents'. Communications sent in accordance with this process will be transmitted by the Company to the appropriate Board members.

---

# Page 75

# Item 11. Executive Compensation


## Executive Compensation

The following table shows for the fiscal years ended December 31, 2022 and December 31, 2021, compensation awarded to, paid to, or earned by the Company's principal executive officer and its two most highly compensated executive officers as of December 31, 2022, collectively, the Named Executive Officers:


## SUMMARY COMPENSATION TABLE


| Name and Principal Position                               |   Year | Salary  ($)(1)   | Option  Awards  ($)(2)   | Stock  Awards  ($)(2)   | Non-Equity  Incentive  Plan Awards  ($)   | All Other  Compensation  ($)(3)   | Total ($)   |
|-----------------------------------------------------------|--------|------------------|--------------------------|-------------------------|-------------------------------------------|-----------------------------------|-------------|
| Michael R. Bristow....................................... |   2022 | 345,000          | -                        | -                       | -                                         | 13,800                            | 358,800     |
| President and Chief Executive Officer                     |   2021 | 343,431          | 162,956                  | -                       | -                                         | 20,126                            | 526,513     |
| Thomas A. Keuer.......................................... |   2022 | 340,000          | -                        | 88,400                  | -                                         | 20,593                            | 448,993     |
| Chief Operating Officer                                   |   2021 | 338,577          | 60,036                   | -                       | -                                         | 22,002                            | 420,615     |
| Christopher D. Ozeroff (4)............................    |   2022 | 304,000          | -                        | -                       | -                                         | 12,429                            | 316,429     |
| Secretary, Senior Vice President and  General Counsel     |   2021 | 303,744          | 47,171                   | -                       | -                                         | 15,114                            | 366,029     |
(1) The amounts reported under 'Salary' in the above table represent the actual amounts paid during the calendar year. Because the Company's actual pay dates do not always coincide with the first and last days of the year, these amounts may differ from the base salary amounts authorized by the Company's Board of Directors.
(2) The amounts reported under 'Option Awards' and "Stock Awards" in the above table reflect the grant date fair value of these awards as determined in accordance with Financial Accounting Standards Board Accounting Standards Codification Topic 718, Compensation - Stock Compensation, excluding the effects of estimated forfeitures. The vesting schedule for options included in the above table are included in the table of 'Outstanding Equity Awards at Fiscal Year End' below. The value of stock option and restricted stock unit awards was estimated using the Black-Scholes option-pricing model. The valuation assumptions used in the valuation of option grants and restricted stock units may be found in Note 8 to the Company's financial statements included in this annual report on Form 10-K for the year ended December 31, 2022.
(3) Represents 401(k) Company match, Health Savings Account contributions by the Company, group term life premiums and cell phone reimbursements.
(4) Mr. Ozeroff and the Company have mutually agreed to conclude Mr. Ozeroff's employment effective March 31, 2023.



## Narrative Disclosure to Summary Compensation Table


## Employment Agreements or Arrangements

Michael R. Bristow, M.D., Ph.D. Dr. Bristow serves as the Company's President and Chief Executive Officer under an Employment and Retention Agreement dated as of June 4, 2008, as amended. Pursuant to such employment agreement, Dr. Bristow is permitted to continue his academic work for the University of Colorado Health Sciences Center and for the Cardiovascular Institute, so long as it does not interfere with his duties as President and Chief Executive Officer of ARCA.

Under his employment agreement, Dr. Bristow is entitled to receive an annual base salary of $200,000, subject to annual increases if approved by the Company's Board of Directors or Compensation Committee and is eligible to receive an annual bonus as determined by the Board of Directors or Compensation Committee in its sole discretion.

In 2019, there were no changes to the previously approved base salary of $304,219 for Dr. Bristow. In May 2019, Dr. Bristow agreed to a voluntary 10% salary reduction for the remainder of 2019. As a result of this reduction, the base salary paid to Dr. Bristow for the remainder of 2019 was $273,797. The forgone portion of any of Dr. Bristow's salary shall not be paid without the prior approval of the Board of Directors, provided, that such forgone amount shall be included in Dr. Bristow's base salary for purposes of calculating any severance amounts which may be owed in the future under the terms of his employment agreement with the Company. The Company did not put in place a bonus plan for its Named Executive Officers for services in 2019.

On August 3, 2020, the Board of Directors approved revisions to the base salary amounts of the Named Executive Officers to return them to the salary amounts in effect prior to the voluntary salary reduction in 2019. As a result, the base salary rate paid to Dr. Bristow for the remainder of 2020 was $304,219.

On December 21, 2020, the Compensation Committee approved a base salary of $345,000 and target bonus percentage of 50% of base salary for Dr. Bristow for the 2021 fiscal year.

---

# Page 76

On January 29, 2021, the Compensation Committee approved a cash bonus of $144,000 for Dr. Bristow. The cash bonus was earned under the 2020 Bonus Plan for services rendered in 2020. See ' Non-Equity Incentive Plan Compensation ' below for descriptions of the 2020 Bonus Plan.

If the Company terminates Dr. Bristow's employment without 'cause,' or if Dr. Bristow terminates his employment with 'good reason' (as these terms are defined in his employment agreement), the Company has agreed to pay Dr. Bristow a severance payment equivalent to (i) (a) 12 months of his base salary, if such termination occurs on the same day as or within 13 months after a change of control of the Company, or (b) six months of his base salary if such termination does not occur on the same day as or within 13 months after a change of control of the Company, (ii) a pro rata portion of any bonus compensation under any employee bonus plan that has been approved by the Board of Directors payable to him for the fiscal year in which his employment terminated to be paid at the same time that such incentive bonus would have been paid had the termination not occurred, and (iii) reimbursement to cover outof-pocket costs to continue group health insurance benefits under COBRA for 6 months, whether he elects or is eligible to receive COBRA (provided, that even if he does not elect or is not eligible to receive COBRA, he will receive the equivalent of such out-ofpocket expenses paid by him not to exceed the costs that the benefits would equal under COBRA if he were so eligible). In addition, ARCA may elect in its sole discretion, to pay additional severance equal to up to 6 months of base salary, which additional payment would extend the covenants and obligations under Dr. Bristow's Employee Intellectual Property, Confidentiality and Non-Compete Agreement for such additional period. The severance payment is conditioned on the execution by Dr. Bristow of a legal release in a form acceptable to the Company. A termination for 'cause' includes Dr. Bristow's willful misconduct, gross negligence, theft, fraud, or other illegal or dishonest conduct, any of which are considered to be materially harmful to the Company; refusal, unwillingness, failure, or inability to perform his material job duties or habitual absenteeism; or violation of fiduciary duty, violation of any duty of loyalty, or material breach of any material term of his employment agreement or his Employee Intellectual Property, Confidentiality and Non-Compete Agreement, or any other agreement, with the Company. 'Good reason' includes a relocation by us of Dr. Bristow's normal work location greater than 30 miles; a decrease in current base salary by more than 15%, with certain exceptions; and the Company's unilateral decision to significantly and detrimentally reduce Dr. Bristow's job responsibilities.

Thomas A. Keuer. Mr. Keuer serves as the Company's Chief Operating Officer under an Amended and Restated Employment Agreement that was effective as of January 1, 2015.

Under his employment agreement, Mr. Keuer is entitled to receive an annual base salary of $280,000, subject to annual increases if approved by the Company's Board of Directors or Compensation Committee and is eligible to receive an annual bonus as determined by the Board of Directors or Compensation Committee in its sole discretion.

In 2019, there were no changes to the previously approved base salary of $303,000 for Mr. Keuer. In May 2019, Mr. Keuer agreed to a voluntary 10% salary reduction for the remainder of 2019. As a result of this reduction, the base salary paid to Mr. Keuer for the remainder of 2019 was $272,700. The forgone portion of any of Mr. Keuer's salary shall not be paid without the prior approval of the Board of Directors, provided, that such forgone amount shall be included in Mr. Keuer base salary for purposes of calculating any severance amounts which may be owed in the future under the terms of his employment agreement with the Company. The Company did not put in place a bonus plan for its Named Executive Officers for services in 2019.

On August 3, 2020, the Board of Directors approved revisions to the base salary amounts of the Named Executive Officers to return them to the salary amounts in effect prior to the voluntary salary reduction in 2019. As a result, the base salary rate paid to Mr. Keuer for the remainder of 2020 was $303,000.

On December 21, 2020, the Compensation Committee approved a base salary of $340,000 and target bonus percentage of 40% of base salary for Mr. Keuer for the 2021 fiscal year.

On January 29, 2021, the Compensation Committee approved a cash bonus of $98,000 for Mr. Keuer. The cash bonus was earned under the 2020 Bonus Plan for services rendered in 2020. See ' Non-Equity Incentive Plan Compensation ' below for descriptions of the 2020 Bonus Plan.

On December 8, 2022, the Compensation Committee approved a retention bonus of $100,000 for Mr. Keuer, subject to continued employment with the Company through the earlier of a change in control of the Company or certain clinical development decisions.

If the Company terminates Mr. Keuer's employment without 'cause,' or if Mr. Keuer terminates his employment with 'good reason' (as these terms are defined in his employment agreement), the Company has agreed to pay Mr. Keuer a severance payment equivalent to (i) (a) 12 months of his base salary, if such termination occurs on the same day as or within 13 months after a change of control of the Company, or (b) six months of his base salary if such termination does not occur on the same day as or within 13 months after a change of control of the Company, (ii) a pro rata portion of any bonus compensation under any employee bonus plan that has been approved by the Board of Directors payable to him for the fiscal year in which his employment terminated to be paid at the same time that such incentive bonus would have been paid had the termination not occurred, and (iii) reimbursement to cover outof-pocket costs to continue group health insurance benefits under COBRA for (x) 12 months, if such termination occurs on the same day as or within 13 months after a change of control of the Company, or (y) six months if such termination does not occur on the same day as or within 13 months after a change of control of the Company, whether he elects or is eligible to receive COBRA (provided, in

---

# Page 77

either event, that even if he does not elect or is not eligible to receive COBRA, he will receive the equivalent of such out-of-pocket expenses paid by him not to exceed the costs that the benefits would equal under COBRA if he were so eligible). In addition, ARCA may elect in its sole discretion, to pay additional severance equal to up to 12 months of base salary, which additional payment would extend the covenants and obligations under Mr. Keuer's Employee Intellectual Property, Confidentiality and Non-Compete Agreement for such additional period. The severance payment is conditioned on the execution by Mr. Keuer of a legal release in a form acceptable to the Company. A termination for 'cause' includes Mr. Keuer's willful misconduct, gross negligence, theft, fraud, or other illegal or dishonest conduct, any of which are considered to be materially harmful to the Company; refusal, unwillingness, failure, or inability to perform his material job duties or habitual absenteeism; or violation of fiduciary duty, violation of any duty of loyalty, or material breach of any material term of his employment agreement or his Employee Intellectual Property, Confidentiality and Non-Compete Agreement, or any other agreement, with the Company. 'Good reason' includes a relocation by us of Mr. Keuer's normal work location greater than 30 miles; a decrease in current base salary by more than 15%, with certain exceptions; and the Company's unilateral decision to significantly and detrimentally reduce Mr. Keuer's job responsibilities.

Christopher D. Ozeroff. Mr. Ozeroff serves as the Company's Senior Vice President and General Counsel under an Employment and Retention Agreement dated as of June 12, 2008, as amended.

Under his employment agreement, Mr. Ozeroff is entitled to receive an annual base salary of $259,000, subject to annual increases if approved by the Company's Board of Directors or Compensation Committee and is eligible to receive an annual bonus as determined by the Board of Directors or Compensation Committee in its sole discretion.

In 2019, there were no changes to the previously approved base salary of $297,343 for Mr. Ozeroff. In May 2019, Mr. Ozeroff agreed to a voluntary 10% salary reduction for the remainder of 2019. As a result of this reduction, the base salary paid to Mr. Ozeroff for the remainder of 2019 was $267,609. The forgone portion of any of Mr. Ozeroff's salary shall not be paid without the prior approval of the Board of Directors, provided, that such forgone amount shall be included in Mr. Ozeroff's base salary for purposes of calculating any severance amounts which may be owed in the future under the terms of his employment agreement with the Company. The Company did not put in place a bonus plan for its Named Executive Officers for services in 2019.

On August 3, 2020, the Board of Directors approved revisions to the base salary amounts of the Named Executive Officers to return them to the salary amounts in effect prior to the voluntary salary reduction in 2019. As a result, the base salary rate paid to Mr. Ozeroff for the remainder of 2020 was $297,343.

On December 21, 2020, the Compensation Committee approved a base salary of $304,000 and target bonus percentage of 35% of base salary for Mr. Ozeroff for the 2021 fiscal year.

On January 29, 2021, the Compensation Committee approved a cash bonus of $84,000 for Mr. Ozeroff. The cash bonus was earned under the 2020 Bonus Plan for services rendered in 2020. See ' Non-Equity Incentive Plan Compensation ' below for descriptions of the 2020 Bonus Plan.

If the Company terminates Mr. Ozeroff's employment without 'cause,' or if Mr. Ozeroff terminates his employment with 'good reason' (as these terms are defined in his employment agreement), the Company has agreed to pay Mr. Ozeroff a severance payment equivalent to (i) (a) 12 months of his base salary, if such termination occurs on the same day as or within 13 months after a change of control of the Company, or (b) six months of his base salary if such termination does not occur on the same day as or within 13 months after a change of control of the Company, (ii) a pro rata portion of any bonus compensation under any employee bonus plan that has been approved by the Board of Directors payable to him for the fiscal year in which his employment terminated to be paid at the same time that such incentive bonus would have been paid had the termination not occurred, and (iii) reimbursement to cover outof-pocket costs to continue group health insurance benefits under COBRA for 6 months, whether he elects or is eligible to receive COBRA (provided, that even if he does not elect or is not eligible to receive COBRA, he will receive the equivalent of such out-ofpocket expenses paid by him not to exceed the costs that the benefits would equal under COBRA if he were so eligible). In addition, ARCA may elect in its sole discretion, to pay additional severance equal to up to 6 months of base salary, which additional payment would extend the covenants and obligations under Mr. Ozeroff's Employee Intellectual Property, Confidentiality and Non-Compete Agreement for such additional period. The severance payment is conditioned on the execution by Mr. Ozeroff of a legal release in a form acceptable to the Company. A termination for 'cause' includes Mr. Ozeroff's willful misconduct, gross negligence, theft, fraud, or other illegal or dishonest conduct, any of which are considered to be materially harmful to the Company; refusal, unwillingness, failure, or inability to perform his material job duties or habitual absenteeism; or violation of fiduciary duty, violation of any duty of loyalty, or material breach of any material term of his employment agreement or his Employee Intellectual Property, Confidentiality and Non-Compete Agreement, or any other agreement, with the Company. 'Good reason' includes a relocation by us of Mr. Ozeroff's normal work location greater than 30 miles; a decrease in current base salary by more than 15%, with certain exceptions; and the Company's unilateral decision to significantly and detrimentally reduce Mr. Ozeroff's job responsibilities.

The Company and Mr. Ozeroff have mutually agreed to conclude Mr. Ozeroff's employment effective March 31, 2023.

Pursuant to Mr. Ozeroff's existing employment agreement, as previously amended, ARCA will provide Mr. Ozeroff severance benefits pursuant to the terms of his existing employment agreement with the Company, as previously amended. The severance benefits include severance payments and reimbursement to cover out-of-pocket costs to continue group health insurance

---

# Page 78

benefits under COBRA, whether he elects or is eligible to receive COBRA (provided, that even if he does not elect or is not eligible to receive COBRA, he will receive the equivalent of such out-of-pocket expenses paid by him not to exceed the costs that the benefits would equal under COBRA if he were so eligible). The severance benefits are conditioned on the execution by Mr. Ozeroff of a legal release of claims.


# Non-Equity Incentive Plan Compensation

In February 2007, the Compensation Committee and the Board of Directors of ARCA established a bonus structure for its entire executive team. The philosophy employed was to create incentives for the executive officers to achieve key corporate goals. The Compensation Committee retained discretion to change the bonus structure and the bonus payment amounts as it considered appropriate.


## 2021 Goals

The Company's 2021 goals were based on (1) executing our development plan for rNAPc2 (AB201), our clinical product candidate for the treatment of patients with COVID-19 (2) further defining our development plan for Gencaro, our clinical product candidate for the treatment of atrial fibrillation, and (3) finance and corporate compliance goals.

The Board of Directors did not approve any payouts under the 2021 Bonus Plan since the primary endpoints for rNAPc2 Phase 2b clinical trial were not met.


## 2020 Cash Bonus Plan

On January 29, 2021, the Compensation Committee approved cash bonuses for certain employees. The cash bonuses were paid in 2021 for performance in 2020, including attainment of the Company's 2020 Goals under its 2020 Cash Bonus Plan (the '2020 Goals'), as determined by the Compensation Committee. The 2020 bonuses were based on the Board of Directors' determination with respect to the Company's achievement of the 2020 Goals.

The 2020 Goals were based on (1) obtaining additional financing (2) rNAPc2 (AB201) IND approval, and (3) enrollment of rNAPc2 (AB201) clinical trial.


## Other Elements of Executive Compensation Program

The remaining elements of the Company's executive compensation program, like its broader employee compensation programs, are intended to make the Company's overall compensation program competitive with those of its peer companies, keeping in mind the constraints imposed by the Company's reliance on capital markets as a primary source of cash. The remaining elements of the Company's executive compensation program, (401(k) Plan, Medical, Dental, and Vision Plans, Life and Disability Insurance) are available to all Company employees.

---

# Page 79

# OUTSTANDING EQUITY AWARDS AT FISCAL YEAR END

The following table shows for the fiscal year ended December 31, 2022, certain information regarding outstanding equity awards at fiscal year end for the Named Executive Officers.

A description of the equity incentive plans we maintain is set forth in Note 8 to the Company's financial statements included in this Annual Report on Form 10-K.


|                                                                                                                                     | Option Awards                                                          | Option Awards                                                            | Option Awards             | Option Awards          |
|-------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------|--------------------------------------------------------------------------|---------------------------|------------------------|
| Name                                                                                                                                | Number of  Securities  Underlying  Unexercised Options (#) Exercisable | Number of  Securities  Underlying  Unexercised Options (#) Unexercisable | Option Exercise Price ($) | Option Expiration Date |
| Michael R. Bristow, President and Chief Executive  Officer ........................................................................ | 1,563                                                                  | -                                                                        | 173.88                    | 9/16/2023              |
|                                                                                                                                     | 681                                                                    | -                                                                        | 173.88                    | 9/16/2023              |
|                                                                                                                                     | 408                                                                    | -                                                                        | 245.70                    | 2/26/2024              |
|                                                                                                                                     | 205                                                                    | -                                                                        | 84.42                     | 2/11/2025              |
|                                                                                                                                     | 1,511                                                                  | -                                                                        | 59.40                     | 6/8/2026               |
|                                                                                                                                     | 2,333                                                                  | -                                                                        | 45.00                     | 2/15/2027              |
|                                                                                                                                     | 95,000                                                                 | 95,000 (1)(3)                                                            | 4.27                      | 12/21/2030             |
|                                                                                                                                     | 31,667                                                                 | 63,333 (2)(3)                                                            | 2.29                      | 12/14/2031             |
| Thomas A. Keuer, Chief Operating Officer...............                                                                             | 265                                                                    | -                                                                        | 173.88                    | 9/16/2023              |
|                                                                                                                                     | 79                                                                     | -                                                                        | 195.30                    | 10/14/2023             |
|                                                                                                                                     | 83                                                                     | -                                                                        | 245.70                    | 2/26/2024              |
|                                                                                                                                     | 108                                                                    | -                                                                        | 84.42                     | 2/11/2025              |
|                                                                                                                                     | 866                                                                    | -                                                                        | 59.40                     | 6/8/2026               |
|                                                                                                                                     | 1,400                                                                  | -                                                                        | 45.00                     | 2/15/2027              |
|                                                                                                                                     | 35,000                                                                 | 35,000 (1)(3)                                                            | 4.27                      | 12/21/2030             |
|                                                                                                                                     | 11,667                                                                 | 23,333 (2)(3)                                                            | 2.29                      | 12/14/2031             |
| Christopher Ozeroff, Secretary, Senior Vice  President and General Counsel † ...............................                        | 338                                                                    | -                                                                        | 173.88                    | 9/16/2023              |
|                                                                                                                                     | 83                                                                     | -                                                                        | 245.70                    | 2/26/2024              |
|                                                                                                                                     | 102                                                                    | -                                                                        | 84.42                     | 2/11/2025              |
|                                                                                                                                     | 822                                                                    | -                                                                        | 59.40                     | 6/8/2026               |
|                                                                                                                                     | 1,333                                                                  | -                                                                        | 45.00                     | 2/15/2027              |
|                                                                                                                                     | 27,500                                                                 | 27,500 (1)(3)                                                            | 4.27                      | 12/21/2030             |
|                                                                                                                                     | 9,167                                                                  | 18,333 (2)(3)                                                            | 2.29                      | 12/14/2031             |
†    Mr. Ozeroff and the Company have mutually agreed to conclude Mr. Ozeroff's employment effective March 31, 2023.
(1) Options vest in 48 monthly installments measured from December 21, 2020.
(2) Options vest in 36 monthly installments measured from December 14, 2021.
(3) In the event of a change in control of the Company, 50% of the unvested shares subject to this award shall become fully and immediately vested upon the closing date of such change in control, provided, however, that on the earlier of (i) the one-year anniversary of the closing date or (ii) involuntary termination, any options that remain unvested on such earlier date shall become fully and immediately vested.

---

# Page 80

|                                                                                              | Stock Awards                                              | Stock Awards   | Stock Awards                                                          |
|----------------------------------------------------------------------------------------------|-----------------------------------------------------------|----------------|-----------------------------------------------------------------------|
| Name                                                                                         | Number of Shares or  Units of Stock That Have  Not Vested |                | Market Value of Shares  or Units of Stock That  Have Not Vested Price |
| Thomas A. Keuer, Chief Operating Officer ................................................... | 40,000                                                    | (1)            | 94,400                                                                |
(1)  Restricted Stock Units vests one year from December 8, 2022, subject to continuing employment with the Company through that date. In the event of a change in control of the Issuer or the grantee's involuntary termination without cause or by the grantee for good reason, 100% of the unvested RSUs shall become fully and immediately vested upon the closing date of such change in control or such involuntary termination date, respectively (to the extent such unvested RSUs have not yet then vested).



# DIRECTOR COMPENSATION


The following table shows for the fiscal year ended December 31, 2022, certain information with respect to the compensation of all non-employee directors of the Company:
|                                                           | DIRECTOR COMPENSATION (1)         | DIRECTOR COMPENSATION (1)   | DIRECTOR COMPENSATION (1)                          |                             |           |
|-----------------------------------------------------------|-----------------------------------|-----------------------------|----------------------------------------------------|-----------------------------|-----------|
| Name                                                      | Fees Earned or  Paid in Cash  ($) | Option Awards  ($)(2)       | Nonqualified  Deferred  Compensation  Earnings ($) | All Other  Compensation ($) | Total ($) |
| Linda Grais, M.D. (3) ................................    | 57,500                            | 11,336                      | -                                                  | -                           | 68,836    |
| Raymond L. Woosley, M.D. (4) .................            | 55,000                            | 11,336                      | -                                                  | -                           | 66,336    |
| Robert E. Conway (5) ................................     | 90,000                            | 11,336                      | -                                                  | -                           | 101,336   |
| Dan J. Mitchell (6).....................................  | 52,500                            | 11,336                      | -                                                  | -                           | 63,836    |
| Anders Hove (7) ........................................  | 45,000                            | 11,336                      | -                                                  | -                           | 56,336    |
| Jacob Ma-Weaver (8).................................      | 21,667                            | 32,226                      | -                                                  | -                           | 53,893    |
| James Flynn (9) ......................................... | 1,667                             | 23,013                      | -                                                  | -                           | 24,680    |
(1) Dr. Bristow, our President and Chief Executive Officer, was also a director during the year ended December 31, 2022, but did not receive any additional compensation for his service as a director. Dr. Bristow's compensation as an executive officer is set forth above under 'Executive Compensation-Summary Compensation Table.'
(2) The amounts reported under 'Option Awards' in the above table reflect the grant date fair value of these awards as determined in accordance with Financial Accounting Standards Board Accounting Standards Codification Topic 718, Compensation - Stock Compensation, excluding the effects of estimated forfeitures. The value of stock option awards was estimated using the Black-Scholes option-pricing model. The valuation assumptions used in the valuation of option grants may be found in Note 8 to the Company's financial statements included in this annual report on Form 10-K for the year ended December 31, 2022.
(3) The aggregate number of shares issuable upon exercise of option awards outstanding at December 31, 2022, for Dr. Grais was 19,646, of which 9,646 shares were fully vested.
(4) The aggregate number of shares issuable upon exercise of option awards outstanding at December 31, 2022, for Dr. Woosley was 19,611, of which 9,611 shares were fully vested.
(5) The aggregate number of shares issuable upon exercise of option awards outstanding at December 31, 2022, for Mr. Conway, Chairman of the Board of Directors, was 19,604, of which 9,604 shares were fully vested.
(6) The aggregate number of shares issuable upon exercise of option awards outstanding at December 31, 2022, for Mr. Mitchell was 19,577, of which 9,577 shares were fully vested.
(7) The aggregate number of shares issuable upon exercise of option awards outstanding at December 31, 2022, for Dr. Hove was 18,999, of which 8,999 shares were fully vested.
(8) The aggregate number of shares issuable upon exercise of option awards outstanding at December 31, 2022, for Mr. Ma-Weaver was 18,000, of which 2,000 shares were fully vested.
(9) The aggregate number of shares issuable upon exercise of option awards outstanding at December 31, 2022, for Mr. Flynn was 12,000, of which no shares were vested



In 2021, the Company revised its compensation plan for non-employee directors to provide that non-employee directors will be compensated for their service on the Board of Directors, as follows:
- · Each non-employee director will receive an annual retainer fee of $40,000;
- · As additional  compensation  for  their  services,  each  non-employee  director  will  receive  (i),  upon  joining  the  Board  of Directors, an initial option grant to purchase 12,000 shares of the Company's Common Stock under the ARCA 2020 Equity Incentive Plan, or the 2020 Plan, (ii), in 2021 the members of the Board of Directors will receive a one-time retention option grant to purchase 12,000 shares of the Company's Common Stock under the 2020 Plan and (iii), on an annual basis as of the date of the Company's annual stockholder meeting, an annual option grant to purchase 6,000 shares of the Company's Common Stock under the 2020 Plan; provided that such non-employee director has served on the Company's Board of

---

# Page 81

Directors for at least six months prior to the date of grant (unless such six month period is modified by recommendation of the Nominating and Corporate Governance Committee and approved by the Compensation Committee);


- · The Chairman of the Board of Directors will receive an additional annual retainer fee of $30,000;
- · The Audit Committee chair will receive an additional annual retainer fee of $15,000;
- · The chairs of the Compensation Committee and the Nominating and Corporate Governance Committee will each receive an additional annual retainer fee of $10,000;
- · Each non-chair member of the Audit Committee will receive an additional annual retainer fee of $7,500; and
- · Each non-chair member of the Compensation Committee and the Nominating and Corporate Governance Committees will receive an additional annual retainer fee of $5,000.


On June 15, 2022, pursuant to the Company's Director Compensation Policy, the Company granted Mr. Ma-Weaver an option to purchase 12,000 shares of Common Stock under the 2020 Plan at an exercise price of $2.27 per share, the closing price of the Company's common stock on The Nasdaq Capital Market on June 15, 2022. The option vests in 36 equal monthly installments beginning on June 15, 2022, assuming Mr. Ma-Weaver's continued service on the Board for such periods.

On December 15, 2022, pursuant to the Company's Director Compensation Policy, the Company granted Mr. Flynn an option to purchase 12,000 shares of Common Stock under the 2020 Plan at an exercise price of $2.32 per share, the closing price of the Company's common stock on The Nasdaq Capital Market on December 15, 2022. The option vests in 36 equal monthly installments beginning on December 15, 2022, assuming Mr. Flynn's continued service on the Board for such periods. On the same day, the Company also approved paying compensation to its existing non-employee directors, pursuant to the Company's Director Compensation Policy, by granting to Dr. Linda Grais, Dr. Anders Hove, Mr. Robert Conway, Mr. Daniel Mitchell, Dr. Raymond Woosley and Mr. Jacob Ma-Weaver options to purchase 6,000 shares of common stock at an exercise price of $2.32 per share, the closing price of the Company's common stock on December 15, 2022. The options are subject to the terms and conditions of the Plan and the Company's standard forms of Stock Option Agreement and Option Grant Notice for the Plan. The options vest in 12 equal monthly installments beginning on December 15, 2022, assuming Dr. Grais', Dr. Hove's, Mr. Conway's, Mr. Mitchell's, Dr. Woosley's and Mr. Ma-Weaver's continued service on the Board for such periods.


## Item 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters


## EQUITY COMPENSATION PLAN INFORMATION


The following table sets forth information as of December 31, 2022, for all of our equity compensation plans:
| Plan Category                                               | Number of Securities  to be Issued Upon  Exercise of  Outstanding Options  or Upon Vesting of  Restricted Stock Units (a)   | Weighted Average  Exercise  Price of Outstanding  Options ($) (b)   | Number of Securities  Remaining  Available for  Future Issuance Under  Equity Compensation Plans (Excluding Securities  Reflected in  Column(a)) (c)   |
|-------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|
| Equity compensation plans approved  by security holders     | 795,960                                                                                                                     | $5.62                                                               | 371,487                                                                                                                                                |
| Equity compensation plans not  approved by security holders | -                                                                                                                           | -                                                                   | -                                                                                                                                                      |
| Total                                                       | 795,960                                                                                                                     | $5.62                                                               | 371,487                                                                                                                                                |


On December 10, 2020, our stockholders approved the ARCA biopharma, Inc. 2020 Equity Incentive Plan, or the 2020 Plan, at the Company's 2020 annual meeting of stockholders. The 2020 Plan is the successor to the Amended and Restated ARCA biopharma, Inc. 2013 Equity Incentive Plan, or the 2013 Plan. A description of the 2020 Plan is set forth in Note 8 to the Company's financial statements included in this annual report on Form 10-K. The 2020 Plan only has options and restricted stock units outstanding as of December 31, 2022, no warrants or rights are outstanding under this plan; therefore, all values in the above table relate solely to the outstanding options and restricted stock units.

On September 17, 2013, our stockholders approved the 2013 Plan at the Company's 2013 annual meeting of stockholders. The 2013 Plan is the successor to the Amended and Restated ARCA biopharma, Inc. 2004 Equity Incentive Plan, or the 2004 Plan. On

---

# Page 82

June 9, 2016, our stockholders approved the Amended 2013 Plan. A description of the 2013 Plan and the Amended 2013 Plan is set forth in Note 8 to the Company's financial statements included in this annual report on Form 10-K. The Amended 2013 Plan only has options outstanding as of December 31, 2022, no warrants or rights are outstanding under this plan; therefore, all values in the above table relate solely to the outstanding options.


# Compensation Risks

We believe our approach to goal setting, setting of targets with payouts at multiple levels of performance, and evaluation of performance results assist in mitigating excessive risk-taking that could harm the value or reward poor judgment by our executives. We believe several features of our programs reflect sound risk management practices. We believe we have allocated compensation among base salary and short and long-term compensation target opportunities in such a way as to not encourage excessive risk-taking. The multi-year vesting of equity awards properly accounts for the time horizon of risk. Furthermore, the Compensation Committee assesses and monitors whether any of our compensation policies and programs has the potential to encourage excessive risk-taking on an annual basis.


## Security Ownership of Certain Beneficial Owners

The following table sets forth certain information regarding the ownership of the Company's Common Stock as of February 15, 2023, by: (i) each director, (ii) each of our named executive officers, (iii) all executive officers and directors of the Company as a group and (iv) all those known by the Company to be beneficial owners of more than five percent of its Common Stock. Unless otherwise noted below, the address of each beneficial owner listed on the table is c/o ARCA biopharma, Inc., 10170 Church Ranch Way, Suite 100, Westminster, Colorado, 80021.

We have determined beneficial ownership in accordance with the rules of the SEC. Except as indicated by the footnotes below, we believe, based on the information furnished to us, that the persons and entities named in the table below have sole voting and investment power with respect to all shares of Common Stock that they beneficially own, subject to applicable community property laws. The table is based upon information supplied by officers, directors and principal stockholders and Schedules 13G or 13D, Form 4s or other ownership reports filed with the SEC.

In computing the number of shares of Common Stock beneficially owned by a person and the percentage ownership of that person, we deemed outstanding shares of Common Stock subject to options or warrants held by that person that are currently exercisable or exercisable within 60 days of February 15, 2023. We did not deem these shares outstanding, however, for the purpose of computing the percentage ownership of any other person.

The percentages below are based on 14,410,143 shares of our Common Stock outstanding as of February 15, 2023.


| Beneficial Owner                                                                                                                                         | Shares  Beneficially Owned   | Percentage Shares  Beneficially Owned   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------|-----------------------------------------|
| Directors and Named Executive Officers                                                                                                                   |                              |                                         |
| Michael R. Bristow, M.D., Ph.D. (1) ........................................                                                                             | 160,607                      | 1.1%                                    |
| Thomas A. Keuer (2).................................................................                                                                     | 58,462                       | *                                       |
| Christopher D. Ozeroff (3)........................................................                                                                       | 96,809                       | *                                       |
| Linda Grais, M.D. (4)................................................................                                                                    | 12,646                       | *                                       |
| Robert E. Conway (5)................................................................                                                                     | 62,604                       | *                                       |
| Raymond L. Woosley (6)..........................................................                                                                         | 12,611                       | *                                       |
| Dan J. Mitchell (7) ....................................................................                                                                 | 13,188                       | *                                       |
| Anders Hove, M.D. (8)..............................................................                                                                      | 11,999                       | *                                       |
| Jacob Ma-Weaver (9)................................................................                                                                      | 4,005,786                    | 27.8%                                   |
| James Flynn (10) .......................................................................                                                                 | 1,334                        | *                                       |
| All current directors and executive officers as a group (11  persons) (11) ............................................................................. | 4,468,934                    | 30.3%                                   |
| 5% Stockholders                                                                                                                                          |                              |                                         |
| Funicular Funds, LP (12) ..........................................................                                                                      | 4,005,786                    | 27.8%                                   |
| BML Investment Partners, L.P. (13).........................................                                                                              | 858,256                      | 6.0%                                    |

---

# Page 83

- * Represents beneficial ownership of less than 1% of our Common Stock.
- (1) Includes the following (i) 1,109 shares owned by Investocor Trust: Dr. Bristow is the sole trustee of Investocor Trust; (ii) 1,414 shares owned by NFS as Custodian for Michael Bristow's IRA; and (iii) options to purchase 155,799 shares that are exercisable within 60 days of February 15, 2023.
(2) Includes options to purchase 57,732 shares that are exercisable within 60 days of February 15, 2023.



- (3) Includes options to purchase 45,839 shares that are exercisable within 60 days of February 15, 2023. Mr. Ozeroff and the Company have mutually agreed to conclude Mr. Ozeroff's employment effective March 31, 2023.
(4) Includes options to purchase 12,646 shares that are exercisable within 60 days of February 15, 2023.
(5) Includes options to purchase 12,604 shares that are exercisable within 60 days of February 15, 2023.
(6) Includes options to purchase 12,611 shares that are exercisable within 60 days of February 15, 2023.
(7) Includes options to purchase 12,577 shares that are exercisable within 60 days of February 15, 2023.
(8) Includes options to purchase 11,999 shares that are exercisable within 60 days of February 15, 2023.
(9) Includes options to purchase 5,334 shares that are exercisable within 60 days of February 15, 2023. Also see Footnote (12) below.
(10) Includes options to purchase 1,334 shares that are exercisable within 60 days of February 15, 2023.
(11) See Notes (1) through (10) above. Also, includes additional options to purchase 34,222 shares that are exercisable within 60 days of February 15, 2023 beneficially owned by our executive officers not listed by name in the table above.
(12) Based on a Form 4 filed with the SEC on December 19, 2022. The Funicular Funds, LP, the Funicular Fund, Cable Car Capital LLC and Jacob Ma-Weaver may be deemed to be a member of a Section 13(d) group that may be deemed to collectively beneficially own more than 10% of the Company's outstanding shares of Common Stock. Despite such shared beneficial ownership, the reporting persons disclaim beneficial ownership of the securities except to the extent of his or its pecuniary interest therein. Funicular Fund, as a feeder fund to the Funicular Funds, LP (the 'Fund'), may be deemed to beneficially own the securities directly owned by the Funicular Funds, LP. Cable Car, as the general partner of the Fund, may be deemed to beneficially own the securities directly owned by the Fund. Mr. Ma-Weaver, as the Managing Member of Cable Car, may be deemed to beneficially own the securities directly owned by the Fund. Includes options to purchase 5,334 shares that are exercisable within 60 days of February 15, 2023 by Mr. Ma-Weaver.
(13) Based on a Schedule 13G/A filed with the SEC on February 8, 2023. BML Investment Partners, L.P. is a Delaware limited partnership whose sole general partner is BML Capital Management, LLC. The managing member of BML Capital Management, LLC is Braden M. Leonard. As a result, Braden M. Leonard is deemed to be the indirect owner of the shares held directly by BML Investment Partners, L.P. Despite such shared beneficial ownership, the reporting persons disclaim that they constitute a statutory group within the meaning of Rule 13d-5(b)(1) of the Exchange Act. The address for BML Investment Partners, L.P. is 65 E Cedar - Suite 2, Zionsville, IN 46077.



## Item 13. Certain Relationships and Related Transactions, and Director Independence


## Independence of the Board of Directors

As required under the Nasdaq listing standards, a majority of the members of a listed company's board of directors must qualify as 'independent,' as affirmatively determined by the board of directors. Our Board of Directors consults with the Company's counsel to ensure that the Board of Directors' determinations are consistent with relevant securities and other laws and regulations regarding the definition of 'independent,' including those set forth in pertinent listing standards of the Nasdaq, as in effect from time to time.

Consistent with these considerations, after review of all relevant identified transactions or relationships between each director, or any of his or her family members, and the Company, its senior management and its independent registered public accounting firm, the Board of Directors has affirmatively determined that the following five directors are independent directors within the meaning of the applicable Nasdaq listing standards: Mr. Conway, Dr. Grais, Mr. Mitchell, Dr. Hove and Dr. Woosley. In making this determination, the Board of Directors found that none of the directors had a material or other disqualifying relationship with the Company. Dr. Bristow, the Company's President and Chief Executive Officer is not an independent director by virtue of his employment relationship with the Company.


## Certain Transactions With or Involving Related Persons

The following is a summary of transactions since January 1, 2021, or any currently proposed transaction, in which we were or are a participant and the amount involved exceeds the lesser of $120,000 or one percent of the average of our total assets at fiscal year end for 2022 and 2021, and in which any of our executive officers, directors or holders of more than 5% of our capital stock, or any member of the immediate family of any of the foregoing persons, had or will have a direct or indirect material interest, other than compensation arrangements disclosed in 'Item 11. Executive Compensation' of this Annual Report on Form 10-K.

---

# Page 84

# Transactions With the Company's President and Chief Executive Officer

The Company has entered into unrestricted research grants with the academic research laboratory of Dr. Bristow, the Company's President and Chief Executive Officer, at the University of Colorado. Funding of any unrestricted research grants is contingent upon the Company's financial condition, and can be deferred or terminated at the Company's discretion. Total expense under these arrangements for the years ended December 31, 2022 and 2021 was $432,000 and $439,000, respectively, of which $216,000 was unpaid and included in accrued expenses and other liabilities as of December 31, 2022.


## Cooperation Agreement

The Company is party to a Cooperation Agreement (the 'Agreement') with Cable Car Capital LLC, The Funicular Fund, LP, Funicular Funds, LP and Jacob Ma-Weaver (collectively, 'Cable Car').

Pursuant to the Agreement, the Board appointed Mr. Ma-Weaver as a Class III director with a term expiring at the Company's 2024 annual meeting of stockholders, effective June 15, 2022 and appointed Mr. Ma-Weaver to the Special Committee of the Board.

Additionally, under the terms of the Agreement, the Company and Cable Car initiated a process and subsequently identified a mutually acceptable second independent director, Mr. James Flynn, to join the Company's board of directors (the 'Second Director Appointment'). Mr. Flynn was elected as Director at the 2022 annual meeting of stockholders.

Under the terms of the Agreement, Cable Car agreed to abide by customary standstill restrictions from the date of the Agreement until the earlier to occur of (i) the 180th day after the First Director Appointment is no longer serving as a director of the Company and (ii) the 90th day prior to the 2023 annual meeting of stockholders (such period, the 'Cooperation Period'), including that Cable Car will not, among other things, (i) seek additional representation, or the removal of an existing director, on the Board, (ii) engage in any solicitation of proxies, or (iii) initiate, propose or otherwise solicit, including any solicitations of the type contemplated by Rule 14a-2(b) promulgated under the Securities Exchange Act of 1934 of the Company's stockholders for the approval of any stockholder proposal. The Company and Cable Car also agreed to customary mutual non-disparagement obligations.


## Policies and Procedures for Related Party Transactions

Our Audit Committee reviews and approves all related party transactions. This review covers any material transaction, arrangement or relationship, or any series of similar transactions, arrangements or relationships, in which we were or are to be a participant, and a related party had or will have a direct or indirect material interest, including, purchases of goods or services by or from the related party or entities in which the related party has a material interest, indebtedness, guarantees of indebtedness and employment by us of a related party.


## Item 14. Principal Accountant Fees and Services

The following table represents aggregate fees billed, or expected to be billed, to us for the fiscal years ended December 31, 2022 and December 31, 2021, by KPMG LLP, our independent registered public accounting firm.


|                                                                                                                 | Fiscal Year Ended 2022   | Fiscal Year Ended 2021   |
|-----------------------------------------------------------------------------------------------------------------|--------------------------|--------------------------|
| Audit Fees (1)..............................................................................................$   | 189,612                  | $ 215,651                |
| Audit-related Fees (2) .................................................................................        | -                        | -                        |
| Tax Fees......................................................................................................  | -                        | -                        |
| All Other Fees .............................................................................................    | -                        | -                        |
| Total Fees....................................................................................................$ | 189,612                  | $ 215,651                |
(1) Audit Fees include fees for the (i) audit of the financial statements included in our Form 10-K for our fiscal years ended December 31, 2022, and December 31, 2021, (ii) review of interim financial statements included on Forms 10-Q and (iii) attest, consent and review services normally provided by the accountant in connection with SEC filings.
(2) Audit-related Fees include fees for accounting consultations.


All fees described above were approved by the Audit Committee.

---

# Page 85

# PRE-APPROVAL POLICIES AND PROCEDURES


The above services performed by the independent registered public accounting firm were pre-approved in accordance with the pre-approval policy and procedures adopted by the Audit Committee. This policy describes the permitted audit, audit-related, tax, and other services that our independent registered public accounting firm may perform. The policy also requires that our independent registered public accounting firm provide in writing:
- · an annual description of all relationships between the independent registered public accounting firm and the client that may reasonably be thought to bear on independence;
- · confirm that, in the independent registered public accounting firm's professional judgment, the independent registered public accounting firm is independent of the client under SEC requirements; and
- · discuss with the Audit Committee the independent registered public accounting firm's independence and the potential effects on its independence of performing any non-audit related services.


The services expected to be performed by our independent registered public accounting firm during the subsequent fiscal year are presented to the Audit Committee for pre-approval. Any pre-approval must describe, in writing, the particular service or category of services.

Requests for audit, audit-related, tax, and other services not contemplated by those pre-approved services must be submitted to the Audit Committee for specific pre-approval. Generally, pre-approval is considered at the Audit Committee's regularly scheduled meetings. However, the authority to grant specific pre-approval between meetings, as necessary, has been delegated to the chairman of the Audit Committee. If the chairman is not available, the other two Audit Committee members together have the authority to grant specific pre-approval between meetings. The chairman or the other members must update the Audit Committee at the next regularly scheduled meeting of any services that were granted specific pre-approval.

The Audit Committee pre-approved all audit related services rendered in 2021 and did not rely on the waiver of pre-approval requirement provided by paragraph (c)(7)(i)(C) of Rule 2-01 of Regulation S-X promulgated under the Exchange Act.

---

# Page 86

# PART IV


## Item 15. Exhibits and Financial Statement Schedules


- (a) The following documents are filed as part of this Report:
- 1. Financial statements filed as part of this Report are listed under Part II, Item 8, page 53 of this Annual Report on Form 10-K.
- 2. No schedules are required because either the required information is not present or is not present in amounts sufficient to require submission of the schedule, or because the information required is included in the consolidated financial statements or the notes thereto.



## (b) Exhibits

A list of exhibits filed with this report or incorporated herein by reference is found in the Exhibit Index.


## EXHIBIT INDEX


|             |                                                                                                                                                              | Incorporated by Reference   | Incorporated by Reference   | Incorporated by Reference   |                |
|-------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|-----------------------------|-----------------------------|----------------|
| Exhibit No. | Description                                                                                                                                                  | Form                        | Filing Date                 | Number                      | Filed Herewith |
| 3.1         | Amended and Restated Certificate of Incorporation of the  Registrant, as amended.                                                                            | 10-K                        | 3/27/2009                   | 3.1                         |                |
| 3.1(a)      | Certificate of Amendment to Restated Certificate of  Incorporation.                                                                                          | 8-K                         | 3/5/2013                    | 5.1                         |                |
| 3.1(b)      | Certificate of Amendment to Restated Certificate of  Incorporation.                                                                                          | 8-K                         | 9/3/2015                    | 3.1                         |                |
| 3.1(c)      | Certificate of Amendment to Restated Certificate of  Incorporation.                                                                                          | 8-K                         | 4/3/2019                    | 3.1                         |                |
| 3.2         | Amended and Restated Bylaws of the Registrant, as  amended.                                                                                                  | 8-K                         | 6/28/2021                   | 3.1                         |                |
| 4.1         | Form of Common Stock Certificate.                                                                                                                            | 8-K                         | 1/28/2009                   | 4.1                         |                |
| 4.2         | Form of Common Stock Certificate.                                                                                                                            | 10-Q                        | 5/8/2019                    | 4.2                         |                |
| 4.3         | Reference is made to Exhibits 3.1, 3.1(a), 3.1(b) and 3.2                                                                                                    |                             |                             |                             |                |
| 4.4         | Description of Registered Securities (Incorporated by  reference to Exhibit 4.7 to the Registrant's Annual Report  on Form 10-K filed on February 18, 2020). | 10-K                        | 2/18/2020                   | 4.7                         |                |
| 10.1§       | License and Sublicense Agreement, dated October 28, 2003,  by and between ARCA Discovery, Inc. and CPEC, L.L.C.                                              | 10-Q                        | 5/15/2009                   | 10.1                        |                |
| 10.2        | Amendment to License and Sublicense Agreement, dated  February 22, 2006, by and between ARCA Discovery, Inc.  and CPEC L.L.C.                                | 10-Q                        | 5/15/2009                   | 10.2                        |                |
| 10.3†       | ARCA biopharma, Inc. 2004 Equity Incentive Plan (f/k/a  Nuvelo, Inc. 2004 Equity Incentive Plan), Form of Partial  Acceleration Stock Option Agreement.      | 10-K                        | 3/27/2009                   | 10.34                       |                |
| 10.4†       | ARCA biopharma, Inc. 2004 Equity Incentive Plan (f/k/a  Nuvelo,  Inc.  2004  Equity  Incentive  Plan),  Form  of  No  Acceleration Stock Option Agreement.   | 10-K                        | 3/27/2009                   | 10.35                       |                |

---

# Page 87

| Exhibit   |                                                                                                                                                                       | Incorporated by Reference Filing   | Incorporated by Reference Filing   | Incorporated by Reference Filing   | Filed    |
|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------|------------------------------------|------------------------------------|----------|
| No.       | Description                                                                                                                                                           | Form                               | Date                               | Number                             | Herewith |
| 10.5†     | ARCA biopharma, Inc. 2004 Equity Incentive Plan (f/k/a  Nuvelo, Inc. 2004 Equity Incentive Plan), Form of Director  Stock Option Agreement.                           | 10-K                               | 3/27/2009                          | 10.36                              |          |
| 10.6†     | ARCA biopharma, Inc. 2004 Equity Incentive Plan (f/k/a  Nuvelo, Inc. 2004 Equity Incentive Plan), Form of Notice  of Grant of Stock Option.                           | 10-K                               | 3/27/2009                          | 10.37                              |          |
| 10.7†     | ARCA biopharma, Inc. 2004 Equity Incentive Plan (f/k/a  Nuvelo, Inc. 2004 Equity Incentive Plan), Form of Notice  of Director Grant of Stock Option.                  | 10-K                               | 3/27/2009                          | 10.38                              |          |
| 10.8†     | Amended  and  Restated  Employment  and  Retention  Agreement,  dated  June  4,  2008,  by  and  between  ARCA  biopharma, Inc. and Michael R. Bristow.               | 10-K                               | 3/27/2009                          | 10.43                              |          |
| 10.9      | Assignment and Assumption Agreement, dated January 26,  2009, by and between ARCA biopharma, Inc. and ARCA  biopharma Colorado, Inc.                                  | 10-K                               | 3/27/2009                          | 10.46                              |          |
| 10.10†    | Amended and Restated Employment Agreement, dated June  12,  2008,  by  and  between  ARCA  biopharma,  Inc.  and  Christopher D. Ozeroff.                             | 10-K                               | 3/27/2009                          | 10.45                              |          |
| 10.11     | Assignment and Assumption Agreement, dated January 26,  2009, by and between ARCA biopharma, Inc. and ARCA  biopharma Colorado, Inc.                                  | 10-K                               | 3/27/2009                          | 10.48                              |          |
| 10.12     | Form  of  Indemnification  Agreement  between  ARCA    biopharma, Inc. and its directors and officers.                                                                | 10-K                               | 3/27/2009                          | 10.52                              |          |
| 10.13     | Capital on Demand TM  Sales Agreement, dated January 11,  2017,  by  and  between  ARCA  biopharma,  Inc.  and  JonesTrading Institutional Services LLC.              | 8-K                                | 1/11/2017                          | 10.1                               |          |
| 10.14     | Amendment No. 1 to Capital on Demand TM  Sales  Agreement, dated August 21, 2017, by and between  ARCA biopharma, Inc. and JonesTrading Institutional  Services LLC.  | 8-K                                | 8/21/2017                          | 10.1                               |          |
| 10.15     | Amendment No. 2 to Capital on Demand TM  Sales  Agreement, dated January 25, 2019, by and between  ARCA biopharma, Inc. and JonesTrading Institutional  Services LLC. | 8-K                                | 1/25/2019                          | 10.1                               |          |
| 10.16     | Amendment No. 3 to Capital on Demand TM  Sales  Agreement, dated March 11, 2019, by and between ARCA  biopharma, Inc. and JonesTrading Institutional Services  LLC.   | 8-K                                | 3/11/2019                          | 10.1                               |          |
| 10.17     | Amendment No. 4 to Capital on Demand TM  Sales  Agreement, dated May 9, 2019, by and between ARCA  biopharma, Inc. and JonesTrading Institutional Services            | 8-K                                | 5/9/2019                           | 10.1                               |          |
| 10.18     | Amendment No. 5 to Capital on Demand TM  Sales  Agreement, dated May 20, 2019, by and between ARCA  biopharma, Inc. and JonesTrading Institutional Services           | 8-K                                | 5/20/2019                          | 10.1                               |          |

---

# Page 88

| Exhibit   |                                                                                                                                                                    | Incorporated by Reference Filing   | Incorporated by Reference Filing   | Incorporated by Reference Filing   | Filed    |
|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------|------------------------------------|------------------------------------|----------|
| No.       | Description                                                                                                                                                        | Form                               | Date                               | Number                             | Herewith |
| 10.19     | Amendment No. 6 to Capital on Demand TM  Sales  Agreement, dated June 28, 2019, by and between ARCA  biopharma, Inc. and JonesTrading Institutional Services  LLC. | 8-K                                | 6/28/2019                          | 10.1                               |          |
| 10.20     | Amendment No. 7 to Capital on Demand TM  Sales  Agreement, dated July 2, 2020, by and between ARCA  biopharma, Inc. and JonesTrading Institutional Services  LLC.  | 8-K                                | 7/2/2020                           | 10.1                               |          |
| 10.21     | Amendment No. 8 to Capital on Demand TM  Sales  Agreement, dated July 14, 2020, by and between ARCA  biopharma, Inc. and JonesTrading Institutional Services  LLC. | 8-K                                | 7/14/2020                          | 10.1                               |          |
| 10.22     | Capital on Demand TM  Sales Agreement, dated July 22,  2020, by and between ARCA biopharma, Inc. and  JonesTrading Institutional Services LLC.                     | 8-K                                | 7/22/2020                          | 10.1                               |          |
| 10.23     | Amendment No. 1 to Capital on Demand TM  Sales  Agreement, dated April 6, 2021, by and between ARCA  biopharma, Inc. and JonesTrading Institutional Services  LLC. | 8-K                                | 4/6/2021                           | 10.1                               |          |
| 10.24§    | Amended  and  Restated  Exclusive  License  Agreement,  dated August 12, 2011, by and between the Regents of the  University of Colorado and ARCA biopharma, Inc.  | 10-Q                               | 8/15/2011                          | 10.5                               |          |
| 10.25     | Securities Purchase Agreement by and among the Company  and the purchasers identified therein, dated June 10, 2015.                                                | 8-K                                | 6/11/2015                          | 10.1                               |          |
| 10.26     | Form of Stock Purchase Agreement between the Company  and the Purchasers, dated as of June 2, 2020.                                                                | 8-K                                | 6/3/2020                           | 10.1                               |          |
| 10.27     | Office Lease Agreement, effective August 7, 2020,  between ARCA biopharma, Inc. and Potens Partners LLC.                                                           | 8-K                                | 8/31/2020                          | 10.1                               |          |
| 10.28†    | Amendment Agreement by and between ARCA  biopharma, Inc. and Michael R. Bristow, effective as of  June 13, 2013.                                                   | 10-Q                               | 8/13/2013                          | 10.6                               |          |
| 10.29†    | Amendment Agreement by and between ARCA  biopharma, Inc. and Christopher Ozeroff, effective as of  June 13, 2013.                                                  | 10-Q                               | 8/13/2013                          | 10.8                               |          |
| 10.30†    | ARCA biopharma, Inc. 2013 Equity Incentive Plan.                                                                                                                   | 8-K                                | 9/23/2013                          | 10.1                               |          |
| 10.31†    | Form of Stock Option Agreement and Option Grant Notice  under 2013 Equity Incentive Plan (Standard).                                                               | 8-K                                | 9/23/2013                          | 10.2                               |          |
| 10.32†    | Form of Stock Option Agreement and Option Grant Notice  under 2013 Equity Incentive Plan (Officer).                                                                | 8-K                                | 9/23/2013                          | 10.3                               |          |
| 10.33†    | Form of Stock Option Agreement and Option Grant Notice  under 2013 Equity Incentive Plan (Director).                                                               | 8-K                                | 9/23/2013                          | 10.4                               |          |
| 10.34†    | Form of Restricted Stock Unit Award Agreement and  Notice of Grant Award under 2013 Equity Incentive Plan  (Standard).                                             | 8-K                                | 9/23/2013                          | 10.5                               |          |

---

# Page 89

| Exhibit   |                                                                                                                                                                                                          | Incorporated by Reference   | Incorporated by Reference   | Incorporated by Reference   | Filed    |
|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|-----------------------------|-----------------------------|----------|
| No.       | Description                                                                                                                                                                                              | Form                        | Filing Date                 | Number                      | Herewith |
| 10.35†    | Form of Restricted Stock Unit Award Agreement and  Notice of Grant Award under 2013 Equity Incentive Plan  (Officer).                                                                                    | 8-K                         | 9/23/2013                   | 10.6                        |          |
| 10.36†    | Amended and Restated Employment Agreement, dated  December 29, 2014, by and between ARCA biopharma,  Inc. and Thomas A. Keuer.                                                                           | 8-K/A                       | 12/30/2014                  | 10.2                        |          |
| 10.37†    | Memorandum Regarding Cash Retention Bonus between  ARCA biopharma, Inc. and Thomas A. Keuer dated  December 8, 2022.                                                                                     | 8-K                         | 12/9/2022                   | 10.1                        |          |
| 10.38†    | ARCA biopharma, Inc. 2020 Equity Incentive Plan.                                                                                                                                                         | 8-K                         | 12/10/2020                  | 10.1                        |          |
| 10.39†    | Form of Stock Option Agreement and Option Grant Notice  under 2020 Equity Incentive Plan (Standard).                                                                                                     | 8-K                         | 12/23/2020                  | 10.1                        |          |
| 10.40†    | Form of Stock Option Agreement and Option Grant Notice  under 2020 Equity Incentive Plan (Officer).                                                                                                      | 8-K                         | 12/23/2020                  | 10.2                        |          |
| 10.41†    | Form of Stock Option Agreement and Option Grant Notice  under 2020 Equity Incentive Plan (Director).                                                                                                     | 8-K                         | 12/23/2020                  | 10.3                        |          |
| 10.42†    | Form of Restricted Stock Unit Award Agreement and  Notice of Grant Award under 2020 Equity Incentive Plan  (Standard).                                                                                   | 8-K                         | 12/23/2020                  | 10.4                        |          |
| 10.43†    | Form of Restricted Stock Unit Award Agreement and  Notice of Grant Award under 2020 Equity Incentive Plan  (Officer).                                                                                    | 8-K                         | 12/23/2020                  | 10.5                        |          |
| 10.44†    | Employment Agreement, dated April 21, 2021, by and  between ARCA biopharma, Inc. and C. Jeff Dekker.                                                                                                     | 10-Q                        | 5/11/2021                   | 10.2                        |          |
| 10.45†    | Memorandum Regarding Cash Retention Bonus between  ARCA biopharma, Inc. and C. Jeffrey Dekker dated  December 8, 2022.                                                                                   | 8-K                         | 12/9/2022                   | 10.2                        |          |
| 10.46 (1) | Assignment Agreement for Patent Rights, dated July 1,  2021, by and between ARCA biopharma, Inc. and  University Medical Center of the Johannes Gutenberg                                                | 10-Q                        | 8/4/2021                    | 10.3                        |          |
| 10.47     | University Mainz. Cooperation Agreement, dated as of June 15, 2022, by and  among ARCA biopharma, Inc., Cable Car Capital LLC,  the Funicular Fund LP, Funicular Funds, LP and Jacob  Ma-Weaver.         | 8-K                         | 6/21/2022                   | 10.1                        |          |
| 23.1      | Consent of KPMG LLP, Independent Registered Public  Accounting Firm.                                                                                                                                     |                             |                             |                             | X        |
| 24.1      | Power of Attorney (included in the signature page hereto).                                                                                                                                               |                             |                             |                             | X        |
| 31.1      | Certification of Principal Executive Officer pursuant to  Rule 13a-14(a) or 15d-14(a) under the Securities Exchange  Act of 1934, as adopted pursuant to Section 302 of the  Sarbanes-Oxley Act of 2002. |                             |                             |                             | X        |
| 31.2      | Certification of Principal Financial Officer pursuant to  Rule 13a-14(a) or 15d-14(a) under the Securities Exchange  Act of 1934, as adopted pursuant to Section 302 of the  Sarbanes-Oxley Act of 2002. |                             |                             |                             | X        |

---

# Page 90

|             |                                                                                                                                                                                        | Incorporated by Reference   | Incorporated by Reference   | Incorporated by Reference   |                |
|-------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|-----------------------------|-----------------------------|----------------|
| Exhibit No. | Description                                                                                                                                                                            | Form                        | Filing Date                 | Number                      | Filed Herewith |
| 32.1        | Certification of Principal Executive Officer and Principal  Financial Officer pursuant to 18 U.S.C. sec. 1350, as  adopted pursuant to Section 906 of the Sarbanes-Oxley Act  of 2002. |                             |                             |                             | X              |
| 101.INS     | Inline XBRL Instance Document - the instance document  does not appear in the Interactive Data File because XBRL  tags are embedded within the Inline XBRL document                    |                             |                             |                             | X              |
| 101.SCH     | Inline XBRL Taxonomy Extension Schema Document  (filed electronically herewith)                                                                                                        |                             |                             |                             | X              |
| 101.CAL     | Inline XBRL Taxonomy Extension Calculation Linkbase  Document (filed electronically herewith)                                                                                          |                             |                             |                             | X              |
| 101.LAB     | Inline XBRL Taxonomy Extension Label Linkbase  Document (filed electronically herewith)                                                                                                |                             |                             |                             | X              |
| 101.PRE     | Inline XBRL Taxonomy Extension Presentation Linkbase  Document (filed electronically herewith)                                                                                         |                             |                             |                             | X              |
| 101.DEF     | Inline  XBRL  Taxonomy  Extension  Definition  Linkbase  Document (filed electronically herewith)                                                                                      |                             |                             |                             | X              |
| 104         | Cover Page Interactive Data File (embedded within the  Inline XBRL document).                                                                                                          |                             |                             |                             |                |
† Indicates management contract or compensatory plan or arrangement required to be filed as an exhibit pursuant to Item 15(b) of Form 10-K.
§ Confidential treatment has been granted as to portions of the exhibit. Confidential materials omitted and filed separately with the SEC.
(1) Schedules have been omitted from this filing pursuant to Item 601(b)(2) of Regulation S-K. ARCA agrees to furnish supplementally a copy of any omitted schedule to the SEC upon its request; provided, however, that the Company may request confidential treatment pursuant to Rule 24b-2 of the Exchange Act for any schedule so furnished. Certain portions of the exhibit, identified by the mark, '[*],' have been omitted because such portions contained information that is both (i) not material and (ii) would likely cause competitive harm if publicly disclosed.

---

# Page 91

# SIGNATURES

Pursuant to the requirements of Section 13 or 15(d) the Securities Exchange Act of 1934, the Registrant has duly caused this report to be signed on its behalf by the undersigned, thereunto duly authorized.


## ARCA biopharma, Inc.

By:

/S/ C. Jeffrey Dekker

C. Jeffrey Dekker


## Chief Financial Officer

(Principal Financial Officer and Principal Accounting Officer)

Date: February 24, 2023


## POWER OF ATTORNEY

KNOW ALL PERSONS BY THESE PRESENTS, that each person whose signature appears below constitutes and appoints Michael R. Bristow and C. Jeffrey Dekker, and each of them, as his true and lawful attorneys-in-fact and agents, with full power of substitution for him, and in his name in any and all capacities, to sign any and all amendments to this Annual Report on Form 10-K, and to file the same, with exhibits thereto and other documents in connection therewith, with the Securities and Exchange Commission, granting unto said attorneys-in-fact and agents, and each of them, full power and authority to do and perform each and every act and thing requisite and necessary to be done therewith, as fully to all intents and purposes as he might or could do in person, hereby ratifying and confirming all that said attorneys-in-fact and agents, and any of them or his or her substitute or substitutes, may lawfully do or cause to be done by virtue hereof.

Pursuant to the requirements of the Securities Exchange Act of 1934, this report has been signed by the following persons on behalf of ARCA biopharma, Inc., in the capacities and on the dates indicated.


| Signature              | Title                                                          | Date              |
|------------------------|----------------------------------------------------------------|-------------------|
| /S/ Michael R. Bristow | President and Chief Executive                                  | February 24, 2023 |
| Michael R. Bristow     | (Principal Executive Officer) Officer and Director             |                   |
| /S/ C. Jeffrey Dekker  | Chief Financial Officer                                        | February 24, 2023 |
| C. Jeffrey Dekker      | (Principal Financial Officer and Principal Accounting Officer) |                   |
| /S/ Linda Grais        | Director                                                       | February 24, 2023 |
| Linda Grais            |                                                                |                   |
| /s/ Raymond Woosley    | Director                                                       | February 24, 2023 |
| Raymond Woosley        |                                                                |                   |
| /s/ Robert Conway      | Director                                                       | February 24, 2023 |
| Robert Conway          |                                                                |                   |
| /s/ Daniel Mitchell    | Director                                                       | February 24, 2023 |
| Daniel Mitchell        |                                                                |                   |
| /s/ Anders Hove        | Director                                                       | February 24, 2023 |
| Anders Hove            |                                                                |                   |
| /s/ Jacob Ma-Weaver    | Director                                                       | February 24, 2023 |
| Jacob Ma-Weaver        |                                                                |                   |
| /s/ James Flynn        | Director                                                       | February 24, 2023 |


James Flynn