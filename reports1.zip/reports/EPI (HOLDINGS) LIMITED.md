

---

# Page 1

# EPI (Holdings) Limited_

(Incorporated in Bermuda with limited liability) (Stock Code 689)


## ANNUAL REPORT 2022

8000

30

---

# Page 2



---

# Page 3

# Contents


- 3 Corporate Information

---

# Page 4

# Abbreviations

In this annual report, the following abbreviations have the following meanings unless otherwise specified:

'Board'

Board of Directors of the Company

'Company'

EPI (Holdings) Limited

'Director(s)'

director(s) of the Company

'Group'

the Company and its subsidiaries

'Hong Kong Companies Ordinance'

Companies Ordinance (Chapter 622 of the Laws of Hong Kong)

'Hong Kong Stock Exchange'

The Stock Exchange of Hong Kong Limited

'Listing Rules'

Rules  Governing  the  Listing  of  Securities  on  the  Hong  Kong  Stock Exchange

'Model Code'

Model Code for Securities Transactions by Directors of Listed Issuers set out in Appendix 10 to the Listing Rules

'PRC'

People's Republic of China

'RMB'

Renminbi

'SFO'

Securities  and  Futures  Ordinance  (Chapter  571  of  the  Laws  of  Hong Kong)

'C$'

Canadian dollars

'HK$' and 'HK cent(s)'

Hong Kong dollars and cent(s)

'US$'

United States dollars

'%'

per cent.

The Chinese version of this annual report is a translation of the English version and is for reference only. In case of any discrepancies or inconsistencies between the English version and the Chinese version, the English version shall prevail.

---

# Page 5

# BOARD OF DIRECTORS

Executive Directors

Mr. Sue Ka Lok

Mr. Yiu Chun Kong

Mr. Chan Shui Yuen


## Independent Non-executive Directors

Mr. Pun Chi Ping Ms. Leung Pik Har, Christine

Mr. Kwong Tin Lap


## AUDIT COMMITTEE

Mr. Pun Chi Ping (Chairman)

Ms. Leung Pik Har, Christine

Mr. Kwong Tin Lap


## REMUNERATION COMMITTEE

Mr. Pun Chi Ping (Chairman)

Ms. Leung Pik Har, Christine

Mr. Kwong Tin Lap


## NOMINATION COMMITTEE

Ms. Leung Pik Har, Christine (Chairlady)

Mr. Pun Chi Ping

Mr. Kwong Tin Lap


## CORPORATE GOVERNANCE COMMITTEE

Mr. Kwong Tin Lap (Chairman)

Mr. Sue Ka Lok

Mr. Chan Shui Yuen


## COMPANY SECRETARY

Mr. Chan Shui Yuen


## REGISTERED OFFICE

Clarendon House

2 Church Street

Hamilton HM11

Bermuda


## Corporate Information


## PRINCIPAL PLACE OF BUSINESS IN HONG KONG

Rooms 1502-03, 15th Floor Great Eagle Centre 23 Harbour Road Wanchai, Hong Kong


## PRINCIPAL BANKERS

The Hongkong and Shanghai Banking Corporation

Limited

Hang Seng Bank Limited

Bank of Communications Co., Ltd., Hong Kong Branch

Bank of Communications (Hong Kong) Limited

China CITIC Bank International Limited

Bank of Montreal


## LEGAL ADVISERS

Reed Smith Richards Butler

Stevenson, Wong & Co.


## AUDITOR

Moore Stephens CPA Limited

Certified Public Accountants

Registered Public Interest Entity Auditors


## PRINCIPAL SHARE REGISTRAR AND TRANSFER OFFICE

MUFG Fund Services (Bermuda) Limited

4th Floor, North Cedar House 41 Cedar Avenue Hamilton HM12

Bermuda


## HONG KONG BRANCH SHARE REGISTRAR AND TRANSFER OFFICE

Tricor Tengis Limited 17/F, Far East Finance Centre 16 Harcourt Road Hong Kong


## TRADING OF SHARES

Hong Kong Stock Exchange

(Stock Code: 689)


## WEBSITE

https://www.epiholdings.com

---

# Page 6

# Statement from the Board

On behalf of the Board, I hereby present to the shareholders the results of the Group for the year ended 31 December 2022 (' FY2022 ').


## RESULTS

For  FY2022,  the  Group  continued  to  principally  engage  in  the  business  of  petroleum  exploration  and production, solar energy, money leading and investment in securities.

During FY2022, there was a sharp surge in international oil prices largely because of the revival of economic activities  worldwide  following  the  easing  of  the  COVID  pandemic,  and  the  tightened  supply  of  energy sources following the outbreak of war between Russia and Ukraine. The price of Brent crude oil, one of the benchmarks of international oil prices, jumped from around US$80 per barrel in December 2021, reached its peak of over US$130 per barrel in March 2022, and dropped back to around US$80 per barrel in December 2022.  Although  international  oil  prices  continue  to  fluctuate  considerably  recently,  they  are  hovering  at comparatively high levels to their  historical  trends  in  the  past  five  years  and  current  market  outlook  of  the industry remains positive.

Leveraging  on  the  Group's  business  experience  of  its  oil  operation  in  Argentina  and  with  the  intent  of continuing  its  petroleum  exploration  and  production  business,  as  announced  by  the  Company  on  17  July 2022,  the  Group  has  completed  the  acquisition  of  an  operating  oil  field  which  comprises  petroleum  and natural  gas  rights,  facilities  and  pipelines,  together  with  all  other  properties  and  assets  located  in  Alberta Province  of  Canada  (the  ' Canadian  Oil  Assets ')  for  a  final  consideration  of  C$22,500,000  (equivalent  to HK$135,461,000).  Upon  closing  of  the  transactions,  the  financial  results  of  the  Canadian  Oil  Assets  have been incorporated in the Group's consolidated financial statements. For the period from 16 July 2022 to 31 December 2022, the Canadian Oil Assets contributed a revenue of HK$30,932,000 and an operating profit of HK$4,078,000 to the Group's results for FY2022, and for the same period, the earnings before interest, taxes, depreciation and amortisation generated by the Canadian Oil Assets was HK$13,178,000. The acquisition of the Canadian Oil Assets represents a valuable and attractive opportunity for the Group to continue developing its petroleum exploration and production business.

In  alignment  with  the  Group's  strategic  initiatives  to  develop  a  diversified  and  balanced  energy  business portfolio,  in  July  2021,  the  Group  entered  into  a  cooperation  framework  agreement  (the  ' Cooperation Agreement ') with a specialist solar energy total solution and services provider to invest in solar energy power generation projects that are participating in the Renewable Energy Feed-in Tariff Scheme (the ' FiT Scheme '), which  is  a  scheme  promoted  by  the  Hong  Kong  Government  to  incentivise  the  private  sector  to  produce clean energy for sale to the two power companies in Hong Kong. In August 2021, for further development of the solar energy business, the Group entered into an acquisition agreement (the ' Acquisition Agreement ') to  acquire  a  portfolio  of  existing  and  to-be-completed  solar  energy  power  generation  projects  which  are participating in the FiT Scheme. As of 31 December 2022, the Group has invested a sum of HK$51,516,000 in solar energy power generation projects under the two aforementioned agreements.

For FY2022, the Group's petroleum exploration and production business contributed a profit of HK$4,078,000 (2021: loss of HK$4,112,000), the solar energy business contributed a profit of HK$1,403,000 (2021: HK$89,000), the money lending business recorded a loss of HK$16,237,000 (2021: profit of HK$17,440,000), and the Group's investment in securities recorded a loss of HK$9,743,000 (2021: HK$32,533,000).

---

# Page 7

# Statement from the Board

Overall speaking, the Group recorded an increase in revenue by 84% to HK$45,102,000 (2021: HK$24,496,000), mainly  due  to  the  incorporation  of  the  Canadian  Oil  Assets'  revenue  in  the  Group's  consolidated  financial statements  since  July  2022,  and  reported  a  loss  attributable  to  owners  of  the  Company  of  HK$46,746,000 (2021:  HK$29,371,000)  that  mainly  due  to  (i)  the  recognition  of  net  loss  on  financial  assets  at  fair  value through profit or loss of HK$1,952,000 in contrast to the net gain of HK$7,870,000 recorded in last year; (ii) the  increase  in  depreciation  which  mainly  related  to  the  Canadian  Oil  Assets  and  the  Group's  solar  energy power generation projects to HK$13,130,000 (2021: HK$1,666,000); (iii) the provision of expected credit loss (' ECL ') on loan and interest receivables of HK$20,019,000 (2021: reversal of ECL of HK$4,356,000); and (iv) the increase in other expense to HK$14,875,000 (2021: HK$7,193,000) mainly due to the professional fees incurred for  the  acquisition  of  the  Canadian  Oil  Assets;  whilst  partly  offset  by  (i)  the  decrease  in  provision  of  ECL  on debt instruments at fair value through other comprehensive income to HK$11,081,000 (2021: HK$49,247,000), and (ii) the profit contributions from the petroleum exploration and production and solar energy businesses totalling  HK$5,481,000 (2021: net loss of HK$4,023,000). Basic loss per share was HK0.89 cent (2021: HK0.56 cent).


## PROSPECTS

It is the Group's business strategy to continue developing its petroleum exploration and production business, along  with  expanding  and  diversifying  its  business  in  the  energy  sector  to  the  next  level  by  investing  in renewable energy assets, including solar energy projects, which would support the healthy and sustainable business development of the Group in the long run and create new value to shareholders. In pursuance of these strategic initiatives, the Group has successfully acquired the Canadian Oil Assets, and entered into the Cooperation Agreement and Acquisition Agreement for the development of its solar energy business.

The  Canadian  Oil  Assets  are  located  near  Calgary  City,  Alberta  Province  in  Canada.  The  Group  considers Canada is one of the ideal countries for developing petroleum exploration and production business as it has a  stable  political  environment,  a  well-established  system  of  oil  regulations  and  industrial  policies,  a  welldeveloped business infrastructure for the oil industry, and the third largest oil reserves in the world. There are thus enormous business opportunities available in Canada for the Group to develop its petroleum business.

The  solar  energy  power  generation  projects  the  Group  investing  in  are  projects  participating  in  the  FiT Scheme. The FiT  Scheme  is  a  policy  initiative  introduced  by  the  Hong  Kong  Government  to  encourage  the private sector to participate in producing cleaner fuel and developing renewable energy technologies. Under the FiT Scheme, scheme participants who install solar or wind power generation system at their premises can sell the renewable energy generated to the two power companies in Hong Kong at a rate considerably higher than the normal electricity tariff rate. The FiT Scheme will be offered until the end of 2033, through investing in solar energy power generation projects participating in the FiT Scheme, the Group is able to secure a longterm  and  stable  stream  of  revenue  from  the  tariff  income  earning  by  the  projects  participating  in  the  FiT Scheme.

Looking forward, the Group will continue to actively pursue its interests in the petroleum and solar energy businesses and will manage its businesses in a prudent approach in view of the business uncertainties brought by the heightened political and economic tensions between China and the US, and the war between Russia and Ukraine which brings significant volatilities to international prices of oil and gas.

It  is  the  Group's  business  strategy  to  build  a  diversified  and  balanced  energy business portfolio, comprising petroleum as well as solar energy assets, which will present the Group with favourable long-term prospects, and is in line with the Group's sustainable corporate strategy of broadening its income stream for the goal of achieving a stable, long-term and attractive return to shareholders.

---

# Page 8

# Statement from the Board


## APPRECIATION

On  behalf  of  the  Board,  I  would  like  to  express  my  sincere  thanks  to  all  shareholders,  bankers,  business associates, suppliers and customers for their continuing support to the Group, the board members for their valuable services, and all staff members for their contribution and hard work during the past year.


## Sue Ka Lok

Executive Director

Hong Kong, 30 March 2023

---

# Page 9

# Management Discussion and Analysis


## BUSINESS REVIEW

For the year ended 31 December 2022 (' FY2022 '), the Group continued to principally engage in the business of petroleum exploration and production, solar energy, money lending and investment in securities.

During FY2022, there was a sharp surge in international oil prices largely because of the revival of economic activities  worldwide  following  the  easing  of  the  COVID  pandemic,  and  the  tightened  supply  of  energy sources following the outbreak of war between Russia and Ukraine. The price of Brent crude oil, one of the benchmarks of  international  oil  prices,  jumped  from  around  US$80  per  barrel  (' bbl ')  in  December  2021  to its  peak  of  over  US$130  per  bbl  in  March  2022,  and  dropped  back  to  around  US$80  per  bbl  in  December 2022.  Although  international  oil  prices  continue  to  fluctuate  considerably  recently,  they  are  hovering  at comparatively high levels to their  historical  trends  in  the  past  five  years  and  current  market  outlook  of  the industry remains positive.

Leveraging  on  the  Group's  business  experience  of  its  oil  operation  in  Argentina  and  with  the  intent  of continuing  its  petroleum  exploration  and  production  business,  as  announced  by  the  Company  on  17  July 2022,  the  Group  has  completed  the  acquisition  of  an  operating  oilfield  which  comprises  petroleum  and natural  gas  rights,  facilities  and  pipelines,  together  with  all  other  properties  and  assets  located  in  Alberta Province  in  Canada  (the  ' Canadian  Oil  Assets ')  for  a  final  consideration  of  C$22,500,000  (equivalent  to HK$135,461,000).  Upon  closing  of  the  transaction,  the  financial  results  of  the  Canadian  Oil  Assets  have been incorporated in the Group's consolidated financial statements. For the period from 16 July 2022 to 31 December 2022, the Canadian Oil Assets contributed a revenue of HK$30,932,000 and an operating profit of HK$4,078,000 to the Group's results for FY2022, and for the same period, the earnings before interest, taxes, depreciations and amortisation (' EBITDA ') generated by the Canadian Oil Assets was HK$13,178,000.

In  alignment  with  the  Group's  strategic  initiatives  to  develop  a  diversified  and  balanced  energy  business portfolio,  in  July  2021,  the  Group  entered  into  a  cooperation  framework  agreement  (the  ' Cooperation Agreement ') with a specialist solar energy total solution and services provider to invest in solar energy power generation projects that are participating in the Renewable Energy Feed-in Tariff Scheme (the ' FiT Scheme '), which  is  a  scheme  promoted  by  the  Hong  Kong  Government  to  incentivise  the  private  sector  to  produce clean energy for sale to the two power companies in Hong Kong. In August 2021, for further development of the solar energy business, the Group entered into an acquisition agreement (the ' Acquisition Agreement ') to  acquire  a  portfolio  of  existing  and  to-be-completed  solar  energy  power  generation  projects  which  are participating in the FiT Scheme. As of 31 December 2022, the Group has invested a sum of HK$51,516,000 in solar energy power generation projects under the two aforementioned agreements.

---

# Page 10

# Management Discussion and Analysis

For  FY2022,  the  Group  recorded  an  increase  in  revenue  by  84%  to  HK$45,102,000  (2021:  HK$24,496,000), mainly  due  to  the  incorporation  of  the  Canadian  Oil  Assets'  revenue  in  the  Group's  consolidated  financial statements  since  July  2022,  and  reported  a  loss  attributable  to  owners  of  the  Company  of  HK$46,746,000 (2021: HK$29,371,000) that mainly attributed to (i) the recognition of net loss on financial assets at fair value through profit or loss (' FVTPL ') of HK$1,952,000 in contrast to the net gain of HK$7,870,000 recorded in last year;  (ii)  the  increase  in  depreciation  which  mainly  related  to  the  Canadian  Oil  Assets  and  the  Group's  solar energy  power  generation  projects  to  HK$13,130,000  (2021:  HK$1,666,000);  (iii)  the  provision  of  expected credit loss (' ECL ') on loan and interest receivables of HK$20,019,000 (2021: reversal of ECL of HK$4,356,000); and (iv) the increase in other expenses to HK$14,875,000 (2021: HK$7,193,000) mainly due to the professional fees incurred for the acquisition of the Canadian Oil Assets, whilst partly offset by (i) the decrease in provision of ECL on debt instruments at fair value through other comprehensive income (' FVTOCI ')  to  HK$11,081,000 (2021:  HK$49,247,000); and (ii)  the  profit  contributions  from  the  petroleum  exploration  and  production  and solar energy businesses totalling HK$5,481,000 (2021: net loss of HK$4,023,000).


## Petroleum Exploration and Production

As stated in the Company's announcement dated 16 March 2021, the Group's interest in an oil concession in the Chañares Herrados area (the ' CHE Concession ') located in Cuyana Basin, Mendoza Province of Argentina was taken over by a new concessionaire on 13 March 2021, accordingly, the Group's petroleum exploration and production business in Argentina ceased in FY2022. As above mentioned, the acquisition of the Canadian Oil  Assets  was  completed  on  16  July  2022,  since  then,  the  financial  results  of  the  Canadian  Oil  Assets  have been  incorporated  in  the  Group's  consolidated  financial  statements.  For  FY2022,  the  Group's  petroleum exploration  and  production  business  (now  constituted  by  the  Canadian  Oil  Assets)  generated  a  revenue of  HK$30,932,000,  an  operating  profit  of  HK$4,078,000  and  an  EBITDA  of  HK$13,178,000  whilst  in  last  year, before the CHE Concession was taken over, it generated a revenue of HK$1,523,000 and incurred an operating losses of HK$4,112,000. It is expected that the revenue and EBITDA generated by the Canadian Oil Assets will continue to grow in 2023 as their full year results, together with the production of new wells drilled, will be incorporated in the Group's results.

The Canadian Oil Assets represent an operating oilfield comprising petroleum and natural gas rights, facilities and pipelines, together with other properties and assets spanned on 8,818 net acres of land in Windy Lake region, near Calgary in Alberta Province of Canada.

The Canadian Oil Assets is managed under EP Resources Corporation (' EPR '), a Canadian incorporated whollyowned subsidiary of the Company, by a team of local management with extensive experience in the oil and gas  industry  in  Calgary,  Canada.  For  the  period  from  16  July  2022  to  31  December  2022,  the  Canadian  Oil Assets  produced  approximately  81,300  bbl  and  sold  81,100  bbl  of  crude  oil,  and  generated  a  revenue  of approximately  C$6,618,000  (equivalent  to  HK$39,821,000)  (before  royalties  payment)  at  an  average  selling price  of  C$81.6  per  bbl.  The  crude  oil  produced  from  the  Canadian  Oil  Assets  were  trucked  and  sold  to  the independent oil distributors located in the nearby regions who will largely resell the same to the American importers.

---

# Page 11

# Management Discussion and Analysis


From  July  2022  onwards  and  up  to  the  end  of  2022,  EPR  had  incurred  capital  expenditure  totalling C$2,655,000 (equivalent to HK$15,285,000) for new wells drilling and production enhancement work for the number of wells as shown in the table below:
|                         | Number of wells   | Capital Expenditure   | Capital Expenditure   |
|-------------------------|-------------------|-----------------------|-----------------------|
|                         |                   | C$'000                | HK$'000  equivalent   |
| New wells drilling      | 3                 | 2,156                 | 12,412                |
| Wells reactivations     | 3                 | 140                   | 806                   |
| Additional perforations | 2                 | 270                   | 1,555                 |
| Wells recompletion      | 1                 | 89                    | 512                   |
|                         |                   | 2,655                 | 15,285                |


As of 31 December 2022, there were 35 producing wells in operation, with an average remaining reserve life of  more  than  ten  years,  compared  to  32  producing  wells  when  the  acquisition  of  the  Canadian  Oil  Assets took  place  in  July  2022.  The  addition  of  the  three  producing  wells  was  a  result  of  the  wells  reactivations work  performed.  The  drilling  work  of  the  three  new  wells  were  in  progress  at  the  end  of  2022,  with  two were  subsequently  completed  in  January  2023  and  one  in  February  2023.  All  three  new  wells  drilled  have commenced production and are currently in operation.


As at 31 December 2022, an update of the estimated oil reserves of the Canadian Oil Assets are as follows:
|                         | Gross Remaining Reserves            | Gross Remaining Reserves            |
|-------------------------|-------------------------------------|-------------------------------------|
|                         | As at  31 December  2022 * '000 bbl | As at  31 December  2021 # '000 bbl |
| Proved                  |                                     |                                     |
| Developed producing     | 502.1                               | 630.2                               |
| Developed non-producing | 140.8                               | 38.6                                |
| Undeveloped             | 902.0                               | 1,063.0                             |
| Total Proved            | 1,544.9                             | 1,731.8                             |
| Probable                | 1,653.0                             | 1,958.8                             |
| Proved plus Probable    | 3,197.9                             | 3,690.6                             |

---

# Page 12

# Management Discussion and Analysis


- * According to the reserve report (' Reserve Report ') prepared by Trimble Engineering Associates Ltd. (' Trimble ') on the estimated oil reserves of the Canadian Oil Assets as at 31 December 2022, Trimble was the competent person engaged by the Company in preparing the competent person's report (' CPR ')  contained in the circular dated 11 March 2022 (the ' Circular ') in relation to the acquisition of the Canadian Oil Assets. The same set of methodology adopted  in  preparing  the  CPR  are  adopted  in  preparing  the  Reserve  Report.  Further  details  of  the  Canadian  Oil Assets were contained in the Circular.
- # The Group acquired the Canadian Oil Assets in July 2022. The data of the estimated oil reserves of the Canadian Oil Assets as at 31 December 2021 are extracted from the Circular and are for illustration only.


According  to  the  Group's  initial  four-year  development  plan  for  the  Canadian  Oil  Assets,  it  was  envisaged that 6, 14, 18 and 11 new wells would be drilled in 2022, 2023, 2024 and 2025. In respect of the 2022 drilling plan,  for  the  reason  that  the  completion  time  of  acquiring  the  Canadian  Oil  Assets  in  July  2022  was  later than envisaged when the development plan was first made, the Group could only manage to complete the drilling work for two new wells in January 2023 and one in February 2023. As for the planned drilling of the other three new wells, the plan is currently held up pending for further evaluation as based on the production data  that  the  Group  has  collected  from  the  local  government  authorities  for  the  oilfields  located  near  the target  new  wells,  and  the  updated  geological  information  including  seismic  data  of  the  target  new  wells and the oilfields nearby, the production of the target new wells may not meet the desired level as originally anticipated. In respect of the 2023 drilling plan, the work is progressing as planned except that the number of  new  wells  to  be  drilled  on  a  target  site  will  be  8  instead  of  14  while  the  forecasted  production  from  the new wells will remain the same. After further study of the geological information of the target site, the Group decided to employ a different horizontal drilling technique which could be more cost effective than the one originally  planned,  with  the  result  that  less  wells  will  be  drilled  while  the  forecasted  production  level  will remain the same. In respect of the drilling plans for 29 new wells in 2024 and 2025, based on the production data of nearby oilfields and geological information recently collected, together with other technical reasons, the plans will be revised with 14, 10 and 5 new wells to be drilled in 2024, 2025 and 2026, adding up to the same number of new wells as originally planned. Primarily owing to the change of drilling plan for 2022 and the  completion  time  of  the  three  new  wells  were  deferred  to  before  the  end  of  February  2023,  it  caused  a variance to the cashflow expected to be generated from the Canadian Oil Assets in 2022.


## Solar Energy

In  recent  years,  major  countries  in  the  world  are  actively  formulating  their  energy  policies  to  curb  carbon emissions  and  it  is  the  Group's  business  strategy  to  expand  its  footprints  in  the  energy  sector  through investing  in  renewable  energy  assets,  including  solar  energy  projects,  which  could  support  the  Group's healthy  and  sustainable  business  development.  On  23  July  2021,  in  order  to  capture  the  business opportunities  in  decarbonisation,  the  Group  entered  into  the  Cooperation  Agreement  with  a  specialist solar  energy  total  solution  and  services  provider  to  invest  in  solar  energy  power  generation  projects,  from which  the  electricity  generated  can  be  sold  to  the  two  power  companies  and  thereby  earning  the  feed-in tariff  income  under  the  FiT  Scheme.  Moreover,  for  further  development  of  the  solar  energy  business,  on  30 August 2021, the Group entered into the Acquisition Agreement to acquire a portfolio of existing and to-becompleted solar energy power generation projects which are participating in the FiT Scheme. Further details of the transactions were stated in the Company's announcements dated 23 July 2021, 30 August 2021 and 16 September 2021.

---

# Page 13

# Management Discussion and Analysis

During  FY2022,  the  Group  has  made  further  investment  of  HK$7,871,000  and  bringing  the  Group's  total investment  in  solar  energy  power  generation  projects  up  to  HK$51,516,000  as  of  31  December  2022,  with a  further  capital  commitment  of  approximately  HK$6,978,000.  As  of  the  year  end,  the  Group  has  40  solar photovoltaic systems in operation, and 10 solar photovoltaic systems are scheduled to be completed before the end of first quarter 2023. For FY2022, the solar energy business contributed a revenue and an operating profit of HK$6,536,000 (2021: HK$652,000) and HK$1,403,000 (2021: HK$89,000) respectively to the Group, and EBITDA of the business was HK$5,157,000 (2021: HK$396,000).


## Money Lending

For  FY2022,  the  Group's  money  lending  business  reported  decreases  in  revenue  by  71%  to  HK$3,877,000 (2021:  HK$13,182,000)  and  operating  profit  (before  provision  of  ECL)  by  71%  to  HK$3,782,000  (2021: HK$13,084,000),  which  were  mainly  due  to  the  lower  average  amount  of  performing  loans  advanced  to borrowers during FY2022. A provision of ECL of HK$20,019,000 (2021: reversal of ECL of HK$4,356,000) on loan and interest receivables was recognised during the year.

The Group performs impairment assessment on loan receivables under the ECL model. The measurement of ECL is  a  function  of  the  probability  of  default,  the  loss  given  default  (i.e.  the  magnitude  of  the  loss  if  there is  a  default)  and  the  exposure  at  default  (i.e.  the  magnitude  of  the  loss  after  accounting  for  value  of  the collateral  if  there  is  a  default).  The  assessment  of  probability  of  default  and  loss  given  default  is  based  on historical  data  and  forward-looking  information,  whilst  the  valuation  of  the  assets/properties  pledged  to the  Group  as  collaterals  are  performed  by  independent  professional  valuers  engaged  by  the  Group,  where applicable, at each reporting date for the purpose of determining ECL. In accordance with the Group's loan impairment policy, the amount of ECL is updated at each reporting date to reflect the changes in credit risk on  loan  receivables  since  initial  recognition.  At  the  period  end,  the  net  impairment  allowance  recognised primarily  represented  the  credit  risk  involved  in  collectability  of  certain  default  and  non-default  loans determined under the Group's loan impairment policy, with reference to factors including the credit history and  financial  conditions  of  the  borrowers,  the  ageing  of  the  overdue  balances,  the  realisation  value  of  the collaterals  pledged  to  the  Group,  and  forward-looking  information  including  the  future  macroeconomic conditions  affecting  the  borrowers  (the  negative  impact  of  the  COVID  epidemic  on  the  economy  had  also been considered).

The Group has a system in place to closely monitor the recoverability of its loan portfolio, its credit monitoring measures include regular collateral value review against market information and regular communication with the  borrowers  of  their  financial  positions,  through  which  the  Group  will  be  able  to  keep  updated  with  the latest credit profile and risk associated with each individual borrower and could take appropriate actions for recovery of a loan at the earliest time. If circumstances require, the Group will commence legal actions against the borrowers for recovery of the overdue loans and taking possession of the collaterals pledged.

For FY2022, a provision of ECL of HK$20,019,000 (2021: reversal of ECL of HK$4,356,000) was recognised which primarily  represented  the  credit  risk  involved  in  collectability  of  certain  credit-impaired  loans  determined under  the  Group's  loan  impairment  policy,  and  have  considered  factors  including  the  credit  history  of the  borrowers,  the  realisation  value  of  the  collaterals  pledged  to  the  Group,  and  the  prevailing  economic conditions.  The  Group  has  taken  various  actions  for  recovery  of  the  credit-impaired  loans.  There  was  no change  in  the  method  used  in  determining  the  impairment  allowance  on  loan  receivables  from  the  prior financial year.

---

# Page 14

# Management Discussion and Analysis

The size of the Group's loan portfolio reduced by 47% to HK$60,582,000 (2021: HK$115,001,000) (on a net of impairment allowance basis) was mainly a result of the settlement or partial repayment of certain loans. The Group  aims  to  make  loans  that  could  be  covered  by  sufficient  collaterals,  preferably  properties  and  assets with good quality, and to borrowers with good credit history. The target customer groups of the business are individuals and corporate entities that have short-term funding needs for business purpose and could provide sufficient collaterals for their borrowings. The Group has a stable source of loan deals from its own business network and its sales agents.


At  31  December  2022,  the  carrying  amount  of  the  loan  portfolio  held  by  the  Group  amounted  to HK$60,852,000  (after  impairment  allowance  of  HK$23,800,000)  (2021:  HK$115,001,000  (after  impairment allowance of HK$34,915,000)) with details as follows:
| Category of borrowers   |   Approximate  weighting to the  carrying amount  of the Group's  loan portfolio % | Interest rate  per annum %   | Maturity        |
|-------------------------|------------------------------------------------------------------------------------|------------------------------|-----------------|
| Corporate               |                                                                               76.9 | 8.5 - 12.0                   | Within one year |
| Individual              |                                                                               23.1 | 11.0 - 18.0                  | Within one year |
|                         |                                                                              100   |                              |                 |


At  31  December  2022,  85%  (2021:  100%)  of  the  carrying  amount  of  the  loan  portfolio  (after  impairment allowance) was secured by collaterals with 15% (2021: nil) being unsecured. At the year end, the loans made to all borrowers were term loans with maturity within one year, and the loan made to the largest borrower and the four largest borrowers accounted for 39% and 100% respectively of the Group's loan portfolio (on a net of impairment allowance basis).

The Group has credit policies, guidelines and procedures in place which cover key internal controls of a loan transaction  including  (i)  due  diligence;  (ii)  credit  appraisal;  (iii)  proper  execution  of  documentations;  (iv) continuous  monitoring  and  (v)  collection  and  recovery.  Before  granting  loan  to  a  potential  customer,  the Group  performs  credit  appraisal  process  to  assess  the  potential  borrower's  credit  quality  and  defines  the credit  limit  granted  to  the  borrower.  The  credit  appraisal  process  encompasses  detailed  assessment  on  the credit history and financial background of the borrower, as well as the value and nature of the collateral to be pledged. The credit limit of a loan successfully granted to the borrower will be subject to regular credit review by the management as part of the ongoing loan monitoring process.

---

# Page 15

# Management Discussion and Analysis

The following is a summary of the key internal controls of the Group's money lending operation:

Due diligence

Credit appraisal

Proper execution of documentations

Continuous monitoring

Collection and recovery

Identity  check  and  financial  background  check  on  the  loan  applicant will  be  performed.  Information  provided  by  the  loan  applicant  including identity,  financial  statements  and  income  proof  of  the  applicant  will  be checked  and  verified  by  the  responsible  loan  officer,  where  appropriate, company, legal, credit and bankruptcy search on the loan applicant, and land  search  and  site  visit  on  the  property  offered  as  collateral,  will  be conducted.

Detailed  assessment  on  the  credit  history  and  financial  background  of the loan applicant, as well as the value and nature of the collateral to be pledged,  will  be  conducted.  There  will  be  credit  assessment  including analysis on the repayment ability and credit history of the loan applicant, and  analysis  on  the  potential  recovery  from  realisation  of  the  collateral. The credit assessment process will be conducted by the responsible loan officer and reviewed by the responsible loan manager.

For loan application recommended by the responsible loan manager and duly  approved  by  the  board  of  directors  of  the  Group's  money  lending subsidiary,  the  responsible  loan  officer  will  arrange  preparation  and proper execution of the loan documentations under the supervision of the responsible  loan  manager,  and  usually  with  the  support  of  professional lawyers.

There  will  be  continuous  monitoring  on  the  repayments  from  borrower, regular  communication  with  the  borrower  of  its  updated  financial position, and regular review on credit limit of the loan granted and market value of the collateral pledged performed by the responsible loan officer and manager.

Formal reminder and legal demand letter will be issued to the borrower if  there  is  an  overdue  payment.  Where  appropriate,  legal  action  will  be commenced  against  the  borrower  for  recovery  of  the  amount  due  and taking possession of the collateral pledged.

All loans will be granted under the approval of the board of directors of the Group's money lending subsidiary.

---

# Page 16

# Management Discussion and Analysis


## Investment in Securities

The Group generally acquires securities listed on the Hong Kong Stock Exchange or other recognised stock exchanges and over-the-counter markets with good liquidity that can facilitate swift execution of securities transactions.  For  making  investment  or  divestment  decision  on  securities  of  individual  target  company, references  will  usually  be  made  to  the  latest  financial  information,  news  and  announcements  issued  by the  target  company,  investment  analysis  reports  that  the  Company  has  access  to,  as  well  as  industry  or macroeconomic  news.  When  deciding  on  acquiring  securities  to  be  held  for  long-term  purpose,  particular emphasis  will  be  placed  on  the  past  financial  performance  of  the  target  company  including  its  sales  and profit  growth,  financial  healthiness,  dividend  policy,  business  prospects,  and  industry  and  macroeconomic outlook. When deciding on acquiring securities to be held other than for long-term purpose, in addition to the factors  mentioned, references will also be made to prevailing market sentiments on different sectors of the investment markets. In terms of return, for long-term securities investments, the Company mainly emphasises on  return  of  investment  in  form  of  capital  appreciation  and  dividend/interest  income.  For  securities investment  other  than  for  long-term  holding,  the  Company  mainly  emphasises  on  return  of  investment  in form of trading gains.

At  31  December  2022,  the  Group's  securities  investments  comprised  a  financial  asset  at  FVTPL  portfolio valued  at  HK$4,772,000  (2021:  HK$6,724,000),  comprising  equity  securities  listed  in  Hong  Kong,  and  a  debt instrument  at  FVTOCI  portfolio  (constituted  by  non-current  and  current  portions)  valued  at  HK$33,739,000 (2021: HK$78,396,000), comprising debt securities listed in Hong Kong or Singapore. As a whole, the Group's securities investments recorded a revenue of HK$3,757,000 (2021: HK$9,139,000) and a loss, after provision of ECL, of HK$9,743,000 (2021: HK$32,533,000).


## Financial assets at FVTPL

At  31  December  2022,  the  Group  held  a  financial  asset  at  FVTPL  portfolio  amounting  to  HK$4,772,000 (2021:  HK$6,724,000)  measured  at  market/fair  value.  For  FY2022,  the  portfolio  generated  a  revenue  of HK$152,000 (2021: HK$268,000), representing dividends from equity securities. The Group recognised a net loss  on  financial  assets  at  FVTPL  of  HK$1,952,000 (2021: gain of HK$7,870,000) for FY2022, which comprised net  unrealised  loss  of  HK$1,952,000  (2021:  net  realised  gain  and  net  unrealised  loss  of  HK$9,099,000  and HK$1,229,000 respectively).

The net unrealised loss represented the decrease in market value of those equity securities held by the Group at the year end. The Group continued to adopt a prudent and disciplined approach in managing its financial asset at FVTPL portfolio and had not acquired any equity securities during the current year.

---

# Page 17

# Management Discussion and Analysis


At  31  December  2022,  the  Group's  financial  asset  at  FVTPL  portfolio  of  HK$4,772,000  comprised  one  major investment with details as below:
| Investee company's name and  its principal activities #   | Approximate  weighting to the  carrying amount of  the Group's  total assets at  31 December 2022 %   | % of  shareholding  interest   | Carrying  amount at  1 January 2022 HK$'000   | Market/ fair value at  31 December 2022 HK$'000   | Unrealised  loss recognised  during the  year ended  31 December 2022 HK$'000   | Dividend  income  recognised during  the year ended  31 December 2022 HK$'000   | # Investee company's financial performance           | # Future prospects of the  investee company     |
|-----------------------------------------------------------|-------------------------------------------------------------------------------------------------------|--------------------------------|-----------------------------------------------|---------------------------------------------------|---------------------------------------------------------------------------------|---------------------------------------------------------------------------------|------------------------------------------------------|-------------------------------------------------|
|                                                           |                                                                                                       | %                              |                                               |                                                   |                                                                                 |                                                                                 |                                                      |                                                 |
| Emperor International                                     |                                                                                                       |                                | A                                             | B                                                 | C = B - A                                                                       |                                                                                 |                                                      |                                                 |
| Holdings Limited                                          |                                                                                                       |                                |                                               |                                                   |                                                                                 |                                                                                 | For the six months ended 30  September 2022, revenue | For property investment  business, the investee |
| (HKEX stock code: 163)                                    |                                                                                                       |                                |                                               |                                                   |                                                                                 |                                                                                 | decreased by 61% to                                  | company possesses a                             |
| Property investment and                                   |                                                                                                       |                                |                                               |                                                   |                                                                                 |                                                                                 | approximately HK$541 million                         | geographically balanced                         |
| development and                                           |                                                                                                       |                                |                                               |                                                   |                                                                                 |                                                                                 | and its results experienced                          | property portfolio which                        |
|                                                           |                                                                                                       |                                |                                               |                                                   |                                                                                 |                                                                                 | a turnaround and recorded                            |                                                 |
| hospitality businesses                                    |                                                                                                       |                                |                                               |                                                   |                                                                                 |                                                                                 | a loss for the period of                             | focuses on commercial                           |



- # Extracted from published financial information of the investee company.



## Debt instruments at FVTOCI

At  31  December  2022,  the  Group's  debt  instrument  at  FVTOCI  portfolio  (constituted  by  non-current  and current portions) of HK$33,739,000 (2021: HK$78,396,000) was measured at market/fair value. During FY2022, the  Group's  debt  instrument  at  FVTOCI  portfolio  generated  a  revenue  amounting  to  HK$3,605,000  (2021: HK$8,871,000),  representing  interest  income  from  debt  securities.  According  to  the  maturity  profile  of  the debt  instruments,  part  of  the  debt  instruments  at  FVTOCI  of  HK$28,041,000  (2021:  HK$47,712,000)  was classified as current assets.

During  FY2022,  the  Group  had  not  acquired  any  debt  securities  (2021:  nil),  and  principal  of  certain  debt securities totalling HK$32,370,000 were redeemed. At the year end, a net fair value loss on debt instruments at FVTOCI of HK$11,238,000 (2021: HK$54,714,000) was recognised as other comprehensive expense primarily due to the fall in market value of these debt securities and downward adjustment on fair value of certain debt instruments due to their increased credit risks.

---

# Page 18

# Management Discussion and Analysis

The  Group  had  engaged  an  independent  professional  valuer  to  perform  an  impairment  assessment  on  the debt  instruments  held  under  the  ECL  model.  The  measurement  of  ECL  is  a  function  of  the  probability  of default and loss given default (i.e. the magnitude of the loss if there is a default), with the assessment of the probability  of  default  and  loss  given  default  is  based  on  historical  data  and  forward-looking  information. The  estimation  of  ECL  reflects  an  unbiased  and  probability-weighted  amount  that  is  determined  with  the respective  risks  of  default  occurring  as  the  weights,  and  also  with  reference  to  the  time  value  of  money.  In determining  the  ECL  on  the  Group's  debt  instruments  for  the  year,  the  management  had  worked  closely with  the  independent  professional  valuer  and  taken  into  accounts  factors  including  the  withdrawal  or downgrading  of  credit  ratings  of  the  debt  instruments  by  the  credit  rating  agencies,  the  defaults  of  the bond issuers in making payments of interest and principal for their indebtedness, as well as forward-looking information including the future macroeconomic conditions at places where the bond issuers are operating. There was no change in the method used in determining the ECL on debt instruments at FVTOCI from last year.  Further  details  of  the  credit  risk  and  impairment  assessment  on  the  debt  instruments  at  FVTOCI  are contained in Note 37 to the consolidated financial statements.

For  FY2022,  a  provision  of  ECL  on  debt  instruments  at  FVTOCI  of  HK$11,081,000  (2021:  HK$49,247,000) was  recognised  in  profit  or  loss  (with  a  corresponding  adjustment  to  other  comprehensive  income)  as  the credit  risks  of  certain  debt  instruments  held  by  the  Group  had  further  increased  since  initial  recognition. During FY2022, the credit ratings of these debt instruments, which were corporate bonds issued by property companies based in the Mainland, were withdrawn or downgraded by the credit rating agencies as the credit risks  of  these  bonds  had  increased  significantly  due  to  the  bond  issuers'  defaults  in  making  interest  and principal  payments for their indebtedness. As the Group expected the financial uncertainties of these bond issuers would ultimately affect the collection of contractual cash flows of these bonds, a provision of ECL on debt instruments at FVTOCI of HK$11,081,000 was recognised.


At  31  December 2022, the Group invested in debt securities issued by six property companies based in the Mainland, the market/fair value of the portfolio amounted to HK$33,739,000, with details as below:
| Category of companies   |   # Approximate  weighting to  the carrying  amount of the  Group's total  assets at   31 December  2022 % | Yield to  maturity on  acquisition date %   | Acquisition  costs HK$'000   | *Acquisition  costs during the  year/carrying  amount at   1 January   2022 HK$'000   | Market/fair  value at   31 December  2022 HK$'000   | Accumulated  fair value loss  recognised   up to   31 December  2022 HK$'000   | Fair value loss  recognised  during the year  ended   31 December  2022 HK$'000   |
|-------------------------|------------------------------------------------------------------------------------------------------------|---------------------------------------------|------------------------------|---------------------------------------------------------------------------------------|-----------------------------------------------------|--------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|
| Property                |                                                                                                       7.78 | 5.62 - 12.50                                | 104,826                      | 49,958                                                                                | 33,739                                              | (71,087)                                                                       | (16,219)                                                                          |
* The amount represented the costs of the securities acquired during the year ended 31 December 2022 and/or the carrying  amount  of  the  securities  brought  forward  from  the  prior  financial  year  after  accounting  for  additional acquisition and/or disposal of the securities (if any) during the current year.
# The weighting of individual debt securities to the carrying amount of the Group's total assets at 31 December 2022 did not exceed 5%.

---

# Page 19

# Management Discussion and Analysis

The  yield  to  maturity  on  acquisition  of  the  debt  securities  which  were  held  by  the  Group  at  the  year  end ranging from 5.62% to 12.50% per annum.


## Overall Results

For  FY2022,  the  Group's  petroleum  exploration  and  production  business  recorded  a  profit  of  HK$4,078,000 (2021: loss of HK$4,112,000), the solar energy business recorded a profit of HK$1,403,000 (2021: HK$89,000), the money lending business recorded a loss of HK$16,237,000 (2021: profit of HK$17,440,000), and the Group's investment in securities recorded a loss of HK$9,743,000 (2021: HK$32,533,000).

Overall speaking, the Group reported a loss attributable to owners of the Company of HK$46,746,000 (2021: HK$29,371,000), and a total comprehensive expense attributable to owners of the Company of HK$49,677,000 (2021: HK$33,508,000) which included a net fair value loss on debt instruments at FVTOCI of HK$11,238,000 (2021: HK$54,714,000).


## FINANCIAL REVIEW


## Liquidity, Financial Resources and Capital Structure

During  FY2022,  the  Group  financed  its  operation  mainly  by  cash  generated  from  its  operations  and shareholders' funds. At the year end, the Group had current assets of HK$191,386,000 (2021: HK$363,774,000) and  liquid  assets  comprising  cash  and  cash  equivalents  as  well  as  financial  assets  at  FVTPL  totalling HK$90,568,000  (2021:  HK$198,548,000).  The  Group's  current  ratio,  calculated  based  on  current  assets  over current  liabilities  of  HK$21,797,000  (2021:  HK$14,105,000),  was  at  a  liquid  level  of  about  8.8  (2021:  25.8). The  decrease  in  liquid  assets  was  mainly  due  to  the  payment  of  consideration  of  HK$135,461,000  for  the acquisition of the Canadian Oil Assets.

At  31  December  2022,  the  Group's  total  assets  amounted  to  HK$433,689,000  (2021:  HK$442,915,000),  the Group's  gearing  ratio,  calculated  on  the  basis  of  total  liabilities  of  HK$57,376,000  (2021:  HK$16,925,000) divided by total assets, was at a low level of about 13% (2021: 4%). Finance costs represented the accretion expense on decommissioning obligation and imputed interest on lease liabilities of HK$1,127,000 (2021: nil) and HK$119,000 (2021: HK$101,000) respectively recognised for the year.

At 31 December 2022, the equity attributable to owners of the Company amounted to HK$376,313,000 (2021: HK$425,990,000) and was equivalent to an amount of approximately HK7.18 cents (2021: HK8.13 cents) per share of the Company. The decrease in equity attributable to owners of the Company of HK$49,677,000 was mainly due to the loss incurred by the Group for the year.

With  the  amount  of  liquid  assets  on  hand,  the  management  is  of  the  view  that  the  Group  has  sufficient financial resources to meet its ongoing operational requirements.

---

# Page 20

# Management Discussion and Analysis


## Foreign Currency Management

The monetary assets and liabilities as well as business transactions of the Group are mainly denominated in Canadian dollars, Hong Kong dollars and United States dollars. The Group has not experienced any significant foreign  exchange  exposure  to  United  States  dollars  as  the  exchange  rate  of  Hong  Kong  dollars  to  United States  dollars  is  pegged.  The  Group's  foreign  exchange  exposure  to  Canadian  dollars  could  be  significant depending on the volatilities of exchange rate of Hong Kong dollars to Canadian dollars, the Group does not currently have a formal foreign currency hedging policy for Canadian dollars and will adopt one in due course should significant exposure arise.


## Contingent Liability

At 31 December 2022, the Group had no significant contingent liability (31 December 2021: nil).


## Pledge of Assets

At 31 December 2022, the Group had not pledged any assets (31 December 2021: nil).


## Capital Commitment

At  31  December  2022,  the  Group  had  a  total  capital  commitment  of  HK$6,978,000  for  acquisition  of  solar photovoltaic  systems  which  was  capital  expenditure  contracted  for  but  not  provided  (31  December  2021: HK$34,390,000).


## HUMAN RESOURCES AND REMUNERATION POLICY

At 31 December 2022, the Group had a total of 23 (2021: 21) employees including directors of the Company with 15 (2021: 18) employees stationed in Hong Kong and the PRC, 8 (2021: nil) employees in Canada and nil (2021:  3)  employees  in  Argentina.  Staff  costs,  including  directors'  emoluments,  amounted  to  HK$7,300,000 (2021:  HK$9,799,000)  for  the  year.  The  drop  in  staff  costs  of  HK$2,499,000  was  mainly  due  to  the  decrease of  the  Group's  headcounts  for  its  operation  in  the  PRC  and  Argentina.  The  remuneration  packages  for directors  and  staff  are  normally  reviewed  annually  and  are  structured  by  reference  to  prevailing  market terms and individual competence, performance and experience. The Group operates a Mandatory Provident Fund Scheme (the ' MPF Scheme ')  for  its  employees in Hong Kong and a pension scheme for its employees in  Canada.  In  addition,  the  Group  provides  other  employee  benefits  which  include  medical  insurance, discretionary bonus and participation in the Company's share option scheme.

The Group's contributions to the MPF Scheme and the other employees' pension scheme are calculated as a percentage of the employees' relevant income and vest fully and immediately with the employees, thus there are no forfeited contributions available to the Group to reduce the existing level of contributions to the MPF Scheme and the other employees' pension scheme.

---

# Page 21

# Management Discussion and Analysis


## PRINCIPAL RISK AND UNCERTAINTIES

The  Group  is  principally  engaged  in  the  business  of  petroleum  exploration  and  production,  solar  energy, money lending and investment in securities. The financial position, operations, businesses and prospects of the Group and its individual business segment are affected by the following significant risk and uncertainty factors:


## Business Risk

The  global  economic  conditions  and  the  state  of  international  financial  and  investment  markets,  including the  economy,  financial  and  investment  markets  of  the  US,  Mainland  China  and  Hong  Kong,  of  which  the Group has no control, have significant influences on the business and financial performance of the Group. The management policy to mitigate this risk is to diversify the Group's businesses and to diversify its investments (where possible) within the same business.


## Market Risk

The Group's money lending business is operating in a very competitive environment that put pressure on the revenue and profitability of this business. The management policy to mitigate this risk is to continue to put effort  in  enlarging  the  market  share  and  enhancing  the  market  competitiveness  of  this  business  by  various means.


## Environmental Risk

The  Group's  petroleum  and  solar  energy  businesses  are  constantly  exposed  to  inherent  risks  such  as mechanical breakdown of equipment, adverse weather conditions, flood, fire or other calamities. Any of these factors may cause disruptions to the Group's operations. The Group may also be liable to pay compensations resulting from the above events which may adversely affect its financial performance.


## Financial Risk

The Group is exposed to financial risks relating to interest rate, foreign currency, securities price, credit and liquidity risk in its ordinary course of business. Further details of such risks and relevant management policies are set out in Note 37 to the consolidated financial statements.


## COMPLIANCE WITH RELEVANT LAWS AND REGULATIONS

As  far  as  the  Board  and  the  management  are  aware,  the  Group  has  complied  in  material  respects  with  the relevant laws and regulations that have a significant impact on the businesses and operations of the Group. During FY2022, there was no material breach of or non-compliance with the applicable laws and regulations by the Group.


## RELATIONSHIP WITH EMPLOYEES, CUSTOMERS AND SUPPLIERS

The  Group  understands  the  importance  of  maintaining  good  relationships  with  its  employees,  customers and suppliers to meet its immediate and long-term business goals. During FY2022, there were no significant disputes between the Group and its employees, customers and suppliers.

---

# Page 22

# Biographical Details of Directors and Senior Management

The biographical details of Directors and senior management are set out below:


## EXECUTIVE DIRECTORS


## Mr. Sue Ka Lok ('Mr. Sue')

Aged  57,  joined  the  Company  as  Executive  Director  and  the  Chief  Executive  Officer  in  October  2016  and stepped down from his position as the Chief Executive Officer in January 2018. Mr. Sue is a member of the Corporate  Governance  Committee  and  a  director  of  certain  subsidiaries  of  the  Company.  Mr.  Sue  holds  a Bachelor of Economics degree from The University of Sydney in Australia and a Master of Science in Finance degree  from  the  City  University  of  Hong  Kong.  Mr.  Sue  is  a  fellow  of  the  Hong  Kong  Institute  of  Certified Public Accountants, a fellow certified practising accountant of the CPA Australia, a fellow of the Hong Kong Securities  and  Investment  Institute,  and  a  chartered  secretary,  a  chartered  governance  professional  and  a fellow of both The Hong Kong Chartered Governance Institute and The Chartered Governance Institute in the United Kingdom. He has extensive experience in corporate management, finance, accounting and company secretarial practice. Mr. Sue is an executive director, the company secretary and chief executive officer of CSC Holdings Limited (formerly known as China Strategic Holdings Limited) (HKEX stock code: 235); an executive director and the chairman of Courage Investment Group Limited (' Courage Investment ')  (HKEX stock code: 1145);  and  a  non-executive  director  of  Birmingham  Sports  Holdings  Limited  (' Birmingham Sports ')  (HKEX stock code: 2309). All the aforementioned companies are listed on the Main Board of the Hong Kong Stock Exchange  and  Courage  Investment  is  also  secondarily  listed  on  the  Main  Board  of  Singapore  Exchange Securities Trading Limited.


## Mr. Yiu Chun Kong ('Mr. Yiu')

Aged  38,  joined  the  Company  as  Executive  Director  in  October  2016.  Mr.  Yiu  is  also  a  director  of  certain subsidiaries  of  the  Company.  He  holds  a  Bachelor  of  Business  Administration  in  Accountancy  degree  from The  Hong  Kong  Polytechnic  University.  Mr.  Yiu  is  a  certified  public  accountant  of  the  Hong  Kong  Institute of  Certified  Public  Accountants.  He  has  rich  experience  in  auditing,  accounting  and  finance.  Mr.  Yiu  is  an executive  director  of  Birmingham  Sports,  a  company  listed  on  the  Main  Board  of  the  Hong  Kong  Stock Exchange.


## Mr. Chan Shui Yuen ('Mr. Chan')

Aged  42,  joined  the  Company  as  Executive  Director  in  October  2016  and  was  appointed  the  Company Secretary  in  November  2017.  Mr.  Chan  is  a  member  of  the  Corporate  Governance  Committee.  He  is  also a  director  of  certain  subsidiaries  of  the  Company.  Mr.  Chan  holds  a  Bachelor  of  Business  Administration (Honours) in Accountancy degree from the City University of Hong Kong and a Master of Financial Analysis degree from The University of New South Wales in Australia. Mr. Chan is a CFA charterholder, a fellow of the Association  of  Chartered  Certified  Accountants,  a  certified  public  accountant  of  the  Hong  Kong  Institute  of Certified Public Accountants and a certified practising accountant of the CPA Australia. He has rich experience in auditing, accounting, finance and compliance.

---

# Page 23

# Biographical Details of Directors and Senior Management


## INDEPENDENT NON-EXECUTIVE DIRECTORS


## Mr. Pun Chi Ping ('Mr. Pun')

Aged  56,  joined  the  Company  as  Independent  Non-executive  Director  in  October  2016.  Mr.  Pun  is  the Chairman  of  the  Audit  Committee  and  the  Remuneration  Committee  and  a  member  of  the  Nomination Committee.  He  holds  a  Master  of  Science  in  Finance  degree  from  the  City  University  of  Hong  Kong  and  a Bachelor  of  Arts  in  Accountancy  degree  from  the  City  Polytechnic  of  Hong  Kong  (now  known  as  the  City University  of  Hong  Kong).  Mr.  Pun  is  a  fellow  of  the  Association  of  Chartered  Certified  Accountants  and  an associate of the Hong Kong Institute of Certified Public Accountants. He has extensive experience in corporate finance, accounting and auditing. Mr. Pun is an independent non-executive director of Birmingham Sports and China Huajun Group Limited (HKEX stock code: 377). Both aforementioned companies are listed on the Main Board of the Hong Kong Stock Exchange.


## Ms. Leung Pik Har, Christine ('Ms. Leung')

Aged  53,  joined  the  Company  as  Independent  Non-executive  Director  in  October  2016.  Ms.  Leung  is  the Chairlady  of  the  Nomination  Committee  and  a  member  of  the  Audit  Committee  and  the  Remuneration Committee.  She  holds  a  Bachelor  of  Business  Administration  degree  from  The  Chinese  University  of  Hong Kong.  Ms.  Leung  has  extensive  experience  in  banking  and  financial  services  industries  and  had  worked  at several  international  financial  institutions  including  Citibank,  N.A.  Hong  Kong,  Bank  of  America,  Industrial and Commercial Bank of China (Asia) Limited and Fubon Bank (Hong Kong) Limited. She is an independent non-executive director of Birmingham Sports, a company listed on the Main Board of the Hong Kong Stock Exchange.


## Mr. Kwong Tin Lap ('Mr. Kwong')

Aged 58, joined the Company as Independent Non-executive Director in December 2018. Mr. Kwong is the Chairman  of  the  Corporate  Governance  Committee,  a  member  of  the  Audit  Committee,  the  Remuneration Committee  and  the  Nomination  Committee.  He  holds  a  Professional  Diploma  in  Accountancy  from  the Hong  Kong  Polytechnic  (now  known  as  The  Hong  Kong  Polytechnic  University)  and  a  Master  of  Science in  Information  Systems  degree  from  The  Hong  Kong  Polytechnic  University.  Mr.  Kwong  is  a  Certified Public  Accountants  (Practising)  in  Hong  Kong,  an  associate  of  the  Hong  Kong  Institute  of  Certified  Public Accountants and a fellow of the Association of Chartered Certified Accountants. He has extensive experience in accounting, finance, auditing and corporate management. Mr. Kwong had been a director of certain Hong Kong listed companies and is currently a director of CCTH CPA Limited.

---

# Page 24

# Biographical Details of Directors and Senior Management


## SENIOR MANAGEMENT


## Mr. Pak Ka Kei ('Mr. Pak'), Financial Controller

Aged 52, joined the Company as Financial Controller in November 2009. He is a director of certain subsidiaries of  the  Company.  Mr.  Pak  graduated  from  the  City  University  of  Hong  Kong  with  a  Bachelor  of  Arts  in Accounting  degree.  Mr.  Pak  has  extensive  experience  in  the  fields  of  audit,  internal  control,  accountancy, taxation  and  treasury.  Prior  to  joining  the  Company,  he  had  worked  for  Ernst  &  Young,  an  international accounting firm, and TCL Multimedia Technology Holdings Limited (now known as TCL Electronics Holdings Limited)  in  its  finance  department  in  Hong  Kong,  emerging  markets  and  Europe  as  deputy  internal  control director and deputy financial controller.

---

# Page 25

# Report of the Directors

The  Directors  are  pleased  to  present  their  report  and  the  audited  consolidated  financial  statements  of  the Company for the year ended 31 December 2022.


## PRINCIPAL ACTIVITIES AND BUSINESS REVIEW

The Company acts as an investment holding company. The principal activities of its principal subsidiaries are set out in Note 38 to the consolidated financial statements.

Further  discussion  and  analysis  of  the  Group's  activities  as  required  by  Schedule  5  to  the  Hong  Kong Companies Ordinance, including a discussion of the review of the Group's businesses, the principal risks and uncertainties  the  Group  facing,  the  particulars  of  important  events  affecting  the  Group  that  have  occurred since  the  end  of  the  financial  year,  an  indication  of  likely  future  developments  in  the  Group's  businesses, the  performance  of  the  Group  during  the  year  with  reference  to  key  financial  performance  indicators,  the key  relationships  with  employees,  customers  and  suppliers  and  the  compliance  with  laws  and  regulations, can  be  found  in  the  'Statement  from  the  Board'  and  'Management  Discussion  and  Analysis'  sections  set out on pages 4 to 19 of this annual report, and the 'Corporate Governance Report' set out on pages 30 to 45  of  this  annual  report.  These  discussions  form  part  of  this  report.  In  addition,  discussions  on  the  Group's environmental policies and performance are contained in the Environmental, Social and Governance Report on pages 46 to 76 of this annual report.


## RESULTS

The results of the Group for the year ended 31 December 2022 are set out in the consolidated statement of profit or loss and other comprehensive income on page 84.


## FINAL DIVIDEND

The Board does not recommend the payment of a final dividend for the year ended 31 December 2022 (2021: nil).


## FIVE-YEAR FINANCIAL SUMMARY

A summary of the published results and assets and liabilities of the Group for the last five financial years, as extracted  from  the  audited  consolidated  financial  statements  of  the  Company,  is  set  out  on  page  170.  The summary does not form part of the audited consolidated financial statements.


## PROPERTY, PLANT AND EQUIPMENT

Details of movements in property, plant and equipment of the Group during the year are set out in Note 18 to the consolidated financial statements.

---

# Page 26

# Report of the Directors


## SHARE CAPITAL

Details of the Company's share capital are set out in Note 30 to the consolidated financial statements.


## PRE-EMPTIVE RIGHTS

There is no provision for pre-emptive rights under the Company's Bye-laws or the applicable laws of Bermuda which would oblige the Company to offer new shares on a pro-rata basis to existing shareholders.


## PURCHASE, SALE OR REDEMPTION OF THE COMPANY'S LISTED SECURITIES

During the year ended 31 December 2022, neither the Company nor any of its subsidiaries had purchased, sold or redeemed any of the Company's listed securities.


## RESERVES

Details of movements in the reserves of the Company and of the Group during the year are set out in Note 40 to the consolidated financial statements and in the consolidated statement of changes in equity, respectively.


## DISTRIBUTABLE RESERVES

At 31 December 2022, the Company had no reserve available for distribution as computed in accordance with the Companies Act 1981 of Bermuda. The Company's share premium account, in the amount of approximately HK$918,270,000 (2021: HK$918,270,000), may be distributed in the form of fully paid bonus shares.


## MAJOR CUSTOMERS AND SUPPLIERS

During the year, revenue from the Group's five largest customers/sources accounted for approximately 93% of  the  total  revenue  for  the  year  and  revenue  from  the  largest  customer  accounted  for  approximately  67%. Purchases from the Group's five largest suppliers accounted for 67% of the total purchases for the year and purchases from the largest supplier accounted for 25%.

None  of  the  directors  or  any  of  their  associates  or  any  shareholders  (which,  to  the  best  knowledge  of  the directors, own more than 5% of the Company's issued shares) had any beneficial interest in the Group's five largest customers or suppliers during the year.

---

# Page 27

# Report of the Directors


## DIRECTORS

The directors of the Company during the year and up to the date of this report were:

Executive Directors:

Mr. Sue Ka Lok

Mr. Yiu Chun Kong

Mr. Chan Shui Yuen

Independent Non-executive Directors:

Mr. Pun Chi Ping Ms. Leung Pik Har, Christine

Mr. Kwong Tin Lap

In  accordance  with  Bye-law  100(A)  of  the  Company's  Bye-laws,  Mr.  Yiu  Chun  Kong  and  Ms.  Leung  Pik  Har, Christine will retire by rotation at the forthcoming annual general meeting of the Company (the ' 2023 AGM ') and, being eligible, will offer themselves for re-election at the 2023 AGM.


## PERMITTED INDEMNITY PROVISION

Pursuant to the Company's Bye-laws, subject to the statutes, the directors for the time being of the Company shall  be  indemnified  and  secured  harmless  out  of  the  assets  of  the  Company  from  and  against  all  actions, costs,  charges,  losses,  damages  and  expenses  which  they  or  any  of  them,  shall  or  may  incur  or  sustain  by reason of any act done, concurred in or omitted in or about the execution of their duty or supposed duty in their  respective  offices  or  trusts  or  otherwise  in  relation  thereto  except  through  their  own  wilful  neglect  or default, fraud and dishonesty. The Company has arranged appropriate directors' and officers' liability coverage for the directors and other officers of the Company during the year.


## DIRECTORS' SERVICE CONTRACTS

None  of  the  directors  being  proposed  for  re-election  at  the  2023  AGM  has  a  service  contract  with  the Company or any of its subsidiaries which is not determinable by the Group within one year without payment of compensation, other than statutory compensation.


## DIRECTORS' REMUNERATION

Details of the directors' remuneration are set out in Note 14 to the consolidated financial statements.

---

# Page 28

# Report of the Directors


## DIRECTORS' INTERESTS IN TRANSACTIONS, ARRANGEMENTS OR CONTRACTS

Save for  the  related  party  transactions  as  disclosed  in  Note  35  to  the  consolidated  financial  statements,  no other transactions, arrangements or contracts of significance to which the Company or any of its subsidiaries was  a  party  and  in  which  a  Director  or  an  entity  connected  with  a  Director  has  or  had  a  material  interest, whether directly or indirectly, subsisted at the end of the year or at any time during the year.


## DIRECTORS'  INTERESTS  AND  SHORT  POSITIONS  IN  SHARES,  UNDERLYING  SHARES  AND DEBENTURES

As at 31 December 2022, none of the directors or chief executive of the Company had registered an interest or  short  positions  in  the  shares,  underlying  shares  and  debentures  of  the  Company  or  any  of  its  associated corporations (within the meaning of Part XV of the SFO) that was required to be recorded pursuant to section 352 of the SFO, or as otherwise notified to the Company and the Hong Kong Stock Exchange pursuant to the Model Code.


## DIRECTORS' RIGHTS TO ACQUIRE SHARES OR DEBENTURES

Save for the 'Share Option Scheme' disclosure in Note 31 to the consolidated financial statements, at no time during the year was the Company or any of its subsidiaries a party to any arrangements to enable the directors of the Company to acquire benefits by means of the acquisition of shares in, or debentures of, the Company or any other body corporate, and none of the directors of the Company or their spouse or minor children had any rights to subscribe for the securities of the Company, or had exercised any such rights during the year.


## SHARE OPTION SCHEME

Details  of  the  share  option  scheme  of  the  Company  are  set  out  in  Note  31  to  the  consolidated  financial statements.

---

# Page 29

# Report of the Directors


## INTERESTS AND SHORT POSITIONS OF SHAREHOLDERS DISCLOSEABLE UNDER THE SFO

As at 31 December 2022, the following interests of more than 5% of the issued shares of the Company were recorded in the register of interests required to be kept by the Company pursuant to section 336 of the SFO.


Long positions in the shares of the Company:
| Name of shareholders                                    | Capacity and  nature of interest     | Number of  shares held              | Approximate  percentage of  the Company's  issued shares (Note (i))   |
|---------------------------------------------------------|--------------------------------------|-------------------------------------|-----------------------------------------------------------------------|
| Mr. Suen Cho Hung, Paul (' Mr. Suen ')                  | Interests of controlled  corporation | 862,085,620  (Notes (ii) and (iii)) | 16.45%                                                                |
| Premier United Group Limited   (' Premier United ')     | Interests of controlled  corporation | 862,085,620  (Notes (ii) and (iii)) | 16.45%                                                                |
| Billion Expo International Limited   (' Billion Expo ') | Beneficial owner                     | 862,085,620  (Notes (ii) and (iii)) | 16.45%                                                                |
| China Shipbuilding Capital Limited                      | Beneficial owner                     | 700,170,000  (Note (iv))            | 13.36%                                                                |
| China State Shipbuilding Corporation   Limited          | Interests of controlled  corporation | 700,170,000  (Note (iv))            | 13.36%                                                                |
| China Create Capital Limited                            | Beneficial owner                     | 357,705,000                         | 6.83%                                                                 |
Notes:
(i) The approximate percentage of the Company's issued shares was calculated on the basis of 5,240,344,044 shares of the Company in issue as at 31 December 2022.
(ii) These interests were held by Billion Expo, a wholly-owned subsidiary of Premier United which in turn was wholly owned by Mr. Suen. Mr. Suen was the sole director of Billion Expo and Premier United. Accordingly, Mr. Suen and Premier United were deemed to be interested in 862,085,620 shares of the Company under the SFO.



- (iii) The interests of Mr. Suen, Premier United and Billion Expo in 862,085,620 shares of the Company referred to in Note (ii) above related to the same parcel of shares.
- (iv) The interests of China Shipbuilding Capital Limited and China State Shipbuilding Corporation Limited related to the same parcel of shares.

---

# Page 30

# Report of the Directors

Save as disclosed above, the Company had not been notified of any other relevant interests or short positions in the shares and underlying shares of the Company as at 31 December 2022 as required pursuant to section 336 of the SFO.


## CONNECTED TRANSACTIONS

During  the  year,  the  related  party  transactions  in  relation  to  the  consultancy  fee  paid  to  the  substantial shareholder and the remuneration of directors and other members of key management as disclosed in Note 35 to the consolidated financial statements fall under the scope of 'Connected Transactions' or 'Continuing Connected Transactions' under Chapter 14A of the Listing Rules but are fully exempted from reporting, annual review, announcement and independent shareholders' approval requirement.

Save as disclosed above, the other related party transaction set out in Note 35 to the consolidated financial statements  does  not  constitute  'Connected  Transactions'  nor  'Continuing  Connected  Transactions'  under Chapter 14A of the Listing Rules.


## REMUNERATION POLICY

The Group remunerates its employees based on their competence, performance, experience and prevailing market  terms.  Other  employee  benefits  include  provident  fund  scheme,  medical  insurance,  share  option scheme as well as discretionary bonus.


## EQUITY-LINKED AGREEMENTS

Save  for  the  share  option  scheme  of  the  Company  as  disclosed  in  Note  31  to  the  consolidated  financial statements, no equity-linked agreements were entered into by the Group, or existed during the year.


## MANAGEMENT CONTRACTS

No  contract  concerning  the  management  and  administration  of  the  whole  or  any  substantial  part  of  any business of the Company was entered into or existed during the year.


## AUDIT COMMITTEE

The audited consolidated financial statements of the Company for the year ended 31 December 2022 have been reviewed by the Audit Committee and duly approved by the Board under the recommendation of the Audit Committee.

---

# Page 31

# Report of the Directors


## AUDITOR

The  consolidated  financial  statements  of  the  Company  for  the  year  ended  31  December  2022  have  been audited by Moore Stephens CPA Limited.

Moore Stephens CPA Limited has been appointed as the auditor of the Company with effect from 4 January 2021 to fill the casual vacancy arising from the resignation of Deloitte Touche Tohmatsu on 4 January 2021.

A resolution will be proposed at the 2023 AGM to re-appoint Moore Stephens CPA Limited as the auditor of the Company.

Save for the above, there was no change of the auditor of the Company in the preceding three years.

On behalf of the Board


## Sue Ka Lok

Executive Director

Hong Kong, 30 March 2023

---

# Page 32

# Corporate Governance Report

The  Company  has  recognised  the  importance  of  transparency  and  accountability,  and  believes  that shareholders can benefit from good corporate governance. The Company aims to achieve good standard of corporate governance.


## CULTURES AND VALUES

The  Board  believes  a  healthy  corporate  culture  is  vital  in  attaining  the  Group's  vision,  values  and  strategy. It  trusts  that  conducting  business  in  an  ethical  and  reliable  way  will  maximise  its  long-term  interests  and those  of  its  stakeholders.  The  structure  of  corporate  governance  adopted  by  the  Company  emphasises  a quality  board,  sound  internal  controls  and  accountability  to  shareholders  and  these  are  based  upon  an ethical corporate culture. It is the Board's mission to establish and foster a healthy corporate culture with the following principles and to ensure that the Company's vision, values and business strategies are aligned to it.


## (i) Ethics and Integrity

The Group strives to maintain a high standard of business ethics and corporate governance across all business levels and operating activities. Directors, management and staff are all required to act lawfully, ethically  and  responsibly.  Such  required  standards  are  set  out  in  the  Group's  Code  of  Conduct,  Anticorruption Policy and Whistleblowing Policy (further discussions on the two policies are in the sections below).  Trainings  are  conducted  from  time  to  time  to  reinforce  the  values  across  the  Group  and  to uphold the standards with respect to ethics and integrity.


## (ii) Commitment to Excellence

The  Group  believes  commitment  to  excellence  is  the  first  step  to  continuous  improvement  and  the driving  force  behind  a  business  organisation.  The  Group  implements  a  performance  appraisal  system and  aims  to  reward  and  recognise  performing  staff  by  providing  them  competitive  remuneration packages, as well as the opportunities of career development and progression within the Group. Such values are articulated in policies, procedures and processes in day-to-day operations. Department heads are responsible to set expectations for staff with respect to their roles and responsibilities. In addition, staff  are  also  encouraged  to  enroll  in  external  training  courses,  seminars  in  order  to  update  their technical skills and keep abreast of the market and regulatory developments.


## CORPORATE GOVERNANCE

The  Company had complied with all the applicable provisions of  the  Corporate  Governance  Code  (the  ' CG Code ')  set  out  in  Appendix  14  to  the  Listing  Rules  for  the  year  ended  31  December  2022,  except  for  the following deviations with reasons as explained:


## Chairman and chief executive

Code Provision C.2.1

Code Provision C.2.1 of the CG Code requires the roles of the chairman and chief executive should be separate and should not be performed by the same individual.

---

# Page 33

# CORPORATE GOVERNANCE (continued)

Chairman and chief executive (continued)

Deviation

The Company had deviated from the Code Provision C.2.1 of the CG Code during the year ended 31 December 2022  due  to  the  positions  of  Chairman  of  the  Board  and  Chief  Executive  Officer  had  been  left  vacant.  The Company is still looking for suitable candidates to fill the vacancies of the Chairman of the Board and the Chief Executive Officer of the Company. The day-to-day management responsibilities are taken up by the Executive Directors of the Company; and the overall direction and strategy of the businesses of the Group are decided by the agreement of the Board. There are three Independent Non-executive Directors on the Board offering independent and differing perspectives. The Board is therefore of the view that there are adequate balance of  power  and  safeguards  in  place  to  enable  the  Company  to  make  and  implement  decisions  promptly  and effectively.


## Shareholders meetings

Code Provision F.2.2

Code  Provision  F.2.2  of  the  CG  Code  stipulates  that  the  chairman  of  the  board  should  attend  the  annual general meeting.


## Deviation

As  the  position  of  Chairman  of  the  Board  had  been  left  vacant,  Mr.  Sue  Ka  Lok,  Executive  Director  of  the Company, was elected and acted as the chairman of the annual general meeting of the Company held on 30 June 2022 in accordance with Bye-law 70 of the Company's Bye-laws.


## DIRECTORS' SECURITIES TRANSACTIONS

The Company has adopted the Model Code as its own code of conduct regarding securities transactions by directors of the Company. Having made specific enquiry with the directors, all of them confirmed that they had  complied  with  the  required  standards  set  out  in  the  Model  Code  during  the  year  ended  31  December 2022.


## Corporate Governance Report

---

# Page 34

# Corporate Governance Report


## BOARD OF DIRECTORS

The  Board  formulates  the  overall  strategy  of  the  Group,  monitors  its  financial  performance  and  maintains effective  oversight  over  the  management.  The  Board  members  are  fully  committed  to  their  roles  and  have acted in good faith to maximise the shareholders' value in the long run, and have aligned the Group's goals and directions with the prevailing economic and market conditions. Daily operations and administration are delegated to the management.

The Board met regularly throughout the year to discuss the overall business strategy as well as the operation and  financial  performance  of  the  Group.  The  directors  are  kept  informed  on  timely  basis  of  major  changes that  may  affect  the  Group's  businesses,  including  relevant  rules  and  regulations.  The  directors  can,  upon reasonable  request,  seek  independent  professional  advice  in  appropriate  circumstances,  at  the  Company's expenses.  The  Board  shall  resolve  to  provide  separate  appropriate  independent  professional  advice  to  the directors to assist the relevant directors to discharge their duties.

As  at  30  March  2023,  the  date  of  this  annual  report,  the  Board  comprises  six  directors,  three  are  Executive Directors, namely Mr. Sue Ka Lok (' Mr. Sue '), Mr. Yiu Chun Kong (' Mr. Yiu ') and Mr. Chan Shui Yuen, and three are Independent Non-executive Directors, namely Mr. Pun Chi Ping (' Mr. Pun '),  Ms.  Leung Pik Har, Christine (' Ms. Leung ') and Mr. Kwong Tin Lap. The directors are considered to have a balance of skill and experience appropriate for the requirements of the businesses of the Group. The Company has received from each of the independent non-executive directors an annual confirmation of his/her independence pursuant to Rule 3.13 of the Listing Rules. The Company considers all the independent non-executive directors are independent in accordance with the independence guidelines set out in the Listing Rules. Biographical details of the directors are set out under the section headed 'Biographical Details of Directors and Senior Management' on pages 20 to 22 of this annual report.

Mr.  Sue  is  a  non-executive  director,  Mr.  Yiu  is  an  executive  director,  and  Mr.  Pun  and  Ms.  Leung  are independent non-executive directors of Birmingham Sports Holdings Limited (HKEX stock code: 2309). Save for  the  aforesaid,  there  is  no  other  financial,  business,  family  or  other  material/relevant  relationship  among members of the Board.

The  Company  will  provide  a  comprehensive,  formal  and  tailored  induction  to  each  newly  appointed director  on  his/her  first  appointment  in  order  to  enable  him/her  to  have  an  appropriate  understanding  of the  businesses  and  operations  of  the  Group  and  that  he/she  is  fully  aware  of  his/her  responsibilities  and obligations under the Listing Rules and relevant regulatory requirements.

---

# Page 35

# Corporate Governance Report


## BOARD OF DIRECTORS (continued)

All  directors  are  encouraged  to  participate  in  continuous  professional  development  to  develop  and  refresh their knowledge and skills, and are continually updated on the developments of the statutory and regulatory regime  and  the  Group's  business  environment  to  facilitate  the  discharge  of  their  responsibilities.  The Company has provided timely technical updates, including briefings on the amendments on the Listing Rules and the news releases published by the Hong Kong Stock Exchange, to the directors. In-house briefings and professional development for directors are arranged where necessary.

The  directors  have  participated  in  continuous  professional  development  by  attending  seminars,  in-house briefings or reading materials on the related areas to develop and refresh their knowledge and skills. During the year ended 31 December 2022, all the directors including Mr. Sue Ka Lok, Mr. Yiu Chun Kong, Mr. Chan Shui  Yuen,  Mr.  Pun  Chi  Ping,  Ms.  Leung  Pik  Har,  Christine  and  Mr.  Kwong  Tin  Lap  had  complied  with  Code Provision C.1.4 of the CG Code and had provided the Company with their respective training records pursuant to the CG Code.


During the year ended 31 December 2022, four regular Board meetings and two general meetings were held and the attendance of each director is set out below:
|                                     | Number of attendance   | Number of attendance   |
|-------------------------------------|------------------------|------------------------|
|                                     | Board  Meetings        | General  Meetings      |
| Executive Directors                 |                        |                        |
| Mr. Sue Ka Lok                      | 4/4                    | 2/2                    |
| Mr. Yiu Chun Kong                   | 4/4                    | 2/2                    |
| Mr. Chan Shui Yuen                  | 4/4                    | 2/2                    |
| Independent Non-executive Directors |                        |                        |
| Mr. Pun Chi Ping                    | 4/4                    | 2/2                    |
| Ms. Leung Pik Har, Christine        | 4/4                    | 2/2                    |
| Mr. Kwong Tin Lap                   | 4/4                    | 2/2                    |

---

# Page 36

# Corporate Governance Report


## CHAIRMAN AND CHIEF EXECUTIVE

Code Provision C.2.1 of the CG Code requires the roles of the chairman and chief executive should be separate and  should  not  be  performed  by  the  same  individual.  The  Company  had  deviated  from  the  requirement during  the  year  ended  31  December  2022  as  the  positions  of  Chairman  of  the  Board  and  Chief  Executive Officer  had  been  left  vacant.  The  Company  is  still  looking  for  suitable  candidates  to  fill  the  vacancies  of the  Chairman  of  the  Board  and  the  Chief  Executive  Officer  of  the  Company.  The  day-to-day  management responsibilities are taken up by the Executive Directors of the Company; and the overall direction and strategy of the businesses of the Group are decided by the agreement of the Board. There are three Independent Nonexecutive Directors on the Board offering independent and differing perspectives. The Board is therefore of the view that there are adequate balance of power and safeguards in place to enable the Company to make and implement decisions promptly and effectively.


## TERM OF APPOINTMENT OF NON-EXECUTIVE DIRECTORS

Currently,  all  the  Independent  Non-executive  Directors  are  appointed  for  a  term  of  twelve-month  period which automatically renews for successive twelve-month periods unless terminated by either party in writing prior  to  the  expiry  of  the  term.  All  the  Independent  Non-executive  Directors  are  also  subject  to  retirement by rotation and re-election at least once every three years at the annual general meetings of the Company in accordance with the Company's Bye-laws.


## REMUNERATION COMMITTEE

The  Remuneration  Committee  has  specific  written  terms  of  reference  that  is  in  compliance  with  the  CG Code. As at the date of this annual report, the Remuneration Committee comprises three Independent Nonexecutive Directors, namely Mr. Pun Chi Ping, Ms. Leung Pik Har, Christine and Mr. Kwong Tin Lap. Mr. Pun Chi Ping is the Chairman of the Remuneration Committee.

The  Remuneration  Committee  is  mainly  responsible  for  formulating  the  remuneration  policy,  reviewing and  recommending  to  the  Board  the  annual  remuneration  policy  and  the  remuneration  of  the  directors. The overriding objective of the remuneration policy is to ensure that the Group is able to attract, retain and motivate a high-caliber team which is essential to the success of the Group. The full terms of reference are available on the Company's website and the Hong Kong Stock Exchange's website.

---

# Page 37

# Corporate Governance Report


## REMUNERATION COMMITTEE (continued)


The  Remuneration  Committee  met  once  during  the  year  ended  31  December  2022  to  review  and  make recommendations to the Board on the remuneration packages for directors. The attendance of each member is set out below:
| Members                      | Number of attendance   |
|------------------------------|------------------------|
| Mr. Pun Chi Ping             | 1/1                    |
| Ms. Leung Pik Har, Christine | 1/1                    |
| Mr. Kwong Tin Lap            | 1/1                    |



Details of the directors' remuneration are set out in Note 14 to the consolidated financial statements. Pursuant to E.1.5 of the CG Code, the details of the annual remuneration of the senior management by bands during the year are set out below:
| Remuneration band            |   Number of individual |
|------------------------------|------------------------|
| HK$1,000,000 to HK$1,500,000 |                      1 |



## NOMINATION COMMITTEE

The Nomination Committee has specific written terms of reference that is in compliance with the CG Code. As at the date of this annual report, the Nomination Committee comprises three Independent Non-executive Directors, namely Mr. Pun Chi Ping, Ms. Leung Pik Har, Christine and Mr. Kwong Tin Lap. Ms. Leung Pik Har, Christine is the Chairlady of the Nomination Committee.

The  Nomination  Committee  is  mainly  responsible  for  identifying  potential  directors  and  making recommendations to the Board on the appointment or re-appointment of directors of the Company. Potential new  directors  are  selected  on  the  basis  of  their  qualifications,  skills  and  experience  that  he/she  could  add value to the management through his/her contributions in the relevant strategic business areas. The full terms of reference are available on the Company's website and the Hong Kong Stock Exchange's website.


The Nomination Committee met once during the year ended 31 December 2022 to review the board diversity policy (the ' Board Diversity Policy ')  of  the  Company, the independence of the independent non-executive directors,  the  structure,  size  and  composition  of  the  Board;  and  review  and  make  recommendations  to  the Board on the re-election of directors. The attendance of each member is set out below:
| Members                      | Number of attendance   |
|------------------------------|------------------------|
| Ms. Leung Pik Har, Christine | 1/1                    |
| Mr. Pun Chi Ping             | 1/1                    |
| Mr. Kwong Tin Lap            | 1/1                    |

---

# Page 38

# Corporate Governance Report


## BOARD DIVERSITY POLICY

The Company recognises the benefits of having a diverse Board to enhance the quality of its performance and has adopted the Board Diversity Policy. The Board Diversity Policy sets out that in determining the optimum composition of the Board, differences in skills, regional and industry experience, background, race, gender and other  qualities  of  directors  shall  be  considered.  All  Board  appointments  are  made  on  merits,  in  the  context of  skills  and  experience  the  Board  as  a  whole  requires,  with  due  regard  to  the  benefits  of  diversity  on  the Board,  and  the  Nomination  Committee  shall  review  and  assess  the  Board  composition  and  its  effectiveness on an annual basis. When there is a vacancy on Board, the Nomination Committee will recommend suitable candidates  for  appointment  to  the  Board  on  merits,  based  on  the  terms  of  reference  of  the  Nomination Committee, with due regard to the Company's own circumstances.

During the year ended 31 December 2022, the Company maintained an effective Board comprising members of  different  genders,  professional  background and industry experience. The Board Diversity Policy has been consistently implemented. As at the date of this annual report, the Board consists of one female Director and five male Directors. The Board considered gender diversity in respect of the Board is satisfactory.

The Group has taken, and will continue to take, steps to promote diversity at all levels of workforce (including senior  management).  Opportunities  for  employment,  training  and  career  development  are  equally  opened to  all  eligible  employees  without  discrimination  so  as  to  develop  a  pipeline  of  potential  successors  to  the Board and the workforce. As at 31 December 2022, the male to female ratio in the workforce (including senior management) is approximately 7:3. The Board considered gender diversity in respect of workforce is achieved.


In  order  to  ensure  that  independent  views  and  input  of  independent  non-executive  directors  are  made available  to  the  Board,  the  Nomination  Committee  and  the  Board  would  assess  the  independence  of independent non-executive directors annually with regard to, among others, the following factors:
- (i) their character, integrity, expertise and experience;
- (ii) declaration of conflict of interest in their roles as independent non-executive directors;
- (iii) duration of appointment as independent non-executive directors;
- (iv) time commitment to the Company's affairs;
- (v) past and present financial or other interests in the businesses of the Company; and
- (vi) connection with other director(s), chief executive or substantial shareholder(s) of the Company.


The Company has received from each of the Independent Non-executive Directors an annual confirmation of his/her independence, and the Company considers that each of the Independent Non-executive Directors has met the independence guidelines set out in Rule 3.13 of the Listing Rules.

---

# Page 39

# Corporate Governance Report


## NOMINATION POLICY

The  Board  has  adopted  a  nomination  policy  (the  ' Nomination  Policy ')  setting  out  the  principles  which guide  the  Nomination  Committee  to  identify  and  evaluate  a  candidate  for  nomination  to  (i)  the  Board  for appointment; and (ii) the shareholders for election as a director of the Company. According to the Nomination Policy,  in  assessing  the  suitability  of  a  proposed  candidate,  the  Board  shall  take  into  account,  among others, the following factors: (i) qualifications, professional experience, skills and knowledge relevant to the businesses  of  the  Group;  (ii)  commitment  in  respect  of  available  time  and  relevant  interest;  (iii)  diversity perspectives  set  out  in  the  Board  Diversity  Policy;  (iv)  in  case  of  independent  non-executive  directors, regulatory  requirement  for  appointment  of  independent  non-executive  directors  and  the  independence criteria set out in the Listing Rules; and (v) any other factors that the Board considers appropriate.

For  filling  a  casual  vacancy  or  as  an  addition  to  the  existing  Board,  the  Nomination  Committee  shall  make recommendations for the Board's consideration and approval. For proposing candidates to stand for election at  a  general  meeting, the Nomination Committee shall make nominations to the Board for its consideration and recommendation. On making recommendation, the Nomination Committee may submit to the Board for consideration a proposal comprising, inter alia, the personal profile of the proposed candidate, which contains at  least  the  candidate's  information  required  to  be  disclosed  under  Rule  13.51  of  the  Listing  Rules.  The Board shall be vested with power to make the final decision on all matters relating to the recommendation of  candidates (i) for appointment; and (ii) for standing for election at a general meeting as a director of the Company.

The Nomination Committee will review the Board Diversity Policy annually and the Nomination Policy from time to time to ensure that the polices will be implemented effectively.


## AUDITOR AND AUDITOR'S REMUNERATION

The  statement  of  the  external  auditor  of  the  Company  about  their  responsibilities  on  the  Company's consolidated  financial  statements  for  the  year  ended  31  December  2022  is  set  out  in  the  'Independent Auditor's Report' on pages 77 to 83 of this annual report.

For the year ended 31 December 2022, the remuneration payable to the Company's auditor, Moore Stephens CPA  Limited,  for  the  provision  of  audit  services  amounted  to  HK$1,448,000.  During  the  year,  a  sum  of HK$453,000 was paid as remuneration to Moore Stephens CPA Limited for the provision of non-audit related services.

---

# Page 40

# Corporate Governance Report


## AUDIT COMMITTEE

The  Audit  Committee  has  specific  written  terms  of  reference  that  is  in  compliance  with  the  CG  Code.  At the  date  of  this  annual  report,  the  Audit  Committee  comprises  three  Independent  Non-executive  Directors, namely Mr. Pun Chi Ping, Ms. Leung Pik Har, Christine and Mr. Kwong Tin Lap, who among themselves possess a wealth of management experience in the accounting profession and in commercial fields. Mr. Pun Chi Ping is the Chairman of the Audit Committee.

The Audit Committee is mainly responsible for reviewing the financial statements of the Company, reviewing the risk management and internal control systems of the Group and meeting with the auditor of the Company for audit matters. Any findings and recommendations of the Audit Committee will be submitted to the Board for consideration.

The Audit Committee is authorised by the Board to investigate any activity within its terms of reference. It is authorised to seek any information it requires from any employee. It is also authorised to obtain outside legal or other independent professional advice and to secure the attendance of outsiders with relevant experience and expertise if it considers necessary. The full terms of reference are available on the Company's website and the Hong Kong Stock Exchange's website.


The Audit Committee met two times during the year ended 31 December 2022 and the attendance of each member is set out below:
| Members                      | Number of attendance   |
|------------------------------|------------------------|
| Mr. Pun Chi Ping             | 2/2                    |
| Ms. Leung Pik Har, Christine | 2/2                    |
| Mr. Kwong Tin Lap            | 2/2                    |

---

# Page 41

# Corporate Governance Report


## AUDIT COMMITTEE (continued)


The following is a summary of work performed by the Audit Committee during the year:
- 1. reviewed  and  discussed  the  audited  consolidated  financial  statements  of  the  Company  for  the  year ended 31 December 2021 and recommended the same to the Board for approval;
- 2. reviewed and discussed the unaudited condensed consolidated financial statements of the Company for the six months ended 30 June 2022 and recommended the same to the Board for approval;
- 3. reviewed and discussed with the management and the auditor of the Company the accounting policies and  practices  which  might  have  significant  impact  on  the  consolidated  financial  statements  of  the Company and the scope of the audit;
- 4. reviewed report from the auditor of the Company regarding their audit on the Company's consolidated financial statements for the year ended 31 December 2021;
- 5. reviewed the effectiveness of the risk management and internal control systems of the Group;
- 6. reviewed and approved the remuneration and the terms of engagement of the Company's auditor; and reviewed and made recommendations to the Board on the re-appointment of the Company's auditor; and
- 7. reviewed and adopted the Anti-corruption Policy and Whistleblowing Policy (further discussions on the two policies are in the sections below).



## CORPORATE GOVERNANCE COMMITTEE

The  Board  has  delegated  the  corporate  governance  duties  to  the  Corporate  Governance  Committee.  The Corporate  Governance  Committee  has  specific  written  terms  of  reference  that  includes  the  corporate governance functions set out in  the  CG  Code.  At  the  date  of  this  annual  report,  the  Corporate  Governance Committee comprises three members, including two Executive Directors, namely Mr. Sue Ka Lok and Mr. Chan Shui Yuen, and one Independent Non-executive Director, namely Mr. Kwong Tin Lap. Mr. Kwong Tin Lap is the Chairman of the Corporate Governance Committee.

The main responsibilities of the Corporate Governance Committee are (i) to develop and review the Group's policies and practices on corporate governance and make recommendations to the Board; (ii) to review and monitor the training and continuous professional development of directors and senior management; (iii) to review and monitor the Group's policies and practices on compliance with legal and regulatory requirements; (iv)  to  develop,  review  and  monitor  the  code  of  conduct  and  compliance  manual  applicable  to  employees and  directors  of  the  Group;  and  (v)  to  review  the  Group's  compliance  with  the  CG  Code  and  its  disclosure requirements in the Corporate Governance Report. The full terms of reference are available on the Company's website and the Hong Kong Stock Exchange's website.

---

# Page 42

# Corporate Governance Report


## CORPORATE GOVERNANCE COMMITTEE (continued)


The  Corporate  Governance  Committee  met  once  during  the  year  ended  31  December  2022  to  review  the training and continuous professional development of directors; and the Group's compliance with the CG Code. The attendance of each member is set out below:
| Members            | Number of attendance   |
|--------------------|------------------------|
| Mr. Kwong Tin Lap  | 1/1                    |
| Mr. Sue Ka Lok     | 1/1                    |
| Mr. Chan Shui Yuen | 1/1                    |



## DIRECTORS' RESPONSIBILITIES FOR CONSOLIDATED FINANCIAL STATEMENTS

The  Directors  acknowledge  their  responsibility  for  preparing  the  consolidated  financial  statements  for the  year  ended  31  December  2022,  which  give  a  true  and  fair  view  of  the  state  of  affairs  of  the  Company and  of  the  Group  at  that  date  and  of  the  Group's  results  and  cash  flows  for  the  year  then  ended,  and  are properly prepared on the going concern basis in accordance with the statutory requirements and applicable accounting standards.


## RISK MANAGEMENT AND INTERNAL CONTROL

The Board acknowledges its responsibility for maintaining sound and effective risk management and internal control  systems  and  reviewing  their  effectiveness  to  safeguard  the  shareholders'  interests  and  the  Group's assets  at  least  annually.  The  systems  are  designed  to  identifying,  analysing,  evaluating  and  mitigating  risk exposures  that  may  impact  the  continued  efficiency  and  effectiveness  of  the  operations  of  the  Group.  The goal of the risk management and internal control mechanism is to provide reasonable assurance regarding the fulfilment of corporate development strategies and not absolute assurance against material misstatement or loss.

Effective risk management is essential in the long-term growth and sustainability of the Group's businesses. The  Board  monitors  the  risk  management  and  internal  control  systems  on  an  ongoing  basis,  evaluates and determines the nature and extent of the risks it  is  willing  to  take  in  achieving  the  strategic  objectives. An  annual  review  of  effectiveness  of  the  Group's  risk  management  and  internal  control  systems  has  been conducted. The annual review covers financial, operational and compliance controls of key operations of the Group and ensures the adequacy of resources, staff qualifications and experience, training programmes and budget of the Group's accounting, internal audit and financial reporting functions.

---

# Page 43

# Corporate Governance Report


## RISK MANAGEMENT AND INTERNAL CONTROL (continued)

The  process  used  to  identify,  evaluate  and  manage  the  significant  risks  (including  environmental,  social and  governance  (' ESG ')  risks)  of  the  Group  is  embedded  in  the  Group's  normal  business  operations. Organisational structure is well established with clearly defined authorities and responsibilities, and the Group has developed various risk management and internal control policies and procedures for each business unit to  follow.  Business  units  are  responsible  for  identifying,  assessing  and  monitoring risks (including ESG risks) associated with their respective units regularly. The results of the assessment are reported to the management which  subsequently  assesses  the  likelihood  of  risk  occurrence,  provides  remedial  plan  and  monitors  the progress of rectification with the assistance of the head of the business units. The results of the assessment and  effectiveness  of  the  Group's  risk  management  and  internal  control  systems  have  been  reported  to  the Audit Committee.

In  connection  with  the  controls  on  compliance  aspect,  guidelines  are  provided  to  the  directors,  officers, management and relevant staff in handling and disseminating sensitive and confidential inside information with  due  care.  Only  personnel  at  appropriate  level  can  get  reach  of  the  sensitive  and  confidential  inside information.

The  Group  does  not  have  an  internal  audit  function  due  to  the  size  of  the  Group  and  consideration  for cost  effectiveness.  Instead,  the  Company  had  engaged  an  external  consultant  to  conduct  a  review  on  the Group's  risk  management  and  internal  control  systems  to  identify  and  evaluate  significant  risks  (including ESG  risks)  of  the  business  operations  for  the  year  ended  31  December  2022.  The  Board  believes  that  the involvement  of  the  external  consultant  could  enhance  the  objectivity  and  transparency  of  the  evaluation process.  The  external  consultant  has  conducted  an  annual  review  to  identify  risks  (including  ESG  risks)  that could potentially impact the businesses of the Group, review key operational and financial processes as well as regulatory compliance and information security, and assess the adequacy and effectiveness of the Group's risk  management and internal control systems. The review covered all material controls, including financial, operational and compliance controls. After the review, a Risk Management and Internal Control Report (the ' RM and IC  Report ')  with  findings  and  recommendations  for  improvement  in  relation  to  the  systems  has been provided to the Audit Committee and the management. The RM and IC Report has been endorsed by the Audit Committee and the management is required to establish remedial plans and take actions to rectify those internal control deficiencies identified (which are all at low risk level) according to its respective risk level and priorities. Subsequent review will be performed by the external consultant to monitor the implementation of those agreed recommendations and to report the results of the follow-up review to the Audit Committee.

After reviewing the RM and IC Report, the Board is not aware of any significant risk management and internal control  weaknesses  or  inconsistencies  with  the  Group's  risk  management  and  internal  control  policies,  and considers the existing risk management and internal control systems are effective and adequate. The Board is  also  of  the  opinion  that  the  Group  has  adequate  financial  and  human  resources  for  its  accounting  and financial  reporting  function  as  well  as  those  relating  to  the  Group's  ESG  performance.  The  Company  has complied with the relevant code provisions of the CG Code relating to risk management and internal control.

---

# Page 44

# Corporate Governance Report


## RISK MANAGEMENT AND INTERNAL CONTROL (continued)


## Anti-corruption Policy

The  Board  had  adopted  an  anti-fraud  and  counter-corruption  policy  (the  ' Anti-corruption  Policy ')  which forms an important part of the Group's effective risk management and internal control systems. The Group is  committed  to  achieving  high  standards  of  business  ethics  and  corporate  governance  across  all  business levels  and  operating  activities  and  has  zero  tolerance  towards  fraud  and  corruption.  It  strives  to  protect its  reputation,  assets  and  information  from  any  attempt  of  fraud,  corruption,  deceit  or  improper  conduct by  employees  or  third  parties.  In  line  with  this,  the  Anti-corruption  Policy  has  outlined  the  Company's expectations  and  requirements  relating  to  the  prevention,  detection,  reporting  and  investigation  of  any suspected  fraud,  corruption  and  other  similar  irregularities.  The  Anti-corruption  Policy  applies  to  all  Group employees and all business partners, including customers, suppliers and debtors. The Audit Committee has the  overall  responsibility  for  the  implementation,  monitoring  and  periodic  review  of  the  Anti-corruption Policy.


## Whistleblowing Policy

The Board has adopted a whistleblowing policy (the ' Whistleblowing Policy ') which forms an important part of the Group's effective risk management and internal control systems. In line with the Group's commitment to promote ethical standards and to uncover any fraud, malpractice and misconduct within the organisation, the purpose of the Whistleblowing Policy is to (i) encourage and assist any employee(s) of the Group or third parties (e.g. customers, suppliers etc.) to raise the concern and disclose related information confidentially; (ii) provide reporting channels and guidance on whistleblowing to employees or third parties to raise the concern rather  than  neglecting  it;  and  (iii)  reveal  suspected  fraud,  malpractice  or  misconduct  before  these  activities cause disruption or loss to the Group. The Audit Committee has the overall responsibility for implementing, monitoring and reviewing the effectiveness of the Whistleblowing Policy and the actions resulting from the investigation.

External parties who wish to obtain more information on the Anti-corruption Policy and Whistleblowing Policy could  contact  us  by  email  to  acchairman@epiholdings.com  or  by  mail  to  Rooms  1502-03,  15th  Floor,  Great Eagle Centre, 23 Harbour Road, Wanchai, Hong Kong.


## COMPANY SECRETARY

Mr.  Chan  Shui  Yuen  (' Mr.  Chan '),  Executive  Director  of  the  Company,  was  appointed  the  Company Secretary on 10 November 2017. The biographical details of Mr. Chan are set out under the section headed 'Biographical Details of Directors and Senior Management' on pages 20 to 22 of this annual report. Mr. Chan has taken no less than 15 hours of the relevant professional training during the year ended 31 December 2022.

---

# Page 45

# Corporate Governance Report


## SHAREHOLDER RIGHTS

The  annual  general  meeting  (' AGM ')  of  the  Company  provides  a  forum  for  communication  between shareholders and the Board. The notice of the AGM is despatched to all shareholders at least 20 clear business days prior to such AGM. The chairmen of all Board committees are invited to attend the AGM. The chairman of the Board and the chairmen of all the Board committees, or in their absence, other members of the respective committees,  are  available  to  answer  questions  at  the  AGM.  The  auditor  of  the  Company  is  also  invited  to attend  the  AGM  to  answer  questions  about  the  conduct  of  the  audit,  the  preparation  and  content  of  the auditor's report, the accounting policies and the auditor's independence.


## Procedures for shareholders to convene a special general meeting

In  accordance  with  Bye-law  64  of  the  Company's  Bye-laws,  the  Board  may,  whenever  it  thinks  fit,  convene a  special  general  meeting,  and  special  general  meetings  shall  also  be  convened  on  requisition,  as  provided by  the  Companies  Act  1981  of  Bermuda  (the  ' Companies  Act ')  and  in  default,  may  be  convened  by  the requisitionists. Pursuant to the Companies Act, shareholders holding at the date of deposit of the requisition not less than one-tenth of the paid up capital of the Company carrying the right of voting at general meetings of the Company shall at all times have the right, by written requisition to the Board or the Company Secretary of  the  Company,  to  require  a  special  general  meeting  to  be  called  by  the  Board  for  the  transaction  of  any business  specified  in  such  requisition.  If  the  Board  does  not  within  twenty-one  days  from  the  date  of  the deposit of the requisition proceed duly to convene a meeting, the requisitionists, or any of them representing more  than  one  half  of  the  total  voting  rights  of  all  of  them,  may  themselves  convene  a  meeting,  but  any meeting so convened shall not be held after the expiration of three months from the said date in accordance with the provisions of Section 74(3) of the Companies Act.


## Procedures for shareholders to put forward proposals at general meetings


Pursuant to the Companies Act, any number of shareholders representing not less than one-twentieth of the total voting rights of all the shareholders having at the date of the requisition a right to vote at the meeting to which the requisition relates; or not less than one hundred shareholders, can request the Company in writing to:
- (a) give  to  shareholders  of  the  Company  entitled  to  receive  notice  of  the  next  annual  general  meeting notice of any resolution which may properly be moved and is intended to be moved at that meeting; and
- (b) circulate to shareholders of the Company entitled to have notice of any general meeting send to them any  statement  of  not  more  than  one  thousand  words  with  respect  to  the  matter  referred  to  in  any proposed resolution or the business to be dealt with at that meeting.


The requisition must be deposited to the Company not less than six weeks before the meeting in case of a requisition requiring notice of a resolution or not less than one week before the meeting in case of any other requisition.

---

# Page 46

# Corporate Governance Report


## SHAREHOLDER RIGHTS (continued)


## Procedures for shareholders to propose a person for election as a director of the Company

According to Bye-law 104 of the Company's Bye-laws, no person other than a director retiring at the general meeting of the Company shall, unless recommended by the directors for election, be eligible for election as a  director  at  any  general  meeting of the Company unless a notice signed by a shareholder of the Company (other  than  the  person  to  be  proposed)  duly  qualified  to  attend  and  vote  at  the  general  meeting  of  the Company for which such notice is given of his/her intention to propose such person for election and also a notice signed by the person to be proposed of his/her willingness to be elected shall have been lodged at the Company's principal place of business in Hong Kong or at the Company's branch share registrar and transfer office  in  Hong  Kong,  Tricor  Tengis  Limited  provided  that  the  minimum  length  of  the  period,  during  which such notice(s) are given, shall be at least seven days and that the period for lodgement of such notice(s) shall commence no earlier than the day after the despatch of the notice of the general meeting and end no later than seven days prior to the date of such general meeting.


## Procedures for directing shareholders' enquiries to the Board

Shareholders may at any time send their enquiries and concerns in writing to the Company Secretary at the Company's principal  place  of  business  in  Hong  Kong  at  Rooms  1502-03,  15th  Floor,  Great  Eagle  Centre,  23 Harbour Road, Wanchai, Hong Kong.


## Shareholders Communication Policy

The Group has adopted a shareholders communication policy (the ' Shareholders Communication Policy ') which sets out the objective of ensuring that the Company's shareholders, both individual and institutional and,  in  appropriate  circumstances,  the  investment  community  at  large,  are  provided  with  ready,  equal and  timely  access  to  balanced  and  understandable  information  about  the  Company  (including  its  financial performance,  strategic  goals  and  plans,  material  developments,  governance  and  risk  profile),  in  order  to enable  the  shareholders  to  exercise  their  rights  in  an  informed  manner,  and  to  allow  the  shareholders  and the  investment  community  to  engage  actively  with  the  Company.  The  Group  has  established  a  range  of communication  channels  between  itself  and  the  shareholders,  investors  and  other  stakeholders.  These include  (i)  contacting  the  Hong  Kong  branch  share  registrar,  Tricor  Tengis  Limited,  regarding  questions on  shareholdings;  (ii)  publishing  corporate  communications  such  as  announcements,  circulars  and  the annual  and  interim  reports;  (iii)  maintaining  a  corporate  website  at  www.epiholdings.com;  and  (iv)  holding shareholders'  meetings.  The  Board  has  the  overall  responsibility  to  maintain  an  ongoing  dialogue  with  the shareholders  and  the  investment  community,  and  will  regularly  review  the  Shareholders  Communication Policy to ensure its effectiveness.

For the year ended 31 December 2022, the Board has reviewed the implementation and effectiveness of the Shareholders Communication Policy including steps taken at the general meetings, the handling of queries received (if any) and the multiple channels of communication and engagement in place, and considered that the Shareholders Communication Policy has been properly implemented during the year under review and is effective.

---

# Page 47

# Corporate Governance Report


## INVESTOR RELATIONS

As  a  channel  to  further  promote  effective  communication,  the  Group  maintains  a  website  at www.epiholdings.com  where  the  Company's  annual  and  interim  reports,  notices,  announcements  and circulars are posted.

A printed copy of the Bye-laws has been published on the websites of the Company and the Hong Kong Stock Exchange. There had been no changes in the Company's constitutional documents during the year ended 31 December 2022.

Enquiries may be put to the Board through the Company Secretary at Rooms 1502-03, 15th Floor, Great Eagle Centre, 23 Harbour Road, Wanchai, Hong Kong.


## DIVIDEND POLICY

According to the dividend policy adopted by the Company, in deciding whether to propose a dividend and in determining the dividend amount, the Board shall take into account, among others, the following factors: (i)  the  actual  and  expected  financial  performance  of  the  Group;  (ii)  the  retained  earnings  and  distributable reserves  of  the  Group;  (iii)  the  expected  working  capital  requirements  and  future  expansion  plans  of  the Group;  (iv)  liquidity  position  of  the  Group;  and  (v)  any  other  factors  that  the  Board  deems  appropriate. The  declaration  and  payment  of  dividends  by  the  Company  shall  be  determined  at  the  sole  and  absolute discretion of the Board and is also subject to compliance with all applicable laws and regulations including the Companies Act and the Company's Bye-laws.


## SUFFICIENCY OF PUBLIC FLOAT

Based on information that is publicly available to the Company and within the knowledge of the Directors, at  least  25%  of  the  Company's total issued shares is held by the public as at 21 April 2023, being the latest practicable date before printing of this annual report.

---

# Page 48

# Environmental, Social and Governance Report


## INTRODUCTION

The Board is pleased to present this Environmental, Social and Governance (' ESG ') Report (' ESG Report ') of the Group for the year ended 31 December 2022 (the ' Reporting Period ' or ' 2022 '). The Group is principally engaged  in  the  business  of  petroleum  exploration  and  production,  solar  energy,  money  lending  and investment in securities.

The  ESG  Report  summarises  the  policies,  sustainability  strategies,  management  approach  and  initiatives implemented by the Group, as well as the performance of the Group in environmental and social aspects of its businesses.


## REPORTING SCOPE

The  Group  identifies  the  reporting  scope  by  considering  the  materiality  principle,  its  core  business  and  its main  revenue  source.  During  the  Reporting  Period,  the  Group  completed  the  acquisition  of  an  operating oilfield  which  comprises  petroleum  and  natural  gas  rights,  facilities  and  pipelines,  together  with  all  other properties  and  assets  located  in  Alberta  Province  in  Canada  (the  ' Canadian Oil Assets ').  The  scope  of  this ESG  Report  covers  the  Group's  major  business  operations  and  activities  in  Hong  Kong  and  the  petroleum exploration and production business in Canada since the completion of the acquisition of the Canadian Oil Assets in July 2022, but excludes the petroleum exploration and production business in Argentina which was ceased in March 2021. The Group will further expand its reporting scope in the future, where appropriate.


## REPORTING BASIS

The ESG Report has been prepared in accordance with the Environmental, Social and Governance Reporting Guide set out in Appendix 27 to the Listing Rules. Information relating to the Group's corporate governance practices is set out in the 'Corporate Governance Report' on pages 30 to 45 of this annual report.


## REPORTING PRINCIPLES

The Group adheres to the following reporting principles as the basis for preparation of the ESG Report:

Materiality: The  content  of  this  ESG  Report  is  determined  by  stakeholder  participation  and  materiality assessment  process,  which  includes  identifying  material  environmental  and  social  related  issues,  collecting and reviewing the views and suggestions of the management and stakeholders, assessing the relevance and significance of different issues and compiling the reported content, further details of which are set out in the sections headed 'Stakeholder Engagement' and 'Materiality Assessment' below.

Quantitative: The key performance indicators (' KPIs ')  relating  to  the  environmental  and  social  aspects  are disclosed in this ESG Report which provide stakeholders of the Group a comprehensive picture of the Group's ESG  performance.  Where  appropriate,  relevant  data  are  supplemented  by  explanatory  notes  to  establish benchmarks.

---

# Page 49

# Environmental, Social and Governance Report


## REPORTING PRINCIPLES (continued)

Balance: Every effort has been made in this ESG Report to reflect the performance of the Group's ESG activities impartially and has avoided selection, omission or presentation of format that might inappropriately influence the decision or judgment of the readers of this ESG Report.

Consistency: Except  for  the  change  in  reporting  scope,  the  approach  in  preparing  this  ESG  Report  is consistent  with  the  ESG  Reports  in  the  previous  years  to  allow  for  meaningful  comparison.  If  there  are  any additional changes that may affect the comparison with the previous reports, explanation will be provided for the corresponding data.


## ESG MANAGEMENT


## Report from the Board

The Group is committed to corporate social responsibility and recognises the importance of environmental, social and economic benefits. The Group also hopes to balance its business development with the interests of its key stakeholders and operates its businesses in a sustainable manner. To achieve this vision, the Group has set a sustainability framework that focuses on environmental protection, resource management, employee and  community  well-being  and  guides  its  sustainability  efforts  to  ensure  that  sustainability  elements  are integrated into all operation and all business decisions.

Global  warming  is  a  growing  concern.  As  a  socially  responsible  corporate,  the  Group  is  committed  to mitigating its environmental impact and integrating responsible environmental practices into its businesses. The Group has been running its solar energy business with a view to contribute its efforts in promoting the use  of  clean  and  renewable  energy  and  building  a  greener  environment.  The  Board  retains  the  collective responsibility  for  the  management  approach,  strategies  and  reporting  of  the  Group's  ESG  matters.  In  order to  better  evaluate,  prioritise  and  manage  the  Group's  ESG-related  issues,  the  Board  discusses  and  reviews the  Group's  ESG-related  risks  and  opportunities,  performance,  goals  and  targets  with  the  assistance  of  the management team at least annually.

During the Reporting Period, the employees of the Group had shown strong team spirit and the Group had provided  multi-pronged  support  to  the  employees  in  the  midst  of  the  COVID  pandemic  to  avoid  infection, and  helped  to  prevent  the  spread  of  virus  in  the  community.  The  Group  had  provided  various  supportive measures which included providing epidemic prevention materials and rapid antigen test kits to employees, and facilitating  'work  from  home'  arrangement.  Despite  the  severity  of  the  pandemic,  the  Group  remained concerned  about  employees'  remuneration  and  benefits,  career  development  opportunities,  provision  of safe  working  environment,  and  fulfilling  corporate  social  responsibility.  Going  forward,  upon  the  revival  of economic activities worldwide following the easing of the pandemic, the Group hopes that all employees and the community will continue to put unremitting efforts in going through the adversities and challenges, and make continuous progress towards sustainable development.

---

# Page 50

# Environmental, Social and Governance Report


## ESG MANAGEMENT (continued)


## Report from the Board (continued)

To achieve this vision, the Board has set a number of environmental and social KPIs and has taken a top-down approach  to  disintegrate  the  KPIs  into  the  functional  departments.  The  Board  not  only  aimed  to  improve the  well-being  of  the  employees,  but  also  encourages  the  employees  to  participate  in  making  changes  in different areas, which include reducing greenhouse gas (' GHG ') emissions and making good use of resources. During the Reporting Period, the Board had actively supported the implementation of the Group's sustainable development strategies and action plans by the management team and all employees. The relevant scope, progress and achievements relating to the environmental and social KPIs are disclosed in this ESG Report. The Group hopes that its professional management team can continue to commit to stable operation and prudent financial management policy, meet the challenges ahead with success, implement sustainable development strategies, improve business performance and create more meaningful long-term value for the enterprise and its stakeholders.


## Governance Structure

The  Board  believes  that  sound  ESG  strategies  can  create  investment  value  for  the  Group  and  deliver  longterm  returns  to  its  stakeholders.  The  establishment  of  an  appropriate  governance  framework  is  critical  to the successful implementation of the Group's ESG sustainability strategies and an ESG governance structure with  clear  duties  and  responsibilities  has  been  set  up  by  the  Group.  The  Board  has  established  the  longterm  policies  and  strategies  for  all  sustainability  matters  and  will  review  the  implementation  status  and progress of the ESG matters annually and report on its performance. The Board has also reviewed the progress made  against  ESG-related  goals  and  targets  through  internal  meetings  with  the  management  team.  The management team reports to  the  Board  at  least  annually  to  assist  the  Board  in  assessing  and  determining whether the Company has established an appropriate and effective internal control system to contain the ESG risks.  At  the  operational  level,  functional  units  are  responsible  for  ensuring  the  integration  of  sustainability strategies and practices into the Group's business operations as well as exploring new action plans/initiatives.


Board members are responsible for:
-  Developing long-term sustainable development policies and strategies
-  Assessing and iden�fying risks and opportuni�es associated with ESG
-  Ensuring appropriate and effec�ve ESG risk management and internal monitoring systems
-  Reviewing and approving policies, objec�ves and ac�on plans/ measures rela�ng to ESG ma�ers
-  Approving ESG reports



The management team is responsible for:
-  Developing and reviewing ESG-related policies, objec�ves and ac�on plans/measures
-  Monitoring and repor�ng to the Board on the progress of the implementa�on of the ac�on plans/measures
-  Iden�fying ESG risks and opportuni�es
-  Reviewing ESG reports



The func�onal departments are responsible for:
-  Iden�fying, assessing, defining and repor�ng to management on significant ESG issues
-  Performing ESG risk management and internal monitoring
-  Ensuring ESG policies, objec�ves and ac�on plans/measures are integrated into business opera�ons


The Board


## Management team

Func�onal departments


-  Repor�ng to management on progress and quality of ac�on plans/measures

---

# Page 51

# Environmental, Social and Governance Report


## ESG MANAGEMENT (continued)


## Governance Structure (continued)

The  Board  has  appointed  an  independent  consultant  to  provide  advice  on  the  ESG  matters  and  assist in  collecting  data  and  information  for  conducting  various  analyses,  and  providing  improvement recommendations  on  the  Group's  ESG  performance.  The  Group  has  also  collected  the  views  of  key stakeholders  on  ESG  matters  during  daily  operations  and  conducted  a  materiality  assessment  to  identify important  ESG  issues  for  the  Group,  details  of  which  are  set  out  in  the  sections  headed  'Stakeholder Engagement' and 'Materiality Assessment' below. To effectively lead the ESG process of the Group, the Board monitors  the  work  of  all  departments  to  ensure  that  they  work  closely  together  to  achieve  the  sustainable development goals of operational compliance and social responsibility.


## Stakeholder Engagement


The Group is committed to maintaining the sustainable development of its businesses and providing support to  environmental  protection  and  the  community  in  which  it  operates.  The  Group  maintains  a  close  tie with  its  stakeholders,  including  government/regulatory  organisations,  shareholders/investors,  employees, customers, suppliers, community, etc. and strives to balance their opinions and interests through constructive communications in order to determine the directions of its sustainable development. The Group assesses and determines its ESG-related risks, and ensures that the relevant risk management and internal control systems are operating properly and effectively. The following table contains the expectations and concerns of the key stakeholders, as identified by the Group, and the corresponding management response:
| Stakeholders                          | Expectations and concerns                                                                                                                            | Management response                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
|---------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Government/ regulatory                | ·  Compliance with laws and  regulations                                                                                                             | ·  Uphold integrity and compliance in  operations                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| organisations Shareholders/ investors | ·  Fulfil tax obligations ·  Joint efforts in combating  COVID-19 ·  Return on investment ·  Information transparency ·  Corporate governance system | ·  Pay tax on time, which in return  contributing to the society ·  Establish comprehensive and  effective internal control and risk  management systems ·  Follow the government's prevention  measures and guidelines to prevent  the spread of COVID-19 ·  Management possesses experience  and professional knowledge in  business sustainability ·  Regular information dissemination  via publications on the websites of  the Hong Kong Stock Exchange and  the Company ·  Dedicated to improvement |

---

# Page 52

# Environmental, Social and Governance Report


## ESG MANAGEMENT (continued)

Stakeholder Engagement (continued)


| Stakeholders   | Expectations and concerns                                                              | Management response                                                                                                                  |
|----------------|----------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------|
| Employees      | ·  Labour rights ·  Career development                                                 | ·  Set up contractual obligations to  protect labour rights                                                                          |
| Customers      | ·  High quality products and  customer services                                        | ·  Provide high quality products and  services continuously in order to  maintain customer satisfaction ·  Ensure proper contractual |
| Suppliers      | ·  Integrity ·  Corporate reputation                                                   | ·  Ensure the performance of  contractual obligations ·  Establish policy and procedures  regarding supply chain management          |
| Community      | ·  Environmental protection ·  Reduce GHG emissions ·  Effective resources utilisation | ·  Pay attention to climate change ·  Strengthen management in energy  saving and emission reduction                                 |

---

# Page 53

# Environmental, Social and Governance Report


## ESG MANAGEMENT (continued)

The following table contains the Group's communication channels with key stakeholders:

Stakeholder Engagement (continued)


| Stakeholders                          | Communication channels                                                               |
|---------------------------------------|--------------------------------------------------------------------------------------|
| Government/ regulatory  organisations | ·  Written or electronic correspondences                                             |
|                                       | ·  Visits and inspections                                                            |
| Shareholders/investors                | ·  General meetings                                                                  |
|                                       | ·  Interim and annual reports                                                        |
| Employees                             | ·  Training activities, seminars and briefings ·  Internal email ·  Suggestion boxes |
|                                       | ·  Customer service hotline ·  Emails ·  Customer meetings                           |
| Customers                             | ·  Site visits                                                                       |
| Suppliers                             | ·  Business meetings and discussions                                                 |
| Community                             | ·  ESG reports                                                                       |
|                                       | ·  Company website and email                                                         |

---

# Page 54

# Environmental, Social and Governance Report


## ESG MANAGEMENT (continued)


## Materiality Assessment


During  the  Reporting  Period,  the  Board  held  discussions  with  the  management  team  and  conducted materiality  assessment  through  various  channels  to  identify  ESG  issues  which  both  the  Group  and  its  key stakeholders are interested in and assessed the level of concern in accordance with their perspectives so as to select the material ESG-related aspects. For the materiality assessment, the Group has adopted the following three processes:
-  Iden�fies ESG issues through diverse channels and internal discussion



## Iden�fica�on


## Priori�sa�on


## Valida�on


-  Examines and adopts the ESG issues of concern in the past stakeholders' engagement
-  Draws a�en�on to emerging ESG issues
-  Synthesises, analyses and evaluates the views of all par�es to iden�fy and priori�ses poten�al and important issues
-  Develops materiality matrix based on the importance of the issue to the Group and its key stakeholders
-  Interacts with the management team to validate the materiality assessment and ensure that these issues are aligned with the sustainable development direc�on sought by the Group
-  Reports the materiality assessment to the Board and makes disclosure in the ESG Report

---

# Page 55

# Importance to Stakeholders


## Environmental, Social and Governance Report


## ESG MANAGEMENT (continued)


## Materiality Assessment (continued)

Materiality assessment facilitates the Group to ensure its business objectives and development direction are in line with the expectations and requirements of its stakeholders. During the Reporting Period, there was no significant change in the materiality of ESG issues, as there was no significant change in the Group's business nature. The matters of concern of the Group and its stakeholders are presented in the following materiality matrix:


## Materiality Matrix

High


## Medium

Low


|           | Anti-discrimination  measures                    |  Talent management  Staff training and                                  |  Customer's satisfaction  Product and customer                      |
|------------|--------------------------------------------------|---------------------------------------------------------------------------|-----------------------------------------------------------------------|
|           | Labour rights  protection                        | promotion opportunity  Staff compensation and                            | service quality  Suppliers management                                |
|           | Community  contribution                          |  Anti-corruption  measures  Air and GHG emissions  Energy conservation |  Operational compliance  Client's privacy  measures and  protection |
|           | Product safety                                   |                                                                           |                                                                       |
|           | Preventive measures for  child and forced labour |                                                                           |                                                                       |
|           | Generation of non- hazardous wastes              |                                                                           |                                                                       |
| Low Medium | Low Medium                                       | Low Medium                                                                | High                                                                  |

---

# Page 56

# Environmental, Social and Governance Report


## A. ENVIRONMENTAL

Owing  to  the  Group's  business  nature,  its  daily  operations  may  impact,  both  directly  and  indirectly, the  environment.  Therefore,  the  Group  is  committed  to  maintaining  the  long-term  sustainability  of the  environment  and  community  where  the  Group  operates,  and  thus  integrated  environmental  and social  consideration  into  its  decision  making  process  and  assumes  the  responsibilities  of  creating  an environmentally sustainable business.

As  the  Group  is  engaged  in  the  petroleum  exploration  and  production  business,  it  inevitably generates  emissions  and  other  pollutants  during  daily  operations.  Therefore,  the  Group  recognises the  importance  of  continuous  improvement  on  ESG  performance  and  its  responsibilities  towards the  potential  negative  environmental  impacts  associated  with  its  business  operations,  and  thus  has established relevant internal guidelines to ensure strict compliance with all local environmental-related laws  and  regulations,  as  well  as  focuses  on  nurturing  and  strengthening  its  employees'  awareness  of environmental protection in their daily work processes.

Owing  to  the  nature  of  the  Canadian  Oil  Assets  operation,  GHG  emissions  from  consumption  of different  types  of  fuel  and  energy,  together  with  hazardous  and  non-hazardous  waste  arising  from operation will be inevitably produced, which will be discussed in the sections 'A1. Emissions' and 'A2. Use Of Resources' below. The daily operations of the oilfield, new wells drilling and other production enhancement activities consume different types of fuel and energy including (i) electricity and propane consumed mainly for well fluid extraction from wells, water separation from the well fluid, and water injection back into underground, and (ii) diesel and propane consumed mainly for running rigs for new wells drilling and other production enhancement works. The consumption of fuel and energy generated Scope  1  GHG  emissions,  and  purchased  electricity  generated  Scope  2  GHG  emissions.  In  addition, hazardous wastes including waste oil and fluid, and non-hazardous wastes including drill cuttings, will be produced from the daily operations, new wells drilling and other production enhancement activities of the Canadian Oil Assets.

The  Group  commenced  its  solar  energy  business  in  2021  through  investing  in  solar  energy  power generation  projects  located  in  Hong  Kong,  under  which  solar  photovoltaic  (' SPV ')  systems  built  are connected to  the  power  grid  of  CLP  Power  Hong  Kong  (' CLP ')  under  the  Renewable  Energy  Feed-in Tariff  Scheme  (the  ' FiT  Scheme '),  and  electricity  produced  by  the  SPV  systems  is  supplied  and  sold to  CLP.  The  FiT  Scheme  is  an  initiative  promoted  by  the  two  power  companies  and  the  Hong  Kong Government  aiming  to  incentivise  the  private  sector  to  produce  clean  energy  for  consumption  in Hong  Kong,  which  also  serves  as  an  important  mean  of  the  government's  plan  of  achieving  carbon neutrality before 2025. The Group has successfully integrated the environmental protection aspect of its  ESG-initiatives  into  a  viable  business  model,  and  is  committed  to  continue  contributing  its  efforts in  promoting  the  use  of  clean  and  renewable  energy  and  building  a  greener  environment  for  the community.

Owing  to  the  change  in  reporting  scope  during  the  Reporting  Period,  the  Group  considered  its  ESG targets set in 2021 were no longer applicable, and thus has revised its ESG targets in 2022. The revised targets  are  described  in  the  sections  headed  'Air  and  GHG  Emissions',  'Waste  Management'  and 'Energy Conservation Measures' below.

---

# Page 57

# Environmental, Social and Governance Report


## A. ENVIRONMENTAL (continued)


## Operational Compliance

The Group adopts industry practices and guidelines in its management of environmental risks arising from the petroleum exploration and production operation in Canada. The Group strictly complies with all  the  relevant  environmental  laws  and  regulations.  During  the  Reporting  Period,  the  Group  was  not aware  of  any  material  non-compliance  with  laws  and  regulations  in  Canada  concerning  air  and  GHG emissions, discharges into water and land, and generation of hazardous and non-hazardous wastes that would have a significant impact on the Group, including but not limited to the Alberta Energy Regulator Directive 58: Oilfield Waste Management Requirements for the Upstream Petroleum Industry, Canadian Environmental  Protection  Act,  1999  (CEPA  1999),  Environmental  Protection  and  Enhancement  Act (EPEA) and Environmental Management Act (EMA) of Canada.


## A1. Emissions


## Air and GHG Emissions

The Group is committed to minimising air emissions from its operations and ensuring compliance with the statutory emission standards. As the Group's daily operations currently do not involve in the usage of company vehicles, the Group does not generate significant amount of air emissions owing to use of vehicles. Nonetheless, the Group has established policies relating to fuel-saving of company vehicles such as minimising their use, eliminating excessive fuel consumption, and carrying out regular vehicle inspection and maintenance.

The  Group  has  always  been  committed  to  assessing  and  reporting  its  carbon  footprint  to  the public. During the Reporting Period, the major sources of the Group's GHG emissions were direct GHG  emissions  from  diesel  and  propane  consumption  arising  from  the  daily  operations,  new well  drilling  and  other  production  enhancement activities  of  the  Canadian  Oil  Assets  (Scope  1) and energy indirect GHG emissions from electricity purchased for the daily use of the Canadian Oil Assets (Scope 2). Owing to the change in reporting scope, the Group has set a revised target to  gradually  reduce  the  Group's  GHG  emissions  intensity  (tCO e/thousand  bbl 5 )  over  the  next 2 five years, using 2022 as the baseline year. To achieve the set target, the Group will continue its efforts in mitigating the GHG emissions in the following years including exploring ways to lower the use of purchased electricity, phasing out energy-inefficient equipment when it reaches the end of the equipment lifecycle and enhancing the Group's employees' environmental awareness.

During 2022, the Group's total GHG emissions intensity increased significantly compared to 2021. This  is  mainly  due  to  the  expansion  in  the  reporting  scope  to  include  the  Group's  petroleum exploration and production business in Canada, which is in sizeable scale.

---

# Page 58

# Environmental, Social and Governance Report


## A. ENVIRONMENTAL (continued)

A1. Emissions (continued)

Air and GHG Emissions (continued)


Summary of GHG emissions and its intensity performance is as follows:
| Indicator 1                     | Unit                 | 2022       | 2021   |
|---------------------------------|----------------------|------------|--------|
| Scope 1 - Direct GHG  emissions |                      |            |        |
|                                 | tCO2e                | 378.81 2   | 9.19 3 |
| Scope 2 - Energy indirect       |                      |            |        |
| GHG emissions                   | tCO2e                | 1,335.95 2 | 8.45 3 |
| Total GHG emissions             | tCO2e                | 1,714.76   | 17.64  |
| Intensity                       | tCO2e/employee 4     | 74.55      | 0.84   |
|                                 | tCO2e/thousand bbl 5 | 21.09      | N/A    |



## Notes:


- 1. GHG emissions data are presented in terms of carbon dioxide equivalent and are based on, but not limited to, 'The Greenhouse Gas Protocol: A Corporate Accounting and Reporting Standards' issued by  the  World  Resources  Institute  and  the  World  Business  Council  for  Sustainable  Development, 'How to prepare an ESG Report - Appendix 2: Reporting Guidance on Environmental KPIs' issued by  the  Hong  Kong  Stock  Exchange,  the  latest  released  emission  factors  of  China's  regional  power grid  basis,  the  'Global  Warming  Potential  Values'  from  the  Fifth  Assessment  Report  (AR5)  of  the Intergovermental Panel on Climate Change (IPCC) 2014 and the Sustainability Report 2022 published by HK Electric.
- 2. These  figures  represent  GHG  emissions  from  the  diesel  and  propane  consumption  (Scope  1)  and purchased electricity (Scope 2) of the Group's Canadian Oil Assets.
- 3. These figures are related to the petroleum exploration and production business in Argentina which was ceased in March 2021, its consumption of natural gas and electricity and the corresponding GHG emissions have been restated to conform with current year presentation.
- 4. As at 31 December 2022, the Group had a total of 23 (2021: 21) directors and employees. This data is used for calculating intensity data per employee and employees related data.
- 5. The Group's Canadian Oil Assets produced approximately 81,300 barrels (' bbl ')  of  crude  oil  in  2022. As  the  petroleum  exploration  and  production  business  in  Canada  accounts  for  most  of  the  Group's GHG  emissions/hazardous  wastes/non-hazardous  wastes/energy  consumption,  this  production  data of crude oil is used for calculating intensity data per thousand bbl, in addition to the intensity data per employee. Owing to the change in the reporting scope, this intensity data type will be disclosed from 2022 onwards.

---

# Page 59

# Environmental, Social and Governance Report


## A. ENVIRONMENTAL (continued)

A1. Emissions (continued)

Air and GHG Emissions (continued)

During the Reporting Period, the Group did not generate any nitrogen oxide (' NOx ') (2021: 11.74 kilograms),  sulphur  oxide  (' SOx ')  (2021:  0.03  kilograms)  and  particulate  matters  (' PM ')  (2021: 1.08 kilograms) as its operations currently do not involve in the usage of company vehicles. The air emissions of NOx, SOx and PM generated in 2021 was due to the vehicles used by the Group's petroleum exploration and production business in Argentina.


## Sewage Discharge

The  Group's  office  in  Hong  Kong  and  Canada  do  not  consume  a  significant  volume  of  water  during their  daily  operations,  and  thus  do  not  generate  a  material  portion  of  sewage.  As  waste  water  from the  Group's  offices  will  be  discharged  into  sewage  pipe  networks  connected  to  the  regional  water purification  plants,  the  water  consumed  by  the  Group  is  considered  as  sewage  discharged.  Details  of the Group's water injection and water consumption are set out in the section headed 'Water Resources Utilisation' below.


## Waste Management

Hazardous wastes

The Group's Canadian Oil Assets operation inevitably generates hazardous wastes including waste oil and  fluid  from  its  daily  operations,  new  wells  drilling  and  other  production  enhancement  activities. Nonetheless, the Group strictly abides by all waste-related laws and regulations in Canada and strives to reduce the amount of hazardous wastes generated from its operations. The Group engages qualified subcontractors to collect, manage and dispose of all hazardous wastes generated from its operations, in compliance with local laws and regulations.

In  order  to  minimise  the  environmental  impacts  from  hazardous  wastes  generated  from  the  Group's operations  and  achieve  the  set  target,  the  Group  has  implemented  measures  to  reduce  waste production  and  regularly  monitors  the  waste  production  level.  If  any  abnormal  fluctuations  in  the amount of hazardous waste produced are identified, the Group will conduct investigation to identify the source of such fluctuations. It is the Group's internal operational guidance to entrust all hazardous wastes to qualified third party for compliant disposal.

---

# Page 60

# Environmental, Social and Governance Report


## A. ENVIRONMENTAL (continued)

Waste Management (continued)

Hazardous wastes (continued)


Summary of hazardous wastes disposal and its intensity performance is as follows:
| Indicator              | Unit               |   2022 | 2021   |
|------------------------|--------------------|--------|--------|
| Total hazardous wastes | tonne              |  65.63 | -      |
| Intensity              | tonne/employee     |   2.85 | -      |
|                        | tonne/thousand bbl |   0.81 | N/A    |



## Generation of non-hazardous wastes

The  Group's  Canadian  Oil  Assets  operation  inevitably  generates  non-hazardous  waste  including waste papers from its daily operations and drill cuttings from new wells drilling and other production enhancement  activities.  The  Group  strives  to  minimise  the  potential  environmental  risks  and impacts  caused  by  its  wastes  by  developing  effective  waste  treatment  strategies  and  policies.  Waste management mainly involves recycling waste papers and collection of domestic wastes. Clearly labelled recycling  bins  are  provided  for  collection  of  waste  papers,  plastic  bottles,  etc.  Wastes  are  properly sorted  and  are  stored  in  designated  collection  areas.  After  identifying  and  classifying  the  wastes,  the recyclable wastes collected are then delivered to the waste collectors for regular recycling. In respect of  drill  cuttings,  it  is  the  Group's  internal  operational  guidance  to  entrust  this  non-hazardous  waste produced in the oilfield to licensed third party for compliant disposal.

In  order  to  minimise  the  environmental  impacts  from  non-hazardous  wastes  generated  from  the Group's  operation,  the  Group  has  implemented  measures  to  reduce  waste  papers.  The  Group encourages  its  employees  to  read  documents  in  electronic  format,  to  consider  the  environment before  printing,  to  despatch  memos  and  announcements  via  emails,  to  preview  document  layout on  computer  screen,  to  print  documents  on  both  sides  of  the  papers,  to  procure  paper  bearing  the Forest  Stewardship  Council  Recycled  Label  for  financial  reports  printing,  and  to  promote  'green office' concepts in the workplace. The Group also encourages its employees to reduce the use of nonrecyclable  materials  to  minimise  the  adverse  impact  on  the  environment.  Owing  to  the  change  in reporting scope, the Group has set a revised target to conduct annual activities to raise awareness of waste reduction among employees from 2022 onwards.

During  the  Reporting  Period,  the  Group's  total  non-hazardous  wastes  intensity  (tonne/employee) increased significantly compared to 2021. This is mainly due to the expansion in the reporting scope to include the Group's petroleum exploration and production business in Canada, which is in sizeable scale.


Summary of non-hazardous wastes disposal and its intensity performance is as follows:
| Indicator                  | Unit               |   2022 | 2021   |
|----------------------------|--------------------|--------|--------|
| Total non-hazardous wastes | tonne              | 601.86 | 0.47   |
| Intensity                  | tonne/employee     |  26.17 | 0.02   |
|                            | tonne/thousand bbl |   7.4  | N/A    |

---

# Page 61

# Environmental, Social and Governance Report


## A. ENVIRONMENTAL (continued)


## A2. Use of Resources

Energy Conservation Measures

The Group actively implements the concept of energy conservation, emission reduction and maintain conscious  use  of  resources.  The  Group's  energy  consumption  mainly  comprises  diesel  and  propane consumption and electricity purchased for its daily operations, new wells drilling and other production enhancement activities for its Canadian Oil Assets.

For the Group office-based operations in Hong Kong and Canada, the Group encourages its employees to  change  their  habit  of  using  electrical  appliances,  and  has  introduced  control  measures  including turning  off  lightings,  air-conditioners,  computers,  personal  electronic  devices  and  office  equipment after  work  and/or  when  they  are  idle,  or  turning  on  the  power  saving  mode.  The  Group  also  aims to  keep  all  electronic  appliances  well-maintained  so  as  to  extend  the  life  of  the  equipment.  The Group  encourages  its  employees  to  avoid  wastage  of  resources,  and  promotes  their  awareness  of environmental  protection  in  work  and  life  through  various  means  including  posting  eye-catching stickers of energy efficiency in visible place in office. Owing to the change in reporting scope, the Group has set a revised target to conduct annual activities to raise awareness of energy conservation among employees from 2022 onwards and gradually reduce the Group's energy consumption intensity (MWh/ thousand bbl) over the next five years, using 2022 as the baseline year. To achieve the set target, the Group has established policies and procedures to achieve electricity conservation and efficient use of electricity among a range of lighting, electronic devices, electrical appliances and equipment.

During  the  Reporting  Period,  the  Group's  total  energy  consumption  intensity  increased  significantly compared to 2021, which is mainly due to the expansion in the reporting scope to include the Group's petroleum exploration and production business in Canada, which is in sizeable scale.

Aiming  to  reduce  GHG  emissions  and  to  contribute  building  a  greener  environment,  the  Group  is assessing the feasibility to lower the use of purchased electricity for the Canadian Oil Assets operation through the use of natural gas, or other renewable energy generation methods including solar energy or wind energy, for electricity generation.

---

# Page 62

# Environmental, Social and Governance Report


## A. ENVIRONMENTAL (continued)


## A2. Use of Resources (continued)

Energy Conservation Measures (continued)


Summary of energy consumption and its intensity performance is as follows:
| Indicator 6                 | Unit             | 2022     | 2021 7   |
|-----------------------------|------------------|----------|----------|
| Gasoline 8                  | MWh              | -        | 5.34     |
| Diesel 8                    | MWh              | 1,046.91 | 12.06    |
| Natural gas 8               | MWh              | -        | 22.28    |
| Propane                     | MWh              | 564.81   | N/A      |
| Direct energy consumption   | MWh              | 1,611.72 | 39.68    |
| Purchased electricity       | MWh              | 2,518.13 | 13.88    |
| Indirect energy consumption | MWh              | 2,518.13 | 13.88    |
| Total energy consumption    | MWh              | 4,129.85 | 53.56    |
| Intensity                   | MWh/employee     | 179.56   | 2.55     |
|                             | MWh/thousand bbl | 50.80    | N/A      |



## Notes:


- 6. The method of calculating energy consumption data is based on the 'Energy Statistics Manual' issued by the International Energy Agency.
- 7. During  2021,  the  Group's  petroleum  exploration  and  production  operation  in  Argentina  consumed approximately 551 liters of gasoline, 1,127 liters of diesel and 2,129,782 liters of natural gas.
- 8. Owing to the enhancement of the Group's data processing mechanism, the equivalent amount of energy consumption in MWh will be disclosed from 2022 onwards.



## Natural Gas Consumption

The Group's petroleum exploration and production business in Argentina used natural gas for heating and its operation ceased since March 2021. The Group had not consumed any natural gas since then including the Reporting Period.


## Water Resources Utilisation

During the daily operations of the Canadian Oil Assets, a large volume of water will be extracted from underground  together  with  the  crude  oil  in  form  of  well  fluid,  and  then  the  water  is  needed  to  be separated  from  the  well  fluid  and  injected  back  into  underground.  During  the  Reporting  Period,  the Group had injected approximately 377,000 cubic meter of water back into underground, in compliance with local environmental rules and practices. The operation did not consume any fresh water, surface water, seawater or third-party water during the Reporting Period for the oil extraction process.

---

# Page 63

# Environmental, Social and Governance Report


## A. ENVIRONMENTAL (continued)


## A2. Use of Resources (continued)

Water Resources Utilisation (continued)

For  the  Group's  office-based  operations  in  Hong  Kong  and  Canada,  the  Group  does  not  have  any issues in sourcing water that is fit for its purpose as water is adequately supplied by the government authorities  to  the  office  buildings  where  the  Group's  offices  are  located.  Nonetheless,  the  Group recognises  the  scarcity  of  resources  the  environment  could  offer  and  always  encourages  its  staff members to cherish water usage.

The  water  consumption  data  for  the  Group's  offices  in  Hong  Kong  and  Canada  are  not  available since  water  usage  is  covered  in  the  office  building  management  fees  and  the  building  management companies  are  not  able  to  provide  water  consumption  and  discharge  data  for  individual  office  unit. Since  the  volume  of  drinking  water  purchased  for  office  use  is  also  considered  as  insignificant,  the target  for  water  efficiency  is  therefore  not  presented  as  water  consumption  data  are  not  available. The 2021 figures shown in the table below represent the water consumption of the Group's Argentina office, which ceased to operate during the Reporting Period.


Summary of water consumption and the Group's intensity performance is as follows:
| Indicator               | Unit           | 2022   |   2021 |
|-------------------------|----------------|--------|--------|
| Water                   | tonne          | -      |  35    |
| Total water consumption | tonne          | -      |  35    |
| Intensity               | tonne/employee | -      |   1.67 |


Packaging Material

Owing to the Group's business nature, the use of packaging material is not a material ESG aspect of the Group.


## A3. The Environment and Natural Resources

Well Site Management and Environment Restoration

During  the  Reporting  Period,  the  Group  employed  its  own  local  management  team  in  Canada  to manage the daily oilfield operations. For drilling operations, the local team prepares the drilling plan and completion jobs design and schedule, manage the overall progress, and engage different service provider/vendor  to  perform  the  drilling  and  completion  jobs.  Although  most  of  the  daily  operations in  the  oilfield  are  carried  out  by  service  providers  and  vendors,  the  Group  still  strives  to  minimise the  potential  environmental  impacts  arising  from  its  business  through  monitoring  the  work  of  the service  providers  and  vendors.  As  far  as  the  Group  understands,  the  activities  performed  by  the service  providers/vendors  were  in  material  respects  complied  with  the  local  environmental  laws  and regulations.

---

# Page 64

# Environmental, Social and Governance Report


## A. ENVIRONMENTAL (continued)


## A3. The Environment and Natural Resources (continued)

Well Site Management and Environment Restoration (continued)

The Group is aware of the potential impact of its petroleum exploration and production business on the  environment  and  natural  resources,  and  therefore  attaches  great  importance  to  minimising  its environmental  impact  where  possible,  and  strictly  complies  with  all  relevant  local  environmentalrelated  laws  and  regulations.  The  Group  recognises  its  responsibility  of  preserving  the  oilfields  and pursuing  sustainable  petroleum  exploration  and  production  practices.  Accordingly,  the  Group  has recognised  a  decommissioning  obligation  in  accordance  with  the  regulations  as  required  by  Alberta Energy  Regulator  which  represents  the  cost  for  future  abandonment  of  the  oil  and  gas  production equipment  and  facilities.  This  obligation  includes  facility  decommissioning  and  dismantling,  removal or  treatment  of  waste  materials,  land  rehabilitation  and  site  restoration.  As  of  31  December  2022, the  Group  was  responsible  for  managing  about  80  wells,  of  which  35  wells  were  presently  active and producing hydrocarbons, and drilling works on three new wells were in progress with two were subsequently completed in January 2023 and one in February 2023. The Group has the responsibility to  decommission  and  reclaim  all  the  aforementioned  well  sites  to  their  original  land  use.  When  the Group decides to permanently cease an operation at a well site, pipeline or facility, the asset must be decommissioned, remediated and reclaimed. The Group will take charge of this process, which involves two  stages:  (i)  abandonment  and  (ii)  reclamation.  Upon  abandonment  of  both  the  downhole  and surface components and removal of all surface equipment, the well is considered as decommissioned. Once abandonment work is completed on a site, environmental assessments, remediation (if applicable) and reclamation activities can commence.

During  the  Reporting  Period,  the  Group  had  completed  abandonment  work  on  two  non-producing wells  and  a  bundle  of  underground  pipeline.  The  abandonment  works  have  been  verified  and recognised by Alberta Energy Regulator.

The  Group  has  consistently  integrated  its  ESG  goals  and  mission  in  its  daily  operations  and implemented  practices  and  procedures  to  preserve  and  improve  the  shared  future.  Other  than  the Group's  petroleum  exploration  and  production  operation,  the  Group's  other  operations  do  not  have significant  impact  on  the  environment  and  natural  resources.  The  Group  has  always  been  actively bringing  environmental  responsibility  into  its  daily  operations,  and  encourages  all  staff  to  adopt environmentally responsible behaviour and raise awareness of environmental protection. As mentioned in the above sections, the Company has implemented various measures to reduce energy consumption, save water resources and reduce wastes. The Group strives to promote the use of clean and renewable energy,  as  promulgated  by  its  solar  energy  business  discussed  below,  with  a  view  to  contribute  its efforts in building a greener environment.


## Fostering Renewable Clean Energy

The  Group  has  also  invested  in  solar  energy  power  generation  projects  that  are  participating  in  the FiT  Scheme.  Solar  energy  is  a  kind  of  clean,  renewable  and  sustainable  source  of  electricity  which builds a greener environment. As of 31 December 2022, the Group has 40 solar photovoltaic systems in operations, and 10 solar photovoltaic systems are scheduled to be completed before the end of the first quarter of 2023. By expanding its footprints in renewable energy sector, the Group demonstrated its  commitment  to  curb  carbon  emissions  and  contributed  concerted  efforts  together  with  the government and the community to exploit renewable energy potential in Hong Kong.

---

# Page 65

# Environmental, Social and Governance Report


## A. ENVIRONMENTAL (continued)


## A3. The Environment and Natural Resources (continued)


## Indoor Air Quality

The Group is committed to providing its employees with a pleasing working environment to enhance their work efficiency. For the Group's office-based operation in Hong Kong and Canada, its employees spend  most  of  their  working  hours  inside  the  office,  implying  that  indoor  air  quality  at  workplace  is of  paramount importance. Therefore, indoor air quality is constantly monitored and improved by the utilisation of several measures. Such measures include cleaning air-conditioning systems regularly and choosing products with low or zero volatile organic compounds where applicable. By adopting these measures, indoor air quality of the Group's offices is maintained.


## A4. Climate Change

Climate change is expected to increase the frequency and severity of extreme weather events and cause catastrophic  damage.  Climate  change  is  also  changing  seasonal  and  annual  patterns  of  temperature, precipitation,  and  other  weather  phenomena.  The  unprecedented  crisis  from  the  global  spread  of COVID-19 has created significant challenges worldwide while the risks of climate change are imminent. Understanding of these trends and their relationships with the Group's businesses can help the Group to prepare and analyse possible risks and opportunities, seize opportunities of potential benefits, and establish the response capacity of the Group in the long-run. The Group believes that a robust response to climate change requires concerted efforts of all stakeholders. Therefore, it will continuously identify and  address  stakeholders'  expectations  to  optimise  its  environmental  measures  in  order  to  achieve sustainable development and create long-term values for the stakeholders and society as a whole.

To handle the intensified threat of climate change, the Group has assessed the potential risks that may arise from its business operations. These risks mainly stem from the following dimensions:


## Physical Risks

For physical risks, increase in severity of extreme weather events such as stronger typhoons and floods, may interrupt the water and electricity supplies, damage the Group's properties, as well as threaten the safety  of  the  Group's  employees.  This  may  cause  interruption  to  the  normal  business  operations  and thus have an adverse effect on the Group's financial performance.

The  Group  has  implemented  different  measures  to  manage  the  abovementioned  physical  risks.  For example, the Group maintains comprehensive insurance coverage on assets that are prone to damage by extreme weather conditions. In addition, the Group has established the practice of communicating the arrangements for extreme weather events to employees in advance. The Group recognises potential financial impacts can be minimised with adequate preparation for extreme weather events.


## Transition Risks

For  transition  risks,  the  Group  expects  policies  and  regulations  in  relation  to  climate  change  will become increasingly stringent. If the Group's existing compliance procedures and business operations could  not  fully  comply  with  the  new  legal  and  regulatory  requirements,  it  might  incur  additional compliance costs and the reputation of the Group may also be adversely affected. In addition, the highcarbon emitting industry will suffer from higher cost, lower returns or asset devaluation. Related climate change risk might also impose an impact to the Group's investment and financing activities regarding related industries.

---

# Page 66

# Environmental, Social and Governance Report


## A. ENVIRONMENTAL (continued)


## A3. The Environment and Natural Resources (continued)


## Transition Risks (continued)

To  manage  the  above  transition  risks,  the  Group  has  implemented  a  series  of  measures.  Firstly,  the Group's  management team regularly  monitors  existing  and  emerging  climate-related  trends,  policies and regulations and seek compliance consulting services to reduce legal risks. Secondly, the Group has gradually  incorporated  sustainability  into  its  business  operations.  Various  measures  have  also  been adopted  to  protect  the  environment,  including  measures  aimed  at  reducing  GHG  emissions  as  well as  resources  conservation.  Furthermore,  with  the  aim  to  demonstrate  the  Group's  commitment  on promoting environmental protection, the Group has commenced its solar energy business to explore and  capitalise  on  potential  opportunities  arising  from  the  increasing  awareness  on  environmental protection,  as  well  as  to  advocate  the  global  vision  of  decarbonisation  by  producing  clean  and renewable solar energy.


## B. SOCIAL


## B1. Employment

Connecting  with  the  right  people,  building  social  capital  and  relationships,  showing  appreciation to  staff  members,  suppliers  and  customers  who  keep  the  business  running  are  the  cornerstones  of business success. The Group has observed the applicable laws and regulations of each business location relating  to  compensation  and  dismissal,  recruitment  and  promotion,  working  hours,  rest  periods, equal opportunities, diversity, anti-discrimination, and other benefits and welfare, and has established relevant policies to ensure its employment practices strictly follows the principles of fairness, equality, competitiveness and non-discrimination in hiring outstanding talents.

During  the  Reporting  Period,  the  Group  was  not  aware  of  any  material  non-compliance  with employment-related laws and regulations that would have a significant impact on the Group, including but not limited to the Employment Ordinance of Hong Kong and the Canadian Human Rights Act and Employment Standards Code of Canada.


## Employment and Labour Practices

The  Group's  employees  are  critical  for  its  continuing  operations.  The  Group  always  views  employees as the core assets of the Group for establishing the foundation of success and long-term development. When  the  Group  formulates  human  resources  strategies,  it  devotes  to  create  an  equitable,  nondiscriminatory and safe working environment. It strives to build a harmonious working environment for employees based on mutual respect, trust, impartiality, transparency and truthfulness, dynamism and teamwork to encourage creativity, flexibility and commitment to accomplish the corporate mission.


## Staff Training and Promotion Opportunity

The  Group  provides  equal  opportunities  to  employees  to  capture,  promote  and  retain  talents and  promote  personal  and  professional  growth  by  offering  them  attractive  and  commensurate remuneration packages as well as providing various career development training. Ongoing education and training for employees in relation to ethical conduct, roles and responsibilities, specific skills, and technological  and  market  development  are  very  important  to  nurturing  talents,  as  are  performance feedback and appraisals from direct manager to uncover potentials of employees and offer competitive remuneration  packages  to  retain  competent  staff.  In  addition,  the  Group  strictly  complies  with  the relevant laws and regulations in hiring employees.

---

# Page 67

# Environmental, Social and Governance Report


## B. SOCIAL (continued)


## B1. Employment (continued)

Staff Training and Promotion Opportunity (continued)

The  Group  devotes  to  protect  human  right  and  privacy  of  employees.  It  selects  the  best  qualified candidates  by  considering  various  criteria  such  as  education  background,  relevant  work  experience, demonstrated  knowledge,  competencies  and  skills,  desirable  personal  traits,  physical  fitness  and development potential.


## Anti-discrimination Measures

The Group gives equal opportunity for employment to all individuals, regardless of their race, religion, colour, nationality, age, marital status, gender, sexual orientation or disability. This applies to all phases of  the  employment  relationships,  including  but  not  limited  to  recruitment,  promotion,  dismissal, personal  development  opportunities  and  determining  wages  and  benefits.  Diversity  is  the  strength of  the  Group,  and  therefore  every  employee  must  respect  the  people  and  cultures  with  whom  or  in which they work. The Group endeavours to seek diversity at all levels and expect a work environment in which all employees can develop and contribute to their full potential, and strives to achieve a win-win situation through joint development of employees and the Group.


Details of the distribution of the directors and employees are as follows:
| Indicator           | As at 31 December 2022   | As at 31 December 2022   | As at 31 December 2021   | As at 31 December 2021   |
|---------------------|--------------------------|--------------------------|--------------------------|--------------------------|
|                     | Number  (Person)         | Percentage  (%)          | Number  (Person)         | Percentage  (%)          |
| Employment type     |                          |                          |                          |                          |
| Full-time           | 23                       | 100.00                   | 21                       | 100.00                   |
| Part-time           | -                        | -                        | -                        | -                        |
| Gender              |                          |                          |                          |                          |
| Male                | 16                       | 69.57                    | 15                       | 71.42                    |
| Female              | 7                        | 30.43                    | 6                        | 28.58                    |
| Age group           |                          |                          |                          |                          |
| 20-30               | -                        | -                        | -                        | -                        |
| 31-40               | 5                        | 21.74                    | 6                        | 28.58                    |
| 41-50               | 6                        | 26.09                    | 3                        | 14.29                    |
| > 50                | 12                       | 52.17                    | 12                       | 57.14                    |
| Geographical region |                          |                          |                          |                          |
| Hong Kong           | 15                       | 65.22                    | 15                       | 71.42                    |
| PRC                 | -                        | -                        | 3                        | 14.29                    |
| Argentina           | -                        | -                        | 3                        | 14.29                    |
| Canada              | 8                        | 34.78                    | N/A                      | N/A                      |

---

# Page 68

# Environmental, Social and Governance Report


## B. SOCIAL (continued)


## B1. Employment (continued)

Anti-discrimination Measures (continued)


During the Reporting Period, the Group had an overall turnover rate 9  of 30.43%. Details of the turnover rate by gender, age group and geographical region are as follows:
|                     | Turnover Rate (%) 10   | Turnover Rate (%) 10   |
|---------------------|------------------------|------------------------|
|                     | 2022                   | 2021                   |
| Gender              |                        |                        |
| Male                | 31.25                  | 18.80                  |
| Female              | 28.57                  | 42.90                  |
| Age group           |                        |                        |
| 20-30               | -                      | 100.00                 |
| 31-40               | 40.00                  | 40.00                  |
| 41-50               | 33.33                  | 20.00                  |
| > 50                | 25.00                  | 8.30                   |
| Geographical region |                        |                        |
| Hong Kong           | -                      | 21.10                  |
| The PRC 11          | N/A                    | 25.00                  |
| Argentina 11        | N/A                    | 57.10                  |
| Canada 11           | 12.50                  | -                      |



Notes:
- 9. The  overall  turnover  rate  is  calculated  by  dividing  the  total  number  of  directors  and  employees  leaving employment  during  the  reporting  period  by  the  total  number  of  directors  and  employees  at  the  end  of the  reporting  period.  Owing  to  the  enhancement  of  the  Group's  data  processing  mechanism,  the  overall turnover rate will be disclosed from 2022 onwards.
- 10. The  turnover  rate  by  category  is  calculated  by  dividing  the  total  number  of  directors  and  employees  in the  specified  category  leaving  employment  during  the  reporting  period  by  the  number  of  directors  and employees in the specified category at the end of the reporting period.
- 11. During  the  Reporting  Period,  three  employees  from  the  PRC,  three  employees  from  Argentina  and  one employee from Canada had left the Group.



## Staff Compensation and Welfare

To retain quality staff, the Group offers competitive remuneration package and regularly evaluate their salary levels to make sure that their remuneration packages are competitive. Though the remuneration package varies in different nations where the Group operates, it strives to build a fair, reasonable and competitive remuneration scheme in all its operation locations. Staff salaries are determined based on their  knowledge, skills, experience and education background relevant to the job requirements. Basic remuneration of staff includes fixed salary, bonuses, paid holidays, etc.

---

# Page 69

# Environmental, Social and Governance Report


## B. SOCIAL (continued)


## B1. Employment (continued)

Staff Compensation and Welfare (continued)

Additional  allowances  that  are  also  available  to  the  employees  include  meal  allowance,  overseas travelling  allowance  and  education  subsidy.  Education  subsidy  covers  courses/modules/seminars that are directly relevant to the job and organised by reputable institutions, other allowances include reimbursement  of  membership  fee  to  professional  institutions  which  are  relevant  to  the  job  and birthday celebration for employees.


## Talent Management

In  order  to  enhance  the  quality  of  work  and  competency  of  employees,  the  Group  conducts  periodic performance  appraisal  and  fairly  assesses  the  level  of  awards,  salary  adjustment  and/or  promotion recommendation  based  on  a  number  of  criteria,  including  work  experience,  seniority,  knowledge and  skills,  performance,  contributions,  etc  of  the  employee.  In  compliance  with  local  labour  laws, social  security  laws  and  regulations,  the  Group  operates  retirement  plans  for  its  employees.  The Group handles the dismissal of employees and compensates them in accordance with local laws and regulations.

The Group attaches importance to employees' health and work-life balance. All staff are expected to discharge  their  job  responsibilities  within  reasonable  work  hours.  In  general,  the  Group  implements five-day  work  system  with  40  working  hours  per  week.  All  employees  are  entitled  to  rest  days  and holidays in accordance with applicable labour laws and regulations. In addition to national mandatory holidays, employees are entitled to annual leave, compensation leave and other compassionate leave.

In  order  to  improve  employee  job  satisfaction,  to  enhance  the  cohesion  between  employees  and help them to build up sense of belongings, the Group continues to optimise the annual performance appraisal, remuneration, recognition and reward process to improve the work environment as well as organise various recreational activities.


## B2. Health and Safety

The Group always puts health and safety of its employees as its first priority, and injury prevention is especially  important  as  part  of  the  management  practices.  The  Group  will  not  compromise  health  or safety in the workplace for production or profit. It is the goal of each location to have and maintain a safe workplace. Health and safety policies and procedures are published for all the plants, offices and work  sites.  All  employees  must  perform  their  duties  following  the  published  health  and  safety  rules, and  must  promptly  report  any  concerns,  safety  violations  or  incidents.  Work  performance  within  the operation fields is checked to verify that it is executed safely so as to minimise incidents and potential risks.

During the Reporting Period, the Group was not aware of any material non-compliance with health and safety-related laws and regulations that would have a significant impact on the Group, including but not limited to the Occupational Safety and Health Ordinance and Employees' Compensation Ordinance of Hong Kong and the Occupational Health and Safety Act of Canada.

---

# Page 70

# Environmental, Social and Governance Report


## B. SOCIAL (continued)


## B2. Health and Safety (continued)

Occupational Health and Workplace Safety

The Group established strict risk assessment and management policies and procedures to identify and minimise potential  hazard  that  might  lead  to  injury,  illness  or  human  loss  by  providing  staff  training and planning in advance for the coordinated action in case of emergency. The policies and procedures provide  clear  and  identified  guidelines  for  staff  to  identify  and  assess  risks,  delineate  procedures  for handling  situations  involving  security  and  safety  of  workers  and  facilities,  carefully  plan  for  business operations  (including  tools  required  for  eliminating  or  controlling  risks)  and  promote  good  working atmosphere.  The  Group  aims  to  maintain  and  practise  the  highest  standards  in  terms  of  preventing incidents  and  potential  accidents  by  developing  specific  procedures,  as  well  as  identify,  assess  and minimise risks by scheduling operations performing in the work field.

The Group provides on-the-job technical training regularly, arranges safety assessment and organises teambuilding activities to promote job safety. This is to ensure that employees are equipped with the required knowledge and skills to fulfil their job duties and able to meet the safety standards.

The Group also has insurance policies in place for injuries at work for every employee. It cares about occupational  health  and  safety  programmes  as  they  strengthen  safety  awareness  and  self  protecting tendencies of employees and maintain a safe production environment.

The  Group  believes  that  good  working  relationship  among  staff  can  minimise  hazards  within  the operation site. The Group sets up comprehensive contingency plan detailing the handling procedures for  different  types  of  contingencies  (fires,  electrical  failure,  flood  and  water  damage,  earthquakes, typhoons, heavy rains, etc.) When a contingency occurs, the procedure starts by notifying through any available  media,  according  to  the  employees'  emergency  roles.  The  primary  purpose  of  the  business contingency plan is to safeguard assets of the Group such as physical safety and mental well-being of human life, to establish and resume critical functions as quickly as possible by providing an alternate processing site and to re-establish critical functions of the Group. A responsible personnel is designated for coordinating and supervising the work necessary during and after the incident.

The  Group  also  establishes  and  optimises  its  occupational  health  management  system  to  protect workers and their rights. The Group provides all site workers in oilfield with safety protective equipment such as  protective  gloves,  shock-proof  glasses,  hearing  protectors,  fire  resistant  jacket,  helmet,  boots with toes and ankles protection, working clothes, etc. in sufficient quantity and quality and the use of the safety protective equipment is mandatory, in accordance with the instructions issued by the Group. All personnel involved in the operation and within the scope of the location are responsible for the use of  safety  protective  equipment  which  must  be  suitable  to  perform  the  work.  In  addition,  prior  to  the start-up of any operational task within or outside the location, a meeting with the involved staff present on location is conducted to give knowledge of the involved manoeuvres, identified risks and scope or needs that are required to complete such an operation.

---

# Page 71

# Environmental, Social and Governance Report


## B. SOCIAL (continued)


## B2. Health and Safety (continued)

Occupational Health and Workplace Safety (continued)

The Group attaches great importance to hazard prevention and control in order to effectively improve the intrinsic safety. Operation department in Canada is responsible for monitoring the daily conditions of the oil wells, well fluid collection tanks and pipelines, and the works performed by the operator on the wells. In case of problem detected, the responsible personnel reports to the operator immediately. Records of works performed on the wells are properly documented and filed.

During  the  Reporting  Period,  the  Group  adopted  various  preventive  measures  to  reduce  the  risk  of infection  and  the  spread  of  COVID-19.  These  precautions  include  provision  of  surgical  masks  and alcohol-based  hand  sanitizers  to  the  employees,  reminding  employees  to  follow  good  hygiene, ensuring the workplace is clean and hygienic, measuring body temperature of employees and visitors at  the  reception.  Also,  the  Group  only  allows  employees  and  visitors  who  do  not  have  symptoms  of infection  of  COVID-19  to  access  to  the  offices  and  requires  them  to  wear  masks  and  maintain  social distance.

There  was  no  work-related  fatality  occurred  in  each  of  the  past  three  years  including  the  Reporting Period. There was also no lost day due to work injury during the Reporting Period.


## B3. Development and Training

An excellent corporate team is critical to the Group's sustainable and long-term business development. Therefore,  the  Group  encourages  its  employees  to  continue  studying  and  lifelong  learning.  Ongoing training  can  enhance  the  employees'  professional  knowledge  and  work  skills,  and  also  provide  a reasonable  assurance  that  the  employees  have  the  necessary  technical  knowledge,  professional skills  and  business  ethics  to  discharge  their  duties  efficiently  and  with  integrity.  The  Group  organises internal  and  external  trainings  in  explaining  the  operational  procedures  by  business,  risk  assessment and management policies and contingency plan, and subsidises employees to attend training courses whenever necessary.  New  hires  are  required  to  participate  in  induction  orientation  which  introduces the  Group's  corporate  culture,  industry  knowledge,  organisational  structure,  operational  safety,  etc. The latest industry information and related legislation updates in connection with the operations of the Group are also despatched to staff from time to time.

---

# Page 72

# Environmental, Social and Governance Report


## B. SOCIAL (continued)


## B3. Development and Training (continued)


During  the  Reporting  Period,  43.48% 12   of  the  Group's  employees  were  trained  and  with  an  average of  0.87  hours  per  employee 13 was  recorded.  The  percentage  of  trained  employees,  the  percentage of  breakdown  of  trained  employees  and  the  average  training  hours  per  employee,  by  gender  and employee category are as follows:
|                        | Average training hours per  employee 14  (hours)   | Average training hours per  employee 14  (hours)   | Percentage of trained  employees 15  (%)   | Percentage of trained  employees 15  (%)   |
|------------------------|----------------------------------------------------|----------------------------------------------------|--------------------------------------------|--------------------------------------------|
|                        | 2022                                               | 2021                                               | 2022                                       | 2021                                       |
| Gender                 |                                                    |                                                    |                                            |                                            |
| Male                   | 0.88                                               | 0.33                                               | 43.75                                      | 33.33                                      |
| Female                 | 0.86                                               | -                                                  | 42.86                                      | -                                          |
| Employee category      |                                                    |                                                    |                                            |                                            |
| Directors              | 2.00                                               | 1.00                                               | 100.00                                     | 100.00                                     |
| Senior management      | 2.00                                               | 0.20                                               | 100.00                                     | 20.00                                      |
| Lower-level management | 2.00                                               | 0.33                                               | 100.00                                     | 33.33                                      |
| Ordinary staff         | 0.14                                               | -                                                  | 7.14                                       | -                                          |



## Notes:


- 12. The  overall  percentage  of  trained  employees  is  calculated  by  dividing  the  total  number  of  directors and  employees  who  received  training  during  the  reporting  period  by  the  total  number  of  directors  and employees at the end of the reporting period.
- 13. The overall average training hours per employee is calculated by dividing the total number of training hours during  the  reporting  period  by  the  total  number  of  directors  and  employees  at  the  end  of  the  reporting period.
- 14. The average training hours per employee by category is calculated by dividing the total number of training hours in the specified category during the reporting period by the total number of directors and employees in the specified category at the end of the reporting period.
- 15. The percentage of trained employees by category is calculated by dividing the total number of directors and employees in the specified category who received training during the reporting period by the total number of directors and employees in the specified category at the end of the reporting period.


During the Reporting Period, the Directors participated in various continuing professional development training activities to further develop and refresh their knowledge and skills. Their respective number of training hours were not included in the above table.

---

# Page 73

# Environmental, Social and Governance Report


## B. SOCIAL (continued)


## B4. Labour Standards

Labour Rights Protection

The Group cherishes human rights and strictly prohibits any unethical hiring practices, including child and forced labour, during its recruitment process. The Group strictly complies with all local laws and will not employ children under the legal working age as defined by the relevant laws and regulations.

During the Reporting Period, the Group was not aware of any material non-compliance with child and forced labour-related laws and regulations that would have a significant impact on the Group, including but not limited to the Employment Ordinance of Hong Kong and the Canada Labour Code of Canada.


## Preventive Measures for Child and Forced Labour

The  Group  reviews  the  identification  documents  during  its  hiring  process  to  prevent  child  labour. The Group has also implemented various measures to strictly prevent any forms of forced labour. For example, detention of employee's identity card or other identification documents is strictly prohibited, labour contract is signed by the employee on a fair and voluntary basis, any form of mental harassment or physical abuse, assault, body search or insult, or forcing an employee to work by means of violence, threat  or  unlawful  restriction  of  personal  freedom  are  all  forbidden.  Employees'  consent  for  working overtime  is  required  to  avoid  involuntary  overtime  work.  Also,  the  employees  are  compensated  as appropriate in accordance with the applicable labour laws and regulations.

In  cases  where  any  individual  below  the  legal  working  age  is  hired,  corrective  actions  will  be  taken immediately  to  rectify  the  situation,  by  terminating  the  employee  and  reporting  to  the  relevant governmental authorities.


## B5. Supply Chain Management

Strengthening relationships with suppliers depend on the determination for conducting all aspects of businesses in a way that is mutually beneficial as well as open. The Group aims to develop relationships with  its  suppliers  based  on  honesty,  fairness  and  mutual  trust.  Suppliers  are  selected  according  to the  quality  of  their  product  and  service,  their  reliability  and  their  competitiveness  of  price.  Each  of the  qualified  suppliers  is  given  a  fair  chance  to  supply  quality  products  and  provide  services  to  the Group,  and  where  feasible,  priority  will  be  provided  to  suppliers  or  service  providers  that  provides environmentally preferable products and services.

To  enhance  suppliers'  quality,  the  Group  conducts  its  supplier  assessment  process  in  a  structured and  systematic  manner.  The  evaluation  criteria  of  a  supplier  include  its  service  or  product  quality, performance on environmental issues, labour practice, commitment to social responsibilities and moral standards.  Furthermore,  the  Group  oversees  business  relationships  with  the  suppliers  in  due  care  in pursuit of mitigating any issues that contradict the Group's performance standards on environmental and social  issues,  including  legal  compliance,  workplace  safety,  mitigation  of  environmental  impacts, protocols against sexual and gender discrimination, and protocols against harassment and abuse.

Periodic supplier and service provider performance evaluation is conducted to better control and assure good quality.

---

# Page 74

# Environmental, Social and Governance Report


## B. SOCIAL (continued)


## B5. Supply Chain Management (continued)

Suppliers Management

The Group endeavours to sources locally, to minimise its logistical  carbon  footprint,  reduce  shipping costs  and  benefit  local  economy.  During  the  Reporting  Period,  the  Group  had  engaged  a  total  of  96 suppliers and service providers to support its daily operations, new wells drilling and other production enhancement activities in the oilfield in Canada, of which, all of the suppliers and service providers have gone through the Group's supplier management procedures.

The  Group  also  serves  to  maintain  long-term,  stable  and  strategic  cooperative  relationships with  suppliers  with  good  credit  history,  high  product  or  service  quality,  proven  track  records  of environmental compliance and sound commitment to social responsibility based on equality to achieve a  win-win  situation.  Such  bases  are  used  to  establish  an  efficient  and  green  supply  chain  system  in selecting suppliers and service providers, and to conduct regular performance reviews with an aim to effectively identify, monitor and control the potential environmental and social risks along the Group's supply chain.


## B6. Product Responsibility

The  Group  attaches  great  importance  to  the  provision  of  the  best  products  and  services  to  its customers. Therefore, the Group has established relevant policies and procedures to monitor the status and progress of all  its  business  activities  carrying  out  at  different  levels,  so  as  to  ensure  high  quality products and services are delivered to its customers.

During  the  Reporting  Period,  the  Group  was  not  aware  of  any  material  non-compliance  with  any laws  and  regulations  in  relation  to  privacy  issues  and  compensation  regarding  health  and  safety, advertisement,  labelling,  and  products  and  services  provided,  that  would  have  a  significant  impact on  the  Group,  including  but  not  limited  to  the  Copyright  Ordinance  of  Hong  Kong  and  the  Personal Information Protection Act (PIPA) of Canada.


## Product and Customer Service Quality

Crude oil extracted from underground is treated through oil/water separation process, to a specification accepted by the customers before delivery and selling to the customers. Checking of specification of crude oil are performed by the trucking company at the Group's facility before delivery, as well as by the customers at the collection facility of the customers and thus no after-sale quality problem exists. During the Reporting Period, there was no product sold or shipped subjected to recalls for safety and health reasons.

---

# Page 75

# Environmental, Social and Governance Report


## B. SOCIAL (continued)


## B6. Product Responsibility (continued)

Client's Privacy Measures and Protection

For  the  money  lending  business,  the  Group  handles  confidential  information  of  clients  with  integrity and  in  accordance  with  applicable  laws  and  regulations.  Employees  respect  the  confidentiality  of information acquired as a result of business relationship and would not disclose any such information to third parties without proper and specific authority unless there is a legal or professional right or duty to do so. Confidential information that may be subject to disclosure requirements according to applicable laws  and  regulations  shall  be  exchanged  internally  and  exclusively  on  a  'need-to-know'  basis.  Such information will strictly not be used for personal advantage by any employee of the Group.


## Intellectual Property (' IP ') Rights

Owing to  the  Group's  business  nature,  it  does  not  involve  in  significant  amount  of  uses  of  IP  rights. Nonetheless,  the  Group  respects  IP  rights.  Employees  are  not  allowed  to  possess  or  use  copyrighted material  without  the  permission  of  the  copyright  owners.  Furthermore,  the  Group's  IT  Department is  responsible  for  obtaining  proper  licenses  for  the  software,  hardware  and  information  used  in  the Group's  daily  business  operations.  The  Group  has  monitoring  procedures  in  place  to  ensure  that  IP rights are not being infringed upon.


## Customer Satisfaction

The Group recognises customer satisfaction as the cornerstone of its continuous business success, and strives  to  maintain  good  relationships  with  all  its  customers.  By  gathering  and  analysing  customers' feedback,  inquires  and  complaints,  the  Group  identifies  room  for  improvement  in  its  products  or services quality in the future. The Group has also formulated relevant policies and procedures to handle customers' feedback and complaints in a timely and professional manner. During the Reporting Period, the Group was not aware of any material written complaints related to products and services provided.


## B7. Anti-corruption

The Group always attaches importance to creating a harmonious and honest work environment and it commits to achieving and maintaining high integrity and accountability standards with great emphasis on corporate governance, moral culture and staff quality. All employees should act in upright, impartial and honest manner and strictly follow the applicable laws and regulations. If employees violate them, they will face disciplinary action or even termination of their employment. Employees must observe the required ethical standards and make their own judgements as to the appropriateness of their conduct in  business  operations.  During  the  Reporting  Period,  6  directors  and  4  employees  received  a  total  of approximately 12 hours and 8 hours of anti-corruption training relating to the latest updates on anticorruption, respectively.

During  the  Reporting  Period,  the  Group  was  not  aware  of  any  material  non-compliance  with  any laws and regulations in relation to bribery, extortion, fraud and money laundering that would have a significant  impact  on  the  Group,  including  but  not  limited  to  the  Prevention  of  Bribery  Ordinance  of Hong Kong and the Corruption of Foreign Public Officials Act (CFPOA) of Canada.

---

# Page 76

# Environmental, Social and Governance Report


## B. SOCIAL (continued)


## B7. Anti-corruption (continued)

Anti-corruption Measures

The Group adopted an anti-fraud and counter corruption policy with a vision to achieve high standards of  business  ethics  and  corporate  governance  across  all  business  levels  and  operating  activities. When  employees  suspect  of  violations  occurred,  they  may,  in  the  case  of  absolute  confidentiality, report  through  different  channels  to  those  charged  with  governance.  The  Group  has  also  adopted  a whistleblowing policy to encourage employees to raise serious concerns internally that are suspected to  be  malpractices  or  impropriety,  in  a  responsible  and  effective  manner  rather  than  overlooking  a problem or blowing the whistle outside. Employees who hide traces, evidence or avoid investigation of suspicious transactions may be considered as illegal. The Group has also provided various reporting channels  for  its  suppliers,  customers  and  other  business  partners  to  report  any  violations  of  laws  or regulations when people are performing their duties for the Group.

In  addition,  in  order  to  minimise  the  fraud  risk,  the  Group  has  a  pre-employment  screening  process under which all applicants would be asked whether he/she has ever committed any criminal offences in  the  past.  The  Group  continues  to  optimise  the  reporting  mechanism  and  resolutely  fight  against corruption for building a clean social environment.

During  the  Reporting  Period,  there  were  no  concluded  legal  cases  regarding  corruption  practices brought against the Group or its employees.


## B8. Community Investment

Community Contribution

The Group views sustainable development and community contribution as corporate goals. The Group believes in people-oriented management principle, carry out a variety of activities in fulfilling its social responsibilities,  actively  pursue  social  contribution  initiatives  and  strive  to  create  a  sustainable  and harmonious  society.  The  Group's  performance  over  the  long  term  depends  on  its  sensitivity  to  local customs  and  conventions  governing  business  relationships  and  its  commitment  to  make  a  positive contribution to the sustainable development of the communities in which it works. The Group considers ways of supporting communities in which it operates through charitable and educational activities and contributions.

The  Group  has  devoted  to  pay  attention  to  protecting  the  nature  and  care  about  the  environment. Everyone should take part in it and hope to create a liveable environment together. The Group strives to minimise any harmful effects of its operations on the natural environment and finite resources and constantly  enhance  employees'  awareness  in  environmental  protection  and  resource  conservation. The Group hopes that every employee can convey the message of protecting the environment to their families,  friends  and  business  partners,  to  build  more  powerful  cohesion  and  in  alleviating  climate change together. In doing so, environmental quality standards which are desirable and attainable are set out to ensure the Group fully complies with all relevant environmental legislation.

The Group is also a  responsible  taxpayer  and  employer  that  offer  job  opportunities  to  ease  the  local employment  pressure.  The  Group  establishes  good  practices  in  running  its  business  and  actively promote  energy  saving  and  environmentally  friendly  concepts  with  a  hope  to  be  the  role  model within the industry. The Group has certainly contributed to social stability and building a harmonious community.

---

# Page 77

# Environmental, Social and Governance Report


## SUMMARY OF ENVIRONMENTAL DATA AND PERFORMANCE


|                                | Unit               | 2022     | 2021   |
|--------------------------------|--------------------|----------|--------|
| GHG emissions:                 |                    |          |        |
| Scope 1 - Direct GHG emissions | tCO2e              | 378.81   | 9.19   |
| Intensity                      | tCO2e/employee     | 16.47    | 0.44   |
|                                | tCO2e/thousand bbl | 4.66     | N/A    |
| Scope 2 - Energy indirect GHG  |                    |          |        |
| emissions                      | tCO2e              | 1,335.95 | 8.45   |
| Intensity                      | tCO2e/employee     | 58.08    | 0.40   |
|                                | tCO2e/thousand bbl | 16.43    | N/A    |
| Total GHG emissions            | tCO2e              | 1,714.76 | 17.64  |
| Intensity                      | tCO2e/employee     | 74.55    | 0.84   |
|                                | tCO2e/thousand bbl | 21.09    | N/A    |
| Air emissions:                 |                    |          |        |
| Nitrogen oxide                 | kilogram           | -        | 11.74  |
| Sulphur oxide                  | kilogram           | -        | 0.03   |
| Particulate matters            | kilogram           | -        | 1.08   |
| Hazardous wastes:              |                    |          |        |
| Total hazardous wastes         | tonne              | 65.63    | -      |
| Intensity                      | tonne/employee     | 2.85     | -      |
|                                | tonne/thousand bbl | 0.81     | N/A    |
| Non-hazardous wastes:          |                    |          |        |
| Total non-hazardous wastes     | tonne              | 601.86   | 0.47   |
| Intensity                      | tonne/employee     | 26.17    | 0.02   |
|                                | tonne/thousand bbl | 7.40     | N/A    |

---

# Page 78

# Environmental, Social and Governance Report


## SUMMARY OF ENVIRONMENTAL DATA AND PERFORMANCE (continued)


|                             | Unit             | 2022     | 2021   |
|-----------------------------|------------------|----------|--------|
| Energy consumption:         |                  |          |        |
| Gasoline                    | MWh              | -        | 5.34   |
| Diesel                      | MWh              | 1,046.91 | 12.06  |
| Natural gas                 | MWh              | -        | 22.28  |
| Propane                     | MWh              | 564.81   | N/A    |
| Direct energy consumption   | MWh              | 1,611.72 | 39.68  |
| Electricity                 | MWh              | 2,518.13 | 13.88  |
| Indirect energy consumption | MWh              | 2,518.13 | 13.88  |
| Total energy consumption    | MWh              | 4,129.85 | 53.56  |
| Intensity                   | MWh/employee     | 179.56   | 2.55   |
|                             | MWh/thousand bbl | 50.80    | N/A    |
| Water consumption:          |                  |          |        |
| Total water consumption     | tonne            | -        | 35.00  |
| Intensity                   | tonne/employee   | -        | 1.67   |

---

# Page 79

# Independent Auditor's Report

Moore Stephens CPA Limited

801-806 Silvercord, Tower 1,

WWWmoore.hk


## Independent Auditor's Report to the Members of EPI (Holdings) Limited

長盈集團(控股)有限公司

(Incorporated in Bermuda with limited liability)


## OPINION

We  have  audited  the  consolidated  financial  statements  of  EPI  (Holdings)  Limited  (the  ' Company ')  and its  subsidiaries  (collectively  referred  to  as  the  ' Group ')  set  out  on  pages  84  to  169,  which  comprise  the consolidated statement of financial position as at 31 December 2022, and the consolidated statement of profit or  loss  and  other  comprehensive  income,  consolidated  statement  of  changes  in  equity  and  consolidated statement of cash flows for the year then ended, and notes to the consolidated financial statements, including a summary of significant accounting policies.

In  our  opinion,  the  consolidated  financial  statements  give  a  true  and  fair  view  of  the  consolidated  financial position  of  the  Group  as  at  31  December  2022,  and  of  its  consolidated  financial  performance  and  its consolidated cash flows for the year then ended in accordance with Hong Kong Financial Reporting Standards (' HKFRSs ')  issued  by  the  Hong  Kong  Institute  of  Certified  Public  Accountants  (' HKICPA ')  and  have  been properly prepared in compliance with the disclosure requirements of the Hong Kong Companies Ordinance.


## BASIS FOR OPINION

We  conducted  our  audit  in  accordance  with  Hong  Kong  Standards  on  Auditing  (' HKSAs ')  issued  by  the HKICPA. Our responsibilities under those standards are further described in the Auditor's Responsibilities for the Audit of the Consolidated Financial Statements section of our report. We are independent of the Group in accordance with the HKICPA's Code of Ethics for Professional Accountants (the ' Code '), and we have fulfilled our  other  ethical  responsibilities  in  accordance  with  the  Code.  We  believe  that  the  audit  evidence  we  have obtained is sufficient and appropriate to provide a basis for our opinion.

---

# Page 80

# Independent Auditor's Report


## KEY AUDIT MATTERS

Key audit matters are those matters that, in our professional judgment, were of most significance in our audit of the consolidated financial statements of the current period. These matters were addressed in the context of our audit of the consolidated financial statements as a whole, and in forming our opinion thereon, and we do not provide a separate opinion on these matters.


## Key audit matter


## How our audit addressed the key audit matter


## Impairment assessment of loan and interest receivables

We  identified  the  impairment  assessment  of  loan  and interest  receivables  as  a  key  audit  matter  due  to  the significance  of  balances  to  the  Group's  consolidated financial  position  and  the  involvement  of  significant management  judgment  in  evaluating  the  expected credit  losses  (' ECL ')  of  loan  and  interest  receivables  at the end of the reporting period.

As  detailed  in  Note  4  to  the  consolidated  financial statements,  in  making  the  assessment,  the  loan  and i nterest  receivables  from  borrowers  are  assessed individually by the management of the Group, based on the financial background, financial condition, collaterals and historical settlement records, including the past due dates  and  probability  of  default,  of  each  borrower  and reasonable and supportable forward-looking information that  is  available  without  undue  cost  or  effort.  Each borrower is assigned a risk grading under internal credit ratings  to  calculate  the  ECL,  taking  into  consideration of  the  estimates  of  expected  cash  shortfalls.  At  every reporting  date,  the  financial  background,  financial condition,  collaterals  and  historical  settlement  records are  reassessed  and  changes  in  the  forward-looking information are considered.


Our  procedures  in  relation  to  management's i mpairment  assessment  of  loan  receivables included:
- · Understanding  and  evaluating  the  entity's key  controls  on  the  related  credit  control and  loan  monitoring  process  and  how  the management  estimates  the  credit  loss allowance for loan receivables and performs loan monitoring process;


·


- Evaluating  the  reasonableness  and appropriateness  of  the  management's assessment  of  the  internal  credit  rating  of the  loan  receivables  by  reference  to  past due status, past collection history, financial background  and  financial  condition  of  the borrowers; and

---

# Page 81

# Key audit matter


## How our audit addressed the key audit matter


## Impairment assessment of loan and interest receivables (continued)

The  management  further  assesses  the  amount  of exposure  of  default  to  assess  the  potential  loss  as  a result  of  the  risk  on  credit-impaired  loan  and  interest receivables  to  which  the  Group  is  exposed  and  take appropriate  corrective  actions.  In  assessing  the  amount of exposure of default, the Group takes into account the timing of cash flows that are expected from foreclosure on the collaterals less the costs of selling the collaterals. ·

The  gross  carrying  amount  of  the  loan  and  interest receivables  is  HK$84,652,000  in  aggregate  and  the impairment  allowance  on  loan  and  interest  receivables is  HK$23,800,000  in  aggregate  as  at  31  December  2022 as  set  out  in  Note  22  to  the  consolidated  financial statements.

Evaluating  the  reasonableness  and appropriateness  on  the  management's basis  and  judgment  in  determining  credit loss  allowance  on  loan  receivables  at  31 December 2022, including the identification of  credit-impaired  loan  receivables,  the estimated  loss  rates  applied  to  each borrower, and the estimated cash flow from the realisation of collaterals pledged to the Group,  with  the  assistance  of  our  internal valuation specialists.


## Independent Auditor's Report

---

# Page 82

# Independent Auditor's Report


## Key audit matter


## How our audit addressed the key audit matter


## Provision for ECL for debt instruments at fair value through other comprehensive income (' FVTOCI ')

We identified  provision  for  ECL  for  debt  instruments  at FVTOCI as a key audit matter because the determination of  loss  allowance  for  debt  instruments  at  FVTOCI  using the  ECL  model  involves  significant  estimates  and judgments, including determination of whether there is significant increase in credit risk since initial recognition, use  of  assumptions  in  determination  of  probability  of default  and  loss  given  default,  and  incorporation  of forward-looking information.

As  disclosed  in  Note  21  to  the  consolidated  financial statements,  the  fair  value  of  debt  instruments  at FVTOCI is  HK$33,739,000  at  31  December  2022  and  the impairment  allowance  of  HK$11,081,000  is  recognised in  profit  or  loss  with  corresponding  adjustment  to other  comprehensive  income  for  the  current  year.  The determination  of  loss  allowances  is  dependent  on  the external  macro  environment  and  the  credit  rating  of each  debt  security.  The  management  also  takes  into consideration  of  historical  data  from  the  international rating agency. The Group had engaged an independent professional valuer to perform ECL assessment.


Our  procedures  in  relation  to  ECL  for  debt i nstruments  at  FVTOCI  on  the  consolidated financial instruments included:
- · Understanding  and  assessing  the  design and  implementation  of  key  internal controls  of  the  credit  grading  process  and measurement of loss allowances;
- · Evaluating  methodology  and  assumptions used  by  management  in  determining  ECL; and


·


- Engaging  our  internal  specialists  to  review the significant management judgments and assumptions,  including  (i)  the  criteria  for significant  increase  in  credit  risk  made  by assessing  credit  rating  migration  between origination  date  and  reporting  date;  (ii) reasonableness  of  probability  of  default, recovery rate and loss given default; and (iii) the  use  of  economic  variables  and  relative weighting for forward-looking scenarios.

---

# Page 83

# Independent Auditor's Report


## OTHER INFORMATION

The directors of the Company are responsible for the other information. The other information comprises the information included in the annual report, but does not include the consolidated financial statements and our auditor's report thereon.

Our opinion on the consolidated financial statements does not cover the other information and we do not express any form of assurance conclusion thereon.

In  connection  with  our  audit  of  the  consolidated  financial  statements,  our  responsibility  is  to  read  the other  information  and,  in  doing  so,  consider  whether  the  other  information  is  materially  inconsistent  with the  consolidated  financial  statements  or  our  knowledge  obtained  in  the  audit  or  otherwise  appears  to be  materially  misstated.  If,  based  on  the  work  we  have  performed,  we  conclude  that  there  is  a  material misstatement of this other information, we are required to report that fact. We have nothing to report in this regard.


## RESPONSIBILITIES OF DIRECTORS AND THOSE CHARGED WITH GOVERNANCE FOR THE CONSOLIDATED FINANCIAL STATEMENTS

The directors of the Company are responsible for the preparation of the consolidated financial statements that give a true and fair view in accordance with HKFRSs issued by the HKICPA and the disclosure requirements of the Hong Kong Companies Ordinance, and for such internal control as the directors determine is necessary to enable the preparation of consolidated financial statements that are free from material misstatement, whether due to fraud or error.

In  preparing  the  consolidated  financial  statements,  the  directors  are  responsible  for  assessing  the  Group's ability to continue as a going concern, disclosing, as applicable, matters related to going concern and using the going concern basis of accounting unless the directors either intend to liquidate the Group or to cease operations, or have no realistic alternative but to do so.

Those charged with governance are responsible for overseeing the Group's financial reporting process.

---

# Page 84

# Independent Auditor's Report


## AUDITOR'S RESPONSIBILITIES FOR THE AUDIT OF THE CONSOLIDATED FINANCIAL STATEMENTS

Our  objectives  are  to  obtain  reasonable  assurance  about  whether  the  consolidated  financial  statements  as a whole are free from material misstatement, whether due to fraud or error, and to issue an auditor's report that includes our opinion solely to you, as a body, in accordance with Section 90 of the Bermuda Companies Act, and for no other purpose. We do not assume responsibility towards or accept liability to any other person for the contents of this report. Reasonable assurance is a high level of assurance, but is not a guarantee that an  audit  conducted  in  accordance  with  HKSAs  will  always  detect  a  material  misstatement  when  it  exists. Misstatements can arise from fraud or error and are considered material if, individually or in the aggregate, they could reasonably be expected to influence the economic decisions of users taken on the basis of these consolidated financial statements.


As part of an audit in accordance with HKSAs, we exercise professional judgment and maintain professional skepticism throughout the audit. We also:
- · Identify and assess the risks of material misstatement of the consolidated financial statements, whether due to fraud or error, design and perform audit procedures responsive to those risks, and obtain audit evidence that is sufficient and appropriate to provide a basis for our opinion. The risk of not detecting a material misstatement resulting from fraud is higher than for one resulting from error, as fraud may involve collusion, forgery, intentional omissions, misrepresentations, or the override of internal control.
- · Obtain an understanding of internal control relevant to the audit in order to design audit procedures that  are  appropriate  in  the  circumstances,  but  not  for  the  purpose  of  expressing  an  opinion  on  the effectiveness of the Group's internal control.
- · Evaluate  the  appropriateness  of  accounting  policies  used  and  the  reasonableness  of  accounting estimates and related disclosures made by the directors.
- · Conclude on the appropriateness of the directors' use of the going concern basis of accounting and, based  on  the  audit  evidence  obtained,  whether  a  material  uncertainty  exists  related  to  events  or conditions that may cast significant doubt on the Group's ability to continue as a going concern. If we conclude that a material uncertainty exists, we are required to draw attention in our auditor's report to the related disclosures in the consolidated financial statements or, if such disclosures are inadequate, to modify our opinion. Our conclusions are based on the audit evidence obtained up to the date of our auditor's report. However, future events or conditions may cause the Group to cease to continue as a going concern.

---

# Page 85

# Independent Auditor's Report


## AUDITOR'S RESPONSIBILITIES FOR THE AUDIT OF THE CONSOLIDATED FINANCIAL STATEMENTS (continued)


- · Evaluate  the  overall  presentation,  structure  and  content  of  the  consolidated  financial  statements, including the disclosures, and whether the consolidated financial statements represent the underlying transactions and events in a manner that achieves fair presentation.
- · Obtain  sufficient  appropriate  audit  evidence  regarding  the  financial  information  of  the  entities  or business  activities  within  the  Group  to  express  an  opinion  on  the  consolidated  financial  statements. We are responsible for the direction, supervision and performance of the group audit. We remain solely responsible for our audit opinion.


We communicate with those charged with governance regarding, among other matters, the planned scope and timing of the audit and significant audit findings, including any significant deficiencies in internal control that we identify during our audit.

We  also  provide  those  charged  with  governance  with  a  statement  that  we  have  complied  with  relevant ethical  requirements  regarding  independence,  and  to  communicate  with  them  all  relationships  and  other matters that may reasonably be thought to bear on our independence, and where applicable, actions taken to eliminate threats or safeguards applied.

From  the  matters  communicated  with  those  charged  with  governance,  we  determine  those  matters  that were of most significance in the audit of the consolidated financial statements of the current period and are therefore  the  key  audit  matters.  We  describe  these  matters  in  our  auditor's  report  unless  law  or  regulation precludes  public  disclosure  about  the  matter  or  when,  in  extremely  rare  circumstances,  we  determine  that a  matter  should  not  be  communicated  in  our  report  because  the  adverse  consequences  of  doing  so  would reasonably be expected to outweigh the public interest benefits of such communication.


## Moore Stephens CPA Limited

Certified Public Accountants

Registered Public Interest Entity Auditors


## Lau Ngai Kee, Ricky

Practising Certificate Number: P04005

Hong Kong 30 March 2023

---

# Page 86

# Consolidated Statement of Profit or Loss and Other Comprehensive Income

For the year ended 31 December 2022


|                                                                                                                                    | Notes   | 2022 HK$'000   | 2021 HK$'000   |
|------------------------------------------------------------------------------------------------------------------------------------|---------|----------------|----------------|
| Revenue                                                                                                                            | 5       | 45,102         | 24,496         |
| Sales of petroleum, net of royalties                                                                                               |         | 30,932         | 1,523          |
| Sales of electricity                                                                                                               |         | 6,536          | 652            |
| Interest income                                                                                                                    |         | 7,482          | 22,053         |
| Dividend income                                                                                                                    |         | 152            | 268            |
| Purchases, processing and related expenses                                                                                         | 7       | (13,952)       | (1,067)        |
| Other income and losses, net                                                                                                       | 8       | (8,210)        | 1,122          |
| Net (loss) gain on financial assets at fair value through   profit or loss                                                         | 9       | (1,952)        | 7,870          |
| (Provision) reversal of expected credit loss on loan   and interest receivables                                                    |         | (20,019)       | 4,356          |
| Provision of expected credit loss on debt instruments at fair   value through other comprehensive income                           |         | (11,081)       | (49,247)       |
| Wages, salaries and other benefits                                                                                                 | 13      | (7,300)        | (9,799)        |
| Depreciation                                                                                                                       | 13      | (13,130)       | (1,666)        |
| Loss on redemption of debt instruments at fair value   through other comprehensive income                                          |         | (453)          | -              |
| Other expenses                                                                                                                     |         | (14,875)       | (7,193)        |
| Gain (loss) on disposal of subsidiaries                                                                                            | 10      | 159            | (397)          |
| Finance costs                                                                                                                      | 11      | (1,246)        | (101)          |
| Loss before tax                                                                                                                    |         | (46,957)       | (31,626) 2,255 |
| Income tax credit                                                                                                                  | 12      | 211            |                |
| Other comprehensive (expense) income                                                                                               |         |                |                |
| Items that may be reclassified subsequently to profit or loss:                                                                     |         |                |                |
| Net fair value loss on debt instruments at fair value through   other comprehensive income                                         |         | (11,238)       | (54,714)       |
| Provision of expected credit loss on debt instruments at fair value  through other comprehensive income included in profit or loss |         | 11,081         | 49,247         |
| Release on redemption of debt instruments at fair value   through other comprehensive income                                       |         | 453            | -              |
| Reclassification of cumulative translation reserve upon   disposal of foreign operations                                           | 10      | 1,312          | 340            |
| Exchange differences arising on translation of financial   statements of foreign operations                                        |         | (4,539)        | 990            |
| Other comprehensive expense for the year,   net of income tax                                                                      |         | (2,931)        | (4,137)        |
| Total comprehensive expense for the year attributable  to owners of the Company                                                    |         | (49,677)       | (33,508)       |
| Loss per share attributable to owners of the Company - Basic                                                                       | 17      | HK(0.89) cent  | HK(0.56) cent  |

---

# Page 87

# Consolidated Statement of Financial Position

At 31 December 2022


|                                                                    | Notes   | 2022 HK$'000   | 2021 HK$'000   |
|--------------------------------------------------------------------|---------|----------------|----------------|
| Non-current assets                                                 |         |                |                |
| Property, plant and equipment                                      | 18      | 218,781        | 34,383         |
| Right-of-use assets                                                | 19      | 2,590          | 4,200          |
| Deposit paid for decommissioning obligation                        | 20      | 8,256          | -              |
| Prepayment for acquisition of non-current assets                   | 20      | 6,978          | 9,874          |
| Debt instruments at fair value through other comprehensive  income | 21      | 5,698          | 30,684         |
| Total non-current assets                                           |         | 242,303        | 79,141         |
| Current assets                                                     |         |                |                |
| Debt instruments at fair value through other comprehensive  income | 21      | 28,041         | 47,712         |
| Inventories                                                        |         | 312            | -              |
| Loan and interest receivables                                      | 22      | 60,852         | 115,001        |
| Trade and other receivables and prepayments                        | 20      | 10,398         | 1,610          |
| Other tax recoverable                                              | 23      | 204            | 732            |
| Income tax recoverable                                             |         | 1,011          | 171            |
| Financial assets at fair value through profit or loss              | 24      | 4,772          | 6,724          |
| Cash and cash equivalents                                          | 25      | 85,796         | 191,824        |
| Total current assets                                               |         | 191,386        | 363,774        |
| Current liabilities                                                |         |                |                |
| Trade and other payables                                           | 26      | 20,805         | 11,852         |
| Income tax payable                                                 |         | 618            | 679            |
| Lease liabilities                                                  | 27      | 374            | 1,574          |
| Total current liabilities                                          |         | 21,797         | 14,105         |
| Net current assets                                                 |         | 169,589        | 349,669        |
| Total assets less current liabilities                              |         | 411,892        | 428,810        |

---

# Page 88

# Consolidated Statement of Financial Position

At 31 December 2022


|                               | Notes   | 2022 HK$'000   | 2021 HK$'000   |
|-------------------------------|---------|----------------|----------------|
| Non-current liabilities       |         |                |                |
| Lease liabilities             | 27      | 2,351          | 2,820          |
| Decommissioning obligation    | 29      | 33,228         | -              |
| Total non-current liabilities |         | 35,579         | 2,820          |
| Net assets                    |         | 376,313        | 425,990        |
| Capital and reserves          |         |                |                |
| Share capital                 | 30      | 52,403         | 52,403         |
| Reserves                      |         | 323,910        | 373,587        |
| Total equity                  |         | 376,313        | 425,990        |



The consolidated financial statements on pages 84 to 169 together with the Company's statement of financial position set out in Note 40 to the consolidated financial statements have been approved and authorised for issue by the Board on 30 March 2023 and are signed on its behalf by:
| Sue Ka Lok   | Chan Shui Yuen   |
|--------------|------------------|
| Director     | Director         |

---

# Page 89

# Consolidated Statement of Changes in Equity

For the year ended 31 December 2022


## Attributable to owners of the Company


|                                                                                                            | Non-                  | Non-                  | Non-                           | Non-                                    | Non-                        | Non-                       | Non-              | Non-                         | Non-          |
|------------------------------------------------------------------------------------------------------------|-----------------------|-----------------------|--------------------------------|-----------------------------------------|-----------------------------|----------------------------|-------------------|------------------------------|---------------|
|                                                                                                            | Share capital HK$'000 | Share premium HK$'000 | Share  options reserve HK$'000 | Investment  revaluation reserve HK$'000 | Translation reserve HK$'000 | Accumulated losses HK$'000 | Sub-total HK$'000 | controlling Interest HK$'000 | Total HK$'000 |
|                                                                                                            | (Note (c))            | (Note (c))            | (Note (c))                     | (Note (c))                              | (Note (c))                  | (Note (c))                 | (Note (c))        | (Note (c))                   | (Note (c))    |
| At 1 January 2021                                                                                          | 52,403                | 918,270               | 201,645                        | 1,233                                   | (2,759)                     | (710,913)                  | 459,879           | (381)                        | 459,498       |
| Loss for the year                                                                                          | -                     | -                     | -                              | -                                       | -                           | (29,371)                   | (29,371)          | -                            | (29,371)      |
| Net fair value loss on debt  instruments at fair value through  other comprehensive income                 | -                     | -                     | -                              | (54,714)                                | -                           | -                          | (54,714)          | -                            | (54,714)      |
| Provision of expected credit loss on  on debt instruments at fair value  through other comprehensive       | -                     | -                     | -                              | 49,247                                  | -                           | -                          | 49,247            | -                            | 49,247        |
| income Reclassification of cumulative  translation reserve upon disposal  of foreign operations            | -                     | -                     | -                              | -                                       | 340                         | -                          | 340               | -                            | 340           |
| Exchange differences arising on  translation of financial statements  of foreign operations                | -                     | -                     | -                              | -                                       | 990                         | -                          | 990               | -                            | 990           |
| Total comprehensive (expense)  income for the year                                                         | -                     | -                     | -                              | (5,467)                                 | 1,330                       | (29,371)                   | (33,508)          | -                            | (33,508)      |
| Deregistration of a subsidiary                                                                             | -                     | -                     | -                              | -                                       | -                           | (381)                      | (381)             | 381                          | -             |
| At 31 December 2021                                                                                        | 52,403                | 918,270               | 201,645                        | (4,234)                                 | (1,429)                     | (740,665)                  | 425,990           | -                            | 425,990       |
| Loss for the year                                                                                          | -                     | -                     | -                              | -                                       | -                           | (46,746)                   | (46,746)          | -                            | (46,746)      |
| Net fair value loss on debt  instruments at fair value through  other comprehensive income                 | -                     | -                     | -                              | (11,238)                                | -                           | -                          | (11,238)          | -                            | (11,238)      |
| Provision of expected credit loss   on debt instruments at fair value  through other comprehensive  income | -                     | -                     | -                              | 11,081                                  | -                           | -                          | 11,081            | -                            | 11,081        |
| Release on redemption of debt  instruments at fair value through  other comprehensive income               | -                     | -                     | -                              | 453                                     | -                           | -                          | 453               | -                            | 453           |
| Reclassification of cumulative  translation reserve upon   disposal of foreign operations                  | -                     | -                     | -                              | -                                       | 1,312                       | -                          | 1,312             | -                            | 1,312         |
| Exchange differences arising on  translation of financial statements  of foreign operations                | -                     | -                     | -                              | -                                       | (4,539)                     | -                          | (4,539)           | -                            | (4,539)       |
| Total comprehensive income  (expense) for the year                                                         | -                     | -                     | -                              |                                         | (3,227)                     | (46,746)                   |                   |                              | (49,677)      |
| At 31 December 2022                                                                                        | 52,403                | 918,270               | 201,645                        | 296 (3,938)                             | (4,656)                     | (787,411)                  | (49,677) 376,313  | - -                          | 376,313       |

---

# Page 90

# Consolidated Statement of Changes in Equity

For the year ended 31 December 2022


## Notes:


- (a) The share options reserve represents the cumulative expense on the share options granted recognised over the vesting period. All the share options forfeited after the vesting date or are still not exercise at the expiry date will continue to be held in this reserve. All the outstanding share options were lapsed and there were no outstanding share options as at 31 December 2022 and 31 December 2021.
- (b) The  investment  revaluation  reserve  represents  cumulative  gains  and  losses  arising  from  revaluation  of  debt instruments at fair value through other comprehensive income that have been recognised in other comprehensive income,  net  of  amounts  reclassified  to  profit  or  loss  when  those  debt  instruments  at  fair  value  through  other comprehensive income are disposed of or are determined to be impaired.
- (c) The translation reserve represents exchange differences arising from the translation of financial statements of the Group's foreign operations into the presentation currency of the Group.

---

# Page 91

# Consolidated Statement of Cash Flows

For the year ended 31 December 2022


|                                                                                                          |       | 2022     | 2021     |
|----------------------------------------------------------------------------------------------------------|-------|----------|----------|
|                                                                                                          | Notes | HK$'000  | HK$'000  |
| Operating activities                                                                                     |       |          |          |
| Loss before tax                                                                                          |       | (46,957) | (31,626) |
| Adjustments for:                                                                                         |       |          |          |
| Depreciation of property, plant and equipment                                                            |       | 11,692   | 382      |
| Depreciation of right-of-use assets                                                                      |       | 1,438    | 1,284    |
| Loss on redemption of debt instruments at fair value   through other comprehensive income                |       | 453      | -        |
| Provision (reversal) of expected credit loss on loan and   interest receivables                          |       | 20,019   | (4,356)  |
| Provision of expected credit loss on debt instruments at fair   value through other comprehensive income |       | 11,081   | 49,247   |
| Write off of other receivables and deposit                                                               |       | -        | 1,680    |
| Write off of property, plant and equipment                                                               |       | 9        | -        |
| Bank and other interest income                                                                           | 8     | (1,343)  | (83)     |
| Modification loss on debt instruments at fair value through  other comprehensive income                  | 8     | 79       | -        |
| Net loss (gain) on financial assets at fair value through   profit or loss                               | 9     | 1,952    | (7,870)  |
| Accretion expense on decommissioning obligation                                                          | 11    | 1,127    | -        |
| Interest expense                                                                                         | 11    | 119      | 101      |
| Dividend income                                                                                          |       | (152)    | (268)    |
| Interest income from money lending business                                                              |       | (3,877)  | (13,182) |
| Interest income from debt instruments at fair value   through other comprehensive income                 |       | (3,605)  | (8,871)  |
| (Gain) loss on disposal of subsidiaries                                                                  | 10    | (159)    | 397      |
| Operating cash flows before movements in working capital                                                 |       | (8,124)  | (13,165) |
| Increase in inventory                                                                                    |       | (326)    | -        |
| (Increase) decrease in trade and other receivables   and prepayment                                      |       | (9,134)  | 12,489   |
| Decrease in loan and interest receivables                                                                |       | 22,881   | 15,955   |
| Decrease (increase) in other tax recoverable                                                             |       | 457      | (123)    |
| Decrease in financial assets at fair value through profit or loss                                        |       | -        | 26,243   |
| Increase (decrease) in trade and other payables                                                          |       | 11,859   | (2,576)  |
| Increase in deposit paid for decommissioning obligation                                                  |       | (8,628)  | -        |
| Cash generated from operations                                                                           |       | 8,985    | 38,823   |
| Dividend received                                                                                        |       | 152      | 268      |
| Income tax (paid) refunded                                                                               |       | (158)    | 915      |
| Interest received from money lending business                                                            |       | 7,245    | 17,948   |
| Interest received from debt instruments at fair value   through other comprehensive income               |       | 4,378    | 7,959    |
| Net cash from operating activities                                                                       |       | 20,602   | 65,913   |

---

# Page 92

# Consolidated Statement of Cash Flows

For the year ended 31 December 2022


|                                                                                                              | Notes   | 2022 HK$'000   | 2021 HK$'000   |
|--------------------------------------------------------------------------------------------------------------|---------|----------------|----------------|
| Investing Activities                                                                                         |         |                |                |
| Acquisition of assets and liabilities                                                                        | 32      | (135,461)      | -              |
| Purchase of property, plant and equipment                                                                    |         | (29,760)       | (26,493)       |
| Prepayment paid on acquisition of non-current assets                                                         |         | (2,454)        | (9,874)        |
| Proceeds from redemption of debt instruments at fair   value through other comprehensive income              |         | 32,370         | -              |
| Consent fee received from modification of debt instruments at  fair value through other comprehensive income |         | 197            | -              |
| Bank and other interest received                                                                             | 8       | 1,343          | 83             |
| Net cash inflow on disposal of subsidiaries                                                                  | 10      | 8,751          | 28,933         |
| Net cash used in investing activities                                                                        |         | (125,014)      | (7,351)        |
| Financing Activities                                                                                         |         |                |                |
| Repayment of lease liabilities                                                                               |         | (1,497)        | (1,340)        |
| Interest paid                                                                                                |         | (119)          | (101)          |
| Net cash used in financing activities                                                                        |         | (1,616)        | (1,441)        |
| Net (decrease) increase in cash and cash equivalents                                                         |         | (106,028)      | 57,121         |
| Cash and cash equivalents at beginning of the year                                                           |         | 191,824        | 134,627        |
| Effect of foreign exchange rate changes                                                                      |         | -              | 76             |
| Cash and cash equivalents at end of the year,   represented by cash and cash equivalents                     |         | 85,796         | 191,824        |

---

# Page 93

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 1. GENERAL INFORMATION

The Company is a public limited liability company incorporated in Bermuda and its shares are listed on the Main Board of the Hong Kong Stock Exchange. The address of the registered office of the Company is located at Clarendon House, 2 Church Street, Hamilton HM11, Bermuda. The address of the principal place of business of the Company is Rooms 1502-03, 15th Floor, Great Eagle Centre, 23 Harbour Road, Wanchai, Hong Kong.

The Company is an investment holding company. The principal activities of its subsidiaries are set out in Note 38.

The  consolidated  financial  statements  are  presented  in  Hong  Kong  dollars  (' HK$ '),  which  is  also  the functional  currency  of  the  Company  and  all  values  are  rounded  to  the  nearest  thousand  (HK$'000) except otherwise indicated.


## 2. APPLICATION OF AMENDMENTS TO HONG KONG FINANCIAL REPORTING STANDARDS ('HKFRSs')

Amendments to HKFRSs that are mandatorily effective for the current year

In  the  current  year,  the  Group  has  applied  the  amendments  to  HKFRSs  issued  by  the  Hong  Kong Institute of Certified Public Accountants (' HKICPA ')  for  the  first  time,  which  are  mandatorily effective for  the  annual  periods  beginning on 1 January 2022 for the preparation of the consolidated financial statements:

Amendments to HKFRS 3

Reference to the conceptual framework

Amendment to HKFRS 16

Covid-19-related rent concessions beyond 30 June 2021

Amendments to HKAS 16

Property, plant and equipment - proceeds before intended use

Amendments to HKAS 37

Onerous contracts - cost of fulfilling a contract

Amendments to HKFRSs

Annual improvements to HKFRSs 2018-2020

The application of the amendments to HKFRSs in the current year has had no material impact on the Group's financial positions and performance for the current and prior years and/or on the disclosures set out in these consolidated financial statements.

---

# Page 94

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 2. APPLICATION OF AMENDMENTS TO HONG KONG FINANCIAL REPORTING STANDARDS ('HKFRSs') (continued)

New and amendments to HKFRSs in issue but not yet effective

The Group has not early applied the following new and amendments to HKFRSs that have been issued but are not yet effective:

HKFRS 17

Insurance contracts 1

Amendments to HKFRS 10 and HKAS 28

Sale or contribution of assets between an investor and its associate or joint venture 2

Amendments to HKFRS 16

Lease liability in a sale and leaseback 3 Classification of liabilities as current or non-current and related amendments to Hong Kong Interpretation 5 (2020) 3

Amendments to HKAS 1

Amendments to HKAS 1

Non-current liabilities with covenant 3

Amendments to HKAS 1 and

HKFRS Practice Statement 2

Disclosure of accounting policies 1

Amendments to HKAS 8

Definition of accounting estimates 1

Amendments to HKAS 12

Deferred tax related to assets and liabilities arising from a single transaction 1


- 1 Effective for annual periods beginning on or after 1 January 2023.
- 2 Effective for annual periods beginning on or after a date to be determined.
- 3 Effective for annual periods beginning on or after 1 January 2024.


The  directors  of  the  Company  anticipate  that  the  application  of  all  new  and  amendments  to  HKFRSs will have no material impact on the consolidated financial statements of the Group in the foreseeable future.

---

# Page 95

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES


## 3.1 Basis of preparation of consolidated financial statements

The consolidated financial statements have been prepared in accordance with HKFRSs issued by the HKICPA. For the purpose of preparation of the consolidated financial statements information is considered material if such information is reasonably expected to influence decisions made by primary users.  In  addition,  the  consolidated  financial  statements  include  applicable  disclosures required by the Listing Rules and by the Hong Kong Companies Ordinance.

The consolidated financial statements have been prepared on the historical cost basis except for certain financial instruments that are measured at fair values at the end of each reporting period, as explained in the accounting policies set out below.

Historical  cost  is  generally  based  on  the  fair  value  of  the  consideration  given  in  exchange  for goods and services.

Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, regardless of whether that  price  is  directly  observable  or  estimated  using  another  valuation  technique.  In  estimating the  fair  value  of  an  asset  or  a  liability,  the  Group  takes  into  account  the  characteristics  of  the asset or liability if market participants would take those characteristics into account when pricing the  asset  or  liability  at  the  measurement  date.  Fair  value  for  measurement  and/or  disclosure purposes  in  these  consolidated  financial  statements  is  determined  on  such  a  basis,  except  for share-based payment transactions that are within the scope of HKFRS 2 'Share-based payment', leasing transactions that are accounted for in accordance with HKFRS 16, and measurements that have some similarities to fair value but are not fair value, such as net realisable value in HKAS 2 'Inventories' or value in use in HKAS 36 'Impairment of assets'.

For  financial  instruments  which  are  transacted  at  fair  value  and  a  valuation  technique  that unobservable inputs are to be used to measure fair value in subsequent periods, the valuation technique is calibrated so that at initial recognition the results of the valuation technique equals the transaction price.

---

# Page 96

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.1 Basis of preparation of consolidated financial statements (continued)


In addition, for financial reporting purposes, fair value measurements are categorised into Level 1, 2 or 3 based on the degree to which the inputs to the fair value measurements are observable and  the  significance  of  the  inputs  to  the  fair  value  measurement  in  its  entirety,  which  are described as follows:
- · Level  1  inputs  are  quoted  prices  (unadjusted)  in  active  markets  for  identical  assets  or liabilities that the entity can access at the measurement date;
- · Level  2  inputs  are  inputs,  other  than  quoted  prices  included  within  Level  1,  that  are observable for the asset or liability, either directly or indirectly; and
- · Level 3 inputs are unobservable inputs for the asset or liability.


The principal accounting policies are set out below.


## 3.2 Significant accounting policies

Basis of consolidation


The consolidated financial statements incorporate the financial statements of the Company and entities controlled by the Company and its subsidiaries. Control is achieved when the Company:
- · has power over the investee;
- · is exposed, or has rights, to variable returns from its involvement with the investee; and
- · has the ability to use its power to affect its returns.


The Group reassesses whether or not it controls an investee if facts and circumstances indicate that there are changes to one or more of the three elements of control listed above.

Consolidation  of  a  subsidiary  begins  when  the  Group  obtains  control  over  the  subsidiary  and ceases  when  the  Group  loses  control  of  the  subsidiary.  Specifically,  income  and  expenses  of  a subsidiary acquired or disposed of during the year are included in the consolidated statement of profit or loss and other comprehensive income from the date the Group gains control until the date when the Group ceases to control the subsidiary.

---

# Page 97

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Basis of consolidation (continued)

Profit or loss and each item of other comprehensive income are attributed to the owners of the Company  and  to  the  non-controlling  interests.  Total  comprehensive  income  of  subsidiaries  is attributed to the owners of the Company and to the non-controlling interests even if this results in the non-controlling interests having a deficit balance.

Where necessary, adjustments are made to the financial statements of subsidiaries to bring their accounting policies in line with the Group's accounting policies.

All  intra-group  assets  and  liabilities,  equity,  income,  expenses  and  cash  flows  relating  to transactions between members of the Group are eliminated in full on consolidation.

Non-controlling  interests  in  subsidiaries  are  presented  separately  from  the  Group's  equity therein, which represent present ownership entitling their holders to a proportionate share of net assets of the relevant subsidiaries upon liquidation.


## Changes in the Group's interests in existing subsidiaries

When  the  Group  loses  control  of  a  subsidiary,  the  assets  and  liabilities  of  that  subsidiary  are derecognised.  A  gain  or  loss  is  recognised  in  profit  or  loss  and  is  calculated  as  the  difference between (i)  the  aggregate  of  the  fair  value  of  the  consideration  received  and  the  fair  value  of any  retained  interest  and  (ii)  the  carrying  amount  of  the  assets  and  liabilities  of  the  subsidiary attributable  to  the  owners  of  the  Company.  All  amounts  previously  recognised  in  other comprehensive  income  in  relation  to  that  subsidiary  are  accounted  for  as  if  the  Group  had directly disposed of the related assets or liabilities of the subsidiary (i.e. reclassified to profit or loss or transferred to another category of equity as specified/permitted by applicable HKFRSs).


## Interests in subsidiaries

Interests in subsidiaries are stated at cost less any accumulated impairment loss.


## Investment in joint operations

A  joint  operation  is  a  joint  arrangement  whereby  the  parties  that  have  joint  control  of  the arrangement  have  rights  to  the  assets,  and  obligations  for  the  liabilities,  relating  to  the  joint arrangement.  Joint  control  is  the  contractually  agreed  sharing  of  control  of  an  arrangement, which exists only when decisions about the relevant activities require unanimous consent of the parties sharing control.

The  Group  accounts  for  the  assets,  liabilities,  revenues  and  expenses  relating  to  its  interest  in a  joint  operation  in  accordance  with  the  HKFRSs  applicable  to  the  particular  assets,  liabilities, revenues and expenses.

---

# Page 98

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Investment in joint operations (continued)

When a group entity transacts with a joint operation in which a group entity is a joint operator (such  as  a  sale  or  contribution  of  assets),  the  Group  is  considered  to  be  conducting  the transaction with the other parties to the joint operation, and gains and losses resulting from the transactions are recognised in the Group's consolidated financial statements only to the extent of other parties' interests in the joint operation.

When a group entity transacts with a joint operation in which a group entity is a joint operator (such as a purchase of assets), the Group does not recognise its share of the gains and losses until it resells those assets to a third party.


## Revenue from contracts with customers

The  Group  recognises  revenue  when  (or  as)  a  performance  obligation  is  satisfied,  i.e.  when 'control' of the goods or services underlying the particular performance obligation is transferred to the customer.

A performance obligation represents a good or service (or a bundle of goods or services) that is distinct or a series of distinct goods or services that are substantially the same.


Control is transferred over time and revenue is recognised over time by reference to the progress towards  complete  satisfaction  of  the  relevant  performance  obligation  if  one  of  the  following criteria is met:
- · the customer simultaneously receives and consumes the benefits provided by the Group's performance as the Group performs;
- · the Group's performance creates or enhances an asset that the customer controls as the Group performs; or
- · the Group's performance does not create an asset with an alternative use to the Group and the Group has an enforceable right to payment for performance completed to date.


Otherwise,  revenue  is  recognised  at  a  point  in  time  when  the  customer  obtains  control  of  the distinct good or service.

---

# Page 99

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Revenue from contracts with customers (continued)

Over  time  revenue  recognition:  measurement  of  progress  towards  complete  satisfaction  of  a performance obligation


## Output method

The progress towards complete satisfaction of a performance obligation is measured based on output method, which is to recognise revenue on the basis of direct measurements of the value of the goods or services transferred to the customer to date relative to the remaining goods or services promised under the contract, that best depict the Group's performance in transferring control of goods or services.

As  a  practical  expedient,  if  the  Group  has  a  right  to  invoice  as  the  amount  represents  and corresponds directly with the value of performance completed and transferred to the customers.

Dividend income is recognised when the Group's right to receive the dividend is established.

Leases

Definition of a lease

A  contract  is,  or  contains,  a  lease  if  the  contract  conveys  the  right  to  control  the  use  of  an identified asset for a period of time in exchange for consideration.

For contracts entered into or modified on or after the date of initial application of HKFRS 16 or arising from business combinations, the Group assesses whether a contract is or contains a lease based on the definition under HKFRS 16 at inception, modification date or acquisition date, as appropriate. Such contract will not be reassessed unless the terms and conditions of the contract are subsequently changed.


## The Group as a lessee


## Allocation of consideration to components of a contract

For  a  contract  that  contains  a  lease  component  and  one  or  more  additional  lease  or  non-lease components, the Group allocates the consideration in the contract to each lease component on the basis of the relative stand-alone price of the lease component and the aggregate stand-alone price of the non-lease components.


## Short-term leases

The Group applies the short-term lease recognition exemption to leases of buildings that have a lease term of 12 months or less from the commencement date and do not contain a purchase option. Lease payments on short-term leases are recognised as expense on a straight-line basis or another systematic basis over the lease term.

---

# Page 100

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Leases (continued)

The Group as a lessee (continued)

Right-of-use assets


The cost of right-of-use asset includes:
- · the amount of the initial measurement of the lease liability;
- · any lease payments made at or before the commencement date, less any lease incentives received; and
- · any initial direct costs incurred by the Group.


Right-of-use  assets  are  measured  at  cost,  less  any  accumulated  depreciation  and  impairment losses, and adjusted for any remeasurement of lease liabilities.

Right-of-use assets are depreciated on a straight-line basis over the shorter of its estimated useful life and the lease term.

The Group presents right-of-use assets as a separate line item on the consolidated statement of financial position.


## Refundable rental deposits

Refundable rental deposits paid are accounted under HKFRS 9 'Financial instruments' (' HKFRS 9 ')  and  initially  measured  at  fair  value.  Adjustments  to  fair  value  at  initial  recognition  are considered as additional lease payments and included in the cost of right-of-use assets.


## Lease liabilities

At the commencement date of a lease, the Group recognises and measures the lease liability at the present value of lease payments that are unpaid at that date. In calculating the present value of lease payments, the Group uses the incremental borrowing rate at the lease commencement date if the interest rate implicit in the lease is not readily determinable.

The  lease  payments  include  fixed  payments  (including  in-substance  fixed  payments)  less  any lease incentives receivable.

After  the  commencement  date,  lease  liabilities  are  adjusted  by  interest  accretion  and  lease payments.

The  Group  presents  lease  liabilities  as  a  separate  line  item  on  the  consolidated  statement  of financial position.

---

# Page 101

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Intangible asset

Intangible asset acquired separately

Intangible asset, including vehicle license, with indefinite useful lives that is acquired separately is carried at cost less any subsequent accumulated impairment losses.

An  intangible  asset  is  derecognised  on  disposal,  or  when  no  future  economic  benefits  are expected from use or disposal. Gains or losses arising from derecognition of an intangible asset, measured as the difference between the net disposal proceeds and the carrying amount of the asset are recognised in profit or loss when the asset is derecognised.

Property, plant and equipment

Oil and gas properties

Expenditure  on  the  construction,  installation  or  completion  of  infrastructure  facilities  such  as platforms,  pipelines  and  the  drilling  of  commercially  proven  development  wells,  is  capitalised within  construction  in  progress  under  property,  plant  and  equipment.  When  development is  completed  on  a  specific  field,  it  is  transferred  to  oil  and  gas  properties.  No  depreciation  is charged during the development phase.

Oil  and  gas  production  properties  include  drilling  costs,  exploration  and  evaluation  costs, development costs and other direct costs attributable to the oil and gas production properties.

Oil  and  gas  properties  are  depreciated  and  depleted  using  the  unit-of-production  method. Unit-of-production rates are based on oil and gas reserves, which are oil, gas and other mineral reserves estimated to be recovered from existing facilities using current operating methods. Oil and gas volumes are considered to be part of production once they have been measured through meters at custody transfer or sales transaction points at the outlet valve on the field storage tank.

Property, plant and equipment, including oil and gas properties, are stated at historical cost less depreciation and impairment. Historical cost includes expenditure that is directly attributable to the acquisition of the items.

Subsequent costs are included in the asset's carrying amount or recognised as a separate asset, as appropriate, only when it is probable that future economic benefits associated with the item will flow to the Group and the cost of the item can be measured reliably. The carrying amount of the replaced part is derecognised. All other repairs and maintenance are charged to profit or loss during the financial period in which they are incurred.

---

# Page 102

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Property, plant and equipment (continued)

Property, plant and equipment other than oil and gas properties

Property, plant and equipment other than oil and gas properties are stated in the consolidated statement  of  financial  position  at  cost  less  subsequent  accumulated  depreciation  and subsequent accumulated impairment losses, if any.

Constructions in progress in the course of construction for production, supply or administrative purposes are carried at cost, less any recognised impairment loss. Costs include any costs directly attributable to bringing the asset to the location and condition necessary for it to be capable of operating  in  the  manner  intended  by  management  and,  for  qualifying  assets,  borrowing  costs capitalised in accordance with the Group's accounting policy. Depreciation of these assets, on the same basis as other property assets, commences when the assets are ready for their intended use.

Depreciation is recognised so as to write off the cost of items of property, plant and equipment less  their  residual  values  over  their  estimated  useful  lives,  using  the  straight-line  method.  The estimated useful lives, residual values and depreciation method are reviewed at the end of each reporting period, with the effect of any changes in estimate accounted for on a prospective basis.

An  item  of  property,  plant  and  equipment  is  derecognised  upon  disposal  or  when  no  future economic benefits are expected to arise  from  the  continued  use  of  the  asset.  Any  gain  or  loss arising on the disposal or retirement of an item of property, plant and equipment is determined as  the  difference  between  the  sales  proceeds  and  the  carrying  amount  of  the  asset  and  is recognised in profit or loss.

Impairment of property, plant and equipment, right-of-use assets and intangible assets

At the end of the reporting period, the Group reviews the carrying amounts of its property, plant and equipment and right-of-use assets to determine whether there is any indication that these assets have suffered an impairment loss. If any such indication exists, the recoverable amount of the relevant asset is estimated in order to determine the extent of the impairment loss (if any). Intangible  assets  with  indefinite  useful  lives  are  tested  for  impairment  at  least  annually,  and whenever there is an indication that they may be impaired.

The  recoverable  amount  of  property,  plant  and  equipment,  right-of-use  assets  and  intangible assets  are  estimated  individually.  When  it  is  not  possible  to  estimate  the  recoverable  amount individually, the Group estimates the recoverable amount of the cash-generating unit to which the asset belongs.

---

# Page 103

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Impairment  of  property,  plant  and  equipment,  right-of-use  assets  and  intangible  assets (continued)

In  testing  a  cash  generating  unit  for  impairment,  corporate  assets  are  allocated  to  the  relevant cash-generating units when a reasonable and consistent basis of allocation can be established, or  otherwise  they  are  allocated  to  the  smallest  group  of  cash-generating  units  for  which  a reasonable  and  consistent  allocation  basis  can  be  established.  The  recoverable  amount  is determined  for  the  cash-generating  unit  or  group  of  cash-generating  units  to  which  the corporate  asset  belongs,  and  is  compared  with  the  carrying  amount  of  the  relevant  cashgenerating unit or group of cash-generating units.

Recoverable amount is the higher of fair value less costs of disposal and value in use. In assessing value in use, the estimated future cash flows are discounted to their present value using a pre-tax discount rate that reflects current market assessments of the time value of money and the risks specific to the asset (or a cash-generating unit) for which the estimates of future cash flows have not been adjusted.

If  the  recoverable  amount  of  an  asset  (or  a  cash-generating  unit)  is  estimated  to  be  less  than its  carrying  amount,  the  carrying  amount  of  the  asset  (or  a  cash-generating  unit)  is  reduced  to its  recoverable  amount.  For  corporate  assets  or  portion  of  corporate  assets  which  cannot  be allocated  on  a  reasonable  and  consistent  basis  to  a  cash-generating  unit,  the  Group  compares the carrying amount of a group of cash-generating units, including the carrying amounts of the corporate assets or portion of corporate assets allocated to that group of cash-generating units, with the recoverable amount of the group of cash-generating units. In allocating the impairment loss,  the  impairment  loss  is  allocated  first  to  reduce  the  carrying  amount  of  any  goodwill  (if applicable) and then to the other assets on a pro-rata basis based on the carrying amount of each asset  in  the  unit  or  the  group  of  cash-generating  units.  The  carrying  amount  of  an  asset  is  not reduced below the highest of its fair value less costs of disposal (if measurable), its value in use (if  determinable) and zero. The amount of the impairment loss that would otherwise have been allocated to the asset is allocated pro rata to the other assets of the unit or the group of cashgenerating units. An impairment loss is recognised immediately in profit or loss.

Where  an  impairment  loss  subsequently  reverses,  the  carrying  amount  of  the  asset  (or  cashgenerating unit or a group of cash-generating units) is increased to the revised estimate of its recoverable  amount,  but  so  that  the  increased  carrying  amount  does  not  exceed  the  carrying amount that would have been determined had no impairment loss been recognised for the asset (or  a  cash-generating  unit  or  a  group  of  cash-generating  units)  in  prior  years.  A  reversal  of  an impairment loss is recognised immediately in profit or loss.

---

# Page 104

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Provisions

Provisions are recognised when the Group has a present obligation (legal or constructive) as a result of a past event, it is probable that the Group will be required to settle that obligation, and a reliable estimate can be made of the amount of the obligation.

The  amount  recognised  as  a  provision  is  the  best  estimate  of  the  consideration  required  to settle the present obligation at the end of the reporting period, taking into account the risks and uncertainties  surrounding  the  obligation.  When  a  provision  is  measured  using  the  cash  flows estimated to settle the present obligation, its carrying amount is the present value of those cash flows (where the effect of the time value of money is material).


## Decommissioning obligation

Decommissioning  obligation  represents  cost  for  the  future  abandonment  of  oil  and  gas production  equipment  and  facilities,  representing  the  legal  obligations,  at  the  end  of  their economic  lives.  Decommissioning  activities  may  include  facility  decommissioning  and dismantling, removal or treatment of waste materials, land rehabilitation, and site restoration.

The  amount  recognised  as  part  of  the  cost  of  oil  and  gas  properties  is  the  estimated  cost of  decommissioning,  discounted  to  its  net  present  value.  The  timing  and  amount  of  future expenditure  are  reviewed  annually  together  with  the  interest  rate  to  be  used  in  discounting the  cash  flows.  Any  change  in  the  present  value  of  the  estimated  expenditure  is  dealt  with prospectively and reflected as an adjustment to the provision and a corresponding adjustment to property, plant and equipment - oil and gas properties.

Decommissioning costs are depreciated as part of  the  cost  of  oil  and  gas  properties  using  the unit-of-production method. The accretion of discount of the provision of decommissioning cost is recognised as finance costs in the consolidated profit or loss.


## Financial instruments

Financial  assets  and  financial  liabilities  are  recognised  when  a  group  entity  becomes  a  party to  the  contractual  provisions  of  the  instrument.  All  regular  way  purchases  or  sales  of  financial assets  are  recognised  and  derecognised  on  a  trade  date  basis.  Regular  way  purchases  or  sales are  purchases  or  sales  of  financial  assets  that  require  delivery  of  assets  within  the  time  frame established by regulation or convention in the market place.

Financial  assets  and  financial  liabilities  are  initially  measured  at  fair  value  except  for  trade receivables  arising  from  contracts  with  customers  which  are  initially  measured  in  accordance with  HKFRS  15  'Revenue  from  contracts  with  customers'.  Transaction  costs  that  are  directly attributable  to  the  acquisition  or  issue  of  financial  assets  and  financial  liabilities  (other  than financial  assets  at  fair  value  through  profit  or  loss  (' FVTPL '))  are  added  to  or  deducted  from the fair value of the financial assets or financial liabilities, as appropriate, on initial recognition. Transaction costs directly attributable to the acquisition of financial assets or financial liabilities at FVTPL are recognised immediately in profit or loss.

---

# Page 105

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Financial instruments (continued)

Effective interest method

The effective interest method is a method of calculating the amortised cost of a financial asset or financial liability and of allocating interest income and interest expense over the relevant period. The effective  interest  rate  is  the  rate  that  exactly  discounts  estimated  future  cash  receipts  and payments (including all fees and points paid or received that form an integral part of the effective interest rate, transaction costs and other premiums or discounts) through the expected life of the financial  asset  or  financial  liability,  or,  where  appropriate,  a  shorter  period,  to  the  net  carrying amount on initial recognition.

Interest and dividend income which are derived from the Group's ordinary course of business are presented as revenue.


## Financial assets

Classification and subsequent measurement of financial assets


Financial assets that meet the following conditions are subsequently measured at amortised cost:
- · the financial asset is held within a business model whose objective is to collect contractual cash flows; and
- · the contractual terms give rise on specified dates to cash flows that are solely payments of principal and interest on the principal amount outstanding.



Financial  assets  that  meet  the  following  conditions  are  subsequently  measured  at  fair  value through other comprehensive income (' FVTOCI '):
- · the  financial  asset  is  held  within  a  business  model  whose  objective  is  achieved  by  both selling and collecting contractual cash flows; and
- · the contractual terms give rise on specified dates to cash flows that are solely payments of principal and interest on the principal amount outstanding.


All  other financial assets are subsequently measured at FVTPL, except that at initial recognition of  a  financial  asset  of  the  Group  may  irrevocably  elect  to  present  subsequent  changes  in  fair value of an equity investment in other comprehensive income (' OCI ')  if  that  equity  investment is neither held for trading nor contingent consideration recognised by an acquirer in a business combination to which HKFRS 3 'Business combinations' applies.

---

# Page 106

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Financial instruments (continued)

Financial assets (continued)

Classification and subsequent measurement of financial assets (continued)


## A financial asset is held for trading if:


- · it has been acquired principally for the purpose of selling in the near term; or
- · on initial recognition it is a part of a portfolio of identified financial instruments that the Group manages together and has a recent actual pattern of short-term profit-taking; or
- · it is a derivative that is not designated and effective as a hedging instrument.


In  addition,  the  Group  may  irrevocably  designate  a  financial  asset  that  are  required  to  be measured  at  the  amortised  cost  or  FVTOCI  as  measured  at  FVTPL  if  doing  so  eliminates  or significantly reduces an accounting mismatch.


## (i) Amortised cost and interest income

Interest  income  is  recognised  using  the  effective  interest  method  for  financial  assets measured subsequently at amortised cost and debt instruments subsequently measured at FVTOCI. Interest income is calculated by applying the effective interest rate to the gross carrying  amount  of  a  financial  asset,  except  for  financial  assets  that  have  subsequently become  credit-impaired.  For  financial  assets  that  have  subsequently  become  creditimpaired,  interest  income  is  recognised  by  applying  the  effective  interest  rate  to  the amortised cost of the financial asset from the next reporting period. If the credit risk on the credit-impaired financial instrument improves so that the financial asset is no longer credit-impaired, interest income is recognised by applying the effective interest rate to the gross  carrying  amount  of  the  financial  asset  from  the  beginning  of  the  reporting  period following the determination that the asset is no longer credit-impaired.


## (ii) Debt instruments classified as at FVTOCI

Subsequent changes in the carrying amounts for debt instruments classified as at FVTOCI as a result of interest income calculated using the effective interest method are recognised in  profit  or  loss.  All  other  changes  in  the  carrying  amount  of  these  debt  instruments  are recognised in OCI and accumulated under the heading of investment revaluation reserve. Impairment allowances are recognised in profit or loss with corresponding adjustment to OCI without reducing the carrying amounts of these debt instruments. When these debt instruments are derecognised, the cumulative gains or losses previously recognised in OCI are reclassified to profit or loss.

---

# Page 107

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Financial instruments (continued)

Financial assets (continued)

Classification and subsequent measurement of financial assets (continued)


## (iii) Financial assets at FVTPL

Financial  assets  that  do  not  meet  the  criteria  for  being  measured  at  amortised  cost  or FVTOCI or designated as FVTOCI are measured at FVTPL.

Financial assets at FVTPL are measured at fair value at the end of each reporting period, with  any  fair  value  gains  or  losses  recognised  in  profit  or  loss.  The  net  gain  or  loss recognised in profit or loss excludes any dividend or interest earned on the financial asset and is included in the 'net loss on financial assets at fair value through profit or loss' line item.

Impairment of financial assets and other items subject to impairment assessment under HKFRS 9

The  Group  performs  impairment  assessment  under  expected  credit  loss  (' ECL ')  model  on financial  assets  (including  trade  and  other  receivables,  loan  and  interest  receivables,  cash  and cash equivalents and debt instruments at FVTOCI) which are subject to impairment assessment under HKFRS 9. The amount of ECL is updated at each reporting date to reflect changes in credit risk since initial recognition.

Lifetime ECL represents the ECL that will result from all possible default events over the expected life of the relevant instrument. In contrast, 12-month ECL (' 12m ECL ') represents the portion of lifetime  ECL  that  is  expected  to  result  from  default  events  that  are  possible  within  12  months after  the  reporting  date.  Assessments  are  done  based  on  the  Group's  historical  credit  loss experience,  adjusted  for  factors  that  are  specific  to  the  debtors,  general  economic  conditions and an assessment of both the current conditions at the reporting date as well as the forecast of future conditions.

The Group always recognises lifetime ECL for trade receivables. The ECL is assessed individually for trade receivables.

---

# Page 108

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Financial instruments (continued)

Financial assets (continued)

Impairment  of  financial  assets  and  other  items  subject  to  impairment  assessment  under  HKFRS  9 (continued)

For all other instruments, the Group measures the loss allowance equal to 12m ECL, unless when there  has  been  a  significant  increase  in  credit  risk  since  initial  recognition  in  which  case,  the Group  recognises  lifetime  ECL.  The  assessment  of  whether  lifetime  ECL  should  be  recognised is  based  on  significant  increases  in  the  likelihood  or  risk  of  a  default  occurring  since  initial recognition.


## (i) Significant increase in credit risk

In  assessing  whether  the  credit  risk  has  increased  significantly  since  initial  recognition, the  Group  compares  the  risk  of  a  default  occurring  on  the  financial  instrument  as  at the  reporting  date  with  the  risk  of  a  default  occurring  on  the  financial  instrument  as at  the  date  of  initial  recognition.  In  making  this  assessment,  the  Group  considers  both quantitative  and  qualitative  information  that  is  reasonable  and  supportable,  including historical experience and forward-looking information that is available without undue cost or effort.


In  particular,  the  following  information  is  taken  into  account  when  assessing  whether credit risk has increased significantly:
- · an actual or expected significant deterioration in the financial instrument's external (if available) or internal credit rating;
- · significant deterioration in external market indicators of credit risk, e. g. a significant increase in the credit spread, the credit default swap prices for the debtor;
- · existing  or  forecast  adverse  changes  in  business,  financial  or  economic  conditions that are expected to cause a significant decrease in the debtor's ability to meet its debt obligations;
- · an actual or expected significant deterioration in the operating results of the debtor;
- · an  actual  or  expected  significant  adverse  change  in  the  regulatory,  economic,  or technological environment of the debtor that results in a significant decrease in the debtor's ability to meet its debt obligations.


Irrespective of the outcome of the above assessment, the Group presumes that the credit risk  has  increased  significantly  since  initial  recognition  when  contractual  payments  are more than 30 days past due, unless the Group has reasonable and supportable information that demonstrates otherwise.

---

# Page 109

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Financial instruments (continued)

Financial assets (continued)

Impairment  of  financial  assets  and  other  items  subject  to  impairment  assessment  under  HKFRS  9 (continued)


## (i) Significant increase in credit risk (continued)

Despite the aforegoing, the Group assumes that the credit risk on a debt instrument has not  increased  significantly  since  initial  recognition  if  the  debt  instrument  is  determined to have low credit risk at the reporting date. A debt instrument is determined to have low credit risk if (i) it has a low risk of default, (ii) the borrower has a strong capacity to meet its contractual cash flow obligations in the near term and (iii) adverse changes in economic and business conditions in the longer term may, but will not necessarily, reduce the ability of the borrower to fulfil its contractual cash flow obligations. The Group considers a debt instrument  to  have  low  credit  risk  when  it  has  an  internal  or  external  credit  rating  of 'investment grade' as per globally understood definitions or the counterparty can meet the financial commitment.

The  Group  regularly  monitors  the  effectiveness  of  the  criteria  used  to  identify  whether there  has  been  a  significant  increase  in  credit  risk  and  revises  them  as  appropriate  to ensure that the criteria are capable of identifying significant increase in credit risk before the amount becomes past due.


## (ii) Definition of default

For internal credit risk management, the Group considers an event of default occurs when information  developed  internally  or  obtained  from  external  sources  indicates  that  the debtor  is  unlikely  to  pay  its  creditors,  including  the  Group,  in  full  (without  taking  into account any collaterals held by the Group).

Irrespective of the above, the Group considers that default has occurred when a financial asset  is  more  than  90  days  past  due  unless  the  Group  has  reasonable  and  supportable information to demonstrate that a more lagging default criterion is more appropriate.

---

# Page 110

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Financial instruments (continued)

Financial assets (continued)

Impairment  of  financial  assets  and  other  items  subject  to  impairment  assessment  under  HKFRS  9 (continued)


## (iii) Credit-impaired financial assets


A  financial  asset  is  credit-impaired  when  one  or  more  events  that  have  a  detrimental impact on the estimated future cash flows of that financial asset have occurred. Evidence that  a  financial  asset  is  credit-impaired  includes  observable  data  about  the  following events:
- · significant financial difficulty of the issuer or the borrower;
- · a breach of contract, such as a default or past due event;
- · the  lender(s)  of  the  borrower,  for  economic  or  contractual  reasons  relating  to  the borrower's financial difficulty, having granted to the borrower a concession(s) that the lender(s) would not otherwise consider;
- · it  is  becoming  probable that the borrower will enter bankruptcy or other financial reorganisation;
- · the  disappearance of an active market for that financial  asset  because  of  financial difficulties; or
- · the issuer engaging in business that are unstable



## (iv) Write-off policy

The  Group  writes  off  a  financial  asset  when  there  is  information  indicating  that  the counterparty is in severe financial difficulty and there is no realistic prospect of recovery, for  example,  when  the  counterparty  has  been  placed  under  liquidation  or  has  entered into  bankruptcy  proceedings,  or  in  the  case  of  trade  receivables,  when  the  amounts  are over  two  years  past  due,  whichever  occurs  sooner.  Financial  assets  written  off  may  still be  subject  to  enforcement  activities  under  the  Group's  recovery  procedures,  taking  into account legal advice where appropriate. A write-off constitutes a derecognition event. Any subsequent recoveries are recognised in profit or loss.

---

# Page 111

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Financial instruments (continued)

Financial assets (continued)

Impairment  of  financial  assets  and  other  items  subject  to  impairment  assessment  under  HKFRS  9 (continued)


## (v) Measurement and recognition of ECL

The measurement of ECL is a function of the probability of default, loss given default (i.e. the magnitude of the loss if there is a default) and the exposure at default. The assessment of  the  probability  of  default  and  loss  given  default  is  based  on  historical  data  adjusted and forward-looking information. Estimation of ECL reflects an unbiased and probabilityweighted amount that is determined with the respective risks of default occurring as the weights.

Generally,  the  ECL  is  the  difference  between  all  contractual  cash  flows  that  are  due  to the Group in accordance with the contract and the cash flows that the Group expects to receive, discounted at the effective interest rate determined at initial recognition.


Where  ECL  is  measured  on  a  collective  basis  or  cater  for  cases  where  evidence  at  the individual instrument level may not yet be available, the financial instruments are grouped on the following basis:
- · Nature of financial instruments (i.e. the Group's other receivables are assessed as a separate group);
- · Past-due status;
- · Nature, size and industry of debtors; and
- · External credit ratings where available.


The  grouping  is  regularly  reviewed  by  management  to  ensure  the  constituents  of  each group continue to share similar credit risk characteristics.

Interest  income  is  calculated  based  on  the  gross  carrying  amount  of  the  financial  asset unless  the  financial  asset  is  credit-impaired,  in  which  case  interest  income  is  calculated based on amortised cost of the financial asset.

---

# Page 112

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Financial instruments (continued)

Financial assets (continued)

Impairment  of  financial  assets  and  other  items  subject  to  impairment  assessment  under  HKFRS  9 (continued)


## (v) Measurement and recognition of ECL (continued)

For  trade  receivables  and  loan  receivables,  the  ECL  of  the  Group  is  recognised  through a  loss  allowance  account.  Impairment  allowances  are  recognised  in  profit  or  loss  with corresponding  adjustment  to  OCI  without  reducing  the  carrying  amounts  of  these  debt instruments.


## Derecognition of financial assets

The Group derecognises a financial asset only when the contractual rights to the cash flows from the asset expire, or when it transfers the financial asset and substantially all the risks and rewards of ownership of the asset to another entity. If the Group neither transfers nor retains substantially all the risks and rewards of ownership and continues to control the transferred asset, the Group recognises its retained interest in the asset and an associated liability for amounts it may have to pay. If the Group retains substantially all the risks and rewards of ownership of a transferred financial  asset,  the  Group  continues  to  recognise  the  financial  asset  and  also  recognises  a collateralised borrowing for the proceeds received.

On  derecognition  of  a  financial  asset  measured  at  amortised  cost,  the  difference  between  the asset's carrying amount and the sum of the consideration received and receivable is recognised in profit or loss.

On derecognition of an investment in a debt instrument classified as at FVTOCI, the cumulative gain or loss previously accumulated in the investment revaluation reserve is reclassified to profit or loss.

---

# Page 113

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Financial instruments (continued)

Financial liabilities and equity

Classification as debt or equity

Debt and equity instruments are classified as either financial liabilities or as equity in accordance with the substance of the contractual arrangements and the definitions of a financial liability and an equity instrument.


## Equity instruments

An equity instrument is any contract that evidences a residual interest in the assets of an entity after deducting all of its liabilities. Equity instruments issued by the Company are recognised at the proceeds received, net of direct issue costs.


## Financial liabilities

All  financial  liabilities  are  subsequently  measured  at  amortised  cost  using  the  effective  interest method.


## Financial liabilities at amortised cost

Financial liabilities including trade and other payables are subsequently measured at amortised cost, using the effective interest method.


## Derecognition of financial liabilities

The  Group  derecognises  financial  liabilities  when,  and  only  when,  the  Group's  obligations  are discharged,  cancelled  or  have  expired.  The  difference  between  the  carrying  amount  of  the financial liability derecognised and the consideration paid and payable is recognised in profit or loss.


## Taxation

Income tax expense represents the sum of the tax currently payable and deferred tax.


## Current tax

The tax currently payable is based on taxable profit for the year. Taxable profit differs from profit (loss) before tax because of income or expense that are taxable or deductible in other years and items that are never taxable or deductible. The Group's liability for current tax is calculated using tax rates that have been enacted or substantively enacted by the end of the reporting period.

---

# Page 114

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Taxation (continued)

Deferred tax

Deferred  tax  is  recognised  on  temporary  differences  between  the  carrying  amounts  of  assets and liabilities in the consolidated financial statements and the corresponding tax bases used in the computation of taxable profit. Deferred tax liabilities are generally recognised for all taxable temporary differences. Deferred tax assets are generally recognised for all deductible temporary differences  to  the  extent  that  it  is  probable  that  taxable  profits  will  be  available  against  which those  deductible  temporary  differences  can  be  utilised.  Such  deferred  tax  assets  and  liabilities are not recognised if the temporary difference arises from the initial recognition (other than in a business combination) of assets and liabilities in a transaction that affects neither the taxable profit  nor  the  accounting  profit.  In  addition,  deferred  tax  liabilities  are  not  recognised  if  the temporary difference arises from the initial recognition of goodwill.

Deferred  tax  liabilities  are  recognised  for  taxable  temporary  differences  associated  with investments in subsidiaries and interests in joint operations, except where the Group is able to control the reversal of the temporary difference and it is probable that the temporary difference will not reverse in the foreseeable future. Deferred tax assets arising from deductible temporary differences associated with such investments and interests are only recognised to the extent that it  is  probable that there will be sufficient taxable profits against which to utilise the benefits of the temporary differences and they are expected to reverse in the foreseeable future.

The carrying amount of deferred tax assets is reviewed at the end of each reporting period and reduced to the extent that it is no longer probable that sufficient taxable profits will be available to allow all or part of the asset to be recovered.

Deferred tax assets and liabilities are measured at the tax rates that are expected to apply in the period in which the liability is settled or the asset is realised, based on tax rate (and tax laws) that have been enacted or substantively enacted by the end of the reporting period.

The measurement of deferred tax liabilities and assets reflects the tax consequences that would follow  from  the  manner  in  which  the  Group  expects,  at  the  end  of  the  reporting  period,  to recover or settle the carrying amount of its assets and liabilities.

For  the  purposes  of  measuring  deferred  tax  for  leasing  transactions  in  which  the  Group recognises  the  right-of-use  assets  and  the  related  lease  liabilities,  the  Group  first  determines whether the tax deductions are attributable to the right-of-use assets or the lease liabilities.

---

# Page 115

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Taxation (continued)

Deferred tax (continued)

For leasing transactions in which the tax deductions are attributable to the lease liabilities, the Group  applies  HKAS  12  'Income  taxes'  requirements  to  right-of-use  assets  and  lease  liabilities separately.  Temporary  differences  on  initial  recognition  of  the  relevant  right-of-use  assets and lease  liabilities  are  not  recognised  due  to  application  of  the  initial  recognition  exemption. Temporary  differences  arising  from  subsequent  revision  of  the  carrying  amounts  of  rightof-use  assets  and  lease  liabilities,  resulting  from  remeasurement  of  lease  liabilities  and  lease modifications, that are not subject to initial recognition exemption are recognised on the date of remeasurement or modification.


## Current and deferred tax for the year

Deferred tax  assets  and  liabilities  are  offset  when  there  is  a  legally  enforceable  right  to  set  off current tax assets against current tax liabilities and when they relate to income taxes levied to the same taxable entity by the same taxation authority.

Current and deferred tax are recognised in profit or loss, except when they relate to items that are recognised in OCI or directly in equity, in which case, the current and deferred tax are also recognised in OCI or directly in equity respectively.

In  assessing  any  uncertainty  over  income  tax  treatments,  the  Group  considers  whether  it is  probable  that  the  relevant  tax  authority  will  accept  the  uncertain  tax  treatment  used,  or proposed to be used by individual group entities in their income tax filings. If it is probable, the current  and  deferred  taxes  are  determined  consistently  with  the  tax  treatment  in  the  income tax  filings.  If  it  is  not  probable  that  the  relevant  taxation  authority  will  accept  an  uncertain  tax treatment, the effect of each uncertainty is reflected by using either the most likely amount or the expected value.

Employee benefits

Retirement benefits costs

Payments to state-managed retirement benefit schemes and Mandatory Provident Fund Scheme (' MPF Scheme ')  and  the  Canada Pension Fund are recognised as an expense when employees have rendered service entitling them to the contributions.

---

# Page 116

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Employee benefits (continued)

Short-term and other long-term employee benefits

Short-term  employee  benefits  are  recognised  at  the  undiscounted  amount  of  the  benefits expected  to  be  paid  as  and  when  employees  rendered  the  services.  All  short-term  employee benefits are recognised as an expense unless another HKFRS requires or permits the inclusion of the benefit in the cost of an asset.

A  liability  is  recognised  for  benefits  accruing  to  employees  (such  as  wages  and  salaries  and annual leave) after deducting any amount already paid.

Liabilities  recognised  in  respect  of  other  long-term  employee  benefits  are  measured  at  the present value of the estimated future cash outflows expected to be made by the Group in respect of  services  provided  by  employees  up  to  the  reporting  date.  Any  changes  in  the  liabilities' carrying  amounts  resulting  from  service  cost,  interest  and  remeasurements  are  recognised  in profit or loss except to the extent that another HKFRS requires or permits their inclusion in the cost of an asset.


## Share-based payments

Equity-settled share-based payment transactions

Share options granted to employees and directors

Equity-settled  share-based  payments  to  employees  and  directors  providing  similar  services  are measured at the fair value of the equity instruments at the grant date.

The fair value of the equity-settled share-based payments determined at the grant date without taking into consideration all non-market vesting conditions is expensed on a straight-line basis over the vesting period, based on the Group's estimate of equity instruments that will eventually vest, with a corresponding increase in equity (share options reserve). At the end of each reporting period,  the  Group  revises  its  estimate  of  the  number  of  equity  instruments  expected  to  vest based on assessment of all relevant non-market vesting conditions. The impact of the revision of the original estimates, if any, is recognised in profit or loss such that the cumulative expense reflects  the  revised  estimate,  with  a  corresponding  adjustment  to  the  share  options  reserve. For share options that vest immediately at the date of grant, the fair value of the share options granted is expensed immediately to profit or loss.

When share options are exercised, the amount previously recognised in share-based payments reserve  will  be  transferred  to  share  premium.  When  the  share  options  are  forfeited  after  the vesting  date  or  are  still  not  exercised  at  the  expiry  date,  the  amount  previously  recognised  in share options reserve will continue to be held in share options reserve.

---

# Page 117

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Government grants

Government grants  are  not  recognised  until  there  is  reasonable  assurance  that  the  Group  will comply with the conditions attaching to them and that the grants will be received.

Government  grants  related  to  income  that  are  receivable  as  compensation  for  expenses  or losses  already  incurred  or  for  the  purpose  of  giving  immediate  financial  support  to  the  Group with no future related costs are recognised in profit or loss in the period in which they become receivable. Such grants are presented under 'other income and losses, net'.


## Foreign currencies

In  preparing the financial statements of each individual group entity, transactions in currencies other than the functional currency of that entity (foreign currencies) are recognised at the rates of  exchanges  prevailing  on  the  dates  of  the  transactions.  At  the  end  of  the  reporting  period, monetary  items  denominated  in  foreign  currencies  are  retranslated  at  the  rates  prevailing  at that  date.  Non-monetary items carried at fair value that are denominated in foreign currencies are  retranslated  at  the  rates  prevailing  on  the  date  when  the  fair  value  was  determined.  Nonmonetary  items  that  are  measured  in  terms  of  historical  cost  in  a  foreign  currency  are  not retranslated.

Exchange differences  arising  on  the  settlement  of  monetary  items,  and  on  the  retranslation  of monetary items, are recognised in profit or loss in the period in which they arise.

For  the  purposes  of  presenting  the  consolidated  financial  statements,  the  assets  and  liabilities of  the  Group's  foreign  operations  are  translated  into  the  presentation  currency  of  the  Group (i.e.  HK$)  using  exchange  rates  prevailing  at  the  end  of  each  reporting  period.  Income  and expenses  items  are  translated  at  the  average  exchange  rates  for  the  period,  unless  exchange rates  fluctuated  significantly  during  the  period,  in  which  case,  the  exchange  rates  at  the date  of  transactions  are  used.  Exchange  differences  arising,  if  any,  are  recognised  in  OCI  and accumulated in equity under the heading of translation reserve.

---

# Page 118

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 3. BASIS OF PREPARATION OF CONSOLIDATED FINANCIAL STATEMENT AND SIGNIFICANT ACCOUNTING POLICIES (continued)


## 3.2 Significant accounting policies (continued)

Foreign currencies (continued)

On  the  disposal  of  a  foreign  operation  (that  is,  a  disposal  of  the  Group's  entire  interest  in  a foreign  operation,  or  a  disposal  involving  loss  of  control  over  a  subsidiary  that  includes  a foreign  operation,  or  a  partial  disposal  of  an  interest  in  a  joint  arrangement  that  includes  a foreign operation of which the retained interest becomes a financial asset), all of the exchange differences accumulated in equity in respect of that operation attributable to the owners of the Company are reclassified to profit or loss.

Business combinations or asset acquisitions


## Optional concentration test

The  Group  can  elect  to  apply  an  optional  concentration  test,  on  a  transaction-by-transaction basis,  that  permits  a  simplified  assessment  of  whether  an  acquired  set  of  activities  and  assets is  not  a  business.  The  concentration  test  is  met  if  substantially  all  of  the  fair  value  of  the  gross assets  acquired  is  concentrated  in  a  single  identifiable  asset  or  group  of  similar  identifiable assets. The gross assets under assessment exclude cash and cash equivalents, deferred tax assets, and goodwill resulting from the effects of deferred tax liabilities. If the concentration test is met, the set of activities and assets is determined not to be a business and no further assessment is needed.


## Asset acquisitions

When the Group acquires a group of assets and liabilities that do not constitute a business, the Group identifies and recognises the individual identifiable assets acquired and liabilities assumed by allocating the purchase price first to financial assets/financial liabilities at the respective fair values,  the  remaining  balance  of  the  purchase  price  is  then  allocated  to  the  other  identifiable assets  and  liabilities  on  the  basis  of  their  relative  fair  values  at  the  date  of  purchase.  Such  a transaction does not give rise to goodwill or bargain purchase gain.

---

# Page 119

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 4. CRITICAL ACCOUNTING JUDGMENT AND KEY SOURCES OF ESTIMATION UNCERTAINTY

In  the  application  of  the  Group's  accounting  policies,  which  are  described  in  Note  3,  the  directors  of the Company are required to make judgments, estimates and assumptions about the carrying amounts of assets and liabilities that are not readily apparent from other sources. The estimates and underlying assumptions are based on historical experience and other factors that are considered to be relevant. Actual results may differ from these estimates.

The estimates and underlying assumptions are reviewed on an on-going basis. Revisions to accounting estimates are recognised in the period in which the estimate is revised if the revision affects only that period, or in the period of the revision and future periods if the revision affects both current and future periods.


## Critical judgments in applying accounting policies

The  following  are  the  critical  judgments,  apart  from  those  involving  estimations  (see  below),  that the  directors  of  the  Company  have  made  in  the  process  of  applying  the  Group's  accounting  policies and  that  have  the  most  significant  effect  on  the  amounts  recognised  in  the  consolidated  financial statements.

Judgment on whether there has been significant increase in credit risk in respect of the Group's financial assets

The  management  assesses  whether  there  has  been  a  significant  increase  in  credit  risk  for  exposures since initial recognition in respect of the Group's loan and interest receivables and debt instruments at FVTOCI. If there has been a significant increase in credit risk, the Group will measure the loss allowance based on lifetime ECL rather than 12-month ECL. In assessing whether the credit risk of an asset has significantly increased, the Group takes into account qualitative factors and quantitative modelling to support reasonable and supportable forward-looking information available without undue cost or effort with significant judgments involved. The Group determines individually whether the loan and interest receivables and debt instruments at FVTOCI have been credit impaired when one or more events that have a detrimental impact on the estimated future cash flows have occurred. In addition, judgement is  involved  to  assess  whether  a  change  in  the  contractual  terms  of  the  Group's  loan  and  interest receivables and debt instruments at FVTOCI would lead to (1) an increase in credit risk; and (2) the need to derecognise the existing loan and interest receivables and debt instruments at FVTOCI and recognise new loan and interest receivables and debt instruments at FVTOCI. The information about the ECL and the Group's loan and interest receivables and debt instruments at FVTOCI are disclosed in Notes 37, 22 and 21 respectively.

---

# Page 120

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 4. CRITICAL ACCOUNTING JUDGMENT AND KEY SOURCES OF ESTIMATION UNCERTAINTY (continued)


## Key sources of estimation uncertainty

The  following  is  the  key  assumption  concerning  the  future,  and  other  key  sources  of  estimation uncertainty  at  the  end  of  the  reporting  period,  that  may  have  a  significant  risk  of  causing  a  material adjustment to the carrying amounts of assets and liabilities within the next financial year.


## Provision of ECL for loan and interest receivables

Management  regularly  reviews  the  impairment  assessment  and  evaluates  the  ECL  of  the  loan  and interest receivables. Appropriate impairment allowance is recognised in profit or loss.

In  assessing  whether  the  credit  risk  has  increased  significantly  since  initial  recognition,  the  Group compares  the  risk  of  a  default  occurring  on  the  financial  instrument  at  the  reporting  date  with  the one as at the date of initial  recognition.  In  making  this  assessment,  the  loan  and  interest  receivables from  borrowers  are  assessed  individually  by  the  management  of  the  Group,  based  on  the  financial background,  financial  condition  and  the  historical  settlement  records,  including  past  due  dates  and default rates, of each borrower and reasonable and supportable forward-looking information (such as macroeconomic factors including Gross Domestic Product (' GDP ') growth and unemployment rate with adjustment on different scenarios of economic environment prospect) that is available without undue cost or effort.

Each borrower is assigned a risk grading under internal credit ratings to calculate the ECL, taking into consideration of the estimates of expected cash shortfalls which are driven by estimates of possibility of default and the amount and timing of cash flows that are expected from foreclosure on the collaterals (if  any)  less  the  costs  of  selling  the  collaterals.  At  every  reporting  date,  the  financial  background, financial  condition  and  the  historical  settlement  records  are  reassessed  and  changes  in  the  forwardlooking information are considered.

The management further assesses the amount of exposure of default to assess the potential loss as a result  of  the  risk  on  credit-impaired  loan  and  interest  receivables  to  which  the  Group  is  exposed  and take  appropriate  corrective  actions.  In  assessing  the  amount  of  exposure  of  default,  the  Group  takes into account the timing of cash flows that are expected from foreclosure on the collaterals less the costs of selling the collaterals.

The  provision  of  ECL  is  sensitive  to  changes  in  estimates.  Owing  to  greater  financial  uncertainty triggered  by  the  COVID  epidemic,  the  Group  has  increased  the  expected  loss  rates  in  the  current year as there is higher risk that a prolonged pandemic could led to increased credit default rates. The information about the ECL and the Group's loan and interest receivables are disclosed in Notes 37 and 22 respectively.

---

# Page 121

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 4. CRITICAL ACCOUNTING JUDGMENT AND KEY SOURCES OF ESTIMATION UNCERTAINTY (continued)


## Key sources of estimation uncertainty (continued)

Debt instrument at FVTOCI

The Group's debts instruments at FVTOCI are held within a business model whose objective is achieved by both collecting contractual cash flows and selling of these assets and the contractual cash flows of these investments are solely payments of principal and interest on the principal amount outstanding.


## Provision of ECL for debt instruments at FVTOCI

The  Group  performed  impairment  assessment  for  debt  instruments  at  FVTOCI  under  ECL  model individually. The determination of the loss allowances is dependent on the external macro environment and the credit rating of each debt securities. The management takes into consideration historical data from the international rating agency.

The  Group  determines  individually  whether  the  issuers  of  the  debt  instruments  have  been  credit impaired when one or more events that have a detrimental impact on the estimated future cash flows have occurred. Evidence that the debt instruments at FVTOCI are credit-impaired includes observable data including significant financial difficulty of the issuer; and the issuer is engaging in business that is unstable.

The provision of ECL involves significant estimates and judgments, including determination of whether there is significant increase in credit risk since initial recognition, use of assumptions in determination of  probability  of  default  and  loss  given  default,  incorporation  of  forward  looking  information. The  information  about  the  ECL  and  the  Group's  financial  assets  are  disclosed  in  Notes  37  and  21 respectively.

At 31 December 2022, the carrying amounts of debt instruments at FVTOCI was HK$33,739,000 (2021: HK$78,396,000) with provision of ECL of HK$11,081,000 (2021: HK$49,247,000) recognised during the year.


## Estimated impairment of property, plant and equipment and right-of-use assets

Property, plant and equipment and right-of-use assets are stated at costs less accumulated depreciation and  impairment,  if  any.  In  determining  whether  an  asset  is  impaired,  the  Group  has  to  exercise judgment  and  make  estimation,  particularly  in  assessing  whether  an  event  has  occurred  or  any indicators that may affect the recoverable amount of the assets. In estimating the value in use, the net present value of future cash flows which are estimated based upon the continued use of the asset and key assumptions applied, including cash flow projections and an appropriate discount rate. When it is not possible to estimate the recoverable amount of an individual asset (including right-of-use assets), the Group estimates the recoverable amount of the cash generating unit to which the assets belongs, including  allocation  of  corporate  assets  when  a  reasonable  and  consistent  basis  of  allocation  can  be established,  otherwise  recoverable  amount  is  determined  at  the  smallest  group  of  cash  generating units,  for  which  the  relevant  corporate  assets  have  been  allocated.  Changing  the  assumptions  and estimates, including the discount rates or the growth rate in the cash flow projections, could materially affect the recoverable amounts.

---

# Page 122

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 4. CRITICAL ACCOUNTING JUDGMENT AND KEY SOURCES OF ESTIMATION UNCERTAINTY (continued)


## Key sources of estimation uncertainty (continued)

Estimated impairment of property, plant and equipment and right-of-use assets (continued)

At 31 December 2022, the carrying amounts of property, plant and equipment and right-of-use assets, subject to impairment assessment were HK$218,781,000 and HK$2,590,000 (2021: HK$34,383,000 and HK$4,200,000) respectively, no impairment loss had been provided for the years ended 31 December 2022  and  31  December  2021  in  respect  of  property,  plant  and  equipment  and  right-of-use  assets respectively.


## 5. REVENUE

Revenue from major products and services

The  Group's  revenue  is  arising  from  petroleum  exploration  and  production,  solar  energy,  money lending and investment in securities businesses.


An analysis of the Group's revenue for the year is as follows:
|                                                  | 2022 HK$'000   | 2021 HK$'000   |
|--------------------------------------------------|----------------|----------------|
| Sales of petroleum                               | 39,821         | 1,847          |
| Less: Royalties                                  | (8,889)        | (324)          |
| Sales of petroleum, net of royalties             | 30,932         | 1,523          |
| Sales of electricity                             | 6,536          | 652            |
| Interest income from money lending business*     | 3,877          | 13,182         |
| Interest income from debt instruments at FVTOCI* | 3,605          | 8,871          |
| Dividend income from financial assets at FVTPL   | 152            | 268            |
|                                                  | 45,102         | 24,496         |
* Under effective interest method

---

# Page 123

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 5. REVENUE (continued)

Revenue from major products and services (continued)

During  the  year,  revenue  from  sales  of  petroleum  was  recognised  at  a  point  in  time.  Revenue  from sales of petroleum was recognised once the control of the crude oil was transferred from the Group to the customer. Revenue was measured based on the oil price agreed with the customers at the point of sales.

During the year, revenue from sales of electricity was recognised at a point in time when the electricity generated  (by  solar  energy  power  generation  systems)  and  transmitted  was  simultaneously  received and consumed by the power companies under the Renewable Energy Feed-in Tariff Scheme (the ' FiT Scheme '),  jointly  launched  by  the  Hong  Kong  Government  and  the  two  power  companies  in  Hong Kong. The Group has no unsatisfied performance obligations at each reporting date.

Dividend income and interest income fall outside the scope of HKFRS 15.


## 6. SEGMENT INFORMATION

The following is an analysis of the Group's revenue and results by operating segments, based on the information provided to the chief operating decision maker representing the Board, for the purposes of allocating resources to segments and assessing their performance. This is also the basis upon which the Group is arranged and organised.


The Group's operating segments under HKFRS 8 'Operating segments' are as follows:
- (i) Petroleum exploration and production
- (ii) Solar energy
- (iii) Money lending
- (iv) Investment in securities

---

# Page 124

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 6. SEGMENT INFORMATION (continued)


## Segment revenue and results

The following is an analysis of the Group's revenue and results by operating segments:


## For the year ended 31 December 2022


|                                           | Petroleum  exploration  and production HK$'000   | Solar energy HK$'000   | Money lending HK$'000   | Investment in securities HK$'000   | Total HK$'000   |
|-------------------------------------------|--------------------------------------------------|------------------------|-------------------------|------------------------------------|-----------------|
| Segment revenue                           |                                                  |                        |                         |                                    |                 |
| External sales/sources                    | 30,932                                           | 6,536                  | 3,877                   | 3,757                              | 45,102          |
| Results                                   |                                                  |                        |                         |                                    |                 |
| Segment results before   provision of ECL | 4,078                                            | 1,403                  | 3,782                   | 1,338                              | 10,601          |
| Provision of ECL                          | -                                                | -                      | (20,019)                | (11,081)                           | (31,100)        |
| Segment results                           | 4,078                                            | 1,403                  | (16,237)                | (9,743)                            | (20,499)        |
| Other income and losses, net              |                                                  |                        |                         |                                    | (8,818)         |
| Corporate expenses                        |                                                  |                        |                         |                                    | (17,772)        |
| Gain on disposal of subsidiaries          |                                                  |                        |                         |                                    | 159             |
| Finance costs                             |                                                  |                        |                         |                                    | (27)            |
| Loss before tax                           |                                                  |                        |                         |                                    | (46,957)        |
| Income tax credit                         |                                                  |                        |                         |                                    | 211             |
| Loss for the year                         |                                                  |                        |                         |                                    | (46,746)        |
| Other information                         |                                                  |                        |                         |                                    |                 |
| Depreciation of property,                 |                                                  |                        |                         |                                    |                 |
| plant and equipment                       | (7,973)                                          | (3,528)                | -                       | -                                  | (11,501)        |
| Depreciation of right-of-use assets       | -                                                | (226)                  | -                       | -                                  | (226)           |

---

# Page 125

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 6. SEGMENT INFORMATION (continued)


## Segment revenue and results (continued)

For the year ended 31 December 2021


|                                                      | exploration  and production HK$'000   | Solar energy HK$'000   | Money lending HK$'000   | Investment in securities HK$'000   | Total HK$'000   |
|------------------------------------------------------|---------------------------------------|------------------------|-------------------------|------------------------------------|-----------------|
| Segment revenue                                      |                                       |                        |                         |                                    |                 |
| External sales/sources                               | 1,523                                 | 652                    | 13,182                  | 9,139                              | 24,496          |
| Results                                              |                                       |                        |                         |                                    |                 |
| Segment results before reversal   (provision) of ECL | (4,112)                               | 89                     | 13,084                  | 16,714                             | 25,775          |
| Reversal (provision) of ECL                          | -                                     | -                      | 4,356                   | (49,247)                           | (44,891)        |
| Segment results                                      | (4,112)                               | 89                     | 17,440                  | (32,533)                           | (19,116)        |
| Other income and losses, net                         |                                       |                        |                         |                                    | 987             |
| Corporate expenses                                   |                                       |                        |                         |                                    | (13,025)        |
| Loss on disposal of subsidiaries                     |                                       |                        |                         |                                    | (397)           |
| Finance costs                                        |                                       |                        |                         |                                    | (75)            |
| Loss before tax                                      |                                       |                        |                         |                                    | (31,626)        |
| Income tax credit                                    |                                       |                        |                         |                                    | 2,255           |
| Loss for the year                                    |                                       |                        |                         |                                    | (29,371)        |
| Other information                                    |                                       |                        |                         |                                    |                 |
| Depreciation of property,   plant and equipment      |                                       |                        |                         |                                    |                 |
|                                                      | (34)                                  | (243)                  | -                       | -                                  | (277)           |
| Depreciation of right-of-use assets                  | (9)                                   | (64)                   | -                       | -                                  | (73)            |


The  accounting  policies  of  the  operating  segments  are  the  same  as  the  Group's  accounting  policies described  in  Note  3.  Segment  results  represent  the  profit  earned/loss  incurred  by  each  segment without allocation of certain other income and losses, net, corporate expenses, gain/loss on disposal of subsidiaries, certain finance costs and income tax credit.

---

# Page 126

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 6. SEGMENT INFORMATION (continued)


## Segment assets and liabilities


The following is an analysis of the Group's assets and liabilities by reportable and operating segments:
|                                      | 2022 HK$'000   | 2021 HK$'000   |
|--------------------------------------|----------------|----------------|
| Segment assets                       |                |                |
| Petroleum exploration and production | 203,649        | 1,256          |
| Solar energy                         | 50,890         | 47,599         |
| Money lending                        | 63,662         | 127,774        |
| Investment in securities             | 38,511         | 85,126         |
| Total segment assets                 | 356,712        | 261,755        |
| Unallocated:                         |                |                |
| Property, plant and equipment        | 653            | 854            |
| Cash and cash equivalents            | 73,914         | 177,911        |
| Right-of-use assets                  | 101            | 1,312          |
| Other assets                         | 2,309          | 1,083          |
| Consolidated assets                  | 433,689        | 442,915        |
| Segment liabilities                  |                |                |
| Petroleum exploration and production | 51,539         | 1,800          |
| Solar energy                         | 2,568          | 2,860          |
| Money lending                        | 2              | 25             |
| Total segment liabilities            | 54,109         | 4,685          |
| Unallocated:                         |                |                |
| Lease liabilities                    | 164            | 1,491          |
| Other liabilities                    | 3,103          | 10,749         |
| Consolidated liabilities             | 57,376         | 16,925         |



For the purposes of monitoring segment performances and allocating resources between segments:
- · all assets are allocated to operating segments other than certain property, plant and equipment, certain cash and cash equivalents, certain right-of-use assets and certain other assets; and
- · all  liabilities  are  allocated  to  operating  segments  other  than  certain  lease  liabilities  and  certain other liabilities.

---

# Page 127

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 6. SEGMENT INFORMATION (continued)


## Geographical information

The  Group's  operations  are  located  in  Canada,  Hong  Kong  and  the  PRC.  The  Group's  operation  in Argentina ceased in the current year.

Information  about  the  Group's  revenue  from  external  customers/sources  is  presented  based  on  the geographical  location  of  the  customers/sources.  Information  about  the  Group's  non-current  assets  is presented based on the geographical location of the assets.


|           | Revenue from external customers/sources   | Revenue from external customers/sources   | Non-current assets  (Note) At 31 December   | Non-current assets  (Note) At 31 December   |
|-----------|-------------------------------------------|-------------------------------------------|---------------------------------------------|---------------------------------------------|
|           | 2022                                      | 2021                                      | 2022                                        | 2021                                        |
|           | HK$'000                                   | HK$'000                                   | HK$'000                                     | HK$'000                                     |
| Canada    | 30,932                                    | -                                         | 185,615                                     | -                                           |
| Hong Kong | 14,170                                    | 21,008                                    | 50,990                                      | 48,285                                      |
| The PRC   | -                                         | 1,965                                     | -                                           | -                                           |
| Argentina | -                                         | 1,523                                     | -                                           | 172                                         |
|           | 45,102                                    | 24,496                                    | 236,605                                     | 48,457                                      |


Note: Non-current assets excluded debt instruments at FVTOCI.


## Information about major customers


Revenue from customers of the corresponding years contributing over 10% of the total revenue is as follows:
|               | 2022 HK$'000   | 2021 HK$'000   |
|---------------|----------------|----------------|
| Customer A  1 | 30,166         | -              |
| Customer B  2 | 6,536          | N/A 4          |
| Customer C  3 | -              | 3,300          |
Notes:
1 Revenue from petroleum exploration and production business
2 Revenue from solar energy business
3 Revenue from money lending business
4 The  corresponding  revenue  did  not  contribute  over  10%  of  the  total  revenue  of  the  Group  during  the relevant year

---

# Page 128

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 7. PURCHASES, PROCESSING AND RELATED EXPENSES


|                                                                  | 2022 HK$'000   | 2021 HK$'000   |
|------------------------------------------------------------------|----------------|----------------|
| Operating cost for petroleum exploration and production business | 12,703         | -              |
| Operating and maintenance cost for solar energy business         | 1,249          | 1,067          |
|                                                                  | 13,952         | 1,067          |



## 8. OTHER INCOME AND LOSSES, NET


|                                                | 2022 HK$'000   | 2021 HK$'000   |
|------------------------------------------------|----------------|----------------|
| Bank and other interest income                 | 1,343          | 83             |
| Government grants  (Note (i))                  | 228            | -              |
| Overprovision of accrued expenses  (Note (ii)) | -              | 1,920          |
| Exchange (loss) gain, net                      | (10,332)       | 453            |
| Modification loss on debt instrument at FVTOCI | (79)           | -              |
| Others                                         | 630            | (1,334)        |
|                                                | (8,210)        | 1,122          |



## Notes:

(i) During the year ended 31 December 2022, the Group recognised government grants of HK$228,000 (2021: nil) in respect of COVID-19-related subsidies which related to Employment Support Scheme provided by the Hong Kong Government.

(ii) During  the  year  ended  31  December  2021,  the  amount  represented  the  overprovision  of  legal  and professional expenses in relation to a possible acquisition in 2012 which the management had subsequently decided  not  to  proceed  with.  The  management  considered  the  possibility  of  settling  such  liabilities  as remote and the provision was reversed accordingly.

---

# Page 129

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 9. NET (LOSS) GAIN ON FINANCIAL ASSETS AT FAIR VALUE THROUGH PROFIT OR LOSS


|                                                                         | 2022 HK$'000   | 2021 HK$'000   |
|-------------------------------------------------------------------------|----------------|----------------|
| Net unrealised loss on financial assets at FVTPL  (Note (i))            | (1,952)        | (1,229)        |
| Net realised gain on disposal of financial assets at FVTPL  (Note (ii)) | -              | 9,099          |
|                                                                         | (1,952)        | 7,870          |



## Notes:

(i) The  amount  represented  the  change  in  the  fair  value  of  the  securities  acquired  during  the  year  and/or the  carrying  amount  of  the  securities  brought  forward  from  the  prior  financial  year  after  accounting  for additional acquisition and/or disposal of the securities (if any) during the year as compared to the fair value of the financial assets at FVTPL held by the Group at 31 December 2022 and 2021, respectively.


- (ii) The  amount  represented  the  change  in  the  fair  value  of  the  securities  acquired  during  the  year  and/or the  carrying  amount  of  the  securities  brought  forward  from  the  prior  financial  year  after  accounting  for additional acquisition of the securities (if any) during the year as compared to the fair values of the financial assets at FVTPL disposed of upon disposal.

---

# Page 130

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 10. GAIN (LOSS) ON DISPOSAL OF SUBSIDIARIES

During the years ended 31 December 2022 and 2021, the Group disposed of its entire equity interests in four (2021: five) subsidiaries to independent third parties.


|                                                                                                            | 2022 HK$'000   | 2021 HK$'000   |
|------------------------------------------------------------------------------------------------------------|----------------|----------------|
| Consideration received:                                                                                    |                |                |
| Consideration received in cash                                                                             | 8,800          | 29,100         |
| Assets and liabilities of the disposed subsidiaries   at the date of disposal:                             |                |                |
| Property, plant and equipment                                                                              | -              | 107            |
| Loan and interest receivables                                                                              | 7,881          | 30,904         |
| Other receivables                                                                                          | 4              | 60             |
| Cash and cash equivalents                                                                                  | 49             | 167            |
| Trade and other payables                                                                                   | (6)            | (1,714)        |
| Income tax payable                                                                                         | (599)          | (367)          |
| Net assets disposed of                                                                                     | 7,329          | 29,157         |
| Gain (loss) on disposal of subsidiaries:                                                                   |                |                |
| Consideration received                                                                                     | 8,800          | 29,100         |
| Net assets disposed of                                                                                     | (7,329)        | (29,157)       |
| Reclassification of cumulative translation reserve upon   disposal of foreign operations to profit or loss | (1,312)        | (340)          |
| Gain (loss) on disposal                                                                                    | 159            | (397)          |
| Net cash inflow arising on disposal:                                                                       |                |                |
| Cash consideration                                                                                         | 8,800          | 29,100         |
| Less: cash and cash equivalents disposed of                                                                | (49)           | (167)          |
|                                                                                                            | 8,751          | 28,933         |

---

# Page 131

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 11. FINANCE COSTS


|                                                            | 2022 HK$'000   | 2021 HK$'000   |
|------------------------------------------------------------|----------------|----------------|
| Accretion expense on decommissioning obligation  (Note 29) | 1,127          | -              |
| Interest on lease liabilities                              | 119            | 101            |
|                                                            | 1,246          | 101            |



## 12. INCOME TAX CREDIT


|                                                        | 2022 HK$'000   | 2021 HK$'000   |
|--------------------------------------------------------|----------------|----------------|
| Tax charge for the year comprises:                     |                |                |
| Current tax                                            |                |                |
| Hong Kong                                              | -              | (944)          |
| The PRC                                                | -              | (207)          |
|                                                        | -              | (1,151)        |
| Overprovision in prior years                           |                |                |
| Hong Kong                                              | 830            | 2,929          |
| The PRC                                                | -              | (101)          |
|                                                        | 830            | 2,828          |
| Withholding tax on interest income from a group entity | (619)          | -              |
| Deferred tax  (Note 28)                                | -              | 578            |
| Income tax credit recognised in profit or loss         | 211            | 2,255          |


Under  the  two-tiered  profits  tax  rates  regime  of  Hong  Kong,  the  first  HK$2  million  of  profits  of  the qualifying group entity will be taxed at 8.25%, and profits above HK$2 million will be taxed at 16.5%. The profits of group entities not qualifying for the two-tiered profits tax rates regime will continue to be taxed at a flat rate of 16.5%. Accordingly, the Hong Kong profits tax of the qualifying group entity is calculated at 8.25% on the first HK$2 million of the estimated assessable profits and at 16.5% on the estimated assessable profits above HK$2 million.

Under the Law of the PRC on Enterprise Income Tax (the ' EIT Law ') and Implementation Regulation of the EIT Law, the tax rate of the PRC subsidiaries is 25% for both years.

Withholding tax rate on the interest income from a Canadian subsidiary is 10%.

---

# Page 132

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 12. INCOME TAX CREDIT (continued)


The tax credit for the year can be reconciled to the loss before tax per the consolidated statement of profit or loss and other comprehensive income as follows:
|                                                                                  | 2022 HK$'000   | 2021 HK$'000   |
|----------------------------------------------------------------------------------|----------------|----------------|
| Loss before tax                                                                  | 46,957         | 31,626         |
| Tax at the applicable rates of 16.5% (2021: 16.5%)                               | 7,748          | 5,218          |
| Tax effect of income not taxable for tax purpose                                 | 2,404          | 435            |
| Tax effect of expenses not deductible for tax purpose                            | (2,528)        | (448)          |
| Tax effect of deductible temporary difference not recognised                     | -              | (5,686)        |
| Utilisation of deductible temporary difference previously not  recognised        | 517            | -              |
| Overprovision in prior years                                                     | 830            | 2,828          |
| Tax effect of tax losses not recognised                                          | (8,279)        | (187)          |
| Withholding tax on interest income from a subsidiary                             | (619)          | -              |
| Income tax at concessionary rate                                                 | -              | 165            |
| Effect of different tax rates of subsidiaries operating   in other jurisdictions | 138            | (70)           |
| Income tax credit for the year                                                   | 211            | 2,255          |



## 13. LOSS FOR THE YEAR


Loss for the year has been arrived at after charging:
|                                                                                   | 2022 HK$'000   | 2021 HK$'000   |
|-----------------------------------------------------------------------------------|----------------|----------------|
| Depreciation of property, plant and equipment                                     | 11,692         | 382            |
| Depreciation of right-of-use assets                                               | 1,438          | 1,284          |
| Total depreciation                                                                | 13,130         | 1,666          |
| Staff costs                                                                       |                |                |
| - directors' emoluments  (Note 14)                                                | 1,385          | 1,612          |
| - other staff costs                                                               | 5,710          | 7,386          |
| - other staff's retirement benefits schemes contributions   (excluding directors) | 205            | 801            |
| Total staff costs                                                                 | 7,300          | 9,799          |
| Auditor's remuneration                                                            | 2,332          | 1,198          |

---

# Page 133

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 14. DIRECTORS' AND CHIEF EXECUTIVE'S EMOLUMENTS


The emoluments paid or payable to each of the six (2021: seven) directors, disclosed pursuant to the applicable Listing Rules and Hong Kong Companies Ordinance, are as follows:
| Name                                | Fees HK$'000   | Salaries and other benefits HK$'000   | Retirement benefit  scheme contributions HK$'000   | Total HK$'000   |
|-------------------------------------|----------------|---------------------------------------|----------------------------------------------------|-----------------|
| 2022                                |                |                                       |                                                    |                 |
| Executive Directors                 |                |                                       |                                                    |                 |
| Mr. Sue Ka Lok                      | -              | 390                                   | 20                                                 | 410             |
| Mr. Yiu Chun Kong                   | -              | 130                                   | 7                                                  | 137             |
| Mr. Chan Shui Yuen                  | -              | 455                                   | 23                                                 | 478             |
| Independent Non-executive Directors |                |                                       |                                                    |                 |
| Mr. Pun Chi Ping                    | 120            | -                                     | -                                                  | 120             |
| Ms. Leung Pik Har, Christine        | 120            | -                                     | -                                                  | 120             |
| Mr. Kwong Tin Lap                   | 120            | -                                     | -                                                  | 120             |
| Total                               | 360            | 975                                   | 50                                                 | 1,385           |
| 2021                                |                |                                       |                                                    |                 |
| Executive Directors                 |                |                                       |                                                    |                 |
| Mr. Sue Ka Lok                      | -              | 390                                   | 20                                                 | 410             |
| Mr. Yiu Chun Kong                   | -              | 130                                   | 7                                                  | 137             |
| Mr. Chan Shui Yuen                  | -              | 490                                   | 25                                                 | 515             |
| Mr. Liang Weijie  (Note)            | -              | 190                                   | -                                                  | 190             |
| Independent Non-executive Directors |                |                                       |                                                    |                 |
| Mr. Pun Chi Ping                    | 120            | -                                     | -                                                  | 120             |
| Ms. Leung Pik Har, Christine        | 120            | -                                     | -                                                  | 120             |
| Mr. Kwong Tin Lap                   | 120            | -                                     | -                                                  | 120             |
| Total                               | 360            | 1,200                                 | 52                                                 | 1,612           |


Note: Appointed on 8 April 2021 and resigned on 18 October 2021

---

# Page 134

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 14. DIRECTORS' AND CHIEF EXECUTIVE'S EMOLUMENTS (continued)

The  executive  directors'  emoluments  shown  above  were  for  their  services  in  connection  with  the management  of  the  affairs  of  the  Company  and  the  Group.  The  emoluments  of  the  independent non-executive directors shown above were for their services as directors of the Company.

During the year, no emoluments were paid by the Group to any directors as an inducement to join, or upon joining the Group or as compensation for loss of office. No directors waived any emoluments for both years.


## 15. EMPLOYEES' EMOLUMENTS


Of the five individuals with the highest emoluments in the Group, one (2021: nil) of them was a director whose  emoluments  is  included  in  the  disclosure  in  Note  14.  The  emoluments  of  the  remaining  four (2021: five) individuals are as follows:
|                                           | 2022 HK$'000   | 2021 HK$'000   |
|-------------------------------------------|----------------|----------------|
| Salaries and other benefits               | 2,745          | 4,634          |
| Retirement benefits schemes contributions | 79             | 591            |
|                                           | 2,824          | 5,225          |



Their emoluments were within the following bands:
|                              | Number of employees   |   Number of employees |
|------------------------------|-----------------------|-----------------------|
|                              | 2022                  |                  2021 |
| Nil to HK$1,000,000          | 3                     |                     3 |
| HK$1,000,001 to HK$1,500,000 | 1                     |                     1 |
| HK$2,500,001 to HK$3,000,000 | -                     |                     1 |

---

# Page 135

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 16. DIVIDENDS

No  dividend  was  paid  or  proposed  for  the  year  ended  31  December  2022  (2021:  nil),  nor  has  any dividend been proposed since the end of the reporting period (2021: nil).


## 17. LOSS PER SHARE

Loss per share is calculated by dividing the loss for the year attributable to owners of the Company by the weighted average number of ordinary shares in issue during the year.


|                                                         | 2022 HK$'000   | 2021 HK$'000   |
|---------------------------------------------------------|----------------|----------------|
| Loss:                                                   |                |                |
| Loss for the year attributable to owners of the Company |                |                |
| for the purpose of calculating basic loss per share     | (46,746)       | (29,371)       |
|                                                         | 2022           | 2021           |
|                                                         | '000           | '000           |
| Number of shares:                                       |                |                |
| Weighted average number of ordinary shares for the      |                |                |
| purpose of calculating basic loss per share             | 5,240,344      | 5,240,344      |


For the years ended 31 December 2022 and 2021, the diluted loss per share attributable to owners of the Company are not presented as there were no dilutive potential ordinary shares in issue.

---

# Page 136

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 18. PROPERTY, PLANT AND EQUIPMENT


|                                                                | Oil and gas properties HK$'000 (Note (i))   | Solar photovoltaic systems HK$'000 (Note (ii))   | Construction in progress HK$'000 (Note (iii))   | Others HK$'000 (Note (iv))   | Total HK$'000   |
|----------------------------------------------------------------|---------------------------------------------|--------------------------------------------------|-------------------------------------------------|------------------------------|-----------------|
| Cost                                                           |                                             |                                                  |                                                 |                              |                 |
| At 1 January 2021                                              | 497,532                                     | -                                                | -                                               | 4,658                        | 502,190         |
| Additions                                                      | -                                           | 30,220                                           | 3,551                                           | 110                          | 33,881          |
| Eliminated on disposal of subsidiaries                         | -                                           | -                                                | -                                               | (1,738)                      | (1,738)         |
| Written-off                                                    | (497,532)                                   | -                                                | -                                               | -                            | (497,532)       |
| Exchange adjustment                                            | -                                           | -                                                | -                                               | 43                           | 43              |
| At 31 December 2021                                            | -                                           | 30,220                                           | 3,551                                           | 3,073                        | 36,844          |
| Additions                                                      | 2,538                                       | 10,580                                           | 21,992                                          | -                            | 35,110          |
| Acquired on acquisition of assets   and liabilities  (Note 32) | 169,338                                     | -                                                | -                                               | -                            | 169,338         |
| Reclassification                                               | 2,992                                       | 3,738                                            | (6,730)                                         | -                            | -               |
| Change in estimate in decommissioning  obligation  (Note 29)   | (245)                                       | -                                                | -                                               | -                            | (245)           |
| Written-off                                                    | -                                           | -                                                | -                                               | (1,222)                      | (1,222)         |
| Exchange adjustment                                            | (7,637)                                     | -                                                | (812)                                           | -                            | (8,449)         |
| At 31 December 2022                                            | 166,986                                     | 44,538                                           | 18,001                                          | 1,851                        | 231,376         |
| Depreciation and impairment                                    |                                             |                                                  |                                                 |                              |                 |
| At 1 January 2021                                              | 497,532                                     | -                                                | -                                               | 3,673                        | 501,205         |
| Provided for the year                                          | -                                           | 243                                              | -                                               | 139                          | 382             |
| Eliminated on disposal of subsidiaries                         | -                                           | -                                                | -                                               | (1,631)                      | (1,631)         |
| Written-off                                                    | (497,532)                                   | -                                                | -                                               | -                            | (497,532)       |
| Exchange adjustment                                            | -                                           | -                                                | -                                               | 37                           | 37              |
| At 31 December 2021                                            | -                                           | 243                                              | -                                               | 2,218                        | 2,461           |
| Provided for the year                                          | 7,973                                       | 3,528                                            | -                                               | 191                          | 11,692          |
| Written-off                                                    | -                                           | -                                                | -                                               | (1,213)                      | (1,213)         |
| Exchange adjustment                                            | (345)                                       | -                                                | -                                               | -                            | (345)           |
| At 31 December 2022                                            | 7,628                                       | 3,771                                            | -                                               | 1,196                        | 12,595          |
| Carrying values                                                |                                             |                                                  |                                                 |                              |                 |
| At 31 December 2022                                            | 159,358                                     | 40,767                                           | 18,001                                          | 655                          | 218,781         |
| At 31 December 2021                                            | -                                           | 29,977                                           | 3,551                                           | 855                          | 34,383          |

---

# Page 137

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 18. PROPERTY, PLANT AND EQUIPMENT (continued)


Notes:
- (i) The  oil  and  gas  properties  are  depreciated  on  a  unit-of-production  basis.  During  the  year  ended  31 December 2021, the Group's interest in the CHE Concession had been taken over by the new concessionaire on 13 March 2021, the oil and gas properties were therefore written-off.
- (ii) As  disclosed  in  the  announcements  of  the  Company  dated  30  August  2021  and  23  July  2021,  (a)  the Group entered into an acquisition agreement to acquire a portfolio of existing and to-be-completed solar photovoltaic  systems;  and  (b)  the  Group  entered  into  a  cooperation  framework  agreement  to  invest  in solar  energy power generation projects which are participating in the FiT Scheme. For the year ended 31 December 2021, the solar photovoltaic systems were depreciated on a straight-line basis of 5% per annum. With  effect  from  1  January  2022,  the  solar  photovoltaic  systems  have  been  depreciated  on  a  straightline  basis  until  the  end  of  the  validity  period  of  the  FiT  scheme,  i.e.  31  December  2033.  The  change  in depreciation rate has increased the depreciation charge for the year by HK$987,000.
- (iii) The amount represented the construction in progress of new oil wells and other production enhancement works  on  oil  wells  in  Canada,  which  are  expected  to  be  completed  within  a  year.  The  construction  in progress  of  solar  photovoltaic  systems  in  Hong  Kong  had  been  completed  and  reclassified  as  solar photovoltaic systems.
- (iv) The remaining items of property, plant and equipment were depreciated on a straight-line basis at 20% to 33 1 /3 % per annum after taking into account their estimated residual values.

---

# Page 138

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 19. RIGHT-OF-USE ASSETS


|                                                     | Offices and Buildings HK$'000   |
|-----------------------------------------------------|---------------------------------|
| Carrying amount                                     |                                 |
| At 31 December 2022                                 | 2,590                           |
| At 31 December 2021                                 | 4,200                           |
| For the year ended 31 December 2022                 |                                 |
| Depreciation charge                                 | 1,438                           |
| Written-off                                         | 172                             |
| Additions to right-of-use assets                    | -                               |
| Total cash outflow for leases                       | 1,645                           |
| Less: expenses relating to short-term leases        | (29)                            |
| Net cash outflow for leases in financing activities | 1,616                           |
| For the year ended 31 December 2021                 |                                 |
| Depreciation charge                                 | 1,284                           |
| Additions to right-of-use assets                    | 2,961                           |
| Total cash outflow for leases                       | 1,517                           |
| Less: expenses relating to short-term leases        | (76)                            |
| Net cash outflow for leases in financing activities | 1,441                           |

---

# Page 139

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 19. RIGHT-OF-USE ASSETS (continued)

For  both  years,  the  Group  leases  offices  and  buildings  for  its  operations.  Lease  contracts  are  entered into for a fixed term of one to twelve years, but may have termination option as described below. Lease terms are negotiated on an individual basis and contain a wide range of different terms and conditions. In determining the lease term and assessing the length of the non-cancellable period, the Group applies the definition of a contract and determines the period for which the contract is enforceable.

At 31 December 2022 and 2021, there were no outstanding lease commitments relating to short-term leases for office as disclosed above.

The Group has termination option in certain leases for its offices and buildings. Termination option is used to maximise operational flexibility in terms of managing the assets used in the Group's operations. The  termination  options  held  are  exercisable  only  by  the  Group  and  not  by  the  lessor.  The  Group reassessed the lease term at the reporting date and concluded not to exercise the termination options and hence the related lease payments during the lease period were included in the lease liabilities.


## Restrictions or covenants on leases

The  lease  agreements  do  not  impose  any  covenants  other  than  the  security  interests  in  the  leased assets that are held by the lessors. Leased assets may not be used as security for borrowing purposes.

---

# Page 140

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 20. DEPOSITS AND PREPAYMENTS, TRADE AND OTHER RECEIVABLES


|                                                               | 2022 HK$'000   | 2021 HK$'000   |
|---------------------------------------------------------------|----------------|----------------|
| Deposit paid for decommissioning obligation  (Note (i))       | 8,256          | -              |
| Prepayment for acquisition of non-current assets  (Note (ii)) | 6,978          | 9,874          |
| Trade receivables  (Note (iii))                               | 5,232          | 194            |
| Deposits and prepayments                                      | 4,826          | 1,316          |
| Others                                                        | 340            | 100            |
|                                                               | 10,398         | 1,610          |



## Notes:

(i) The  amount  represented  a  refundable  deposit  paid  to  Alberta  Energy  Regulator  in  relation  to decommissioning obligation of the Group's of petroleum exploration and production business in Canada.

(ii) The  amount  represented  prepayment  for  the  acquisition  of  solar  photovoltaic  systems  in  relation  to  the Group's solar energy business, which would be utilised as consideration upon completion of the acquisition. The management expects the acquisition would be completed within one year.


- (iii) The Group allows an average credit period of 30 to 60 days (2021: 30 to 60 days). The trade receivables of HK$5,232,000 (2021: HK$194,000) were aged within 30 days based on the customers' statement date and were neither past due nor impaired.


Before accepting any new customer, the Group assesses the potential customer's credit quality and defines credit  limits  by  customer.  Credit  limit  and  credit  quality  attributed  to  customers  are  reviewed  by  the management regularly.

Details of impairment assessment of trade receivables are set out in Note 37.

---

# Page 141

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 20. DEPOSITS AND PREPAYMENTS, TRADE AND OTHER RECEIVABLES (continued)


Included in trade and other receivables were the following amounts denominated in currencies other than the functional currency of the relevant group entities:
|                          | 2022 HK$'000   |   2021 HK$'000 |
|--------------------------|----------------|----------------|
| Argentina Peso (' ARS ') | -              |              6 |



## 21. DEBT INSTRUMENTS AT FAIR VALUE THROUGH OTHER COMPREHENSIVE INCOME


|                                                                                                                                                                                                                                                  | 2022 HK$'000   | 2021 HK$'000   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|----------------|
| Listed investments, at fair value:                                                                                                                                                                                                               |                |                |
| - De  bt securities listed in Hong Kong or Singapore with fixed  interests ranging from 5.25% to 11.75% (2021: 4.70% to  11.75%) per annum and maturity dates ranging from 23  March 2022 to 28 June 2025 (2021: 8 March 2022 to 28   June 2025) | 33,739         | 78,396         |
| Analysed as:                                                                                                                                                                                                                                     |                |                |
| Current portion                                                                                                                                                                                                                                  | 28,041         | 47,712         |
| Non-current portion                                                                                                                                                                                                                              | 5,698          | 30,684         |
|                                                                                                                                                                                                                                                  | 33,739         | 78,396         |


At 31 December 2022 and 2021, the fair values of debt instruments at FVTOCI were determined based on quoted market prices and credit risk adjustments on certain debt instruments.

The Group had engaged an independent professional valuer to perform ECL assessment on the debt instruments. The Company's management worked closely with the independent professional valuer to establish the appropriate valuation techniques and inputs to the model for ECL assessment. In making that  evaluation,  the  Group  assessed  ECL  for  debt  instruments  at  FVTOCI  by  reference  to  the  credit rating  of  the  debt  instruments  estimated  by  the  recognised  rating  agencies  (i.e.  Moody's,  Fitch),  the macroeconomic factors and the changes in market conditions affecting each issuer, and the probability of  default and loss given default of each debt instrument. The Group also took into account forwardlooking information that was reasonably and supportably available to the Group without undue cost or effort, including information such as GDP growth rate and unemployment rate.

---

# Page 142

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 21. DEBT INSTRUMENTS AT FAIR VALUE THROUGH OTHER COMPREHENSIVE INCOME (continued)

Provision  of  ECL  of  HK$11,081,000  (2021:  HK$49,247,000)  was  recognised  in  profit  or  loss  with corresponding adjustment to other comprehensive income for the year.

Details  of  impairment  assessment  are  set  out  in  Note  37.  All  debt  instruments  at  FVTOCI  were denominated in US$.


## 22. LOAN AND INTEREST RECEIVABLES


|                                     | 2022 HK$'000   | 2021 HK$'000   |
|-------------------------------------|----------------|----------------|
| Fixed-rate loan receivables  (Note) | 84,000         | 140,378        |
| Interest receivables                | 652            | 9,538          |
|                                     | 84,652         | 149,916        |
| Less: Impairment allowance          | (23,800)       | (34,915)       |
|                                     | 60,852         | 115,001        |
| Analysed as:                        |                |                |
| Current portion                     | 60,852         | 115,001        |
| Analysed as:                        |                |                |
| Secured                             | 51,494         | 115,001        |
| Unsecured                           | 9,358          | -              |
|                                     | 60,852         | 115,001        |


Note:

Included  in  loan  receivables  was  an  unsecured  loan  of  principal  amount  of  HK$12,500,000  (2021:  nil) carrying  interest  at  8.5%  per  annum  lent  to  a  related  party  of  the  Company (Note  35) . In  March  2023, loan  principal  of  HK$7,500,000  has  been  repaid,  and  maturity  date  of  the  remaining  loan  principal  of HK$5,000,000 has been extended to 19 December 2023 with interest rate being revised from 8.5% to 10.5% per annum.

---

# Page 143

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 22. LOAN AND INTEREST RECEIVABLES (continued)

The range of interest rates and maturity dates attributed to the Group's performing loan receivables at 31 December 2022 were 10.5% to 18.0% (2021: 10.0% to 18.0%) per annum and from 27 April 2023 to 19 December 2023 (2021: from 12 March 2022 to 13 August 2022) respectively.


An analysis of the Group's loan and interest receivables by their contractual maturity dates is as follows:
|                                | 2022 HK$'000   | 2021 HK$'000   |
|--------------------------------|----------------|----------------|
| Loan and interest receivables: |                |                |
| Within one year or on demand   | 60,852         | 115,001        |


Before  granting  loans  to  borrowers,  the  Group  uses  internal  credit  assessment  process  to  assess  the potential borrowers' credit quality individually and defines the credit limits granted to the borrowers. The credit limits attributed to the borrowers are reviewed by the management regularly.


## Impairment assessment

In  assessing  whether  the  credit  risk  has  increased  significantly  since  initial  recognition,  the  Group compares the risk of a default occurring on the financial instrument at the reporting date with the risk perceived at the date of initial recognition. In making this assessment, the loan and interest receivables from  borrowers  are  assessed  individually  by  the  management  of  the  Group,  based  on  the  financial background,  financial  condition  and  historical  settlement  records,  including  past  due  dates  and probability of default, of each borrower and reasonable and supportable forward-looking information that is available without undue cost or effort. Each borrower is assigned a risk grading under internal credit ratings to calculate the ECL, taking into consideration the estimates of expected cash shortfalls which are  driven  by  estimates  of  possibility  of  default  and  the  expected  loss  given  default  including taking  into  account  the  amount  and  timing  of  cash  flows  that  are  expected  from  foreclosure  on the  collaterals  (if  any)  less  the  costs  of  selling  the  collaterals.  At  every  reporting  date,  the  financial background, financial condition and historical settlement records of each borrower are reassessed and changes in the forward-looking information are considered.

---

# Page 144

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 22. LOAN AND INTEREST RECEIVABLES (continued)

Impairment assessment (continued)

At  31  December  2022,  included  in  the  Group's  loan  and  interest  receivables  were  debtors  with aggregate gross carrying amount of HK$84,652,000 (2021: HK$149,916,000), of which (i) HK$23,500,000 (2021:  HK$44,596,000)  was  secured  by  the  borrowers'  pledged  properties,  the  market  value  of  the properties  less  the  estimated  costs  to  sell  amounted  to  HK$14,169,000  (2021:  HK$29,306,000)  and cumulative ECL of HK$9,473,000 (2021: HK$15,162,000) was provided after considering the adjustment to reflect loss given default based on the expected realisation value of the collaterals; (ii) HK$33,589,000 (2021:  HK$70,959,000)  was  secured  by  the  borrowers'  pledged  unlisted  debt  instruments  issued  by  a listed company in Hong Kong with principal amount totalling HK$100,000,000 (2021: HK$200,000,000), cumulative  ECL  of  HK$9,782,000  (2021:  nil)  was  provided  after  considering  the  adjustment  to  reflect loss given default based on the expected realisation value of the collaterals; (iii) HK$15,025,000 (2021: HK$15,024,000)  was  secured  by  the  borrowers'  own  unlisted  debt  instrument  pledged,  cumulative ECL of HK$1,365,000 (2021: HK$416,000) was provided after considering the adjustment to reflect loss given default based on the expected realisation value of the collaterals; and (iv) the remaining amount of  HK$12,538,000  (2021:  HK$19,337,000)  was  not  secured  by  any  collateral  or  credit  enhancement and  cumulative  ECL  of  HK$3,180,000  (2021:  HK$19,337,000)  was  provided  based  on  the  ECL assessment performed. At 31 December 2022, loans were granted to a Hong Kong resident, companies incorporated in Hong Kong and British Virgin Islands, and a company listed on the Hong Kong Stock Exchange.

The Group considers various actions for recovery of the credit-impaired loan including regular collateral reviews  and  interviews  with  the  borrower  to  update  the  credit  risk  of  the  borrower.  In  the  event  of default,  the  Group  might  take  possession  of  assets  held  as  collateral  through  court  proceeding  or voluntary delivery of possession by the borrower. The credit quality review process enables the Group to assess the potential loss as a result of the risk to which it is exposed and take appropriate corrective actions.

At  31  December  2022,  of  the  Group's  loan  and  interest  receivables  with  aggregate  gross  carrying amount of  HK$84,652,000  (2021:  HK$149,916,000),  (i)  HK$15,062,000  (2021:  HK$57,572,000)  were  not past  due;  (ii)  nil  (2021:  HK$34,134,000)  had  been  past  due  for  less  than  30  days;  (iii)  HK$12,500,000 (2021:  HK$537,000)  had  been  past  due  for  more  than  30  days  but  less  than  90  days;  and  (iv) HK$57,090,000  (2021:  HK$57,673,000)  had  been  past  due  for  90  days  or  more.  The  directors  of  the Company considered those secured loan and interest receivables that were past due for more than 90 days and unsecured loan and interest receivables that were past due for more than 30 days as creditimpaired, details of the cumulative ECL provided are set out above.

The Group recognised impairment allowance of HK$20,019,000 (2021: reversal of impairment allowance of HK$4,356,000) on loan and interest receivables for the current year.

---

# Page 145

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 22. LOAN AND INTEREST RECEIVABLES (continued)

Impairment assessment (continued)

The Group is not permitted to sell or repledge the collaterals in the absence of default by the borrowers. There had not been any significant changes in the quality of the collateral held for the loan and interest receivables.


The movement of impairment allowance on loan and interest receivables for the year is as follows:
|                                                                             | 12m ECL HK$'000   | Lifetime ECL (credit- impaired)  HK$'000   | Total HK$'000   |
|-----------------------------------------------------------------------------|-------------------|--------------------------------------------|-----------------|
| At 1 January 2021                                                           | 611               | 49,090                                     | 49,701          |
| Changes due to loan and interest receivables  recognised at 1 January 2021: |                   |                                            |                 |
| - Impairment allowance recognised  (Note (i))                               | 2,195             | 12,677                                     | 14,872          |
| - Impairment allowance reversed  (Note (ii))                                | (6)               | (20,068)                                   | (20,074)        |
| - Disposal of subsidiaries  (Note (iii))                                    | (3,230)           | (7,200)                                    | (10,430)        |
| New loans granted during the year                                           | 846               | -                                          | 846             |
| At 31 December 2021                                                         | 416               | 34,499                                     | 34,915          |
| Changes due to loan and interest receivables  recognised at 1 January 2022: |                   |                                            |                 |
| - Impairment allowance recognised  (Note (iv))                              | 949               | 15,890                                     | 16,839          |
| - Disposal of subsidiaries  (Note (v))                                      | -                 | (10,928)                                   | (10,928)        |
| - Write off of impairment allowance  (Note (vi))                            | -                 | (20,206)                                   | (20,206)        |
| New loan granted during the year                                            | -                 | 3,180                                      | 3,180           |
| At 31 December 2022                                                         | 1,365             | 22,435                                     | 23,800          |

---

# Page 146

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 22. LOAN AND INTEREST RECEIVABLES (continued)

Impairment assessment (continued)


Notes:
- (i) The  impairment  loss  of  HK$12,677,000  and  HK$2,195,000  were  mainly  related  to  loan  and  interest receivables with gross carrying amount of HK$76,044,000 assessed under lifetime ECL (credit-impaired) and HK$19,894,000 assessed under 12m ECL.
- (ii) The impairment allowance reversed of HK$6,000 was related to settlement of loan and interest receivables with gross carrying amount of HK$1,810,000 assessed under 12m ECL. The impairment allowance reversed of  HK$20,068,000  was  mainly  related  to  settlement  of  loan  and  interest  receivables  with  gross  carrying amount of HK$42,824,000 assessed under lifetime ECL (credit-impaired).
- (iii) The impairment allowance reversed of HK$10,430,000 was related to disposal of subsidiaries with loan and interest receivables of gross carrying amount of HK$41,334,000 as of the disposal date.
- (iv) The  impairment  loss  of  HK$15,890,000  and  HK$949,000  were  mainly  related  to  loan  and  interest receivables with gross carrying amount of HK$76,768,000 assessed under lifetime ECL (credit-impaired) and HK$15,025,000 assessed under 12m ECL.
- (v) The impairment allowance reversed of HK$10,928,000 was related to disposal of subsidiaries with loan and interest receivables of gross carrying amount of HK$18,809,000 as of the disposal date.
- (vi) The impairment allowance written off of HK$20,206,000 was related to loan and interest receivables with gross carrying amount of HK$20,206,000 assessed under life-time ECL (credit-impaired).


Details of ECL assessment are set out in Note 37.


## 23. OTHER TAX RECOVERABLE

Pursuant  to  the  relevant  rules  and  regulation  in  Argentina,  value-added  tax  on  expenditure  incurred in  drilling  and  purchase  of  property,  plant  and  equipment  relating  to  the  petroleum  exploration  and production operation in Argentina can be used to offset future value-added tax on sales made. As at 31 December 2022, no tax will be recovered as the Group's operation in Argentina ceased (2021: the Group was searching for potential oilfield projects in Argentina and the directors of the Company considered that an amount of HK$732,000 would be recovered from the sales of petroleum).

As  at  31  December  2022,  other  tax  recoverable  of  HK$204,000  (2021:  nil)  represented  goods  and services tax receivables in Canada.

---

# Page 147

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 24. FINANCIAL ASSETS AT FAIR VALUE THROUGH PROFIT OR LOSS


|                                         | 2022 HK$'000   | 2021 HK$'000   |
|-----------------------------------------|----------------|----------------|
| Listed investments, at fair value:      |                |                |
| - Equity securities listed in Hong Kong | 4,772          | 6,724          |


Listed equity securities were stated at fair values which were determined based on the quoted market closing prices available on the Hong Kong Stock Exchange.


## 25. CASH AND CASH EQUIVALENTS

Bank  balances  include  short-term  deposits  matured  within  3  months  carried  interest  ranging  from 0.01% to 5.00% (2021: 0.01% to 0.60%) per annum.

The  directors  of  the  Company  considered  that  the  amount  of  ECL  on  cash  and  cash  equivalents  was immaterial.


In  addition,  included  in  the  cash  and  cash  equivalents  were  the  following  amounts  denominated  in currencies other than the functional currency of the relevant group entities:
|     | 2022 HK$'000   | 2021 HK$'000   |
|-----|----------------|----------------|
| ARS | -              | 18             |
| US$ | 1,862          | 31,946         |
| RMB | 11             | 11             |
| C$  | 31             | 11             |

---

# Page 148

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 26. TRADE AND OTHER PAYABLES


|                                                                       | 2022 HK$'000   | 2021 HK$'000   |
|-----------------------------------------------------------------------|----------------|----------------|
| Trade payables                                                        | -              | 129            |
| Other tax payables                                                    | -              | 1,178          |
| Accrued professional fees                                             | 279            | 390            |
| Payables for acquisition of property, plant and equipment  (Note (i)) | 12,720         | 7,388          |
| Other payables and accruals  (Note (ii))                              | 7,806          | 2,767          |
|                                                                       | 20,805         | 11,852         |



## Notes:

(i) At 31 December 2022, the amount of HK$12,720,000 was related to the acquisition of oil and gas properties with  credit  period  of  60  days  (2021:  HK$7,388,000  was  related  to  the  acquisition  of  solar  photovoltaic systems with credit period of 45 days).

(ii) At  31  December  2022,  the  amount  included  other  payables  of  HK$3,958,000  (2021:  nil)  related  to  the operating expenses, workover costs and abandonment costs in relation to the petroleum exploration and production business in Canada.


The following is an aged analysis of trade payables, presented based on the invoice date, at the end of the reporting period:
|             | 2022 HK$'000   |   2021 HK$'000 |
|-------------|----------------|----------------|
| 0 - 30 days | -              |            129 |


The average credit period on purchases of goods was 30 days.

All the other payables were unsecured, interest-free and expected to be settled within one year.


Included in trade and other payables were the following amount denominated in currency other than the functional currency of the relevant group entities:
|     | 2022 HK$'000   | 2021 HK$'000   |
|-----|----------------|----------------|
| ARS | -              | 1,752          |

---

# Page 149

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 27. LEASE LIABILITIES


|                                                            | 2022 HK$'000   | 2021 HK$'000   |
|------------------------------------------------------------|----------------|----------------|
| Lease liabilities payable:                                 |                |                |
| Within one year                                            | 374            | 1,574          |
| More than one year but not exceeding two years             | 200            | 418            |
| More than two years but not exceeding five years           | 643            | 906            |
| More than five years                                       | 1,508          | 1,496          |
|                                                            | 2,725          | 4,394          |
| Less: Amount due within one year shown current liabilities | (374)          | (1,574)        |
| Amount due after one year                                  | 2,351          | 2,820          |


The weighted average incremental borrowing rate applied to lease liabilities was 3.41% (2021: 3.41%).


Included  in  lease  obligations  were  the  following  amount  denominated  in  currency  other  than  the functional currency of the relevant group entities:
|     | 2022 HK$'000   |   2021 HK$'000 |
|-----|----------------|----------------|
| ARS | -              |            172 |

---

# Page 150

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 28. DEFERRED TAX LIABILITIES


The movement of deferred tax liabilities is as follows:
|                                           | Net unrealised  gain on  financial assets  at FVTPL HK$'000   |
|-------------------------------------------|---------------------------------------------------------------|
| At 1 January 2021                         | 578                                                           |
| Credited to profit or loss  (Note 12)     | (578)                                                         |
| At 31 December 2021 and  31 December 2022 | -                                                             |


At  31  December  2022,  the  Group  had  unused  tax  losses  of  HK$102,077,000  (2021:  HK$81,249,000) available for offset against future profits. No deferred tax asset has been recognised in respect of the unused tax losses due to the unpredictability of future profit streams. Included in unused tax losses are losses of HK$16,159,000 (2021: HK$3,762,000) that will expire within twenty (2021: five) years from year 2023 to 2042 (2021: from year 2022 to 2026). All other tax losses may be carried forward indefinitely.

At 31 December 2022, the Group had deductible temporary differences of approximately HK$1,365,000 (2021:  HK$15,578,000)  arising  from  impairment  allowance  of  loan  and  interest  receivables;  and HK$67,432,000  (2021:  HK$56,351,000)  arising  from  impairment  allowance  of  debt  instruments  at FVTOCI,  no  deferred  tax  assets  had  been  recognised  due  to  the  unpredictability  of  future  profits streams.


## 29. DECOMMISSIONING OBLIGATION


|                                                                   | HK$'000   |
|-------------------------------------------------------------------|-----------|
| At 1 January 2021 and 31 December 2021                            | -         |
| Addition through acquisition of assets and liabilities  (Note 32) | 33,877    |
| Change in estimate  (Note 18)                                     | (245)     |
| Accretion expenses  (Note 11)                                     | 1,127     |
| Exchange realignment                                              | (1,531)   |
| At 31 December 2022                                               | 33,228    |

---

# Page 151

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 30. SHARE CAPITAL


|                                                                                           | Number of  ordinary  shares '000   | Share  capital HK$'000   |
|-------------------------------------------------------------------------------------------|------------------------------------|--------------------------|
| Authorised:                                                                               |                                    |                          |
| Ordinary shares of HK$0.01 each At 1 January 2021, 31 December 2021 and  31 December 2022 | 100,000,000                        | 1,000,000                |
| Issued and fully paid:                                                                    |                                    |                          |
| Ordinary shares of HK$0.01 each                                                           |                                    |                          |
| At 1 January 2021, 31 December 2021 and  31 December 2022                                 | 5,240,344                          | 52,403                   |



## 31. SHARE OPTION SCHEME

The  existing  share  option  scheme  of  the  Company  (the  ' Share  Option  Scheme ')  was  adopted  by the Company at the annual general meeting of the Company held on 22 June 2016. Unless otherwise cancelled  or  amended,  the  Share  Option  Scheme  will  be  valid  and  effective  for  a  period  of  ten  years commencing on the date of adoption. The purpose of the Share Option Scheme is to enable the Group to grant options to the participants as incentives or rewards for their contribution to the Group or any entity in which the Group holds any equity interest (the ' Invested Entity '). Eligible participants of the Share Option Scheme include any employees of any member of the Group or any Invested Entity; any directors (including executive, non-executive and independent non-executive directors) of any member of the Group or any Invested Entity; any supplier of goods or services to any member of the Group or any Invested Entity; any customer of any member of the Group or any Invested Entity; any person or entity that provides research, development or other technological support to any member of the Group or  any  Invested  Entity;  any  consultant  or  adviser  of  any  member  of  the  Group  or  any  Invested  Entity; and any shareholder of any member of the Group or any Invested Entity or any holder of any securities issued by any member of the Group or any Invested Entity.

The  offer  of  a  grant  of  share  options  shall  remain  open  for  acceptance  by  the  participant  concerned for  a  period  of  fifteen  (15)  business  days  from  the  date  of  grant  provided  that  no  such  offer  shall  be open for acceptance after the expiry of the option period or after the Share Option Scheme has been terminated. The amount payable by each grantee of options to the Company on acceptance of the offer for the grant of options is HK$1.00.

---

# Page 152

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 31. SHARE OPTION SCHEME (continued)

The subscription price for the shares on the exercise of options under the Share Option Scheme shall be a price determined by the Board in its absolute discretion at the time of the grant of the relevant option (and  shall  be  stated  in  the  letter  containing  the  offer  of  the  grant  of  the  option)  but  in  any  case  the subscription price shall not be less than the higher of: (i) the closing price of the shares as stated in the Hong Kong Stock Exchange's daily quotations sheet on the date of grant which must be a business day; (ii) the average closing price of the shares as stated in the Hong Kong Stock Exchange's daily quotations sheets for the five business days immediately preceding the date of grant; and (iii) the nominal value of the share. The exercise period of the share options granted is determined by the Board but in any event, no longer than ten years from the date of grant.

The  total  number  of  shares  issued  and  to  be  issued  upon  exercise  of  the  options  granted  to  each participant,  together  with  all  options  granted  and  to  be  granted  to  the  participant  under  any  other share  option  scheme(s)  of  the  Company  within  the  12-month  period  immediately  preceding  the proposed date of grant (including exercised, cancelled and outstanding options) shall not exceed 1% of the total number of the shares in issue at the proposed date of grant. Any further grant of options to a participant in excess of the 1% limit shall be subject to the approval of the Company's shareholders with such participant and the participant's associates abstaining from voting.

The limit on the total number of shares which may be issued upon exercise of all outstanding options granted and yet to be exercised under the Share Option Scheme and any other share option scheme(s) of  the  Company  must  not  exceed  30%  of  the  total  number  of  the  shares  in  issue  from  time  to  time. In  addition,  the  total  number  of  the  shares  which  may  be  issued  upon  exercise  of  all  options  to  be granted under the Share Option Scheme, together with all options to be granted under any other share option scheme(s) of the Company (excluding lapsed options), must not represent more than 10% of the total number of the shares in issue at the date of approval of the Share Option Scheme (the ' Scheme Mandate Limit ')  or  at  the  date  of  the  approval  of  the  refreshed  Scheme  Mandate  Limit  as  the  case maybe.

On  4  May  2017,  the  Company  granted  share  options  to  eligible  persons  to  subscribe  for  a  total  of 436,710,000 ordinary shares of the Company under the Share Option Scheme. The exercise price of the options granted is HK$0.53 per share and the exercisable period was from 4 May 2017 to 3 May 2020 (both dates inclusive).

On 4 May 2020, all the outstanding share options were lapsed.

At the annual general meeting of the Company held on 29 June 2021, the shareholders of the Company approved the refreshment of the Scheme Mandate Limit (the ' Scheme Mandate Limit Refreshment '). The  total  number  of  shares  of  the  Company  available  for  issue  under  the  Share  Option  Scheme  is 524,034,404 shares as refreshed, representing approximately 10% of the issued shares of the Company as  at  the  date  of  approval  of  the  Scheme  Mandate  Limit  Refreshment  and  at  the  date  of  this  annual report.

At 31 December 2022 and 31 December 2021, there were no outstanding share options.

---

# Page 153

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 32. ACQUISITION OF ASSETS AND LIABILITIES

On  9  February  2022,  the  Group  entered  into  an  asset  purchase  and  sale  agreement  with  RockEast Energy  Corp.  for  the  acquisition  of  an  operating  oilfield  which  comprises  petroleum  and  natural  gas rights, facilities and pipelines, together with all other properties and assets located in Alberta Province in  Canada  (' Canadian  Oil  Assets ').  On  16  July  2022,  the  acquisition  of  the  Canadian  Oil  Assets  was completed.  The  directors  of  the  Company  have  elected  to  apply  the  optional  concentration  test  in accordance with HKFRS 3 and concluded that the transaction was an acquisition of assets and liabilities as  the  Canadian Oil Assets are concentrated in a group of similar identifiable assets of similar nature. In  addition,  the  directors  of  the  Company  are  also  of  the  opinion  that  the  Canadian  Oil  Assets  is  the smallest identifiable group of assets that generates cash flows.


Details of the acquisition are summarised as follows:
|                                                                                     | HK$'000   |
|-------------------------------------------------------------------------------------|-----------|
| Net assets acquired:                                                                |           |
| Property, plant and equipment  (Note 18)                                            | 169,338   |
| Decommissioning obligation  (Note 29)                                               | (33,877)  |
|                                                                                     | 135,461   |
| Analysis of net outflow of cash and cash equivalents in respect of the acquisition: |           |
| Cash consideration paid                                                             | 135,461   |

---

# Page 154

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 33. RECONCILIATION OF LIABILITIES ARISING FROM FINANCING ACTIVITIES

The table below details changes in the Group's liabilities arising from financing activities, including both cash and non-cash changes. Liabilities arising from financing activities are those for which cash flows were, or future cash flows will be, classified in the Group's consolidated statement of cash flows as cash flows from financing activities.


|                      | Lease  liabilities HK$'000   |
|----------------------|------------------------------|
| At 1 January 2021    | 2,773                        |
| Financing cash flows | (1,441)                      |
| New lease entered    | 2,961                        |
| Interest expense     | 101                          |
| At 31 December 2021  | 4,394                        |
| Financing cash flows | (1,616)                      |
| Interest expense     | 119                          |
| Written-off          | (172)                        |
| At 31 December 2022  | 2,725                        |

---

# Page 155

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 34. RETIREMENT BENEFIT SCHEMES

The Group contributes to MPF Scheme for all qualifying employees in Hong Kong under the Mandatory Provident Fund Schemes Ordinance (Chapter 485 of the Laws of Hong Kong). Contributions to the MPF Scheme by the Group and the employees are calculated  as  a  percentage  of  the  employee's  relevant income.  The  retirement  benefit  scheme  costs  recognised  in  profit  or  loss  represent  contributions payable by the Group to the scheme. The assets of the MPF Scheme are held separately from those of the Group in independently administered funds.

The  Group  also  participates  in  the  employees'  pension  scheme  of  the  respective  municipal governments  in  the  countries  where  the  Group  operates.  The  Group  makes  monthly  contributions calculated  as  a  percentage  of  the  monthly  basic  salary  of  the  employees  and  the  relevant  municipal government undertakes to assume the retirement benefit obligations of all existing and future retirees of the Group.

The Group has no other obligations for the payment of pension and other post-retirement benefits of employees other than the above contributions payments.

The total expense recognised in profit or loss of HK$255,000 (2021: HK$853,000) represents contribution paid/payable to these schemes by the Group at rates specified in the rules of the schemes.


## 35. RELATED PARTY TRANSACTIONS


The Group had the following transactions and balance with the related parties during the year:
|                           | Notes   | Nature of transaction/balance   | 2022 HK$'000   | 2021 HK$'000   |
|---------------------------|---------|---------------------------------|----------------|----------------|
| Relationship              |         |                                 |                |                |
| A related company         | (i)     | Loan interest income            | 483            | -              |
|                           |         | Loan and interest receivables   | 12,538         | -              |
| An individual shareholder | (ii)    | Consultancy fee                 | 130            | 130            |
Notes:
(i) The  related  company  is  a  public  limited  liability  company  whose  shares  are  listed  on  the  Main  Board  of the Hong Kong Stock Exchange. The related company and the Company were both indirectly owned by an individual shareholder who held more than 10%, but less than 30%, of the issued shares of both companies. The board of directors of the related company and the Company had four common directors.
(ii) The individual shareholder of the Company held more than 10%, but less than 30%, of the Company's issued shares.

---

# Page 156

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 35. RELATED PARTY TRANSACTIONS (continued)

Compensation of key management personnel


The remuneration of directors and other members of key management during the year is as follows:
|                                          | 2022 HK$'000   | 2021 HK$'000   |
|------------------------------------------|----------------|----------------|
| Short-term employee benefits             | 2,441          | 5,774          |
| Retirement benefit schemes contributions | 67             | 546            |
|                                          | 2,508          | 6,320          |


The  remuneration  of  directors  and  key  management  is  determined  by  the  Remuneration  Committee having regard to the competence, performance and experience of the individuals and prevailing market terms.


## 36. CAPITAL RISK MANAGEMENT

The  Group's  objectives  when  managing  capital  are  to  safeguard  the  Group's  ability  to  continue  as  a going concern in order to provide returns for shareholders and benefits for other stakeholders and to maintain an optimal capital structure to reduce the cost of capital.

In order to maintain the capital structure, the Group will balance its overall capital structure through the payment of dividends, new share issues as well as raise of new debts.

The  Group  does  not  have  a  target  gearing  ratio,  but  has  a  policy  of  maintaining  a  flexible  financing structure so as to be able to take advantage of new investment opportunities that may arise.


## 37. FINANCIAL INSTRUMENTS

Financial risk management objectives

Financial  instruments  are  fundamental  to  the  Group's  daily  operations.  The  Group's  major  financial instruments  include  deposit  paid  for  decommissioning  obligation,  debt  instruments  at  FVTOCI,  trade and other receivables, loan and interest receivables, financial assets at FVTPL, cash and cash equivalents and trade and other payables and lease liabilities. Details of these financial instruments are disclosed in the respective notes. The risks associated with the financial instruments and the policies on how to mitigate  these  risks  are  set  out  below.  The  management  of  the  Group  manages  and  monitors  these exposures to ensure appropriate measures are implemented on a timely and effective manner.

---

# Page 157

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)


## Categories of financial instruments


|                                    | 2022 HK$'000   | 2021 HK$'000   |
|------------------------------------|----------------|----------------|
| Financial assets                   |                |                |
| Financial assets at FVTPL          | 4,772          | 6,724          |
| Financial assets at amortised cost | 162,594        | 307,959        |
| Debt instruments at FVTOCI         | 33,739         | 78,396         |
| Financial liabilities              |                |                |
| Amortised cost                     | 17,624         | 8,070          |
| Lease liabilities                  | 2,725          | 4,394          |



## Interest rate risk

The Group is exposed to fair value interest  rate  risk  in  relation  to  loan  and  interest  receivables,  debt instruments  at  FVTOCI  and  lease  liabilities.  The  Group  is  also  exposed  to  cash  flow  interest  rate  risk relates primarily to the Group's short-term deposits placed with banks and variable-rate bank balances that  are  interest-bearing  at  market  interest  rates.  The  Group  currently  does  not  have  an  interest  rate hedging policy. However, the management monitors interest rate exposure and will consider hedging significant interest rate exposure should the need arise.


Total interest revenue/income from financial assets that are measured at amortised cost or at FVTOCI is as follows:
|                                                         | 2022 HK$'000   | 2021 HK$'000   |
|---------------------------------------------------------|----------------|----------------|
| Interest revenue                                        |                |                |
| Financial assets at amortised cost                      | 3,877          | 13,182         |
| Debt instruments at FVTOCI                              | 3,605          | 8,871          |
| Other income and losses, net                            |                |                |
| Financial assets at amortised cost                      | 1,343          | 83             |
| Revenue/interest income under effective interest method | 8,825          | 22,136         |

---

# Page 158

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)


## Interest rate risk (continued)

The Group's sensitivity to interest rate risk has been determined based on the exposure to interest rates for bank balances at the end of the reporting period and the reasonably possible change taking place at the beginning of each year and held constant throughout the year. If interest rates on bank balances had been 50 basis points higher/lower and all other variables were held constant, loss after tax for the year  ended  31  December  2022  would  decrease/increase  by  HK$429,000  (2021:  decrease/increase  by HK$959,000).


## Foreign currency risk management

Several  subsidiaries  of  the  Company  have  assets  and  liabilities  denominated  in  foreign  currencies which  expose  the  Group  to  foreign  currency  risk.  During  the  year  under  review,  the  Group  had  not experienced any significant exchange rate exposure to US$ as HK$ and US$ exchange rate is pegged. Besides, the Group continuously monitors foreign exchange exposure of C$ and RMB and will consider a formal foreign currency hedging policy for it should the needs arise. The Group currently does not have a formal foreign currency hedging policy for C$, however, the management regularly monitors foreign exchange exposure of C$ and will undertake appropriate hedging measures should significant exposure arise.


The  carrying  amounts  of  the  group  entities'  foreign  currency  denominated  monetary  assets  and monetary liabilities, at the reporting date, are as follows:
|     | Assets       | Assets       | Liabilities   | Liabilities   |
|-----|--------------|--------------|---------------|---------------|
|     | 2022 HK$'000 | 2021 HK$'000 | 2022 HK$'000  | 2021 HK$'000  |
| ARS | -            | 24           | -             | (1,924)       |
| C$  | 31           | 11           | -             | -             |
| US$ | 35,601       | 110,342      | -             | -             |
| RMB | 11           | 11           | -             | -             |

---

# Page 159

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)


## Foreign currency risk management (continued)


## Foreign currency sensitivity

The  following  table  details  the  Group's  sensitivity  to  10%  increase  and  decrease  in  HK$  against  the relevant foreign currencies. Under the pegged exchange rate system, the financial impact on exchange difference between HK$ and US$ will be immaterial as most US$ denominated monetary assets are held by group entities having HK$ as their functional currency, and therefore no sensitivity analysis has been prepared against US$.

Sensitivity  rate  of  10%  is  used  when  reporting  foreign  currency  risk  internally  to  key  management personnel  and  represents  management's  assessment  of  the  reasonably  possible  change  in  foreign exchange  rates.  The  sensitivity  analysis  includes  only  outstanding  foreign  currency  denominated monetary items and adjusts their translation at the year end for a 10% change in foreign currency rates. The analysis represents the sensitivity of  trade  and  other  receivables,  bank  balances,  trade  and  other payables  and  lease  liabilities  that  are  denominated  in  ARS,  RMB  and  C$,  the  Group's  major  foreign currency  items.  A  positive  number  below  indicates  an  increase  in  loss  after  tax  whereas  a  negative number below indicates a decrease in loss after tax where Hong Kong dollars strengthen 10% against the  relevant  currencies.  For  a  10%  (2021:  10%)  weakening  of  Hong  Kong  dollars  against  the  relevant currencies, there would be an equal and opposite impact on the loss after tax.


|                            | 2022 HK$'000   | 2021 HK$'000   |
|----------------------------|----------------|----------------|
| ARS impact                 |                |                |
| Decrease in loss after tax | -              | (133)          |
| C$ impact                  |                |                |
| Increase in loss after tax | 2              | 1              |
| RMB impact                 |                |                |
| Increase in loss after tax | 1              | 1              |


In  management's  opinion,  the  sensitivity  analysis  reflects  the  exposure  at  the  year  end,  but  not  the exposure during the year.

---

# Page 160

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)


## Other price risk

The Group is exposed to price risk from investments in listed equity securities and listed debt securities. The management manages this exposure by maintaining a portfolio of investments with different risk profiles.


## Sensitivity analysis


## Financial assets at FVTPL

The sensitivity analysis below has been determined based on the exposure to equity price risk at the reporting date.

If equity prices had been 20% higher/lower, loss after tax for the year ended 31 December 2022 would decrease/increase by HK$797,000 (2021: loss after tax would decrease/increase by HK$1,123,000) as a result of the change in fair value of financial assets at FVTPL.


## Credit risk and impairment assessment

Credit  risk  refers  to  the  risk  that  the  Group's  counterparties  default  on  their  contractual  obligations resulting  in  financial  losses  to  the  Group.  The  Group's  credit  risk  exposures  are  primarily  attributable to  trade  and  other  receivables,  loan  and  interest  receivables,  cash  and  cash  equivalents  and  debt instruments at FVTOCI. The Group does not hold any collateral or other credit enhancements to cover its  credit  risks  associated  with  its  financial  assets,  except  that  the  credit  risks  associated  with  certain loan and interest receivables are mitigated because they are secured by collaterals.

---

# Page 161

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)

Credit risk and impairment assessment (continued)


The Group's internal credit risk grading assessment comprises the following categories:
| Internal  credit rating   | Description                                                                                                                                      | Trade Receivables                   | Financial assets  other than trade  receivables   |
|---------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------|---------------------------------------------------|
| Low risk                  | The counterparty has a low risk of default  and does not have any past due amounts                                                               | Lifetime ECL -  not credit-impaired | 12m ECL                                           |
| Medium risk               | Debtor frequently settles after due dates                                                                                                        | Lifetime ECL -  not credit-impaired | 12m ECL                                           |
| High risk                 | There have been significant increases in  credit risk since initial recognition through  information developed internally or external            | Lifetime ECL -  not credit-impaired | Lifetime ECL -  not credit-impaired               |
| Loss                      | There is evidence indicating that the asset is  credit-impaired                                                                                  | Lifetime ECL -  credit-impaired     | Lifetime ECL -  credit-impaired                   |
| Write-off                 | There is evidence indicating that the debtor  is in severe financial difficulty and the Group  written off has no realistic prospect of recovery | Amount is                           | Amount is written off                             |

---

# Page 162

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)

Credit risk and impairment assessment (continued)


The table below details the credit risk exposures of the Group's financial assets, which are subject to ECL assessment:
|                                    | Notes   | External  credit rating   | Internal  credit rating   | 12m or  lifetime ECL          | 2022  Gross  carrying  amount/ fair value HK$'000   | 2021  Gross  carrying  amount/ fair value HK$'000   |
|------------------------------------|---------|---------------------------|---------------------------|-------------------------------|-----------------------------------------------------|-----------------------------------------------------|
| Debt instruments at FVTOCI         |         |                           |                           |                               |                                                     |                                                     |
| Investments in listed bonds        | 21      | BB+                       | Low risk                  | 12m ECL                       | -                                                   | 15,675                                              |
|                                    |         | B- to RD                  | High risk                 | Lifetime ECL                  | 31,558                                              | 57,640                                              |
|                                    |         | WD (2021: RD)             | Loss                      | Lifetime ECL-credit  impaired | 2,181                                               | 5,081                                               |
| Financial assets at amortised cost |         |                           |                           |                               |                                                     |                                                     |
| Loan and interest receivables      | 22      | N/A                       | Medium risk               | 12m ECL                       | 15,025                                              | 15,025                                              |
|                                    |         |                           | Loss                      | Lifetime ECL-credit  impaired | 69,627                                              | 134,891                                             |
| Other receivables and deposits     | 20      | N/A                       | (Note (i))                | 12m ECL                       | 10,713                                              | 946                                                 |
|                                    |         |                           | Write off                 | Lifetime ECL-credit  impaired | -                                                   | 1,680                                               |
| Trade receivables                  | 20      | N/A                       | (Note (ii))               | Lifetime ECL                  | 5,232                                               | 194                                                 |
| Cash and cash equivalents          | 25      | BBB- to AA                | N/A                       | 12m ECL                       | 85,750                                              | 191,797                                             |
Notes:
(i) For  the  purpose  of  internal  credit  assessment,  the  Group  assesses  whether  credit  risk  has  increased significantly  since  initial  recognition  based  on  the  financial  background,  financial  condition  and  historical settlement records of the counterparties, and both the quantitative and qualitative information including reasonable and supportive forward-looking information available without undue cost or effort.
(ii) The  Group  has  applied  the  simplified  approach  in  HKFRS  9  to  measure  the  loss  allowance  for  trade receivables on lifetime ECL basis.

---

# Page 163

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)


## Credit risk and impairment assessment (continued)

Trade receivables

At 31 December 2022, the Group had concentration of credit risk for its trade receivables as 100% (2021: 100%) of the amount was attributable to the Group's two trading customers in Canada (2021: nil) and one customer in Hong Kong (2021: one customer in Hong Kong) and they contributed to 86% (2021: 3%) of the Group's revenue. However, since the trade receivables are due from reputable oil distributors in Canada with good settlement history and a major electrical power company (2021: a major electrical power company) in Hong Kong of good creditability, the management considers that the Group's credit risk is low and ECL is minimal at 31 December 2022 and 2021.


## Other receivables and deposits

For  other  receivables  and  deposits,  the  management  assessed  individually  on  the  recoverability  of other  receivables  and  deposits  based  on  the  financial  background,  financial  condition  and  historical settlement records of the debtors, and also quantitative and qualitative information that is reasonable and  supportive  forward-looking  information.  The  management  believes  that  there  are  no  significant increase  in  credit  risk  of  other  receivables  and  deposits  of  HK$10,713,000  (2021:  HK$946,000)  since initial  recognition  and  the  Group  performs  impairment  assessment  based  on  12m  ECL.  For  the  year ended  31  December  2022  and  2021,  the  Group  assessed  the  ECL  for  these  other  receivables  and deposits as insignificant and thus no loss allowance is recognised.

During the year ended 31 December 2021, the management considered that the counterparty of the deposits  held  for  the  petroleum  exploration  and  production  business  in  Argentina  was  in  financial difficulty since initial recognition and thus the amount of HK$1,680,000 was written-off.


## Loan and interest receivables

At 31 December 2022, the carrying amount of loan and interest receivables was HK$60,852,000 (2021: HK$115,001,000).  The  Group  had  concentration  of  credit  risk  for  its  loan  and  interest  receivables as  100%  (2021:  100%)  of  the  carrying  amount  at  31  December  2022  was  due  from  four  (2021:  five) borrowers which amounted to HK$60,852,000 (2021: HK$115,001,000) at 31 December 2022, and the loan made to the largest borrower amounted to HK$23,808,000 (2021: HK$37,090,000) which accounted for 39% (2021: 32%) of the Group's loan portfolio (on a net of impairment allowance basis). The Group seeks to maintain strict control over its outstanding loan and interest receivables to minimise credit risk. The management has a credit policy in place and the exposures to the credit risk are monitored on an ongoing basis.

---

# Page 164

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)


## Credit risk and impairment assessment (continued)

Loan and interest receivables (continued)

The recoverability of outstanding loan and interest receivables are determined by an evaluation of the financial  background,  financial  condition  and  historical  settlement  records,  including  past  due  rates and default rates of the borrowers and reasonable and supportable forward-looking information (such as forecast of macroeconomic factors including GDP growth and unemployment rate with adjustment on  different  scenarios  of  economic  environment  prospect)  that  is  available  without  undue  cost  or effort at the end of each reporting period. The borrowers are assigned with different risk grading under internal  credit  ratings  to  calculate  the  ECL,  taking  into  consideration  the  estimates  of  expected  cash shortfalls  which  are  driven  by  estimates  of  possibility  of  default  and  the  expected  loss  given  default including taking into account the amount and timing of cash flows that are expected from foreclosure on the collaterals (if any) less the costs of selling the collaterals. Owing to the great financial uncertainty triggered by the COVID epidemic, the Group has increased the expected loss rates in the current year as  there  is  a  high  risk  that  a  prolonged  pandemic  could  lead  to  increased  credit  default  rates.  The collaterals pledged to the Group in relation to outstanding loans comprise properties and unlisted debt instruments issued by a listed company in Hong Kong with the estimated fair value of the collaterals are lower than the related loan balances individually.

At 31 December 2022, included in the Group's loan and interest receivables balance were debtors with aggregate gross carrying amount of HK$69,590,000 (2021: HK$92,344,000) which were past due as at the reporting date, of which (i) nil (2021: HK$34,134,000) had been past due for less than 30 days; (ii) HK$12,500,000  (2021:  HK$537,000)  had  been  past  due  for  more  than  30  days  but  less  than  90  days; and  (iii)  HK$57,090,000  (2021:  HK$57,673,000)  had  been  past  due  for  90  days  or  more.  Details  of  the cumulative ECL provided are set out in Note 22.


## Debt instruments at FVTOCI

At  31  December 2022, the carrying amount of debt instruments at FVTOCI was HK$33,739,000 (2021: HK$78,396,000).  The  Group  had  concentration  of  credit  risk  for  its  debt  instruments  at  FVTOCI  as 94%  (2021:  78%)  of  the  carrying  amount  at  31  December  2022  was  due  from  four  (2021:  four)  debt instruments at FVTOCI which amounted to HK$31,557,000 (2021: HK$61,519,000) at 31 December 2022.

During the year ended 31 December 2022, provision of ECL on debt instruments at FVTOCI amounting to  HK$11,081,000  (2021:  HK$49,247,000)  was  recognised  in  profit  or  loss  with  corresponding adjustment  to  other  comprehensive  income.  At  31  December  2022,  the  cumulative  impairment allowance for debt instruments at FVTOCI amounted to HK$67,432,000 (2021: HK$56,351,000).

---

# Page 165

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)


## Credit risk and impairment assessment (continued)

Debt instruments at FVTOCI (continued)

The Group's debt instruments at FVTOCI mainly comprise instruments that have, on an individual basis, a commensurate level of risk of default when comparing to its rate of return in terms of coupon interest given that the counterparty has a stable capacity to repay. The Group assesses the financial strengths and  performance  of  the  issuers  in  satisfying  the  repayment  of  principal  and  interest  of  the  debt instruments as they fall due. The Group also closely monitors the changes in credit ratings of the issuers and follows their market news for taking immediate actions if there is an indication of a deterioration of the repayment ability of the issuers.

The  Group  determines  individually  whether  the  issuers  of  the  debt  instruments  have  been  suffered from significant increase in credit risk since initial recognition by comparing the credit rating and other qualitative benchmarks that affect the credit quality of the issuers at initial recognition and at the end of  the  reporting  period.  At  31  December  2022,  included  in  the  Group's  debt  instruments  of  carrying amount of HK$33,739,000 (2021: HK$78,396,000), debt instruments of (i) nil (2021: HK$15,675,000) were assessed under 12m ECL, due to low credit risk; (ii) HK$31,558,000 (2021: HK$57,640,000) were assessed under lifetime ECL (not credit impaired), due to significant deterioration in the internal credit rating and adverse change in the business of the issuer during the reporting period; and (iii) HK$2,181,000 (2021: HK$5,081,000)  were  assessed  under  lifetime  ECL  (credit  impaired),  as  certain  issuers  are  engaging  in businesses that are unstable and are in significant financial difficulties.

The Group had engaged an independent professional valuer to perform ECL assessment on the debt instruments  and  the  Company's  management  worked  closely  with  the  qualified  external  valuer  to establish the appropriate valuation techniques and inputs to the model. In making that evaluation, the Group assessed the ECL for debt instruments at FVTOCI by reference to the credit rating of the debt instruments estimated by the recognised rating agency (i.e. Moody's, Fitch), the macroeconomic factors affecting  each  issuer,  and  the  probability  of  default  and  loss  given  default  of  each  debt  instrument. The  Group  also  took  into  account  forward-looking  information  that  was  reasonably  and  supportably available to the Group without undue cost or effort, including information such as GDP growth rate and unemployment rate.

---

# Page 166

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)


## Credit risk and impairment assessment (continued)

Debt instruments at FVTOCI (continued)


|                                                                          | Lifetime ECL Lifetime ECL   | Lifetime ECL Lifetime ECL       | Lifetime ECL Lifetime ECL   | Lifetime ECL Lifetime ECL   |
|--------------------------------------------------------------------------|-----------------------------|---------------------------------|-----------------------------|-----------------------------|
|                                                                          | 12m ECL HK$'000             | (not credit-  impaired) HK$'000 | (credit-  impaired) HK$'000 | Total HK$'000               |
| At 1 January 2021                                                        | 7,104                       | -                               | -                           | 7,104                       |
| Changes due to debt instruments at FVTOCI  recognised at 1 January 2021: |                             |                                 |                             |                             |
| - Transferred to lifetime ECL  (Note (i))                                | (6,588)                     | 3,281                           | 3,307                       | -                           |
| - Impairment allowance reversed  (Note (ii))                             | (434)                       | -                               | -                           | (434)                       |
| - Impairment allowance recognised                                        | -                           | 15,967                          | 33,714                      | 49,681                      |
| At 31 December 2021                                                      | 82                          | 19,248                          | 37,021                      | 56,351                      |
| Changes due to debt instruments at FVTOCI  recognised at 1 January 2022: |                             |                                 |                             |                             |
| -  Impairment allowance reversed  (Note (iii))                           | (82)                        | (3,229)                         | -                           | (3,311)                     |
| -    Impairment allowance recognised  (Note (iv))                        | -                           | 11,492                          | 2,900                       | 14,392                      |
| At 31 December 2022                                                      | -                           | 27,511                          | 39,921                      | 67,432                      |



## Notes:

(i) The impairment losses of HK$6,588,000 was transferred from 12m ECL to lifetime ECL (not credit-impaired) and  lifetime  ECL  (credit-impaired)  with  debt  instruments  of  carrying  amount  of  HK$57,640,000  and HK$5,081,000 respectively.

(ii) The  impairment  allowance  reversed  of  HK$434,000  was  attributed  to  the  decrease  in  credit  risk  of  debt instrument with carrying amount of HK$15,675,000.

(iii) The impairment allowance reversed of HK$82,000 and HK$3,229,000 was attributed to the derecognition of debt instruments with carrying amount of HK$15,675,000 and HK$12,763,000 respectively.


- (iv) The  impairment  allowance  of  HK$11,492,000  was  recognised  under  lifetime  ECL  (not  credit-impaired)  as the issuer of the corresponding debt instruments continued to suffer from further deterioration in business conditions during the year, and impairment allowance of HK$2,900,000 was recognised under lifetime ECL (credit-impaired)  as  the  issuer  of  the  corresponding  debt  instruments  continued  to  engage  in  businesses that are unstable and are in significant financial difficulties.

---

# Page 167

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)


## Liquidity risk

Liquidity  risk  reflects  the  risk  that  the  Group  will  have  insufficient  resources  to  meet  its  financial liabilities as they fall due. In managing liquidity risk, the Group monitors and maintains sufficient funds to meet all its potential liabilities as they fall due, including shareholder distributions. It is applicable to normal market conditions as well as negative projections against expected outcomes, so as to avoid any risk of incurring contractual penalties or damaging the Group's reputation.

The following table details the Group's remaining contractual maturity for its financial liabilities based on the agreed repayment terms.

For  non-derivative  financial  liabilities,  the  table  has  been  drawn  up  based  on  the  undiscounted  cash flows of financial liabilities based on the earliest date on which the Group can be required to pay. The table includes both interest and principal cash flows. To the extent that interest flows are floating rate, the undiscounted amount is derived from interest in effect at the end of the reporting period.


## Liquidity table


|                                      | Weighted  average  interest rate %   | On demand  or less than  1 month HK$'000   | 1 to 6 months HK$'000   | 7 months to  1 year HK$'000   | Over 1 year HK$'000   | Total  undiscounted  cash flows HK$'000   | Carrying  amount HK$'000   |
|--------------------------------------|--------------------------------------|--------------------------------------------|-------------------------|-------------------------------|-----------------------|-------------------------------------------|----------------------------|
| At 31 December 2022                  |                                      |                                            |                         |                               |                       |                                           |                            |
| Non-derivative financial liabilities |                                      |                                            |                         |                               |                       |                                           |                            |
| Other payables                       | -                                    | 17,624                                     | -                       | -                             | -                     | 17,624                                    | 17,624                     |
| Lease liabilities                    | 3.41                                 | 187                                        | 116                     | 139                           | 2,782                 | 3,224                                     | 2,725                      |
|                                      |                                      | 17,811                                     | 116                     | 139                           | 2,782                 | 20,848                                    | 20,349                     |
| At 31 December 2021                  |                                      |                                            |                         |                               |                       |                                           |                            |
| Non-derivative financial liabilities |                                      |                                            |                         |                               |                       |                                           |                            |
| Trade payables                       | -                                    | 129                                        | -                       | -                             | -                     | 129                                       | 129                        |
| Other payables                       | -                                    | 7,941                                      | -                       | -                             | -                     | 7,941                                     | 7,941                      |
|                                      |                                      | 8,070                                      | -                       | -                             | -                     | 8,070                                     | 8,070                      |
| Lease liabilities                    | 3.41                                 | 141                                        | 706                     | 847                           | 3,387                 | 5,081                                     | 4,394                      |
|                                      |                                      | 8,211                                      | 706                     | 847                           | 3,387                 | 13,151                                    | 12,464                     |

---

# Page 168

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 37. FINANCIAL INSTRUMENTS (continued)


## Fair value measurements of financial instruments

Fair value of the Group's financial assets that are measured at fair value on a recurring basis

Some of the  Group's  financial  assets  are  measured  at  fair  value  at  the  end  of  each  reporting  period. The following table gives information about how fair values of these financial assets are determined (in particular, the valuation technique(s) and inputs used).


|                            | Fair value   | Fair value   | Fair value  hierarchy   | Valuation technique(s)  and key input(s)   |
|----------------------------|--------------|--------------|-------------------------|--------------------------------------------|
|                            | 2022         | 2021         |                         |                                            |
|                            | HK$'000      | HK$'000      |                         |                                            |
| Financial assets           |              |              |                         |                                            |
| Debt instruments at FVTOCI |              |              |                         |                                            |
| Listed debt securities     | -            | 33,259       | Level 1                 | Quoted bid prices in                       |
|                            |              |              |                         | active markets                             |
|                            | 33,739       | 45,137       | Level 2                 | Quoted bid prices with                     |
|                            |              |              |                         | credit risk adjustment                     |
| Listed equity securities   |              |              |                         |                                            |
|                            | 4,772        | 6,724        | Level 1                 | Quoted bid prices in                       |
|                            |              |              |                         | an active market                           |


There were no transfers among Level 1, 2 and 3 of fair value hierarchy in the current and prior years.

Fair value of the Group's financial assets and financial liabilities that are not measured at fair value on a recurring basis

The directors consider that the carrying amounts of financial assets and financial liabilities at amortised cost recognised in the consolidated financial statements approximate to their fair values.

---

# Page 169

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 38. PARTICULARS OF PRINCIPAL SUBSIDIARIES


Details of the Company's principal subsidiaries, which are limited liability companies, at 31 December 2022 and 2021, are as follows:
| Name of subsidiary                                                                                                                                | Place of incorporation/ operations   | Nominal value of  issued and  fully paid  ordinary share/ registered capital   | Attributable proportion of  nominal value of issued/registered  capital held by the Company   | Attributable proportion of  nominal value of issued/registered  capital held by the Company   | Principal activities                     |
|---------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------|--------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|------------------------------------------|
| EPI Energy Investments Limited                                                                                                                    | Hong Kong                            | HK$1 (2021: HK$1)                                                              | -                                                                                             | 100%  (2021: 100%)                                                                            | Sales of electricity                     |
| Have Result Finance Limited                                                                                                                       | Hong Kong                            | HK$100 (2021: HK$100)                                                          | -                                                                                             | 100%  (2021: 100%)                                                                            | Money lending                            |
| EPI Management Limited                                                                                                                            | Hong Kong                            | HK$1 (2021: HK$1)                                                              | -                                                                                             | 100%  (2021: 100%)                                                                            | Investment in securities and  management |
| Xiamen Mega Link Hengtian Zhichuang  Investment Management Partners  Corporation (Limited Partnership)   (literal translation of its Chinese name | The PRC                              | N/A (2021: RMB60,824,578)                                                      | -                                                                                             | N/A  (2021: 100%)                                                                             | Investment holding and  money lending    |
| EP Resources Corporation ( Note (iii))                                                                                                            | Canada                               | C$10,560,001                                                                   | -                                                                                             | 100%                                                                                          | Petroleum exploration and  production    |



## Notes:

(i) Incorporated as unincorporated business (limited partnership).

(ii) During the year ended 31 December 2022, the company was disposed of.

(iii) Incorporated on 5 January 2022.

The  above  table  lists  the  subsidiaries  of  the  Group  which,  in  the  opinion  of  the  directors,  principally affected  the  results  of  the  Group.  To  give  details  of  other  insignificant  subsidiaries  which  are  mainly inactive or engaged in investment holding would, in the opinion of the directors, result in particulars of excessive length.

None  of  the  subsidiaries  had  any  debt  securities  outstanding  at  the  end  of  the  year,  or  at  any  time during the year.

---

# Page 170

# Notes to the Consolidated Financial Statements

For the year ended 31 December 2022


## 39. CAPITAL COMMITMENTS

At  31  December  2022,  the  Group  had  a  total  capital  commitment  of  HK$6,978,000  for  acquisition of  solar  photovoltaic  systems  which  was  capital  expenditure  contracted  for  but  not  provided  in  the consolidated financial statements.


## 40. STATEMENT OF FINANCIAL POSITION OF THE COMPANY


|                                            | 2022 HK$'000   | 2021 HK$'000   |
|--------------------------------------------|----------------|----------------|
| Non-current assets                         |                |                |
| Unlisted interests in subsidiaries         | -*             | -*             |
| Loan to a subsidiary                       | 99,571         | -              |
| Amounts due from subsidiaries              | 48,408         | 35,210         |
| Total non-current assets                   | 147,979        | 35,210         |
| Current assets                             |                |                |
| Other receivables, prepayment and deposits | 7,000          | 468            |
| Tax recoverable                            | 146            | -              |
| Amounts due from subsidiaries              | 111,037        | 198,758        |
| Cash and cash equivalents                  | 58,715         | 171,712        |
| Total current assets                       | 176,898        | 370,938        |
| Current liabilities                        |                |                |
| Other payables                             | 2,028          | 2,438          |
| Amounts due to subsidiaries                | 6,221          | 6,630          |
| Tax payable                                | 618            | 146            |
| Total current liabilities                  | 8,867          | 9,214          |
| Net current assets                         | 168,031        | 361,724        |
| Total assets less current liabilities      | 316,010        | 396,934        |
| Capital and reserves                       |                |                |
| Share capital                              | 52,403         | 52,403         |
| Reserves  (Note)                           | 263,607        | 344,531        |
| Total equity                               | 316,010        | 396,934        |
* The amount of investment in subsidiaries is less than HK$1,000.

---

# Page 171

# Notes to the Consolidated Financial Statements For the year ended 31 December 2022


## 40. STATEMENT OF FINANCIAL POSITION OF THE COMPANY (continued)

Note:


Movements of the Company's reserves are as follows:
|                                       | Share  premium HK$'000   | Share options  reserve HK$'000   | Accumulated  losses HK$'000   | Total HK$'000   |
|---------------------------------------|--------------------------|----------------------------------|-------------------------------|-----------------|
| At 1 January 2021                     | 918,270                  | 201,645                          | (780,201)                     | 339,714         |
| Profit and total comprehensive income |                          |                                  |                               |                 |
| for the year                          | -                        | -                                | 4,817                         | 4,817           |
| At 31 December 2021                   | 918,270                  | 201,645                          | (775,384)                     | 344,531         |
| Loss and total comprehensive expense  |                          |                                  |                               |                 |
| for the year                          | -                        | -                                | (80,924)                      | (80,924)        |
| At 31 December 2022                   | 918,270                  | 201,645                          | (856,308)                     | 263,607         |

---

# Page 172

# Five-Year Financial Summary

For the year ended 31 December 2022


## RESULTS


|                             | For the year ended 31 December   | For the year ended 31 December   | For the year ended 31 December   | For the year ended 31 December   | For the year ended 31 December   |
|-----------------------------|----------------------------------|----------------------------------|----------------------------------|----------------------------------|----------------------------------|
|                             | 2022 HK$'000                     | 2021 HK$'000                     | 2020 HK$'000                     | 2019 HK$'000                     | 2018 HK$'000                     |
| Revenue                     | 45,102                           | 24,496                           | 42,449                           | 60,560                           | 71,419                           |
| (Loss) profit before tax    | (46,957)                         | (31,626)                         | 8,578                            | (137,327)                        | (115,087)                        |
| Income tax credit (expense) | 211                              | 2,255                            | (440)                            | (772)                            | (140)                            |
| (Loss) profit for the year  | (46,746)                         | (29,371)                         | 8,138                            | (138,099)                        | (115,227)                        |
| Attributable to:            |                                  |                                  |                                  |                                  |                                  |
| Owners of the Company       | (46,746)                         | (29,371)                         | 8,519                            | (138,099)                        | (115,227)                        |
| Non-controlling interests   | -                                | -                                | (381)                            | -                                | -                                |
|                             | (46,746)                         | (29,371)                         | 8,138                            | (138,099)                        | (115,227)                        |



## ASSETS AND LIABILITIES


|                                                | At 31 December   | At 31 December   | At 31 December   | At 31 December   | At 31 December   |
|------------------------------------------------|------------------|------------------|------------------|------------------|------------------|
|                                                | 2022 HK$'000     | 2021 HK$'000     | 2020 HK$'000     | 2019 HK$'000     | 2018 HK$'000     |
| Total assets                                   | 433,689          | 442,915          | 475,763          | 469,264          | 599,667          |
| Total liabilities                              | (57,376)         | (16,925)         | (16,265)         | (25,368)         | (24,614)         |
| Equity attributable to owners   of the Company | 376,313          | 425,990          | 459,498          | 443,896          | 575,053          |
| Attributable to:                               |                  |                  |                  |                  |                  |
| Owners of the Company                          | 376,313          | 425,990          | 459,879          | 443,896          | 575,053          |
| Non-controlling interests                      | -                | -                | (381)            | -                | -                |
|                                                | 376,313          | 425,990          | 459,498          | 443,896          | 575,053          |